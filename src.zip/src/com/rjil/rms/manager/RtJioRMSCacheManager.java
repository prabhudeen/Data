package com.rjil.rms.manager;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.atom.OAM.Client.Management.OamClientManager;
import com.atom.OAM.Client.Management.OamClientRegistrationNotifier;
import com.atom.OAM.Client.util.OamClientConstants;
import com.jio.resttalk.service.impl.RestTalkManager;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeBuilder;
import com.jio.telco.framework.clearcode.MSName;
import com.jio.telco.framework.jetty.JettyBuilder;
import com.jio.telco.framework.pool.PoolingManager;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.clearcode.RMRAsnCallBackIntfImpl;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.cnf.fcaps.RMSDownloadCNFFCAPSFileHandler;
import com.rjil.rms.cnf.fcaps.RtJioRMRCNFDictTemplateDownload;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.erm.RMRERMManager;
import com.rjil.rms.es.erm.RMRERMPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioAlarmConditionalCntrListener;
import com.rjil.rms.management.alarms.RtJioAlarmLoggingListener;
import com.rjil.rms.management.alarms.RtJioRMSMemoryOverflowListener;
import com.rjil.rms.management.counters.RtJioRMSCounterManager;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.management.params.RtJioRMSConfigurationManager;
import com.rjil.rms.management.params.RtJioRMSExcelWorkbookLoader;
import com.rjil.rms.rest.handlers.RMSEventHandler;
import com.rjil.rms.rest.handlers.RtJioRMSAlarmContextHandler;
import com.rjil.rms.rest.handlers.RtJioRMSBroadcastContextHandler;
import com.rjil.rms.rest.handlers.RtJioRMSCLIHandler;
import com.rjil.rms.rest.handlers.RtJioRMSConfigContextHandler;
import com.rjil.rms.rest.handlers.RtJioRMSCounterContextHandler;
import com.rjil.rms.startup.RMSShutDownHook;
import com.rjil.rms.statistics.RTJioRMSStatisticsManager;
import com.rjil.rms.sync.request.RtJioRMRDictTemplateDownload;
import com.rjil.rms.sync.request.RtJioRMRFileUploaderContextHandler;
import com.rjil.rms.sync.request.RtJioRMSFileDownloaderContextHandler;
import com.rjil.rms.ui.metadata.MetadataManager;
import com.rjil.rms.util.RTJioRMSConstants;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioRMSRegistrationOAMObserver;

/**
 * 
 * This Class provide configuration manager and all module is initialised in
 * this class
 * 
 * @author Kiran.Jangid
 *
 */

public class RtJioRMSCacheManager {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final RtJioRMSCacheManager instance = new RtJioRMSCacheManager();
	private RtJioRMSThreadPoolExecutor threadPoolExecutor;
	private RtJioRMSExcelWorkbookLoader excelWorkbookLoader;
	private RtJioRMSRegistrationOAMObserver oamRegistrationObserver;
	private RtJioRMSConfigurationManager configurationManager;
	private RtJioRMSCounterManager counterManager;
	private String microserviceId;
	private int processId;
	private ExecutorService executorService = Executors.newFixedThreadPool(10);
	private List<String> elbComponentIds = new ArrayList<>();
	private List<RMRERMPojo> ermELBList = new ArrayList<>();
	private RMRERMManager ermManager = new RMRERMManager();

	private RTJioRMSStatisticsManager statisticsManager;
	private boolean jettystatus;
	private boolean registeredToOam;

	private boolean elasticdbConnected;

	private String timestamp;
	private String hostName;

	/**
	 * @return the singleton instance of RTJioRMSCacheManager class
	 */
	public static RtJioRMSCacheManager getInstance() {
		return instance;
	}

	/**
	 * 
	 * @return
	 */

	public List<String> getElbComponentIds() {
		return elbComponentIds;
	}

	/**
	 * 
	 * @return
	 */

	public RMRERMManager getErmManager() {
		return ermManager;
	}

	/**
	 * This method initializes ThreadPoolExecutor during executors
	 */
	public void initThreadPoolExecutor() {
		try {
			threadPoolExecutor = new RtJioRMSThreadPoolExecutor(RtJioRMSConfigParamEnum.CORE_POOL_SIZE.getIntValue(),
					RtJioRMSConfigParamEnum.MAXIMUM_POOL_SIZE.getIntValue(),
					RtJioRMSConfigParamEnum.KEEP_ALIVE_TIME.getIntValue(), TimeUnit.MILLISECONDS,
					new LinkedBlockingQueue<Runnable>());
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initThreadPoolExecutor", "initialize thread pool error", e);
		}
	}

	/**
	 * initializes and loads the excel workbook in memory
	 */
	public void initExcelWorkbookLoader() {

		try {
			this.excelWorkbookLoader = new RtJioRMSExcelWorkbookLoader();
			this.excelWorkbookLoader.initialize();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initExcelWorkbookLoader", "initialize excel loader error", e);
		}

	}

	/**
	 * initializes and loads the excel workbook in memory
	 */
	public void initErmManager() {
		this.ermManager = new RMRERMManager();
	}

	/**
	 * This method initialises the logging manager for debugging purpose
	 */
	public void initLoggingConfiguration() {
		try {

			setMicroserviceId(
					OamClientManager.getInstance().readOamClientConfig(RTJioRMSConstants.OAM_CONFIG_FILE_PATH));

			setProcessId(RtJioCommonMethods.generateProcessId());

			LoggerWriter.getInstance().initializeLogger(getMicroserviceId(),
					RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue(), Integer.toString(getProcessId()),
					RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue(),
					RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue(),
					RtJioRMSConfigParamEnum.MAX_LOG_FILE_SIZE.getIntValue(),
					RtJioRMSConfigParamEnum.MAX_LOG_BACKUP_INDEX.getIntValue(),
					RtJioRMSConfigParamEnum.TOTAL_LOGS_FILE_SIZE.getIntValue(),
					RtJioRMSConfigParamEnum.EXPIRE_TIME_FOR_LOGS_FILES.getIntValue()
					);

			LoggerWriter.getInstance().changeLogPath(RtJioRMSConfigParamEnum.LOG_FILE_PATH.getStringValue());
			LoggerWriter.getInstance().setLogLevel(RtJioRMSConfigParamEnum.APPLICATION_LOG_LEVEL.getStringValue());

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initLoggingConfiguration", "initialize logger error", e);
		}

	}

	/**
	 * initializes the configuration manager to load all the configurations at
	 * startup
	 */
	public void initConfigurationManager() {
		try {
			this.configurationManager = new RtJioRMSConfigurationManager();
			this.configurationManager.start();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initConfigurationManager", "initialize Configuration Manager error", e);
		}

	}

	/**
	 * initializes the performance counter manager
	 */
	public void initCounterManager() {
		try {
			this.counterManager = new RtJioRMSCounterManager();
			this.counterManager.startService();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initCounterManager", "initialize Counter Manager error", e);
		}

	}

	/**
	 * This method initializes the Rest-Talk manager for creating and sending
	 * http events
	 */
	public void initRestTalkManager() {
		RestTalkManager.getInstance().startRestTalk();
	}

	/**
	 * This method initializes the Jetty server (HTTP server) to receive and
	 * process events
	 */
	public void initJettyServer() {

		jettystatus = false;

		try {

			JettyBuilder jettyBuilder = ResourceBuilder.jetty();

			// check weather container is used or not, if not then it will assign IP from OAM
			if (!RtJioRMSConfigParamEnum.CONTAINERIZED_INTERFACE.getBooleanValue()) {
				jettyBuilder.setIP(OamClientManager.getInstance().getOAMClientParam(OamClientConstants.IP));
			}

			String portStr = OamClientManager.getInstance().getOAMClientParam(OamClientConstants.PORT);
			int port = Integer.parseInt(portStr);

			jettyBuilder.setPort(port).setMinThreadsForPool(RtJioRMSConfigParamEnum.MINIMUM_POOL_SIZE.getIntValue())
					.setMaxThreadsForPool(RtJioRMSConfigParamEnum.MAXIMUM_POOL_SIZE.getIntValue())
					.addHandler(RtJioRMSConfigParamEnum.RMR_ALARM_CONTEXT.getStringValue(),
							RtJioRMSAlarmContextHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_CONFIG_CONTEXT.getStringValue(),
							RtJioRMSConfigContextHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_COUNTER_CONTEXT.getStringValue(),
							RtJioRMSCounterContextHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_BROADCAST_CONTEXT.getStringValue(),
							RtJioRMSBroadcastContextHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_EVENT_CONTEXT.getStringValue(), RMSEventHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_CLI_CONTEXT.getStringValue(), RtJioRMSCLIHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_DICT_TEMPLATE_CONTEXT.getStringValue(),
							RtJioRMRDictTemplateDownload.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue(),
							RtJioRMSFileDownloaderContextHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_CNF_DOWNLOAD_SYNC_CONTEXT.getStringValue(),
							RMSDownloadCNFFCAPSFileHandler.class)
					.addHandler(RtJioRMSConfigParamEnum.RMR_FILE_UPLOADER_CONTEXT.getStringValue(),
							RtJioRMRFileUploaderContextHandler.class)
					.start();

			jettystatus = true;
		} catch (Exception e) {
			jettystatus = false;
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initJettyServer", "initialize Jetty Server Manager error", e);
		}

	}

	/**
	 * This method register the RMS application to OAM
	 */
	public void registerToOAM() {
		
		System.out.println("register ToOAM fucntion called.....");
		try {
			registeredToOam = false;
			this.oamRegistrationObserver = new RtJioRMSRegistrationOAMObserver(new RtJioAlarmLoggingListener(),
					new RtJioAlarmConditionalCntrListener(), new RtJioRMSMemoryOverflowListener());

			// set this in enum as well as config param sheet
			OamClientRegistrationNotifier.getInstance().addObserver(this.oamRegistrationObserver);

			Logger logger = LogManager.getLogger();

			OamClientManager.getInstance().initializeWithESTransportClient(logger,
					RTJioRMSConstants.OAM_CONFIG_FILE_PATH,
					this.oamRegistrationObserver.getAlarmLoggingCallbackHandler(),
					this.oamRegistrationObserver.getAlarmConditionCntrListener(), null,
					this.oamRegistrationObserver.getApplicationMemoryUsageListener(), false, null,
					EsManager.getInstance().getClient(),
					OamClientManager.getInstance().getOAMClientParam(OamClientConstants.ID),
					EsManager.getInstance().getProcessor());

			registeredToOam = true;

		} catch (Exception e) {
			registeredToOam = true;
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"registerToOAM", "initialize register To OAM error", e);
		}

	}

	/**
	 * @return
	 */
	public boolean deRegisterOAM() {

		registeredToOam = true;
		boolean returnValue = false;
		try {
			OamClientManager.getInstance().disconnect();

			registeredToOam = false;
			returnValue = true;

		} catch (Exception e) {

			registeredToOam = true;
			returnValue = false;
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deRegisterOAM", "deregister To OAM error", e);
		}

		return returnValue;
	}

	/**
	 * Initialise Shutdown hook Process
	 */

	public void initShutDownHook() {
		Runtime.getRuntime().addShutdownHook(new RMSShutDownHook());
	}

	/**
	 * Initialise Elastic DB
	 */

	public void initElasticDb() {

		elasticdbConnected = false;
		String[] strlist = RtJioRMSConfigParamEnum.ES_COORDINATORNODE_IPANDPORT.getStringValue().trim()
				.split(RtJioRMSConfigParamEnum.ES_NODE_SEPARATOR.getStringValue().trim());
		Map<String, String> esNodesAddress = new HashMap<>();

		for (int i = 0; i < strlist.length; i++) {
			String string = strlist[i];
			esNodesAddress.put(string.split(RtJioRMSConfigParamEnum.ES_PORT_SEPARATOR.getStringValue().trim())[0],
					string.split(RtJioRMSConfigParamEnum.ES_PORT_SEPARATOR.getStringValue().trim())[1]);
		}

		boolean esStarted = EsManager.getInstance().initESConnection(
				RtJioRMSConfigParamEnum.ES_CLUSTERNAME.getStringValue(),
				RtJioRMSConfigParamEnum.ES_XPACKUNAME.getStringValue(),
				RtJioRMSConfigParamEnum.ES_XPACKPASSWORD.getStringValue(), esNodesAddress);

		if (esStarted
				&& EsManager.getInstance().createIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
				&& EsManager.getInstance()
						.createIndex(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
				&&	EsManager.getInstance()
						.createIndex(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())) {
			EsManager.getInstance().createSchema();
		}

		if (!esStarted) {
			elasticdbConnected = false;
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initElasticDb", "initialization unsuccessful");
			return;
		}

		elasticdbConnected = true;
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "initElasticDb",
				"DB Connection, Index Init and Schema Init Successful ");

	}

	/**
	 * Initialisation of Clear Code
	 */

	public void initClearCodeManager() {
		try {

			ClearCodeBuilder builder = ResourceBuilder.clearCode();
			builder.setXdrRecordLimitPerFile(RtJioRMSConfigParamEnum.XDR_RECORD_LIMIT_PER_FILE.getStringValue())
					.setXdrNodeName(MSName.Release_Management_Repository)
					.setXdrLocalPath(RtJioRMSConfigParamEnum.XDR_LOCAL_DUMP_PATH.getStringValue())
					.setIsXDRFtpEnabled(RtJioRMSConfigParamEnum.XDR_FTP_ENABLED.getBooleanValue())
					.setRemoteHostAddress(RtJioRMSConfigParamEnum.XDR_REMOTE_ADDRESSES.getStringValue())
					.setRemoteUsername(RtJioRMSConfigParamEnum.XDR_REMOTE_USER_NAME.getStringValue())
					.setRemotePath(RtJioRMSConfigParamEnum.XDR_REMOTE_DUMP_PATH.getStringValue())
					.setRemotePassword(RtJioRMSConfigParamEnum.XDR_REMOTE_PASSWORD.getStringValue())
					.setXdrAsnCallBackIntf(new RMRAsnCallBackIntfImpl());

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initClearCodeManager", "Error in Clear Code Init", e);
		}
	}

	/**
	 * 
	 * @return
	 */

	public ClearCodeAsnPojo getClearCodeObj() {
		ClearCodeAsnPojo cccObj = null;
		try {
			cccObj = (ClearCodeAsnPojo) PoolingManager.getPoolingManager().borrowObject(ClearCodeAsnPojo.class);
			cccObj.setStartTime();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getClearCodeObj", "Error in Clear Code Init", e);
		}
		return cccObj;
	}

	/**
	 * 
	 * @return
	 */

	public DownloadBinaryThread getUploadBinaryImageThread() {
		DownloadBinaryThread downloadObject = null;
		try {
			downloadObject = (DownloadBinaryThread) PoolingManager.getPoolingManager()
					.borrowObject(DownloadBinaryThread.class);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getUploadBinaryImageThread", "Error in Borrow Object of DownloadBinaryThread", e);
		}
		return downloadObject;
	}

	/**
	 * 
	 * @param thread
	 */

	public void returnUploadBinaryImageThread(DownloadBinaryThread thread) {
		try {

			PoolingManager.getPoolingManager().returnObject(thread);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getUploadBinaryImageThread", "Error in Borrow Object of DownloadBinaryThread", e);
		}
	}

	public RtJioRMSConfigurationManager getConfigurationManager() {
		return configurationManager;
	}

	public RtJioRMSCounterManager getCounterManager() {
		return counterManager;
	}

	public RtJioRMSRegistrationOAMObserver getOamRegistrationObserver() {
		return oamRegistrationObserver;
	}

	public RtJioRMSExcelWorkbookLoader getExcelWorkbookLoader() {
		return excelWorkbookLoader;
	}

	public RtJioRMSThreadPoolExecutor getThreadPoolExecutor() {
		return threadPoolExecutor;
	}

	public ExecutorService getExecutorService() {
		return executorService;
	}

	public void setMicroserviceId(String microserviceId) {
		this.microserviceId = microserviceId;
	}

	public void setProcessId(int processId) {
		this.processId = processId;
	}

	public String getMicroserviceId() {
		return microserviceId;
	}

	public int getProcessId() {
		return processId;
	}

	/**
	 * initializes the statistics manager to load all the configurations at
	 * startup
	 */
	public void initStatisticsManager() {
		this.statisticsManager = new RTJioRMSStatisticsManager();
		this.statisticsManager.startService();
	}

	public boolean isOAMRegistered() {
		return this.registeredToOam;
	}

	public boolean isJettyInitialized() {
		return this.jettystatus;
	}

	public boolean isEsDbConnected() {
		return this.elasticdbConnected;
	}

	public String getMSUpTime() {
		return this.timestamp;
	}

	/**
	 * to set up time
	 */

	public void setMSUpTime() {
		this.timestamp = (new Date()).toString();
	}

	public String getHostName() {
		return this.hostName;
	}

	/**
	 * to set host name
	 */

	public void setHostName() {
		try {
			hostName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"setHostName", "setting host name", e);
		}
	}

	public RTJioRMSStatisticsManager getStatisticsManager() {
		return statisticsManager;
	}

	/**
	 * Method to initialise Metadata
	 */

	public void initMetadata() {
		MetadataManager.getInstance().loadMetadata();
	}

	/**
	 * @return the ermELBList
	 */
	public List<RMRERMPojo> getErmELBList() {
		return ermELBList;
	}

	/**
	 * Method to forcefully register OAM Client
	 * 
	 * @param cliData
	 * @return
	 */

	public boolean doForcefulRegisterToOam(RMRCLIPojo cliData) {

		Boolean flag = false;

		try {

			String oamIP = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.OAM_IP.getName());
			String nettyPort = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.OAM_NETTY_PORT.getName());
			String httpPort = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.OAM_PORT.getName());

			// set this in enum as well as config param sheet
			OamClientRegistrationNotifier.getInstance().addObserver(this.oamRegistrationObserver);

			Logger logger = LogManager.getLogger();

			OamClientManager.getInstance().doForcefulReregister(logger, RTJioRMSConstants.OAM_CONFIG_FILE_PATH,
					this.oamRegistrationObserver.getAlarmLoggingCallbackHandler(),
					this.oamRegistrationObserver.getAlarmConditionCntrListener(), null,
					this.oamRegistrationObserver.getApplicationMemoryUsageListener(), true, oamIP, nettyPort, httpPort,
					null);

			flag = true;

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doForcefulRegisterToOam", "Exception occured in doForcefulRegisterToOam", e);
		}
		return flag;
	}

}
