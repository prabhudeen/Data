package com.rjil.rms.fcaps;

/**
 * 
 * Constant to build Json FCAPS to write in ES
 * 
 * @author kiran.jangid
 *
 */

public enum FCAPSOperationConstantsEnum {

	APPDATA_FCAPS_TYPE("fcapType"),

	APPDATA_TYPE("type"),

	FCAPS_ALARM("alarm"),

	FCAPS_COUNTER("counter"),

	FCAPS_CONFIG("config"),

	APPDATA_VNF_ID("vnfID"),

	APPDATA_VNF_VERSION("vnfVersion"),

	APPDATA_VNF_NAME("vnfName"),

	APPDATA_VENDOR_ID("vendorID"),

	APPDATA_VENDOR_NAME("vendorName"),

	APPDATA_FILE_NAME("fileName"),

	APPDATA_REPOSITORY_PATH("repositoryPath"),

	APPDATA_DOWNLOAD_URL("downloadUrl"),

	TIME_STAMP("timeStamp");

	private String value;

	private FCAPSOperationConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
