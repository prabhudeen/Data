package com.rjil.rms.fcaps;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

/**
 * This Class Implement all operation related to FCAPS. for example upload of
 * alarm, counter and configuration sheet
 * 
 * @author Kiran.Jangid
 *
 */

public class RMSFCAPSManager implements FCAPSManager, RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "processEvent",
				"processing event in RMSFCAPSManager for eventTracking.getEventName() ");

		switch (eventTracking.getEventName()) {
		case RMSEventConstant.RMS_EVENT_ALARM_UPLOAD:
			uploadAlarmSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_COUNTER_UPLOAD:
			uploadCounterSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_CONFIG_UPLOAD:
			uploadConfigSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_GET_COUNTER:
			getCounterSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_GET_ALARM:
			getAlarmSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_GET_CONFIGURATION:
			getConfigSheet(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_GET_FCAPS:
			getFCAPSDetails(eventTracking);
			break;
		default:
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "processEvent",
					"event not found in RMSFCAPSManager for eventTracking.getEventName() = "+eventTracking.getEventName() );
			ResponsePayload payload = new ResponsePayload();
			payload.setHttpStatusCode(400);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.EVENT_NOT_AVAILABLE.getValue());
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "processEvent",
					"Response payload = "+payload.toString() );
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			
			break;
		}

	}

	@Override
	public void uploadAlarmSheet(RMREventPojo eventTracking) {

		final String methodName = "uploadAlarmSheet";

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String fileName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String vnfName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue());
			String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
			String vnfVersion = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
			String vendorId = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
			String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_ALARM.getValue(),
					vendorId, vnfId, vnfVersion);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					targetPath, "Uploading alarm sheet", eventTracking.getFlowId(), eventTracking.getPublisherName());

			FileUtils.writeByteArrayToFile(new File(targetPath, fileName), eventTracking.getRequestStream());

			JSONObject appData = new JSONObject();
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue(), vnfId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue(), vnfVersion);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue(), vnfName);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue(), targetPath);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue(),
					RtJioCommonMethods.generateDownloadUrl(FCAPSOperationConstantsEnum.FCAPS_ALARM.getValue(), vendorId,
							vnfId, vnfVersion, fileName));
			appData.put(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue(), fileName);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString(), "Writing Alarm Data", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			// Code to write Data in ES

			EsManager.getInstance().getFcapsOperationImpl().uploadFCAPSSheetForAlarm(vnfId, appData.toString());

			RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
					RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.POST),
					RMSEventConstantEnum.AM_EVENT_ALARM_UPLOAD.getValue(), appData.toString(),
					RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

			// sending broadcast to upload Alarms at All Instances
			RMRHAManager.getInstance().broadcastEvent(eventTracking);

		} catch (Exception e) {

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_UPLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

	@Override
	public void uploadConfigSheet(RMREventPojo eventTracking) {

		final String methodName = "uploadConfigSheet";

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String fileName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String vnfName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue());
			String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
			String vnfVersion = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
			String vendorId = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
			String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_CONFIG.getValue(),
					vendorId, vnfId, vnfVersion);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					targetPath, "Uploading config sheet", eventTracking.getFlowId(), eventTracking.getPublisherName());

			FileUtils.writeByteArrayToFile(new File(targetPath, fileName), eventTracking.getRequestStream());

			JSONObject appData = new JSONObject();
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue(), vnfId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue(), vnfVersion);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue(), vnfName);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue(), targetPath);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue(),
					RtJioCommonMethods.generateDownloadUrl(FCAPSOperationConstantsEnum.FCAPS_CONFIG.getValue(),
							vendorId, vnfId, vnfVersion, fileName));
			appData.put(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue(), fileName);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			// Code to write Data in ES
			EsManager.getInstance().getFcapsOperationImpl().uploadFCAPSSheetForConfig(vnfId, appData.toString());

			RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
					RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.POST),
					RMSEventConstantEnum.CM_EVENT_CONFIG_UPLOAD.getValue(), appData.toString(),
					RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId());
			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

			// sending broadcast to upload Alarms at All Instances
			RMRHAManager.getInstance().broadcastEvent(eventTracking);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload Config Sheet", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_UPLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

	@Override
	public void uploadCounterSheet(RMREventPojo eventTracking) {

		final String methodName = "uploadCounterSheet";

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String fileName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String vnfName = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue());
			String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
			String vnfVersion = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
			String vendorId = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
			String targetPath = RtJioCommonMethods.generateFCAPSRep(
					FCAPSOperationConstantsEnum.FCAPS_COUNTER.getValue(), vendorId, vnfId, vnfVersion);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					targetPath, "Uploading counter sheet", eventTracking.getFlowId(), eventTracking.getPublisherName());

			FileUtils.writeByteArrayToFile(new File(targetPath, fileName), eventTracking.getRequestStream());

			JSONObject appData = new JSONObject();
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue(), vnfId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue(), vnfVersion);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue(), vnfName);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue(), vendorId);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue(), targetPath);
			appData.put(FCAPSOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue(),
					RtJioCommonMethods.generateDownloadUrl(FCAPSOperationConstantsEnum.FCAPS_COUNTER.getValue(),
							vendorId, vnfId, vnfVersion, fileName));
			appData.put(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue(), fileName);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			// Code to write Data in ES
			EsManager.getInstance().getFcapsOperationImpl().uploadFCAPSSheetForCounter(vnfId, appData.toString());

			RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
					RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.POST),
					RMSEventConstantEnum.PM_EVENT_COUNTER_UPLOAD.getValue(), appData.toString(),
					RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

			// sending broadcast to upload Alarms at All Instances
			RMRHAManager.getInstance().broadcastEvent(eventTracking);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload Counter Sheet", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

	@Override
	public void getAlarmSheet(RMREventPojo eventTracking) {

		String fileName = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
		String vnfVersion = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
		String vendorId = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
		String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_ALARM.getValue(),
				vendorId, vnfId, vnfVersion);

		try (InputStream fis = new FileInputStream(new File(targetPath, fileName))) {

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getAlarmSheet", "Error in Get Alarm Sheet Service ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getAlarmSheet", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}

	}

	@Override
	public void getConfigSheet(RMREventPojo eventTracking) {

		String fileName = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
		String vnfVersion = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
		String vendorId = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
		String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_CONFIG.getValue(),
				vendorId, vnfId, vnfVersion);

		try (InputStream fis = new FileInputStream(new File(targetPath, fileName))) {

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getConfigSheet", "Error in Get Config Sheet Service ", e);
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getConfigSheet", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}
	}

	@Override
	public void getCounterSheet(RMREventPojo eventTracking) {

		String fileName = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
		String vnfVersion = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
		String vendorId = eventTracking.getRequestParams()
				.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
		String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_COUNTER.getValue(),
				vendorId, vnfId, vnfVersion);

		try (InputStream fis = new FileInputStream(new File(targetPath, fileName))) {

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getCounterSheet", "Error in Get Counter Sheet Service ", e);
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getCounterSheet", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}
	}

	@Override
	public void getFCAPSDetails(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());

			JSONObject appData = new JSONObject();

			JSONArray arry = new JSONArray();

			for (String string : EsManager.getInstance().getFcapsOperationImpl().getAllFCAPSSheetForVnfid(vnfId)) {
				arry.put(new JSONObject(string));
			}

			appData.put("fcaps", arry);

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			payload.setAppData(appData);
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSDetails", "Error in Get FCAPS Details ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSDetails", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

}
