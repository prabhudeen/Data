package com.rjil.rms.fcaps;

import java.io.File;
import java.io.FileInputStream;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RTJioRMSConstants;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRFCAPSTemplateDownloadEvent implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		final String methodName = "processEvent";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"processing event : " + eventTracking.getEventName());

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String type = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_TYPE.getValue());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"type = " + type);

			String targetPath = RtJioRMSConfigParamEnum.BINARY_SOURCE_HOME_PATH.getValue().toString() + "/" + type;
			String fileName = null;
			switch (type) {
			case RTJioRMSConstants.FCAP_TYPE_ALARM:
				fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_ALARM_FILE_NAME.getValue().toString();
				break;
			case RTJioRMSConstants.FCAP_TYPE_CONFIG:
				fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_CONFIG_FILE_NAME.getValue().toString();
				break;
			case RTJioRMSConstants.FCAP_TYPE_COUNTER:
				fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_COUNTER_FILE_NAME.getValue().toString();
				break;
			default:
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue()
						+ ": type is not valid or missing");
				return;
			}

			File templateFile = new File(targetPath, fileName);

			if (!templateFile.exists()) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE
						+ ": Template file is not available for " + type);
				ccAsnPojo.addClearCode(ClearCodes.FCAPS_TEMPLATE_DOWNLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			FileInputStream f = new FileInputStream(templateFile);
			byte[] b = new byte[f.available()];
			f.read(b);

			JSONObject appData = new JSONObject();
			appData.put("fileName", fileName);
			appData.put("fileData", b);
			appData.put("fileFormat", "xlsx");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			f.close();

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Dwonload FCAPs Template Sheet", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_TEMPLATE_DOWNLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
