package com.rjil.rms.fcaps;

import java.io.File;
import java.io.FileInputStream;

import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRFCAPSDictionaryDownloadEvent implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		final String methodName = "processEvent";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"processing event : " + eventTracking.getEventName());

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String vnfId = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
			String vnfVersion = eventTracking.getRequestParams()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
			String type = eventTracking.getRequestParams().get(FCAPSOperationConstantsEnum.APPDATA_TYPE.getValue());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"vnf id = " + vnfId + ", type = " + type + ", vnf version = " + vnfVersion);

			if (vnfId == null || type == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue()
						+ ", vnfId or Type is Missing");
				return;
			}

			String vendorId;
			String fileName;
			JSONObject object;
			switch (type) {
			case "alarm":
				object = new JSONObject(EsManager.getInstance().getFcapsOperationImpl().getFCAPSSheetForAlarm(vnfId));
				vendorId = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
				fileName = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
				break;
			case "config":
				object = new JSONObject(EsManager.getInstance().getFcapsOperationImpl().getFCAPSSheetForConfig(vnfId));
				vendorId = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
				fileName = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
				break;
			case "counter":
				object = new JSONObject(EsManager.getInstance().getFcapsOperationImpl().getFCAPSSheetForCounter(vnfId));
				vendorId = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
				fileName = (String) object.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
				break;
			default:
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue()
						+ ", Type value should be alarm, config or counter");
				return;
			}

			String targetPath = RtJioCommonMethods.generateFCAPSRep(type, vendorId, vnfId, vnfVersion);

			if (targetPath == null) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
				return;
			}

			FileInputStream f = new FileInputStream(new File(targetPath, fileName));
			byte[] b = new byte[f.available()];
			f.read(b);

			JSONObject appData = new JSONObject();
			appData.put("fileName", fileName);
			appData.put("fileData", b);
			appData.put("fileFormat", "xlsx");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			f.close();

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Download FCAPs Dictionary", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DICTIONARY_DOWNLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
