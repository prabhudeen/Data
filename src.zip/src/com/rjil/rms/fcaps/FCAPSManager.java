package com.rjil.rms.fcaps;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * Interface that provide FCAPS operation and orchestration
 * 
 * @author Kiran.Jangid
 *
 */

public interface FCAPSManager {

	/**
	 * 
	 * Interface to upload alarm sheet
	 * 
	 * @param eventTracking
	 */

	void uploadAlarmSheet(RMREventPojo eventTracking);

	/**
	 * 
	 * Interface to upload configuration sheet
	 * 
	 * @param eventTracking
	 */

	void uploadConfigSheet(RMREventPojo eventTracking);

	/**
	 * 
	 * Interface to upload counter sheet
	 * 
	 * @param eventTracking
	 */

	void uploadCounterSheet(RMREventPojo eventTracking);

	/**
	 * Interface to download Alarm Sheet
	 * 
	 * @param eventTracking
	 */

	void getAlarmSheet(RMREventPojo eventTracking);

	/**
	 * Interface to download configuration sheet
	 * 
	 * @param eventTracking
	 */

	void getConfigSheet(RMREventPojo eventTracking);

	/**
	 * 
	 * Interface to download counter sheet
	 * 
	 * @param eventTracking
	 */

	void getCounterSheet(RMREventPojo eventTracking);

	/**
	 * Interface to get all details of fcaps of particular vnf id
	 * 
	 * @param eventTracking
	 */

	void getFCAPSDetails(RMREventPojo eventTracking);

}
