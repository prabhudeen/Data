package com.rjil.rms.notification;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * To Handle Notification of Events Coming from MicroServices
 * 
 * @author Kiran.Jangid
 *
 */
@FunctionalInterface
public interface RMSEventNotification {

	/**
	 * To Handle Image Delete Notification. It will image data as well as Draft
	 * Data
	 * 
	 * @param eventTracking
	 */

	void imageDeleteNotification(RMREventPojo eventTracking);

}
