package com.rjil.rms.notification;

import org.json.JSONArray;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

/**
 * 
 * @author Nikhil.Dosapati
 *
 */

public class RMRVNFTerminationNotification implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CLASS_NAME = "RMRVNFTerminationNotification";

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEvent",
				"Processing Event Notification for : " + eventTracking.getEventName());

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "processEvent";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_TERMINATE_REQUEST.increment();

		try {

			JSONObject jsonObject = new JSONObject(new String(eventTracking.getRequestStream()));
			JSONArray jsonArray = jsonObject.getJSONArray("vnf-list");

			JSONObject object = (JSONObject) jsonArray.get(0);
			String vnfId = object.getString(NotificationOperationConstantEnum.VNF_ID.getValue());
			String vnfVersion = object.getString(NotificationOperationConstantEnum.VNF_VERSION.getValue());
			
			JSONObject jsonBody=new JSONObject();
			jsonBody.put(NotificationOperationConstantEnum.VNF_ID.getValue(), vnfId);
			jsonBody.put(NotificationOperationConstantEnum.VNF_VERSION.getValue(), vnfVersion);
			

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "Vnf Id : " + vnfId + "| vnfVersion : " +vnfVersion, eventTracking.getFlowId(), eventTracking.getPublisherName());

			// Check Mandatory Parameter
			if (vnfId == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(NotificationOperationErrorMessageConstantEnum.ERROR_VNF_ID_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.ERROR_VNF_ID_MISSING_NOTIFY_VNF_TERMINATE.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_TERMINATE_INVALID.increment();
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
				return;
			}

			// publishing Event to PVIM to check vnf status
			RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
					RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.GET),
					RMSEventConstant.GET_VNF_DEPLOYMENT_STATUS, jsonBody.toString(),
					RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId(),
					eventTracking.getBranchId());

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in updating vnf draft data", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in updating vnf draft data");

			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVER_ERROR_NOTIFY_VNF_DELETION.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_FAILURE.increment();

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);

		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
