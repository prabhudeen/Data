package com.rjil.rms.notification;

import org.json.JSONArray;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author Nikhil.Dosapati
 *
 */

public class RMRVNFInstantiationNotification implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CLASS_NAME = "RMRVNFInstantiationNotification";

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEvent",
				"Processing Event Notification for : " + eventTracking.getEventName());

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "processEvent";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_INSTANTIATE_REQUEST.increment();

		try {

			JSONObject jsonObject = new JSONObject(new String(eventTracking.getRequestStream()));
			JSONArray jsonArray1 = jsonObject.getJSONArray("vnf-list");
			JSONObject object1 = (JSONObject) jsonArray1.get(0);
			JSONArray jsonArray2 = (JSONArray) object1.getJSONArray("vnfc-list");
			JSONObject object2 = (JSONObject) jsonArray2.get(0);
			String vnfId = object2.getString("vnfID");

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "Vnf Id : " + vnfId, eventTracking.getFlowId(), eventTracking.getPublisherName());

			// Check Mandatory Parameter
			if (vnfId == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(NotificationOperationErrorMessageConstantEnum.ERROR_VNF_ID_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.ERROR_VNF_ID_MISSING_NOTIFY_VNF_INSTANTIATE.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_INSTANTIATE_INVALID.increment();
				return;
			}

			if (!EsManager.getInstance().getDraftOperationImpl().updateDraftStatus(vnfId,
					DraftOperationConstantsEnum.OPERATION_INSTANTIATE.getValue(),
					DraftOperationConstantsEnum.COMPLETED.getValue())) {

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("Error in Instantiating VNF Image Binary");
				return;

			}

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

		} catch (DataNotAvailableError ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Data Not Available for requested vnf", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payload.setHttpStatusCode(404);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in Updating VNF Draft Data : Vnf Id not available");

			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVER_ERROR_NOTIFY_VNF_INSTANTIATE.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_INSTANTIATE_FAILURE.increment();

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Instantiating vnf", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in Instantiating VNF Image Binary");

			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVER_ERROR_NOTIFY_VNF_INSTANTIATE.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_INSTANTIATE_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
