package com.rjil.rms.notification;

/**
 * Binary Operation Constant
 * 
 * @author kiran.jangid
 *
 */

public enum NotificationOperationConstantEnum {

	VNF_ID("vnfID"),

	VNF_NAME("vnfName"),
	
	VNF_VERSION("vnfVersion");

	private String value;

	private NotificationOperationConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
