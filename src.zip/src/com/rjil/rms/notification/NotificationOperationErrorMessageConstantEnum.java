package com.rjil.rms.notification;

/**
 * Binary Operation Constant
 * 
 * @author kiran.jangid
 *
 */

public enum NotificationOperationErrorMessageConstantEnum {

	ERROR_IN_DELETE_IMAGE_DATA_FROM_ES("Error in deleting data from Elastic"),

	ERROR_IN_DELETE_IMAGE_DATA_FROM_FILE_FOLDER("Error in deleting data from File Folder"),

	ERROR_IN_DELETE_DRAFT_DATA("Draft Data Deletion Failed for VNF ID : "),

	ERROR_IN_DELETE_IMAGE_DATA("Image Data Deletion Failed for VNF ID : "),

	ERROR_VNF_ID_MISSING("Bad Request : VNF ID Mandatory Parameter Missing"),
	
	ERROR_CNF_ID_MISSING("Bad Request : CNF ID Mandatory Parameter Missing"),
	
	ERROR_NETWORK_SERVICE_INSTANCE_ID_MISSING("Bad Request : Network Service Instance ID Mandatory Parameter Missing"),

	ERROR_DATA_NOT_FOUND("Data Not Found for VNF Id :");

	private String value;

	private NotificationOperationErrorMessageConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
