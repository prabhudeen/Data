package com.rjil.rms.notification;

import java.nio.file.NoSuchFileException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.binary.BinaryOperationConstantEnum;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.NoSuchBinaryFile;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.hdfs.RtJioRMShdfsConstants;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * This class handles all notification events
 * 
 * <br>
 * Events : <b> NOTIFY_VNF_DELETION</b>
 * 
 * @author Kiran.Jangid
 *
 */

public class RMSEventNotificationManager implements RMREventProcessor, RMSEventNotification {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
    private boolean deleteVnfDataFormHDFS = false;
	private static final String CLASS_NAME = "RMSEventNotificationManager";

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEvent",
				"Processing Event Notification for : " + eventTracking.getEventName());

		switch (eventTracking.getEventName()) {
		case RMSEventConstant.RMR_NOTIFICATION_EVENT_VNF_DELETION:
			imageDeleteNotification(eventTracking);
			break;
		default:
			break;
		}

	}

	@Override
	public void imageDeleteNotification(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "imageDeleteNotification";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_REQUEST.increment();

		try {

			String notificationDataStr = new String(eventTracking.getRequestStream());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					notificationDataStr, "Request : ", eventTracking.getFlowId(), eventTracking.getPublisherName());

			JSONObject notificationDataObject = new JSONObject(notificationDataStr);

			String vnfId = notificationDataObject.getString(NotificationOperationConstantEnum.VNF_ID.getValue());

			// Check Mandatory Parameter
			if (vnfId == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(NotificationOperationErrorMessageConstantEnum.ERROR_VNF_ID_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.ERROR_VNF_ID_MISSING_NOTIFY_VNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_INVALID.increment();
				return;
			}

			// Creating query to get list of Image Data from ES
			Map<String, String> queryBuilder = new HashMap<>();
			queryBuilder.put(BinaryOperationConstantEnum.VNF_ID.getValue(), vnfId);

			try {

				String vnfVersion = notificationDataObject
						.getString(NotificationOperationConstantEnum.VNF_VERSION.getValue());

				if (vnfVersion != null) {
					queryBuilder.put(BinaryOperationConstantEnum.VNF_VERSION.getValue(), vnfVersion);
				}

			} catch (JSONException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, methodName,
						"vnf version is null : ", e);
			}

			List<Object> imageListStr = EsManager.getInstance().getVnfOperationImpl().listVNFCImages(queryBuilder);

			if (imageListStr.isEmpty()) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						NotificationOperationErrorMessageConstantEnum.ERROR_DATA_NOT_FOUND.getValue() + vnfId);
				ccAsnPojo.addClearCode(ClearCodes.ERROR_DATA_NOT_FOUND_NOTIFY_VNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_INVALID.increment();
				return;
			}
			deleteVnfDataFormHDFS=false;
			if(RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue())
			{
				Object imageStr = imageListStr.get(0);
				JSONObject jsonObj = new JSONObject((Map) imageStr);
                
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Deleting Image Data form HDFS : " + jsonObj.toString());

				Gson gsonObj = new Gson();
				VNFCImage vnfcImage = gsonObj.fromJson(jsonObj.toString(), VNFCImage.class);
				
				 Configuration conf = new Configuration();
		         conf.addResource(new Path(RtJioRMShdfsConstants.CORE_SITE_XML));
		         conf.addResource(new Path(RtJioRMShdfsConstants.HDFS_SITE_XML));
		         //            conf.addResource(new Path(mapredSiteXmlPath));
		         loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
							"Getting First Data from List of vnfcs " + vnfcImage.toString());
		         FileSystem fileSystem = FileSystem.get(conf);
		         String filePath = RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue()+
		        		           "/"+vnfcImage.getVendorName()+"/"+vnfcImage.getVnfName()+"/"+vnfcImage.getVnfVersion()+"/";
		         Path path =new Path(filePath);
		         if (!fileSystem.exists(path)) {
		        	  throw new NoSuchBinaryFile();
		         }
		         
		         fileSystem.delete(path, true);
		         
		         fileSystem.close();
		         
		         deleteVnfDataFormHDFS=true;
		         
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Deleting all image of Vnf ID from HDFS: " + vnfcImage.getVnfID());
			}

			JSONArray jsonArray = null;

			for (Object imageStr : imageListStr) {

				JSONObject jsonObj = new JSONObject((Map) imageStr);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Deleting Image Data : " + jsonObj.toString());

				Gson gsonObj = new Gson();
				VNFCImage vnfcImage = gsonObj.fromJson(jsonObj.toString(), VNFCImage.class);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Deleting Image ID : " + vnfcImage.getVnfcID());

				try {

					// deleting image from ES and file folder
					if(deleteVnfDataFormHDFS || RtJioCommonMethods.deleteFileFromDestination(vnfcImage)) {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
								"Deleted Image File for Image ID : " + vnfcImage.getVnfcID());

						if (EsManager.getInstance().getVnfOperationImpl().deleteVNFCImage(vnfcImage.getVnfcID())) {

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
									"Deleted ES Data for Image ID : " + vnfcImage.getVnfcID());

						} else {

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, methodName,
									"Error in Deleting ES Data for Image ID : " + vnfcImage.getVnfcID());

							if (jsonArray == null) {
								jsonArray = new JSONArray();
							}

							// Failure vnfc id
							JSONObject errorMessage = new JSONObject();
							errorMessage.put("vnfc-id", vnfcImage.getVnfcID());
							errorMessage.put("error-message",
									NotificationOperationErrorMessageConstantEnum.ERROR_IN_DELETE_IMAGE_DATA_FROM_ES
											.getValue());
							jsonArray.put(errorMessage);

						}

					} else {

						if (jsonArray == null) {
							jsonArray = new JSONArray();
						}

						// Failure vnfc id
						JSONObject errorMessage = new JSONObject();
						errorMessage.put("vnfc-id", vnfcImage.getVnfcID());
						errorMessage.put("error-message",
								NotificationOperationErrorMessageConstantEnum.ERROR_IN_DELETE_IMAGE_DATA_FROM_FILE_FOLDER
										.getValue());
						jsonArray.put(errorMessage);
					}

				} catch (NoSuchFileException e) {

					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), methodName,
							"Image File not available on this instance for vnfc id : " + vnfcImage.getVnfcID(), e);

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
							"Sending Broadcast to Other Instance ");

					if (!RtJioRMSConfigParamEnum.IS_USING_SHARED_RESOURCE.getBooleanValue()) {
						// Sending whole event to other instances
						Map<String, String> jsnObj = new HashMap<>();
						jsnObj.put("vnfcId", vnfcImage.getVnfcID());
						RMREventPojo eventPojo = new RMREventPojo();
						eventPojo.setRequestParams(jsnObj);
						eventPojo.setEventName(RMSEventConstant.RMS_EVENT_BINARY_DELETE);
						RMRHAManager.getInstance().broadcastEvent(eventPojo);
					}

				}

			}

			if (jsonArray != null && jsonArray.length() > 0) {

				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						NotificationOperationErrorMessageConstantEnum.ERROR_IN_DELETE_IMAGE_DATA.getValue() + vnfId);

				JSONObject resObj = new JSONObject();
				resObj.put("actions", jsonArray);
				payload.setAppData(resObj);

				ccAsnPojo.addClearCode(ClearCodes.ERROR_IN_DELETE_IMAGE_DATA_NOTIFY_VNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_FAILURE.increment();

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						"Image Data deletion failure for VNF ID : " + vnfId, methodName, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				return;
			}

			// to delete Draft Data

			if (EsManager.getInstance().getDraftOperationImpl().deleteDraft(vnfId,
					DraftOperationConstantsEnum.OPERATION_ONBOARD.getValue())
					&& EsManager.getInstance().getDraftOperationImpl().deleteDraft(vnfId,
							DraftOperationConstantsEnum.OPERATION_DEPLOYMENT.getValue())
					&& EsManager.getInstance().getDraftOperationImpl().deleteDraft(vnfId,
							DraftOperationConstantsEnum.OPERATION_INSTANTIATE.getValue())) {

				payload.setHttpStatusCode(200);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_SUCCESS.increment();

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Draft Data deleted for VNF ID : " + vnfId);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "Draft Data deleted for VNF ID : " + vnfId, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

			} else {

				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						NotificationOperationErrorMessageConstantEnum.ERROR_IN_DELETE_DRAFT_DATA.getValue() + vnfId);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, methodName,
						"Draft Data deletion failure for VNF ID : " + vnfId);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, "Draft Data deletion failure for VNF ID : " + vnfId, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				ccAsnPojo.addClearCode(ClearCodes.ERROR_IN_DELETE_DRAFT_DATA_NOTIFY_VNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_FAILURE.increment();

				return;
			}

		} 
		 catch(NoSuchBinaryFile ex)
		{
			 loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in deleting binary File form HDFS", ex);

		}
		catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting binary", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in Deleting VNF Image Binary");

			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVER_ERROR_NOTIFY_VNF_DELETION.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
