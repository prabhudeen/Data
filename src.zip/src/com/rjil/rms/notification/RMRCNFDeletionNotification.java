package com.rjil.rms.notification;

import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.draft.CNFDraftOperationConstantsEnum;
import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRCNFDeletionNotification implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CLASS_NAME = "RMRCNFDeletionNotification";

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEvent",
				"Processing Event Notification for : " + eventTracking.getEventName());

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "processEvent";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_REQUEST.increment();

		try {

			String notificationDataStr = new String(eventTracking.getRequestStream());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					notificationDataStr, "Request : ", eventTracking.getFlowId(), eventTracking.getPublisherName());

			JSONObject notificationDataObject = new JSONObject(notificationDataStr);

			String cnfId = notificationDataObject.getString(CNFDraftOperationConstantsEnum.CNF_ID.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "Cnf Id : " + cnfId, eventTracking.getFlowId(), eventTracking.getPublisherName());

			// Check Mandatory Parameter
			if (cnfId == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(NotificationOperationErrorMessageConstantEnum.ERROR_CNF_ID_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.ERROR_CNF_ID_MISSING_NOTIFY_CNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_INVALID.increment();
				return;
			}

			if (EsManager.getInstance().getCnfdraftOperationImpl().deleteDraft(cnfId,
					DraftOperationConstantsEnum.OPERATION_ONBOARD.getValue())
					&& EsManager.getInstance().getCnfdraftOperationImpl().deleteDraft(cnfId,
							DraftOperationConstantsEnum.OPERATION_DEPLOYMENT.getValue())
					&& EsManager.getInstance().getCnfdraftOperationImpl().deleteDraft(cnfId,
							DraftOperationConstantsEnum.OPERATION_INSTANTIATE.getValue())) {

				payload.setHttpStatusCode(200);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_SUCCESS.increment();

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "Draft Data deleted for CNF ID : " + cnfId, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

			} else {

				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						NotificationOperationErrorMessageConstantEnum.ERROR_IN_DELETE_DRAFT_DATA.getValue() + cnfId);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, "Draft Data deletion failure for CNF ID : " + cnfId, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				ccAsnPojo.addClearCode(ClearCodes.ERROR_IN_DELETE_DRAFT_DATA_NOTIFY_CNF_DELETION.getValue(),
						ClearCodeLevel.PROTOCOL);
				RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_FAILURE.increment();

				return;
			}

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting cnf draft data", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in deleting cnf draft data");

			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVER_ERROR_NOTIFY_CNF_DELETION.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
