package com.rjil.rms.hdfs;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.binary.BinaryOperationConstantEnum;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.broadcast.sender.BroadCastAddUIMetadataEvent;
import com.rjil.rms.broadcast.sender.BroadCastDeleteBinaryEvent;
import com.rjil.rms.broadcast.sender.BroadCastDeleteUIMetadataEvent;
import com.rjil.rms.broadcast.sender.BroadCastModifyUIMetadataEvent;
import com.rjil.rms.broadcast.sender.BroadCastNotifyVnfDeletionEvent;
import com.rjil.rms.broadcast.sender.BroadCastUpdateBinaryEvent;
import com.rjil.rms.broadcast.sender.BroadCastUploadAlarmDictionaryEvent;
import com.rjil.rms.broadcast.sender.BroadCastUploadBinaryEvent;
import com.rjil.rms.broadcast.sender.BroadCastUploadConfigDictionaryEvent;
import com.rjil.rms.broadcast.sender.BroadCastUploadCounterDictionaryEvent;
import com.rjil.rms.broadcast.sender.ProcessBroadcast;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.operation.ESOperationException;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.startup.RMSManagerBootstrap;
import com.rjil.rms.sync.request.RtJioRMRFileUploaderContextHandler;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

public class RtJioRMShdfsFactoryClass {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private RtJioRMShdfsProcess processTask = null;
	private RMREventPojo eventPojo;
	private VNFCImage vnfcImage;

	/**
	 * 
	 * @param eventPojo
	 */

	public RtJioRMShdfsFactoryClass(RMREventPojo eventPojo, VNFCImage vnfcImage) {
		this.eventPojo = eventPojo;
		this.vnfcImage = vnfcImage;
	}

	/**
	 * 
	 */

	public RtJioRMShdfsFactoryClass() {
		/**
		 * Default
		 */
	}
	
	public RtJioRMShdfsFactoryClass(RMREventPojo eventPojo) {
		this.eventPojo = eventPojo;
	}

	public void processEventTask(HDFSTaskListener listener) {
        String taskName="";
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Processing HDFS factory  class = " + this.eventPojo.toString());

		switch (this.eventPojo.getEventName()) {
		
		case RMSEventConstant.RMS_EVENT_BINARY_PROVISIONING:
			processTask = new RtJioRMShdfsUploadFile(eventPojo, vnfcImage,listener);
			taskName = "UPLOAD";
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_DELETE:
			 String completPath =RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() +
             FolderStructureGenerator.generateHDFSDriectroy(vnfcImage)+"/";
//             vnfcImage.getImageName();
			processTask = new RtJioRMSDeleteImageFromHDFS(completPath,listener);
			taskName ="DELETE";
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_UPDATE:
			processTask = new RtJioRMSUpdateBinaryHDFS(eventPojo,listener);
			taskName = "UPDATE";
			break;
		default:
			break;
		}

		if(processTask != null) {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"Processing Task "+taskName +" = " + this.eventPojo.toString());
			ExecutorService executor = Executors.newFixedThreadPool(5);
			executor.submit(processTask);
		}

	}

}
