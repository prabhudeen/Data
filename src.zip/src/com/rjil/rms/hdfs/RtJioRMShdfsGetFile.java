package com.rjil.rms.hdfs;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.FileNotAvailableError;
import com.rjil.rms.binary.error.FileUploadSuccess;
import com.rjil.rms.binary.error.NoSpaceAvailable;
import com.rjil.rms.binary.error.NoSuchBinaryFile;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

import io.netty.handler.codec.http.HttpResponse;

public class RtJioRMShdfsGetFile implements RtJioRMShdfsProcess,Runnable{

	private HDFSTaskListener taskListener;
	private String coreSiteXmlPath = RtJioRMShdfsConstants.CORE_SITE_XML;;
	private String hdfsSiteXmlPath = RtJioRMShdfsConstants.HDFS_SITE_XML;;
	private String source = null;
	private String dest = null;
	private VNFCImage vnfcImage;
	private RMREventPojo eventPojo;
	HttpServletResponse response;
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
    private String path;
	public RtJioRMShdfsGetFile(RMREventPojo eventPojo, VNFCImage vnfcImage, HDFSTaskListener listener,HttpServletResponse response,String path) {
		super();
		this.vnfcImage = vnfcImage;
		this.eventPojo = eventPojo;
		this.taskListener = listener;
		this.response=response;
		this.path = path;
	}
      
	public RtJioRMShdfsGetFile(HttpServletResponse response2, String vnfcPath,HDFSTaskListener listener) {
		this.response =response2;
		this.path =vnfcPath;
		this.taskListener = listener;
;	}

	@Override
	public void processHdfsTask() {
		
		try {
			readFile(this.path);
			this.taskListener.completed(new FileUploadSuccess());
		} catch (IOException | NoSuchBinaryFile e) {
			
			 loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "run",
						"Error While Downloading HDFC File =" +this.path);
			 this.taskListener.completed(new FileNotAvailableError());
		}
	}
	@Override
	public void run() {
		
		processHdfsTask();
	}
	
	  public void readFile(String file) throws IOException, NoSuchBinaryFile {
         
	  loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"inside READFILE METHOD =" +file);
		  String  methodName = "readFile";
          Configuration conf = new Configuration();
          conf.addResource(new Path(coreSiteXmlPath));
          conf.addResource(new Path(hdfsSiteXmlPath));
          //            conf.addResource(new Path(mapredSiteXmlPath));
          
          FileSystem fileSystem = FileSystem.get(conf);

          Path path = new Path(file);
          if (!fileSystem.exists(path)) {
               throw new NoSuchBinaryFile();
          }
          loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File path available in HDFS =" +file);
       
          long length = fileSystem.getFileStatus(path).getLen();
          response.setHeader("Content-Length", Long.toString(length));
        
          
          FSDataInputStream in = fileSystem.open(path);
          System.out.println("path : "+ path); 
          
          String filename = file.substring(file.lastIndexOf('/') + 1,file.length());
          
          OutputStream out = new BufferedOutputStream(new FileOutputStream(
                       new File(filename)));
          
          
          OutputStream os = response.getOutputStream();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName, "Download File Lenght : " + length);
          

          System.out.println("fileName : "+filename);
          byte[] b = new byte[1024];
          int numBytes = 0;
          while ((numBytes = in.read(b)) > 0) {
                 os.write(b, 0, numBytes);     
                 System.out.write(b, 0, numBytes);
          }
          
          loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File Download Completed on file Path =" +file);
          
          //System.out.println(IOUtils.toS);

			os.flush();
			os.close();
            in.close();
          out.close();
          fileSystem.close();
          
          
          
   }

}
