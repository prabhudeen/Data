package com.rjil.rms.hdfs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.rjil.rms.binary.error.DeleteErrorHDFS;
import com.rjil.rms.binary.error.FileDeleteSuccess;
import com.rjil.rms.binary.error.NoSuchBinaryFile;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.sun.jersey.core.spi.component.ProviderServices;

public class RtJioRMSDeleteImageFromHDFS implements RtJioRMShdfsProcess,Runnable{
	  private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	  private String coreSiteXmlPath = RtJioRMShdfsConstants.CORE_SITE_XML;
      private String hdfsSiteXmlPath = RtJioRMShdfsConstants.HDFS_SITE_XML;
      String imagePath;
      HDFSTaskListener taskListner;
      public RtJioRMSDeleteImageFromHDFS(String path,HDFSTaskListener listener) {
             super();
             this.imagePath = path;
             this.taskListner =listener;
      }
      
	@Override
	public void processHdfsTask() {
		String methodName ="processHdfsTask";
		
		try {
			
			deleteFile(this.imagePath);
			this.taskListner.completed(new FileDeleteSuccess());
		} catch (IOException e) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName,
					"Error While Deleting File or Folder from HDFS");
			this.taskListner.completed(new DeleteErrorHDFS());
		} catch (NoSuchBinaryFile e) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName,
					"Some Folder or File structure not exists.");
			this.taskListner.completed(new DeleteErrorHDFS());
		}
	}

	@Override
	public void run() {
		
	   processHdfsTask();
	}
	
	 public void deleteFile(String file) throws IOException, NoSuchBinaryFile {
		 String methodName ="DeleteFile";
		 loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName,
					"Path = "+file);
         Configuration conf = new Configuration();
         conf.addResource(new Path(coreSiteXmlPath));
         conf.addResource(new Path(hdfsSiteXmlPath));
         //            conf.addResource(new Path(mapredSiteXmlPath));
         
         FileSystem fileSystem = FileSystem.get(conf);
         
         Path path = new Path(file);
         if (!fileSystem.exists(path)) {
        	  throw new NoSuchBinaryFile();
         }
         
         fileSystem.delete(path, true);
         
         fileSystem.close();
	 }
}