package com.rjil.rms.hdfs;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletResponse;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.binary.BinaryManager;
import com.rjil.rms.binary.BinaryOperationConstantEnum;
import com.rjil.rms.binary.RMSBinaryManager;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.error.FileUploadFailure;
import com.rjil.rms.binary.error.FileUploadSuccess;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

public class RtJioRMSUpdateBinaryHDFS implements RtJioRMShdfsProcess, Runnable {

	private String coreSiteXmlPath = RtJioRMShdfsConstants.CORE_SITE_XML;
	private String hdfsSiteXmlPath = RtJioRMShdfsConstants.HDFS_SITE_XML;
	RMREventPojo eventTracking;
	private HDFSTaskListener taskListner;
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	public RtJioRMSUpdateBinaryHDFS(RMREventPojo pojo, HDFSTaskListener taskListner) {
		super();
		this.eventTracking = pojo;
		this.taskListner = taskListner;
	}

	public boolean ifExists(Path source) throws IOException {

		Configuration config = new Configuration();
		config.addResource(new Path(coreSiteXmlPath));
		config.addResource(new Path(hdfsSiteXmlPath));
		// config.addResource(new Path(mapredSiteXmlPath));

		FileSystem hdfs = FileSystem.get(config);
		boolean isExists = hdfs.exists(source);
		return isExists;

	}

	@Override
	public void processHdfsTask() {
		// TODO Auto-generated method stub
		try {
			updateBinaryHDFS(this.eventTracking);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		processHdfsTask();
	}

	public void updateBinaryHDFS(RMREventPojo eventTracking) throws IOException {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "updateBinary";
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"INSIDE UPDATE BINARY HDFS FUNCTON: ");
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			// Getting image id from request to Update Image data form Database
			// and Folder
			String vnfcId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNFC_ID.getValue());

			// Getting image data from ES
			String imageStr = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

			if (imageStr == null) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("Image Data is not available for Id : " + vnfcId);
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Image Data is not available for Id  : " + vnfcId);
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

				return;
			}

			JsonObject jsonObjectES = (new JsonParser().parse(imageStr)).getAsJsonObject();
			Gson gsonObjES = new Gson();
			VNFCImage vnfcImageOnES = gsonObjES.fromJson(jsonObjectES, VNFCImage.class);

			String pathToFile = RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/"
					+ FolderStructureGenerator.generateHDFSDriectroy(vnfcImageOnES);
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Updating Image Data : =" + pathToFile);

			if (!ifExists(new Path(pathToFile))) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Destination Path not exists in HDFS : ");
				return;
			}

			if (vnfcImageOnES.getImageName() != null) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Deleting image file at path : " + pathToFile);

				RtJioRMShdfsProcess deleteTask = new RtJioRMSDeleteImageFromHDFS(pathToFile, new HDFSTaskListener() {

					@Override
					public void completed(BinaryUploadResponse response) {
						ResponsePayload payload = response.getResponse();
						ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

						if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
									this.getClass().getName(), methodName,
									"Deleted Succesfully this image: " + pathToFile);

							String updateBinaryJson = new String(eventTracking.getRequestStream());

							loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
									methodName, updateBinaryJson, "Provisioning binary", eventTracking.getFlowId(),
									eventTracking.getPublisherName());

							JsonObject jsonObject = (new JsonParser().parse(updateBinaryJson)).getAsJsonObject();

							Gson gsonObj = new Gson();
							VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
									this.getClass().getName(), methodName, "Request : " + updateBinaryJson);

							File src = new File(vnfcImage.getFilePath() + "/" + vnfcImage.getImageName());

							loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
									methodName, null, "File Path : " + src.getAbsolutePath(), eventTracking.getFlowId(),
									eventTracking.getPublisherName());

							if (!src.exists()) {
								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
										this.getClass().getName(), methodName, null,
										"File Does not Exist at path : " + src.getAbsolutePath(),
										eventTracking.getFlowId(), eventTracking.getPublisherName());

								payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
								payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
								payload.setErrorMessage("File Does not Exist : " + src.getName());
								ccAsnPojo.addClearCode(ClearCodes.FILE_NOT_AVAILABLE.getValue(),
										ClearCodeLevel.PROTOCOL);

								RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking,
										new JSONObject(payload), null);
								ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
								taskListner.completed(new FileUploadFailure());
								return;
							}

							RtJioRMShdfsUploadFile updateBinaryImage = new RtJioRMShdfsUploadFile(eventTracking,
									vnfcImage, new HDFSTaskListener() {

										@Override
										public void completed(BinaryUploadResponse response) {
											ResponsePayload payload = response.getResponse();
											ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance()
													.getClearCodeObj();

											if (payload.getType().equalsIgnoreCase(
													ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

												try {

													if (EsManager.getInstance().getVnfOperationImpl().updateVNFCImage(
															vnfcId, vnfcImage.toString())) {

														loggerWriter.writeClassLevelLog(
																RMSLoggerTypeEnum.INFO.getValue(),
																this.getClass().getName(), methodName,
																"Updated Succesfully image: " + pathToFile
																		+ vnfcImage.getImageName());

														VNFCImage vnfcImageTemp = new VNFCImage();
														vnfcImageTemp.setFileUrl(RtJioCommonMethods
																.generateDownloadUrlForImage(vnfcImage));
														vnfcImageTemp.setImageName(vnfcImage.getImageName());
														vnfcImageTemp.setFormat(vnfcImage.getFormat());
														vnfcImageTemp.setVnfID(vnfcImage.getVnfID());
														vnfcImageTemp.setVnfcID(vnfcImage.getVnfcID());
														vnfcImageTemp.setVnfVersion(vnfcImage.getVnfVersion());
														vnfcImageTemp.setVnfcVersion(vnfcImage.getVnfcVersion());

														JSONObject vnfcIm = new JSONObject(vnfcImageTemp);
														RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
																RtJioRMSCacheManager.getInstance().getErmManager()
																		.createNewEventBuilder(HttpMethod.POST)
																		.addQueryParam(
																				BinaryOperationConstantEnum.VNF_ID
																						.getValue(),
																				vnfcImageTemp.getVnfID())
																		.addQueryParam(
																				BinaryOperationConstantEnum.VNF_VERSION
																						.getValue(),
																				vnfcImageTemp.getVnfVersion())
																		.addQueryParam(
																				BinaryOperationConstantEnum.VNFC_VERSION
																						.getValue(),
																				vnfcImageTemp.getVnfcVersion())
																		.addQueryParam(
																				BinaryOperationConstantEnum.VNFC_ID
																						.getValue(),
																				vnfcImageTemp.getVnfcID()),
																RMSEventConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL
																		.getValue(),
																vnfcIm.toString(),
																RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT
																		.getStringValue(),
																eventTracking.getFlowId());

														loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
																this.getClass().getName(), methodName, null,
																"Download Url Published to VNFC : " + vnfcIm.toString(),
																eventTracking.getFlowId(),
																eventTracking.getPublisherName());

														ccAsnPojo.addClearCode(
																ClearCodes.VNFC_IMAGE_UPLOAD_SUCCESS.getValue(),
																ClearCodeLevel.PROTOCOL);

														payload.setType(
																ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
														payload.setHttpStatusCode(HttpServletResponse.SC_OK);

													}
												} catch (Exception e) {
													loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
															this.getClass().getName(), methodName,
															"Error while updating image in ES: "
																	+ vnfcImage.getImageName());
												}

											} else {
												loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
														this.getClass().getName(), methodName,
														"Binary Updation Unsuccessfull : " + pathToFile);
											}

										}
									});

							if (updateBinaryImage != null) {

								loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
										this.getClass().getName(), "run", "Processing Task UPDATE = " + eventTracking);
								ExecutorService executor = Executors.newFixedThreadPool(5);
								executor.submit(updateBinaryImage);
							}

						} else {
							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
									this.getClass().getName(), methodName, "Error in deleteing image: " + pathToFile);
							payload.setHttpStatusCode(500);
							payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
							payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
							payload.setErrorMessage("Error in deleting image: " + pathToFile);
							ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue(),
									ClearCodeLevel.PROTOCOL);
							RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking,
									new JSONObject(payload), null);
							ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
							taskListner.completed(new FileUploadFailure());
							return;

						}

					}
				});

				if (deleteTask != null) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
							"Processing Task DELETE = " + this.eventTracking.toString());
					ExecutorService executor = Executors.newFixedThreadPool(5);
					executor.submit(deleteTask);
				}

			}

			// Removed code to send event to VNFC n writing data in Es

		} catch (Exception ex) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Update Binary Service binary", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in Update Binary Service binary");

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
