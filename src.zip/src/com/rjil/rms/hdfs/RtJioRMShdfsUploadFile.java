package com.rjil.rms.hdfs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.FileUploadSuccess;
import com.rjil.rms.binary.error.NoSpaceAvailable;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.startup.RMSManagerBootstrap;

public class RtJioRMShdfsUploadFile implements RtJioRMShdfsProcess, Runnable {

	private HDFSTaskListener taskListener;
	private String coreSiteXmlPath = RtJioRMShdfsConstants.CORE_SITE_XML;
	private String hdfsSiteXmlPath = RtJioRMShdfsConstants.HDFS_SITE_XML;
	private String source = null;
	private String dest = null;
	private VNFCImage vnfcImage;
	private RMREventPojo eventPojo;
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	public RtJioRMShdfsUploadFile(RMREventPojo eventPojo, VNFCImage vnfcImage, HDFSTaskListener listener) {
		super();	
		this.vnfcImage = vnfcImage;
		this.eventPojo = eventPojo;
		this.taskListener = listener;
	}

	@Override
	public void processHdfsTask() {

		try {

			
			source = vnfcImage.getFilePath() + "/" + vnfcImage.getImageName();
			dest = RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/" + vnfcImage.getVendorName() + "/"
					+  vnfcImage.getVnfName() + "/" + vnfcImage.getVnfcVersion() + "/" + vnfcImage.getVnfcID();
			try {
				
				mkdir(RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue());
				
				mkdir(RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/" + vnfcImage.getVendorName());
				
				mkdir(RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/" + vnfcImage.getVendorName()+"/"+
				 vnfcImage.getVnfName());
				
				mkdir(RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/" + vnfcImage.getVendorName() + "/"
					+"/"+ vnfcImage.getVnfName() + "/" + vnfcImage.getVnfVersion());
				
				mkdir(RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue() + "/" + vnfcImage.getVendorName() + "/"
						+"/"+ vnfcImage.getVnfName() + "/" + vnfcImage.getVnfVersion()+ "/" +vnfcImage.getVnfcID());
				

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
						"All Directories Created...");
			} catch (Exception ex) {
				
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"run", "Error while creating directory", ex);
			}
			copyFromLocal(source, dest);
			String completeDestPath = "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
					+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
					+ RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue()
					+ FolderStructureGenerator.generateHDFSDriectroy(vnfcImage)
					+ "?" + FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + "binary";
			
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"SET THE DESTINATION PATH IN VNFC IMAGE  = " +completeDestPath);
			
			vnfcImage.setFileUrl(completeDestPath);
			vnfcImage.setTimeStamp(System.currentTimeMillis());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File Copied to HDFS Storage...");

			this.taskListener.completed(new FileUploadSuccess());

		} catch (IOException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"run", "Error in Upload Binary", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.NO_SPACE_AVAILABLE_IN_SERVER);
			this.taskListener.completed(new NoSpaceAvailable());
		}
	}

	@Override
	public void run() {

		processHdfsTask();

	}

	public boolean ifExists(Path source) throws IOException {

		Configuration config = new Configuration();
		config.addResource(new Path(coreSiteXmlPath));
		config.addResource(new Path(hdfsSiteXmlPath));
		// config.addResource(new Path(mapredSiteXmlPath));

		FileSystem hdfs = FileSystem.get(config);
		boolean isExists = hdfs.exists(source);
		return isExists;

	}

	public void mkdir(String dir) throws IOException {
		
		System.out.println("Inside mkdir1234567");
		Configuration conf = new Configuration();
		System.out.println("Inside mkdi7");
		conf.addResource(new Path(coreSiteXmlPath));
		conf.addResource(new Path(hdfsSiteXmlPath));
		FileSystem fileSystem = FileSystem.get(conf);

		Path path = new Path(dir);
		System.out.println(path + "  " + fileSystem);
		System.out.println(path.getParent());
		if (fileSystem.exists(path)) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"PAPTH ALREADY EXISTS MAKE DIR Task = " + this.eventPojo.toString());
			return;
		}

		fileSystem.mkdirs(path);
		
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"directory created " + this.eventPojo.toString());
		fileSystem.close();

	}

	public void copyFromLocal(String source, String dest) throws IOException {

		Configuration conf = new Configuration();
		conf.addResource(new Path(coreSiteXmlPath));
		conf.addResource(new Path(hdfsSiteXmlPath));
		conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
		conf.set("fs.file.impl", org.apache.hadoop.fs.LocalFileSystem.class.getName());

		FileSystem fileSystem = FileSystem.get(conf);
		Path srcPath = new Path(source);

		Path dstPath = new Path(dest);
		// Check if the file already exists
		if (!(fileSystem.exists(dstPath))) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"PAPTH NOT EXISTS in CopyFromLocal Function = " + this.eventPojo.toString());
		}

		// Get the filename out of the file path
		String filename = source.substring(source.lastIndexOf('/') + 1, source.length());

		try {
			fileSystem.copyFromLocalFile(srcPath, dstPath);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File " + filename + "copied to " + dest);
			System.out.println("File " + filename + "copied to " + dest);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"run", "File " + filename + "copied to " + dest, e);
		} finally {
			fileSystem.close();
		}
	}

}