package com.rjil.rms.hdfs;

import com.rjil.rms.binary.error.BinaryUploadResponse;

public interface HDFSTaskListener {
	
	void completed(BinaryUploadResponse response);

}
