package com.rjil.rms.hdfs;

public interface RtJioRMShdfsProcess extends Runnable{
	
	void processHdfsTask();

}
