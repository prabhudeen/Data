package com.rjil.rms.hdfs;

public class RtJioRMShdfsConstants {

	public static final String CORE_SITE_XML = "./../configuration/core-site.xml";
	public static final String HDFS_SITE_XML = "./../configuration/hdfs-site.xml";
	public static final String SOURCE_PATH = "/root/NFVSDN/hadoopexample/myFile";
	public static final String DESTINATION_PATH = "";

}
