package com.rjil.rms.broadcast.listener;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.binary.BinaryOperationConstantEnum;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.error.ErrorInPullingThreadException;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.erm.RMRERMHttpParametersAndHeadersIntf;
import com.rjil.rms.es.operation.ESOperationException;
import com.rjil.rms.event.ProcessListner;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.startup.RMSManagerBootstrap;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

/**
 * This listener will be called when modify event will broadcast
 * 
 * @author kiran.jangid
 *
 */

public class BroadCastListenerUpdateBinaryAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		ResponsePayload payload = new ResponsePayload();
		RMREventPojo eventPojo = new RMREventPojo();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		final String methodName = "processListener";

		try {

			// Getting image id from request to Update Image data form Database
			// and Folder
			String vnfcId = broadData.getRequestHeaders().get(BinaryOperationConstantEnum.VNFC_ID.getValue());

			// Getting image data from ES
			String imageStr = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Received Data in Broadcast : " + imageStr + "---" + vnfcId);

			String eventStr = EsManager.getInstance().getHaOperation()
					.getEventData(broadData.getRequestHeaders().get(RMRERMHttpParametersAndHeadersIntf.FLOW_ID) + "_"
							+ broadData.getRequestHeaders().get(RMRERMHttpParametersAndHeadersIntf.BRANCH_ID));

			eventPojo.buildEventPojo(eventStr);

			JsonObject jsonObjectES = (new JsonParser().parse(imageStr)).getAsJsonObject();
			Gson gsonObjES = new Gson();
			VNFCImage vnfcImageOnES = gsonObjES.fromJson(jsonObjectES, VNFCImage.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Updating Image Data : " + imageStr);

			// check existing destination file, return if exist

			String pathToFile = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + "/"
					+ vnfcImageOnES.getVendorName() + "/" + vnfcImageOnES.getVnfName() + "/"
					+ vnfcImageOnES.getVnfVersion() + "/" + vnfcId + "/";

			File dest = new File(pathToFile);
			if (!dest.exists()) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "File Does not Exist at Destination path : " + dest.getAbsolutePath());
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_FILE_NOT_EXIST_AT_DEST.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			}

			// checking Source file exist or not, if not then return with error
			// event Ack

			String provisionBinaryJson = new String(broadData.getRequestStream());

			JsonObject jsonObject = (new JsonParser().parse(provisionBinaryJson)).getAsJsonObject();

			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request : " + provisionBinaryJson);

			File src = new File(vnfcImage.getFilePath() + "/" + vnfcImage.getImageName());

			if (!src.exists()) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "File Does not Exist at path : " + src.getAbsolutePath());

				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("File Does not Exist at Source Path : " + src.getAbsolutePath());
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_FILE_NOT_EXIST_AT_SRC.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			}

			// deleting image, that is already exist

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Deleting image file at path : " + dest.getAbsolutePath());

			String pathToImageFile = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + "/"
					+ vnfcImageOnES.getVendorName() + "/" + vnfcImageOnES.getVnfName() + "/"
					+ vnfcImageOnES.getVnfVersion() + "/" + vnfcId + "/" + vnfcImageOnES.getImageName() + "/";

			Path imageDest = Paths.get(pathToImageFile);

			try {
				Files.delete(imageDest);
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Image Deleted Succesfully on broadcast  : " + imageDest);
			} catch (NoSuchFileException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error : Older file forcefully deleted by somebody", e);

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
				payload.setErrorMessage("Error : Older file forcefully deleted by somebody");
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_OLDER_FILE_NOT_PRESENT.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			} catch (DirectoryNotEmptyException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error : Directory not empty", e);

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
				payload.setErrorMessage("Error : Directory not empty");
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_OLDER_FILE_DIRECTORY_NOT_PRESENT.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			} catch (IOException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error : Internal IO Error", e);

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
				payload.setErrorMessage("Error : Internal IO Error");
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

				ccAsnPojo.addClearCode(
						ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_INTERNAL_IO_WHEN_OLDER_FILE_DELETE_OPERATION.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			} catch (SecurityException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error : Security deny to delete older file", e);

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
				payload.setErrorMessage("Error : Security deny to delete older file");
				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_SECURITY_DENY_TO_DELETE_OLD_FILE.getValue(),
						ClearCodeLevel.PROTOCOL);

				return;
			}

			provisionBinaryInRMR(vnfcImage, eventPojo);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error : Internal Server Error in updaing vnfc Image", e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue());
			payload.setErrorMessage("Error : Internal Server Error in updaing vnfc Image");
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload), null);

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void provisionBinaryInRMR(VNFCImage vnfcImage, RMREventPojo eventPojo)
			throws ErrorInPullingThreadException {

		final String methodName = "provisionBinaryInRMR";

		DownloadBinaryThread downloadBinaryThread;

		loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName, null,
				"File Exist : " + vnfcImage.getImageName(), eventPojo.getFlowId(), eventPojo.getPublisherName());

		downloadBinaryThread = RtJioRMSCacheManager.getInstance().getUploadBinaryImageThread();

		if (downloadBinaryThread != null) {

			downloadBinaryThread.downloadBinary(vnfcImage, new ProcessListner() {

				@Override
				public void completed(BinaryUploadResponse response) {

					ResponsePayload payload = response.getResponse();

					ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

					if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

						loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, null, "File Copied Successfully", eventPojo.getFlowId(),
								eventPojo.getPublisherName());

						String strUrl = "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
								+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
								+ RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue()
								+ RMSManagerBootstrap.rmsManager.getFolderStructureGenerator()
										.generateFolderStructure(vnfcImage, vnfcImage.getVnfcID())
								+ "?" + FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + "binary";

						vnfcImage.setFileUrl(strUrl);
						vnfcImage.setTimeStamp(System.currentTimeMillis());

						try {

							if (EsManager.getInstance().getVnfOperationImpl().uploadVNFCImage(vnfcImage.getVnfcID(),
									vnfcImage.toString())) {

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
										this.getClass().getName(), methodName, null,
										"Data updated In ES Successfully : vnfc Id " + vnfcImage.getVnfcID()
												+ " | Data = " + vnfcImage.toString(),
										eventPojo.getFlowId(), eventPojo.getPublisherName());

								VNFCImage vnfcImageTemp = new VNFCImage();
								vnfcImageTemp.setFileUrl(RtJioCommonMethods.generateDownloadUrlForImage(vnfcImage));
								vnfcImageTemp.setImageName(vnfcImage.getImageName());
								vnfcImageTemp.setFormat(vnfcImage.getFormat());
								vnfcImageTemp.setVnfID(vnfcImage.getVnfID());
								vnfcImageTemp.setVnfcID(vnfcImage.getVnfcID());
								vnfcImageTemp.setVnfVersion(vnfcImage.getVnfVersion());
								vnfcImageTemp.setVnfcVersion(vnfcImage.getVnfcVersion());

								JSONObject vnfcIm = new JSONObject(vnfcImageTemp);

								RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
										RtJioRMSCacheManager.getInstance().getErmManager()
												.createNewEventBuilder(HttpMethod.POST)
												.addQueryParam(BinaryOperationConstantEnum.VNF_ID.getValue(),
														vnfcImageTemp.getVnfID())
												.addQueryParam(BinaryOperationConstantEnum.VNF_VERSION.getValue(),
														vnfcImageTemp.getVnfVersion())
												.addQueryParam(BinaryOperationConstantEnum.VNFC_VERSION.getValue(),
														vnfcImageTemp.getVnfcVersion())
												.addQueryParam(BinaryOperationConstantEnum.VNFC_ID.getValue(),
														vnfcImageTemp.getVnfcID()),
										RMSEventConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL.getValue(),
										vnfcIm.toString(), RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(),
										eventPojo.getFlowId());

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
										this.getClass().getName(), methodName, null,
										"Updated Url Published to VNFC : " + vnfcIm.toString(), eventPojo.getFlowId(),
										eventPojo.getPublisherName());

								payload.setHttpStatusCode(200);
								payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

								RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo,
										new JSONObject(payload), null);

							} else {

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
										this.getClass().getName(), methodName, null,
										"Error in Updating Data In ES : vnfc id = " + vnfcImage.getVnfcID()
												+ " | Data = " + vnfcImage.toString(),
										eventPojo.getFlowId(), eventPojo.getPublisherName());

								payload.setHttpStatusCode(500);
								payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
								payload.setErrorCode(ClearCodes.VNFC_IMAGE_UPLOAD_DATABASE_WRITE_FAILURE.getValue());
								payload.setErrorMessage(
										"Error in Updating Data In ES : vnfc id = " + vnfcImage.getVnfcID());

								RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo,
										new JSONObject(payload), null);

								ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_DATABASE_UPDATE_FAILURE.getValue(),
										ClearCodeLevel.PROTOCOL);

							}

						} catch (ESOperationException e) {

							loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
									this.getClass().getName(), methodName, eventPojo.getFlowId(),
									eventPojo.getPublisherName(), e);

							payload.setHttpStatusCode(500);
							payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
							payload.setErrorMessage("Error in Updating Data in ES");

							RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload),
									null);

							ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_ES_OPERATION_FAILURE.getValue(),
									ClearCodeLevel.PROTOCOL);
						}

					} else {

						// throw new ES

						loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
								methodName, null,
								"File Copied Failure : File Not copied to Location = " + payload.getErrorMessage(),
								eventPojo.getFlowId(), eventPojo.getPublisherName());

						payload.setHttpStatusCode(500);
						payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
						payload.setErrorMessage(
								"File Copied Failure : File Not copied to Location = " + payload.getErrorMessage());

						RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payload),
								null);

						ccAsnPojo.addClearCode(
								ClearCodes.VNFC_IMAGE_UPDATE_FAILURE_FILE_COPY_TO_LOCATION_FAILURE.getValue(),
								ClearCodeLevel.PROTOCOL);
					}

					// RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo,
					// new JSONObject(payload), null);
					ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

				}
			});

			RtJioRMSCacheManager.getInstance().getExecutorService().execute(downloadBinaryThread);

		} else {
			throw new ErrorInPullingThreadException();
		}

	}

}
