package com.rjil.rms.broadcast.listener;

import java.io.File;

import org.apache.commons.io.FileUtils;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerUploadAlarmDictionaryAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		try {

			String fileName = broadData.getRequestHeaders()
					.get(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String vnfId = broadData.getRequestHeaders().get(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
			String vnfVersion = broadData.getRequestHeaders()
					.get(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
			String vendorId = broadData.getRequestHeaders()
					.get(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
			String targetPath = RtJioCommonMethods.generateFCAPSRep(FCAPSOperationConstantsEnum.FCAPS_ALARM.getValue(),
					vendorId, vnfId, vnfVersion);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Uploading alarm sheet");

			FileUtils.writeByteArrayToFile(new File(targetPath, fileName), broadData.getRequestStream());

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Uploading alarm sheet Error", e);

		}

	}

}
