package com.rjil.rms.broadcast.listener;

import java.util.Map;

import com.google.gson.Gson;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.ui.metadata.MetadataManager;
import com.rjil.rms.ui.metadata.MetadataOperationConstantsEnum;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;
import com.rjil.rms.ui.metadata.error.DuplicateElementError;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerAddUIMetadataAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Request to add Metadata Info for | request data = " + broadData.toString());

		String type = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.TYPE.getValue());
		String category = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Request to add Metadata Info for | type = " + type + " | category = " + category);

		try {

			if (type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())) {

				String parameterList = new String(broadData.getRequestStream());

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Parameters are adding = " + parameterList);

				Gson gsonParser = new Gson();

				Map<String, Object> paramMap = gsonParser.fromJson(parameterList, Map.class);

				// check parameter added successful or not

				if (!MetadataManager.getInstance().getOperation().addMetadata(category, paramMap)) {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, "Error in add metadata");
				}

				return;

			}

			// check type is parameter and add single parameter in metadata file
			if (type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue())) {

				String format = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.FORMAT.getValue());
				String parameter = broadData.getRequestHeaders()
						.get(MetadataOperationConstantsEnum.PARAMETER.getValue());
				String value = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.VALUE.getValue());

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Request to add Metadata Info for | parameter = " + parameter + " | key = "
								+ category + " | value = " + value);

				Object valueNew;

				if (format.equals(MetadataOperationConstantsEnum.STRING.getValue())) {
					valueNew = value;
				} else if (format.equals(MetadataOperationConstantsEnum.NUMBER.getValue())) {
					valueNew = Integer.valueOf(value);
				} else {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, "Invalid format");

					return;
				}

				// check parameter added successful or not
				if (!MetadataManager.getInstance().getOperation().addMetadata(category, parameter, valueNew)) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, "Error in adding Parameter in Category");

					return;
				}

				return;

			}

		} catch (DuplicateElementError e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in add metadata due to data is duplicate available", e);
		} catch (DataNotAvailableError e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in add metadata due to data is not available", e);
		}

	}

}
