package com.rjil.rms.broadcast.listener;

import java.nio.file.NoSuchFileException;
import com.google.gson.Gson;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerDeleteBinaryAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		try {

			String vnfcId = broadData.getRequestHeaders().get("vnfcId");

			String vnfcData = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"File Deleting from vnfc : " + vnfcData);

			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(vnfcData, VNFCImage.class);

			// deleting image from ES and file folder
			if (RtJioCommonMethods.deleteFileFromDestination(vnfcImage)) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Deleted Image File for Image ID : " + vnfcImage.getVnfcID());

				if (EsManager.getInstance().getVnfOperationImpl().deleteVNFCImage(vnfcImage.getVnfcID())) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Deleted ES Data for Image ID : " + vnfcImage.getVnfcID());

				} else {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, "Error in Deleting ES Data for Image ID : " + vnfcImage.getVnfcID());

				}

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Error in File Deletion for Vnfc : " + vnfcId);

			}

		} catch (NoSuchFileException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting file in folder", e);

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting binary", ex);

		}

	}

}
