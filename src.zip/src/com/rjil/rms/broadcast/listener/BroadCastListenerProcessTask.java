package com.rjil.rms.broadcast.listener;

import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerProcessTask implements Runnable {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RMRBroadcastPojo broadData;

	/**
	 * 
	 * @param broadData
	 */

	public BroadCastListenerProcessTask(RMRBroadcastPojo broadData) {
		this.broadData = broadData;
	}

	/**
	 * 
	 */

	public BroadCastListenerProcessTask() {
	}

	@Override
	public void run() {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Processing Broadcast Listener In Task = " + this.broadData.toString());

		BroadcastListener processBroadcastListener = null;

		switch (this.broadData.getBroadcastAction()) {
		case RMSEventConstant.RMR_EVENT_ADD_METADATA:
			processBroadcastListener = new BroadCastListenerAddUIMetadataAction();
			break;
		case RMSEventConstant.RMR_EVENT_MODIFY_METADATA:
			processBroadcastListener = new BroadCastListenerModifyUIMetadataAction();
			break;
		case RMSEventConstant.RMR_EVENT_DELETE_METADATA:
			processBroadcastListener = new BroadCastListenerDeleteUIMetadataAction();
			break;
//		case RMSEventConstant.RMR_NOTIFICATION_EVENT_VNF_TERMINATION:
//			processBroadcastListener = new BroadCastListenerNotifyVnfDeletionAction();
//			break;
		case RMSEventConstant.RMS_EVENT_BINARY_PROVISIONING:
			processBroadcastListener = new BroadCastListenerUploadBinaryAction();
			break;
		case RMSEventConstant.RMS_EVENT_ALARM_UPLOAD:
			processBroadcastListener = new BroadCastListenerUploadAlarmDictionaryAction();
			break;
		case RMSEventConstant.RMS_EVENT_COUNTER_UPLOAD:
			processBroadcastListener = new BroadCastListenerUploadCounterDictionaryAction();
			break;
		case RMSEventConstant.RMS_EVENT_CONFIG_UPLOAD:
			processBroadcastListener = new BroadCastListenerUploadConfigDictionaryAction();
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_DELETE:
			processBroadcastListener = new BroadCastListenerDeleteBinaryAction();
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_UPDATE:
			processBroadcastListener = new BroadCastListenerUpdateBinaryAction();
			break;
			
		default:
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"Broadcast Action is not handled = " + this.broadData.getBroadcastAction());
			break;
		}

		if (processBroadcastListener != null) {
			processBroadcastListener.processListener(broadData);
		}

	}
}
