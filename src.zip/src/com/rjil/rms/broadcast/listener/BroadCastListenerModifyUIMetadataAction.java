package com.rjil.rms.broadcast.listener;

import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.ui.metadata.MetadataManager;
import com.rjil.rms.ui.metadata.MetadataOperationConstantsEnum;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerModifyUIMetadataAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request to modify Metadata Info for | request data = " + broadData.toString());

			String category = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.CATEGORY.getValue());
			String parameter = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.PARAMETER.getValue());
			String value = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.VALUE.getValue());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request to modify Metadata Info for | category = " + category + " , parameter = " + parameter
							+ " , value = " + value);

			String format = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.FORMAT.getValue());

			Object valueNew;

			if (format.equals(MetadataOperationConstantsEnum.STRING.getValue())) {
				valueNew = value;
			} else if (format.equals(MetadataOperationConstantsEnum.NUMBER.getValue())) {
				valueNew = Integer.valueOf(value);
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Invalid Format");
				return;
			}

			// check parameter modifying successful or not
			if (!MetadataManager.getInstance().getOperation().setMetadataKeyValue(category, parameter, valueNew)) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

				return;
			}

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in modify metadata due to data is not available", e);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in modify metadata ", e);

		}

	}

}
