package com.rjil.rms.broadcast.listener;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import com.google.gson.Gson;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerNotifyVnfDeletionAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		try {

			String filePath = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue()
					+ broadData.getRequestHeaders().get("filePath");

			String vnfcId = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue()
					+ broadData.getRequestHeaders().get("vnfcId");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"File Deleting from Folder : " + filePath);

			String vnfcData = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"File Deleting from vnfc : " + vnfcData);

			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(vnfcData, VNFCImage.class);

			try {

				// deleting image from ES and file folder
				if (RtJioCommonMethods.deleteFileFromDestination(vnfcImage)) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Deleted Image File for Image ID : " + vnfcImage.getVnfcID());

					if (EsManager.getInstance().getVnfOperationImpl().deleteVNFCImage(vnfcImage.getVnfcID())) {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, "Deleted ES Data for Image ID : " + vnfcImage.getVnfcID());

					} else {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
								methodName, "Error in Deleting ES Data for Image ID : " + vnfcImage.getVnfcID());

					}

				} else {

				}

			} catch (NoSuchFileException e) {

				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Image File not available on this instance for vnfc id : " + vnfcImage.getVnfcID(),
						e);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Sending Broadcast to Other Instance ");

			}

			Path directory = Paths.get(filePath);

			Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) throws IOException {

					// this will work because it's always a File
					Files.delete(file);
					return FileVisitResult.CONTINUE;
				}

				@Override
				public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
					// this will work because Files in the directory are already
					// deleted
					Files.delete(dir);
					return FileVisitResult.CONTINUE;
				}
			});

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"File Deleted from Folder : " + filePath);

		} catch (NoSuchFileException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting file in folder", e);

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting binary", ex);

		}

	}

}
