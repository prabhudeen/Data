package com.rjil.rms.broadcast.listener;

import java.io.File;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.error.ErrorInPullingThreadException;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.event.ProcessListner;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerUploadBinaryAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CLASS_NAME = "BroadCastListenerUploadBinaryAction";

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		try {

			String provisionBinaryJson = new String(broadData.getRequestStream());

			JsonObject jsonObject = (new JsonParser().parse(provisionBinaryJson)).getAsJsonObject();

			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
					"Request : " + provisionBinaryJson);

			File src = new File(vnfcImage.getFilePath() + "/" + vnfcImage.getImageName());

			if (!src.exists()) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "File Does not Exist at path : " + src.getAbsolutePath());
				return;
			}

			provisionBinaryInRMR(vnfcImage);

		} catch (Exception ex) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in provision binary", ex);
		}

	}

	private void provisionBinaryInRMR(VNFCImage vnfcImage) throws ErrorInPullingThreadException {

		final String methodName = "provisionBinaryInRMR";

		DownloadBinaryThread downloadBinaryThread;

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"File Exist : " + vnfcImage.getImageName());

		downloadBinaryThread = RtJioRMSCacheManager.getInstance().getUploadBinaryImageThread();

		if (downloadBinaryThread != null) {

			downloadBinaryThread.downloadBinary(vnfcImage, new ProcessListner() {

				@Override
				public void completed(BinaryUploadResponse response) {

					ResponsePayload payload = response.getResponse();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "payload = " + payload.toString());

					if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, "File Copied Successfully");

					} else {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName,
								"File Copied Failure : File Not copied to Location = " + payload.getErrorMessage());

					}

				}
			});

			RtJioRMSCacheManager.getInstance().getExecutorService().execute(downloadBinaryThread);

		} else {
			throw new ErrorInPullingThreadException();
		}

	}

}
