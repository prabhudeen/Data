package com.rjil.rms.broadcast.listener;

import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;

/**
 * 
 * @author Kiran.Jangid
 *
 */

@FunctionalInterface
public interface BroadcastListener {

	/**
	 * 
	 * @param broadData
	 */
	void processListener(RMRBroadcastPojo broadData);

}
