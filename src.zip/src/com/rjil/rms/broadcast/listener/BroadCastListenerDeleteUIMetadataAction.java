package com.rjil.rms.broadcast.listener;

import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.ui.metadata.MetadataManager;
import com.rjil.rms.ui.metadata.MetadataOperationConstantsEnum;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastListenerDeleteUIMetadataAction implements BroadcastListener {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processListener(RMRBroadcastPojo broadData) {

		final String methodName = "processListener";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Request to delete Metadata Info for | request data = " + broadData.toString());

		try {

			String type = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.TYPE.getValue());
			String category = broadData.getRequestHeaders().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

			// check type is parameter and add single parameter in metadata file
			if (type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue())) {

				String parameter = broadData.getRequestHeaders()
						.get(MetadataOperationConstantsEnum.PARAMETER.getValue());

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName,
						"Request to delete Metadata Info for | parameter = " + parameter + " | category = " + category);

				// check parameter deleted successful or not
				if (!MetadataManager.getInstance().getOperation().deleteMetadata(category, parameter)) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

					return;
				}

				return;

			}

			// check type is category and add multiple parameter in metadata
			// file
			if (type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())) {

				// check category deleted successful or not
				if (!MetadataManager.getInstance().getOperation().deleteMetadata(category)) {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
					return;
				}

				return;

			}

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in delete metadata due to data is not available", e);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in delete metadata ", e);

		}

	}

}
