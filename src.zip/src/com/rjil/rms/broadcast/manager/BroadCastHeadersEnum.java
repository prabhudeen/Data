package com.rjil.rms.broadcast.manager;

/**
 * Binary Operation Constant
 * 
 * @author kiran.jangid
 *
 */

public enum BroadCastHeadersEnum {

	INSTANCE_ID("Instance-Id"),

	BROADCAST_ACTION("Broadcast-Action");

	private String value;

	private BroadCastHeadersEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
