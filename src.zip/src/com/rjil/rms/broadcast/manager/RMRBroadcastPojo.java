package com.rjil.rms.broadcast.manager;

import java.util.Iterator;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMRBroadcastPojo {

	private String instanceId;
	private String broadcastAction;
	private Map<String, String> requestParams;
	private Map<String, String> requestHeaders;
	private JSONObject requestJson;
	private byte[] requestStream;
	private long timeStamp;
	private static final String HEADERS = "headers";
	private static final String QUERY_PARAMETERS = "parameters";
	private static final String REQUEST_BODY = "data";

	private static final LoggerWriter loggerWriter = LoggerWriter.getInstance();

	public JSONObject getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(JSONObject requestJson) {
		this.requestJson = requestJson;
	}

	public Map<String, String> getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(Map<String, String> requestParams) {
		this.requestParams = requestParams;
	}

	public byte[] getRequestStream() {
		return requestStream;
	}

	public void setRequestStream(byte[] requestStream) {
		this.requestStream = requestStream;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public long getTimeStamp() {
		return timeStamp;
	}

	@Override
	public String toString() {

		try {

			JSONObject headers = new JSONObject();

			// v1.0 ERM
			headers.put(BroadCastHeadersEnum.BROADCAST_ACTION.getValue(), this.getBroadcastAction());
			headers.put(BroadCastHeadersEnum.INSTANCE_ID.getValue(), this.getInstanceId());

			if (this.getRequestHeaders() != null) {
				Iterator<String> headersTemp = this.getRequestHeaders().keySet().iterator();
				while (headersTemp.hasNext()) {
					String string = headersTemp.next();
					headers.put(string, this.getRequestHeaders().get(string));
				}
			}

			JSONObject eventDataStr = new JSONObject();
			eventDataStr.put(HEADERS, headers);

			if (this.getRequestJson() != null) {
				JSONObject data = new JSONObject(this.getRequestJson());
				eventDataStr.put(REQUEST_BODY, data);
			} else if (this.getRequestStream() != null && this.getRequestStream().length > 0) {
				eventDataStr.put(REQUEST_BODY, new String(this.getRequestStream()));
			}

			if (this.getRequestParams() != null) {
				JSONObject param = new JSONObject(this.getRequestParams());
				eventDataStr.put(QUERY_PARAMETERS, param);
			}

			return eventDataStr.toString();

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"toString", "Error in converting broadcast pojo to json string :", e);
			return "";
		}
	}

	/**
	 * 
	 * @param eventDataStr
	 * @return
	 * @throws JSONException
	 */

	public RMRBroadcastPojo getEventPojo(String eventDataStr) throws JSONException {

		RMRBroadcastPojo eventData = new RMRBroadcastPojo();

		// Complete Event Data Str
		JSONObject eventJson = new JSONObject(eventDataStr);

		// Getting header, query parameter and Body
		JSONObject headersStr = eventJson.getJSONObject(HEADERS);

		eventData.setBroadcastAction(headersStr.getString(BroadCastHeadersEnum.BROADCAST_ACTION.getValue()));
		eventData.setInstanceId(headersStr.getString(BroadCastHeadersEnum.INSTANCE_ID.getValue()));

		if (eventJson.has(QUERY_PARAMETERS)) {
			JSONObject parametersStr = eventJson.getJSONObject(QUERY_PARAMETERS);
			Gson gson = new Gson();
			Map<String, String> params = gson.fromJson(parametersStr.toString(), Map.class);
			eventData.setRequestParams(params);
		}

		if (eventJson.has(REQUEST_BODY)) {
			JSONObject datasStr = eventJson.getJSONObject(REQUEST_BODY);
			eventData.setRequestJson(datasStr);
		}

		return eventData;

	}

	/**
	 * @return the instanceId
	 */
	public String getInstanceId() {
		return instanceId;
	}

	public void setBroadcastAction(String broadcastAction) {
		this.broadcastAction = broadcastAction;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	/**
	 * @return the broadcastAction
	 */
	public String getBroadcastAction() {
		return broadcastAction;
	}

	/**
	 * @return the requestHeaders
	 */
	public Map<String, String> getRequestHeaders() {
		return requestHeaders;
	}

	/**
	 * @param requestHeaders
	 *            the requestHeaders to set
	 */
	public void setRequestHeaders(Map<String, String> requestHeaders) {
		this.requestHeaders = requestHeaders;
	}

}
