package com.rjil.rms.broadcast.manager;

import com.rjil.rms.broadcast.listener.BroadCastListenerProcessTask;
import com.rjil.rms.broadcast.sender.BroadCastEventProcessTask;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRHAManager {

	private static RMRHAManager manager;

	private RMRHAManager() {
	}

	public static RMRHAManager getInstance() {

		if (manager == null) {
			manager = new RMRHAManager();
		}

		return manager;
	}

	/**
	 * 
	 * @param eventTracking
	 */

	public void broadcastEvent(RMREventPojo eventTracking) {

		RMRBroadcastPojo broadcastData = new RMRBroadcastPojo();
		broadcastData.setBroadcastAction(eventTracking.getEventName());
		broadcastData.setInstanceId(RtJioRMSCacheManager.getInstance().getMicroserviceId());

		if (eventTracking.getRequestStream() != null && eventTracking.getRequestStream().length > 0) {
			broadcastData.setRequestStream(eventTracking.getRequestStream());
		}

		if (eventTracking.getRequestParams() != null) {
			broadcastData.setRequestParams(eventTracking.getRequestParams());
		}
		
		if (eventTracking.getRequestHeaders() != null) {
			broadcastData.setRequestHeaders(eventTracking.getRequestHeaders());
		}

		RtJioRMSCacheManager.getInstance().getThreadPoolExecutor()
				.execute(new BroadCastEventProcessTask(broadcastData));
	}

	/**
	 * 
	 * @param broadData
	 */

	public void broadcastListener(RMRBroadcastPojo broadData) {
		RtJioRMSCacheManager.getInstance().getThreadPoolExecutor().execute(new BroadCastListenerProcessTask(broadData));
	}

}
