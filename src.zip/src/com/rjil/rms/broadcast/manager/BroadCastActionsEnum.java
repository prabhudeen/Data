package com.rjil.rms.broadcast.manager;

/**
 * Binary Operation Constant
 * 
 * @author kiran.jangid
 *
 */

public enum BroadCastActionsEnum {

	VNF_ID("vnfID");

	private String value;

	private BroadCastActionsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
