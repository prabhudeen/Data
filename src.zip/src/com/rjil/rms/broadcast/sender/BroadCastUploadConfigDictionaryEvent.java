package com.rjil.rms.broadcast.sender;

import java.util.HashMap;
import java.util.Set;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.broadcast.manager.BroadCastHeadersEnum;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastUploadConfigDictionaryEvent implements ProcessBroadcast {

	private RMRBroadcastPojo broadcastPojo;
	
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	/**
	 * 
	 * @param broadcastPojo
	 */

	public BroadCastUploadConfigDictionaryEvent(RMRBroadcastPojo broadcastPojo) {
		this.broadcastPojo = broadcastPojo;
	}

	@Override
	public void processTask() {

		HashMap<String, String> headersData = new HashMap<>();
		headersData.put(BroadCastHeadersEnum.BROADCAST_ACTION.getValue(), this.broadcastPojo.getBroadcastAction());
		headersData.put(BroadCastHeadersEnum.INSTANCE_ID.getValue(),
				RtJioRMSCacheManager.getInstance().getMicroserviceId());

		Set<String> headersName = this.broadcastPojo.getRequestParams().keySet();

		for (String string : headersName) {
			headersData.put(string, this.broadcastPojo.getRequestParams().get(string));
		}

		String requestBody = "NA";

		if (this.broadcastPojo.getRequestStream() != null && this.broadcastPojo.getRequestStream().length > 0) {
			requestBody = new String(this.broadcastPojo.getRequestStream());
		}
		
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Notify Config Dictionary Broadcast : Request Body : " + requestBody + " , Subsciber List : NA"
						+ " , Headers : " + headersData + " , Context : "
						+ RtJioRMSConfigParamEnum.RMR_BROADCAST_CONTEXT.getStringValue());

		OamClientManager.getInstance().brodcastData(requestBody, "NA", headersData,
				RtJioRMSConfigParamEnum.RMR_BROADCAST_CONTEXT.getStringValue());

	}

}
