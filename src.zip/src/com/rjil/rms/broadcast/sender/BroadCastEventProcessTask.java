package com.rjil.rms.broadcast.sender;

import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Thread to Process all dump Event
 * 
 * @author Kiran.Jangid
 *
 */

public class BroadCastEventProcessTask implements Runnable {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RMRBroadcastPojo eventPojo;

	/**
	 * 
	 * @param eventPojo
	 */

	public BroadCastEventProcessTask(RMRBroadcastPojo eventPojo) {
		this.eventPojo = eventPojo;
	}

	/**
	 * 
	 */

	public BroadCastEventProcessTask() {
		/**
		 * Default
		 */
	}

	@Override
	public void run() {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Processing Broadcast Sender In Task = " + this.eventPojo.toString());

		ProcessBroadcast processBroadcast = null;

		switch (this.eventPojo.getBroadcastAction()) {
		case RMSEventConstant.RMR_EVENT_ADD_METADATA:
			processBroadcast = new BroadCastAddUIMetadataEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMR_EVENT_MODIFY_METADATA:
			processBroadcast = new BroadCastModifyUIMetadataEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMR_EVENT_DELETE_METADATA:
			processBroadcast = new BroadCastDeleteUIMetadataEvent(this.eventPojo);
			break;
//		case RMSEventConstant.RMR_NOTIFICATION_EVENT_VNF_TERMINATION:
//			processBroadcast = new BroadCastNotifyVnfDeletionEvent(this.eventPojo);
//			break;
		case RMSEventConstant.RMS_EVENT_BINARY_PROVISIONING:
			processBroadcast = new BroadCastUploadBinaryEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMS_EVENT_ALARM_UPLOAD:
			processBroadcast = new BroadCastUploadAlarmDictionaryEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMS_EVENT_COUNTER_UPLOAD:
			processBroadcast = new BroadCastUploadCounterDictionaryEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMS_EVENT_CONFIG_UPLOAD:
			processBroadcast = new BroadCastUploadConfigDictionaryEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_DELETE:
			processBroadcast = new BroadCastDeleteBinaryEvent(this.eventPojo);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_UPDATE:
			processBroadcast=new BroadCastUpdateBinaryEvent(this.eventPojo);
			break;
		default:
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"Invalid Broadcast Action = " + this.eventPojo.getBroadcastAction());
			break;
		}

		if (processBroadcast != null) {
			processBroadcast.processTask();
		}

	}

}
