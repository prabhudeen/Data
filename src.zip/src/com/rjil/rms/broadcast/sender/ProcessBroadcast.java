package com.rjil.rms.broadcast.sender;

/**
 * 
 * @author Kiran.Jangid
 *
 */

@FunctionalInterface
public interface ProcessBroadcast {

	/**
	 * 
	 * @param eventPojo
	 */

	void processTask();

}
