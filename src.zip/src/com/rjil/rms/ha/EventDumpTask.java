package com.rjil.rms.ha;

import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Thread to Dump Event
 * 
 * @author Kiran.Jangid
 *
 */

public class EventDumpTask implements Runnable {

	private RMREventPojo eventData;
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	/**
	 * 
	 * @param eventData
	 */

	public EventDumpTask(RMREventPojo eventData) {
		this.eventData = eventData;
	}

	public EventDumpTask() {
		/**
		 * Default Constructor
		 */
	}

	@Override
	public void run() {

		String identifier = eventData.getFlowId() + "_" + eventData.getBranchId();
		String eventDataStr = eventData.toString();

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Event Duming Process : " + identifier + " | Event Data : " + eventDataStr);

		EsManager.getInstance().getHaOperation().dumpEventData(identifier, eventDataStr);

	}

}
