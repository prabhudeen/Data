package com.rjil.rms.ha;

import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMRSubscribedEvent;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.RMREventProcessor;

/**
 * Thread to Process all dump Event
 * 
 * @author Kiran.Jangid
 *
 */

public class DumpEventProcessTask implements Runnable {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RMREventPojo eventPojo;

	/**
	 * 
	 * @param eventPojo
	 */

	public DumpEventProcessTask(RMREventPojo eventPojo) {
		this.eventPojo = eventPojo;
	}

	/**
	 * 
	 */

	public DumpEventProcessTask() {
		/**
		 * Default
		 */
	}

	@Override
	public void run() {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
				"Processing Data In Task = " + this.eventPojo.toString());

		RMRSubscribedEvent subscribedEvent = new RMRSubscribedEvent();
		RMREventProcessor processEvent = subscribedEvent.getEventObject(this.eventPojo.getEventName());
		processEvent.processEvent(this.eventPojo);

	}

}
