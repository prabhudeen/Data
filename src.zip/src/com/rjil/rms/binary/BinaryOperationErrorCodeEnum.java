package com.rjil.rms.binary;

/**
 * Binary Life Cycle Management Error Code
 * 
 * @author kiran.jangid
 *
 */

public enum BinaryOperationErrorCodeEnum {

	FILE_NOT_EXIST(3101, "File Not Exist"),

	FILE_CORRUPT(3102, "File Corrupt");

	private int errorCode;
	private String errorMessage;

	private BinaryOperationErrorCodeEnum(int index, String value) {
		this.errorCode = index;
		this.errorMessage = value;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
