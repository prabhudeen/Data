package com.rjil.rms.binary;

import org.json.JSONObject;

/**
 * 
 * @author Sandeep.Narula
 *
 */

public class VNFCImage {

	private String vnfID;
	private String vnfName;
	private String vnfVersion;

	private String vnfcID;
	private String vnfcName;
	private String vnfcVersion;

	private String vendorName;
	private String vendorID;

	private String fileUrl;
	private String filePath;

	private String imageName;
	private String format;
	private String imageDescription;

	private long timeStamp;

	public String getVnfID() {
		return vnfID;
	}

	public void setVnfID(String vnfID) {
		this.vnfID = vnfID;
	}

	public String getVnfName() {
		return vnfName;
	}

	public void setVnfName(String vnfName) {
		this.vnfName = vnfName;
	}

	public String getVnfcName() {
		return vnfcName;
	}

	public void setVnfcName(String vnfcName) {
		this.vnfcName = vnfcName;
	}

	public String getVnfcID() {
		return vnfcID;
	}

	public void setVnfcID(String vnfcID) {
		this.vnfcID = vnfcID;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorID() {
		return vendorID;
	}

	public void setVendorID(String vendorID) {
		this.vendorID = vendorID;
	}

	public String getVnfVersion() {
		return vnfVersion;
	}

	public void setVnfVersion(String vnfVersion) {
		this.vnfVersion = vnfVersion;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	@Override
	public String toString() {
		return new JSONObject(this).toString();
	}

	public String getVnfcVersion() {
		return vnfcVersion;
	}

	public void setVnfcVersion(String vnfcVersion) {
		this.vnfcVersion = vnfcVersion;
	}

	/**
	 * @return the imageDescription
	 */
	public String getImageDescription() {
		return imageDescription;
	}

	/**
	 * @param imageDescription
	 *            the imageDescription to set
	 */
	public void setImageDescription(String imageDescription) {
		this.imageDescription = imageDescription;
	}

	/**
	 * @return the timeStamp
	 */
	public long getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}

}
