package com.rjil.rms.binary;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * Interface to operate binary. It include provision binary, download binary,
 * update binary, delete binary, view binaries
 * 
 * @author kiran.jangid
 *
 */

public interface BinaryManager {

	/**
	 * 
	 * @param eventTracking
	 */

	void provisionBinary(RMREventPojo eventTracking);

	/**
	 * To download Binary
	 * 
	 * @param eventTracking
	 */

	void downloadBinary(RMREventPojo eventTracking);

	/**
	 * To update Binary
	 * 
	 * @param eventTracking
	 */

	void updateBinary(RMREventPojo eventTracking);

	/**
	 * To Delete Binary
	 * 
	 * @param eventTracking
	 */

	void deleteBinary(RMREventPojo eventTracking);

	/**
	 * To View Binary
	 * 
	 * @param eventTracking
	 */

	void getBinary(RMREventPojo eventTracking);

	/**
	 * To View Binary List
	 * 
	 * @param eventTracking
	 */

	void getBinaryList(RMREventPojo eventTracking);

}
