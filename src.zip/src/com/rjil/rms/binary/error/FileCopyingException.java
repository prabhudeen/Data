package com.rjil.rms.binary.error;

/**
 * 
 * Error in Pulling Thread from Pool
 * 
 * @author Kiran.Jangid
 *
 */

public class FileCopyingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param errorMessage
	 */
	public FileCopyingException(String errorMessage) {
		super(errorMessage);
	}
	
	/**
	 * Error When File Copying Exception
	 */

	public FileCopyingException() {
		super();
	}

}
