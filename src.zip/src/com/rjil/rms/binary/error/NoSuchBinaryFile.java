package com.rjil.rms.binary.error;

public class NoSuchBinaryFile extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "No File Available in HDFS File System";
	}

}