package com.rjil.rms.binary.error;

/**
 * Interface to handle Binary Upload Response
 * 
 * @author Kiran.Jangid
 *
 */

@FunctionalInterface
public interface UploadResponse {

	/**
	 * 
	 * @param response
	 */
	void completed(BinaryUploadResponse response);

}
