package com.rjil.rms.binary.error;

import javax.servlet.http.HttpServletResponse;

import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class FileCorruptError extends BinaryUploadResponse {

	static final String ERROR_MESSAGE = "File has been Corrupted";
	static final String ERROR_CODE = ClearCodes.FILE_HAS_BEEN_CORRUPTED.getValue();

	/**
	 * File Corrupt Error
	 */

	public FileCorruptError() {
		this.payload = new ResponsePayload();
		buildResponse();
	}

	@Override
	protected void buildResponse() {
		this.payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
		this.payload.setErrorMessage(ERROR_MESSAGE);
		this.payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		this.payload.setErrorCode(ERROR_CODE);
	}

}
