package com.rjil.rms.binary.error;

import com.rjil.rms.rest.handlers.ResponsePayload;

/**
 * Custom Error Raise by Binary Upload. It will have Response
 * 
 * @author Kiran.Jangid
 *
 */

public abstract class BinaryUploadResponse {

	protected ResponsePayload payload;

	public ResponsePayload getResponse() {
		return payload;
	}

	protected abstract void buildResponse();

}
