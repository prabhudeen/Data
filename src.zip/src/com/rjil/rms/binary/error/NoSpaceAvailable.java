package com.rjil.rms.binary.error;

import javax.servlet.http.HttpServletResponse;

import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class NoSpaceAvailable extends BinaryUploadResponse {

	static final String ERROR_MESSAGE = "No Space Available";
	static final String ERROR_CODE = ClearCodes.NO_SPACE_AVAILABLE.getValue();

	/**
	 * No Space Available
	 */

	public NoSpaceAvailable() {
		this.payload = new ResponsePayload();
		buildResponse();
	}

	@Override
	protected void buildResponse() {
		this.payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
		this.payload.setErrorMessage(ERROR_MESSAGE);
		this.payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		this.payload.setErrorCode(ERROR_CODE);
	}

}
