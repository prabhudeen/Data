package com.rjil.rms.binary.error;

import javax.servlet.http.HttpServletResponse;

import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;

public class FileDeleteSuccess extends BinaryUploadResponse {

	public FileDeleteSuccess() {
		this.payload = new ResponsePayload();
		buildResponse();
	}

	@Override
	protected void buildResponse() {
		this.payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
		this.payload.setHttpStatusCode(HttpServletResponse.SC_OK);
	}

}