package com.rjil.rms.binary.error;

/**
 * 
 * Error in Pulling Thread from Pool
 * 
 * @author Kiran.Jangid
 *
 */

public class ErrorInPullingThreadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {
		return "Error in Pulling Thread form Pool";
	}

}
