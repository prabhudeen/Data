package com.rjil.rms.binary.util;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.modules.pool.factory.GenericWorkerThreadInterface;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.ErrorInCopyingFile;
import com.rjil.rms.binary.error.FileUploadSuccess;
import com.rjil.rms.binary.error.NoSpaceAvailable;
import com.rjil.rms.event.ProcessListner;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.startup.RMSManagerBootstrap;

/**
 * 
 * Worker Thread to Download Binary and Copy Binary from one location to another
 * 
 * @author kiran.jangid
 *
 */

public class DownloadBinaryThread implements Runnable, GenericWorkerThreadInterface {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private VNFCImage vnfcImage;
	private ProcessListner listener;

	@Override
	public void reset() {
		this.vnfcImage = null;
	}

	@Override
	public void run() {

		try {

			String vnfcPath = RMSManagerBootstrap.rmsManager.getFolderStructureGenerator()
					.generateFolderStructure(vnfcImage, vnfcImage.getVnfcID());

			copyVNFCBinaryToFolder(vnfcImage.getFilePath(), vnfcImage.getImageName(), vnfcPath);

			RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().put(vnfcPath,
					vnfcPath + "/" + vnfcImage.getImageName());
			
			this.listener.completed(new FileUploadSuccess());

		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"run", "Error in Upload Binary", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.NO_SPACE_AVAILABLE_IN_SERVER);
			this.listener.completed(new NoSpaceAvailable());
		}

	}

	/**
	 * 
	 * @param vnfcImage
	 * @param processListner
	 */

	public void downloadBinary(VNFCImage vnfcImage, ProcessListner processListner) {
		this.vnfcImage = vnfcImage;
		this.listener = processListner;
	}

	/**
	 * 
	 * To copy binary file from one path to another
	 * 
	 * @param filePath
	 * @param fileName
	 * @param destinationDirectory
	 * @param listener2
	 * @throws IOException
	 */

	public void copyVNFCBinaryToFolder(String filePath, String fileName, String destinationDirectory)
			throws IOException {

		File src = new File(filePath + "/" + fileName);

		new File(
				RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getValue().toString() + "/" + destinationDirectory,
				fileName).deleteOnExit();

		File dest = new File(
				RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + "/" + destinationDirectory);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"copyVNFCBinaryToFolder",
				"Copying file from : " + src.getAbsolutePath() + "  to " + dest.getAbsolutePath());

		FileUtils.copyFileToDirectory(src, dest);

		if (!dest.exists()) {
			listener.completed(new ErrorInCopyingFile());
		}
	}

}
