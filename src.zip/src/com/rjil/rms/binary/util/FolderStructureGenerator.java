package com.rjil.rms.binary.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * 
 * @author Sandeep.Narula
 */

public class FolderStructureGenerator {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	/**
	 * 
	 * @param vnfcImage
	 * @param vnfcID
	 * @return
	 */
     
	public String generateFolderStructure(VNFCImage vnfcImage, String vnfcID) {

		String pathToFile = "/" + vnfcImage.getVendorName() + "/" + vnfcImage.getVnfName() + "/"
				+ vnfcImage.getVnfVersion() + "/" + vnfcID + "/";

		String pathToVimFile = "/" + vnfcImage.getVendorName() + "/" + vnfcImage.getVnfName() + "/"
				+ vnfcImage.getVnfVersion();

		File file = new File(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH + pathToFile);

		if (!file.exists()) {
			file.mkdirs();
		}

		file = new File(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH + pathToVimFile + "/" + "vim.json");

		try {
			file.createNewFile();
		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"generateFolderStructure", "Error in generate Folder Structure", e);
		}

		return pathToFile;

	}
  
	
	public static String generateHDFSDriectroy(VNFCImage vnfcImage) {

		String pathToFile = "/" + vnfcImage.getVendorName() + "/" + vnfcImage.getVnfName() + "/"
				+ vnfcImage.getVnfVersion() + "/" + vnfcImage.getVnfcID();
		
		return pathToFile;

	}
	
	/**
	 * This generic method will delete file and folder
	 * 
	 * @param vnfcImage
	 * @param vnfcID
	 * @return
	 * @throws NoSuchFileException
	 */

	public boolean deleteFileAndFolder(VNFCImage vnfcImage, String vnfcID) throws NoSuchFileException {

		final String methodName = "deleteFileAndFolder";

		String pathToFile = "/" + vnfcImage.getVendorName() + "/" + vnfcImage.getVnfName() + "/"
				+ vnfcImage.getVnfVersion() + "/" + vnfcID + "/";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"File Deleting from Folder : " + pathToFile);

		try {

			Path directory = Paths
					.get(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + pathToFile);

			Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) throws IOException {

					// this will work because it's always a File
					Files.delete(file);
					return FileVisitResult.CONTINUE;
				}

				@Override
				public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
					// this will work because Files in the directory are already
					// deleted
					Files.delete(dir);
					return FileVisitResult.CONTINUE;
				}
			});

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"File Deleted from Folder : " + pathToFile);

			return true;

		} catch (NoSuchFileException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting file in folder", e);

			throw new NoSuchFileException("File Not Available on Path " + pathToFile);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in deleting file in folder", e);

			return false;
		}

	}
}
