package com.rjil.rms.binary;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.modules.pool.factory.VNFCBinaryUploadTaskFactory;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.error.ErrorInPullingThreadException;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.operation.ESOperationException;
import com.rjil.rms.event.ProcessListner;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.hdfs.HDFSTaskListener;
import com.rjil.rms.hdfs.RtJioRMSDeleteImageFromHDFS;
import com.rjil.rms.hdfs.RtJioRMShdfsFactoryClass;
import com.rjil.rms.hdfs.RtJioRMShdfsProcess;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.startup.RMSManagerBootstrap;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMSBinaryManager implements BinaryManager, RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
    private boolean deletedFile=false;
	private static final String CLASS_NAME = "RMSBinaryManager";
    private boolean deleteFromHDFS = false;
    private boolean deleteFromLocal=false;
	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEvent",
				"processing Event for : " + eventTracking.getEventName());

		switch (eventTracking.getEventName()) {
		case RMSEventConstant.RMS_EVENT_BINARY_DOWNLOAD:
			downloadBinary(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_LIST:
			getBinaryList(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_VIEW:
			getBinary(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_DELETE:
			deleteBinary(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_UPDATE:
			updateBinary(eventTracking);
			break;
		case RMSEventConstant.RMS_EVENT_BINARY_PROVISIONING:
			provisionBinary(eventTracking);
			break;
		default:
			break;
		}

	}

	@Override
	public void provisionBinary(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "provisionBinary";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String provisionBinaryJson = new String(eventTracking.getRequestStream());

			JsonObject jsonObject = (new JsonParser().parse(provisionBinaryJson)).getAsJsonObject();

			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
					"Request : " + provisionBinaryJson);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					provisionBinaryJson, "Provisioning binary", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			File src = new File(vnfcImage.getFilePath() + "/" + vnfcImage.getImageName());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "File Path : " + src.getAbsolutePath(), eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			if (!src.exists()) {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, "File Does not Exist at path : " + src.getAbsolutePath(), eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("File does not exist : " + src.getName());
				ccAsnPojo.addClearCode(ClearCodes.FILE_NOT_AVAILABLE.getValue(), ClearCodeLevel.PROTOCOL);

				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
				return;
			}
			

			
			
			if (RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue()) {
				
				if(EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcImage.getVnfcID())!=null) {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, methodName,
							"Upload vnfcImage Already Exists : ");
					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage("Upload vnfcImage Already Exists " + src.getName());
					ccAsnPojo.addClearCode(ClearCodes.UPLOAD_VNFC_IMAGE_STATUS_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);

					RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
					ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
					return;
				}
				
				RtJioRMShdfsFactoryClass processTask = new RtJioRMShdfsFactoryClass(eventTracking, vnfcImage);
				 
				processTask.processEventTask(new HDFSTaskListener(){

					@Override
					public void completed(BinaryUploadResponse response) {

						ResponsePayload payload = response.getResponse();

						loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, null, "payload = " + payload.toString(), eventTracking.getFlowId(),
								eventTracking.getPublisherName());

						ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

						if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

							loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
									methodName, null, "File Copied Successfully", eventTracking.getFlowId(),
									eventTracking.getPublisherName());
							try {

								if (EsManager.getInstance().getVnfOperationImpl().uploadVNFCImage(vnfcImage.getVnfcID(),
										vnfcImage.toString())) {

									loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
											this.getClass().getName(), methodName, null,
											"Data written In ES Successfully : vnfc Id " + vnfcImage.getVnfcID()
													+ " | Data = " + vnfcImage.toString(),
											eventTracking.getFlowId(), eventTracking.getPublisherName());

									VNFCImage vnfcImageTemp = new VNFCImage();
									vnfcImageTemp.setFileUrl(RtJioCommonMethods.generateDownloadUrlForImage(vnfcImage));
									vnfcImageTemp.setImageName(vnfcImage.getImageName());
									vnfcImageTemp.setFormat(vnfcImage.getFormat());
									vnfcImageTemp.setVnfID(vnfcImage.getVnfID());
									vnfcImageTemp.setVnfcID(vnfcImage.getVnfcID());
									vnfcImageTemp.setVnfVersion(vnfcImage.getVnfVersion());
									vnfcImageTemp.setVnfcVersion(vnfcImage.getVnfcVersion());

									JSONObject vnfcIm = new JSONObject(vnfcImageTemp);

									RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
											RtJioRMSCacheManager.getInstance().getErmManager()
													.createNewEventBuilder(HttpMethod.POST)
													.addQueryParam(BinaryOperationConstantEnum.VNF_ID.getValue(),
															vnfcImageTemp.getVnfID())
													.addQueryParam(BinaryOperationConstantEnum.VNF_VERSION.getValue(),
															vnfcImageTemp.getVnfVersion())
													.addQueryParam(BinaryOperationConstantEnum.VNFC_VERSION.getValue(),
															vnfcImageTemp.getVnfcVersion())
													.addQueryParam(BinaryOperationConstantEnum.VNFC_ID.getValue(),
															vnfcImageTemp.getVnfcID()),
											RMSEventConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL.getValue(),
											vnfcIm.toString(), RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(),
											eventTracking.getFlowId());

									loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
											this.getClass().getName(), methodName, null,
											"Download Url Published to VNFC : " + vnfcIm.toString(),
											eventTracking.getFlowId(), eventTracking.getPublisherName());

									ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_SUCCESS.getValue(),
											ClearCodeLevel.PROTOCOL);

									// if
									// (!RtJioRMSConfigParamEnum.IS_USING_SHARED_RESOURCE.getBooleanValue())
									// {
									// // Sending broadcast request to all
									// // instances
									// RMRHAManager.getInstance().broadcastEvent(eventTracking);
									// }

								} else {

									loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
											this.getClass().getName(), methodName, null,
											"Error in Writing Data In ES : vnfc id = " + vnfcImage.getVnfcID()
													+ " | Data = " + vnfcImage.toString(),
											eventTracking.getFlowId(), eventTracking.getPublisherName());

									payload.setHttpStatusCode(500);
									payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
									payload.setErrorCode(ClearCodes.VNFC_IMAGE_UPLOAD_DATABASE_WRITE_FAILURE.getValue());
									ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_DATABASE_WRITE_FAILURE.getValue(),
											ClearCodeLevel.PROTOCOL);

								}

							} catch (ESOperationException e) {

								loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
										this.getClass().getName(), methodName, eventTracking.getFlowId(),
										eventTracking.getPublisherName(), e);

								payload.setHttpStatusCode(500);
								payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
								ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_FAILURE.getValue(),
										ClearCodeLevel.PROTOCOL);
							}

						} else {

							loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
									methodName, null,
									"File Copied Failure : File Not copied to Location = " + payload.getErrorMessage(),
									eventTracking.getFlowId(), eventTracking.getPublisherName());

							payload.setHttpStatusCode(500);
							payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
							ccAsnPojo.addClearCode(payload.getErrorCode(), ClearCodeLevel.PROTOCOL);
						}

						RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload),
								null);
						ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

					}
				});
			} else {
				provisionBinaryInRMR(vnfcImage, eventTracking);

			}

			// Removed code to send event to VNFC n writing data in Es

		} catch (Exception ex) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in provision binary", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in Upload Binary Service binary");

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	@Override
	public void updateBinary(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "updateBinary";
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				" inside updat binary function = "+eventTracking.getRequestJson());
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		
		if(RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue()) {
			
	   	RtJioRMShdfsFactoryClass processTask = new RtJioRMShdfsFactoryClass(eventTracking);
		processTask.processEventTask(new HDFSTaskListener() {
			
			@Override
			public void completed(BinaryUploadResponse response) {
				
				ResponsePayload payload = response.getResponse();

				ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

				if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {
					
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
							"UPDATED Binary Image : SUCCESS ="+eventTracking.getRequestJson());
				}
				else
				{
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
							"UPDATED Binary Image FAILED ="+eventTracking.getRequestJson());
				}
				
				
				
			}
			
	     	});
		
		 }
		else{
			
			try {

				// Getting image id from request to Update Image data form Database
				// and Folder
				String vnfcId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNFC_ID.getValue());

				// Getting image data from ES
				String imageStr = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

				if (imageStr == null) {
					payload.setHttpStatusCode(404);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage("Image Data is not available for Id : " + vnfcId);
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
							"Image Data is not available for Id  : " + vnfcId);
					ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
					RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
					ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

					return;
				}

				JsonObject jsonObjectES = (new JsonParser().parse(imageStr)).getAsJsonObject();
				Gson gsonObjES = new Gson();
				VNFCImage vnfcImageOnES = gsonObjES.fromJson(jsonObjectES, VNFCImage.class);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Updating Image Data : " + imageStr);
				String pathToFile = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + "/"
						+ vnfcImageOnES.getVendorName() + "/" + vnfcImageOnES.getVnfName() + "/"
						+ vnfcImageOnES.getVnfVersion() + "/" + vnfcId + "/";

				File dest = new File(pathToFile);
				if (!dest.exists()) {
					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
							null, "Sending broadcast request to all instances for update binary : ",
							eventTracking.getFlowId(), eventTracking.getPublisherName());
					if (!RtJioRMSConfigParamEnum.IS_USING_SHARED_RESOURCE.getBooleanValue()) {
						// Sending broadcast request to all
						// instances
						RMRHAManager.getInstance().broadcastEvent(eventTracking);
						return;
					}
				}

				if (vnfcImageOnES.getImageName() != null) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Deleting image file at path : " + dest.getAbsolutePath());

					String pathToImageFile = RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + "/"
							+ vnfcImageOnES.getVendorName() + "/" + vnfcImageOnES.getVnfName() + "/"
							+ vnfcImageOnES.getVnfVersion() + "/" + vnfcId + "/" + vnfcImageOnES.getImageName() + "/";

					Path imageDest = Paths.get(pathToImageFile);

					try {

						Files.delete(imageDest);
						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, "Deleted Succesfully this image: " + imageDest);

					} catch (Exception e) {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, "Error in deleteing image: " + imageDest);
						loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
								this.getClass().getName(), methodName, "Error in deleteing image: " + imageDest, e);
						payload.setHttpStatusCode(500);
						payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
						payload.setErrorCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue());
						payload.setErrorMessage("Error in deleting image: " + imageDest);
						ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
						RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload),
								null);
						ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
						return;

					}
				}

				String updateBinaryJson = new String(eventTracking.getRequestStream());

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						updateBinaryJson, "Provisioning binary", eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				JsonObject jsonObject = (new JsonParser().parse(updateBinaryJson)).getAsJsonObject();

				Gson gsonObj = new Gson();
				VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"Request : " + updateBinaryJson);

				File src = new File(vnfcImage.getFilePath() + "/" + vnfcImage.getImageName());

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "File Path : " + src.getAbsolutePath(), eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				if (!src.exists()) {
					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
							null, "File Does not Exist at path : " + src.getAbsolutePath(), eventTracking.getFlowId(),
							eventTracking.getPublisherName());

					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage("File Does not Exist : " + src.getName());
					ccAsnPojo.addClearCode(ClearCodes.FILE_NOT_AVAILABLE.getValue(), ClearCodeLevel.PROTOCOL);

					RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
					ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
					return;
				}

				provisionBinaryInRMR(vnfcImage, eventTracking);

				// Removed code to send event to VNFC n writing data in Es

			} catch (Exception ex) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Update Binary Service binary", ex);

				loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPDATE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);

				payload.setHttpStatusCode(500);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("Error in Update Binary Service binary");

				RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
				ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			}
			
		}

	}

	@Override
	public void downloadBinary(RMREventPojo eventTracking) {

		final String methodName = "downloadBinary";

		String subContext = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VENDOR_NAME.getValue())
				+ "/" + eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNF_NAME.getValue()) + "/"
				+ eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNF_VERSION.getValue()) + "/"
				+ eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNFC_NAME.getValue());

		String pathToBinary = RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().get(subContext);

		try (InputStream fis = new FileInputStream(
				new File(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + pathToBinary))) {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "downloadBinary",
					"pathToBinary    " + pathToBinary);

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Download Binary Service binary", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}
	}

	@Override
	public void deleteBinary(RMREventPojo eventTracking) {

		final String methodName = "deleteBinary";

		ResponsePayload payload = new ResponsePayload();

		// Getting image id from request to delete Image data form Database
		String vnfcId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNFC_ID.getValue());
		String vnfId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNF_ID.getValue());

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				"Deleting Image Request for vnf id : " + vnfId + " | vnfc id : " + vnfcId);

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			// Getting image data from ES
			String imageStr = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);

			if (imageStr == null) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage("Image Data is not available for Id : " + vnfcId);
				return;
			}

			JsonObject jsonObject = (new JsonParser().parse(imageStr)).getAsJsonObject();
			Gson gsonObj = new Gson();
			VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
					"Deleting Image Data : " + imageStr);
          
           
			// deleting image from ES and file folder
			
			deleteFromHDFS=false;
			deleteFromLocal=false;
			if(RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue()) {
				
				RtJioRMShdfsFactoryClass hdfsTasks =new RtJioRMShdfsFactoryClass(eventTracking,vnfcImage);
				hdfsTasks.processEventTask(new HDFSTaskListener() {
				
				@Override
				public void completed(BinaryUploadResponse response) {
					ResponsePayload payload = response.getResponse();
					ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
					
					if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
								"Deleting Image Data from HDFS :  Success");
						
						try {
							
							DeleteFromES(payload,vnfId,vnfcId,vnfcImage,eventTracking,ccAsnPojo);
							
						} catch (ESOperationException e) {
							loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
									methodName, "Error in delete data from Elastic or HDFS", e);
						}
						
					}else {
						loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
								methodName, "Error while delete data from HDFS");

						payload.setHttpStatusCode(500);
						payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
						payload.setErrorMessage("Error in delete data from HDFS");
						ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DELETE_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
						
					}
					
				 }
				
			   });
			}
			else {
				
				deleteFromLocal = RtJioCommonMethods.deleteFileFromDestination(vnfcImage);		
				DeleteFromES(payload,vnfId,vnfcId,vnfcImage,eventTracking,ccAsnPojo);
			}
			
			
		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in delete data from Elastic or HDFS", e);

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}
	
void DeleteFromES(ResponsePayload payload,String vnfId,String vnfcId, VNFCImage vnfcImage,RMREventPojo eventTracking,ClearCodeAsnPojo ccAsnPojo) throws ESOperationException {
	
	String methodName="DeleteFromES";
	
	if(EsManager.getInstance().getVnfOperationImpl().deleteVNFCImage(vnfcId)) {

		// publishing Event to VNFC to notify delete vnfc image
		RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
				RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.POST)
						.addQueryParam(BinaryOperationConstantEnum.VNF_ID.getValue(), vnfId)
						.addQueryParam(BinaryOperationConstantEnum.VNF_VERSION.getValue(),
								vnfcImage.getVnfVersion())
						.addQueryParam(BinaryOperationConstantEnum.VNFC_VERSION.getValue(),
								vnfcImage.getVnfcVersion())
						.addQueryParam(BinaryOperationConstantEnum.VNFC_ID.getValue(), vnfcId),
				RMSEventConstantEnum.PUBLISH_DELETE_VNFC_IMAGE.getValue(), null,
				RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId());
        
		// Success Event ACK After completion of Image Deletion
		
		payload.setHttpStatusCode(200);
		payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
		ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DELETE_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				"Success Event ACK After completion of Image Deletion :  ="+payload.toString());
	} else {
		payload.setHttpStatusCode(404);
		payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
		payload.setErrorMessage("Error in deleting data from Elastic and File Folder");
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				"Failed to delete vnfc data from ES :  ="+payload.toString());
	}
}
	

	@Override
	public void getBinary(RMREventPojo eventTracking) {

		final String methodName = "getBinary";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				"inside get binary  ");

		ResponsePayload payload = new ResponsePayload();

		JSONObject appData = new JSONObject();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		// build json data form getting json form elastic db

		try {

			String vnfcId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNFC_ID.getValue());

			appData.put("vnfcImage",
					new JSONObject(EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId)));

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			payload.setAppData(appData);

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_GET_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Image Data form Elastic", e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage("Error in get Image Data form Elastic");
			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_GET_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		}

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
				"image json sending to ERM : " + appData.toString());

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
	}

	@Override
	public void getBinaryList(RMREventPojo eventTracking) {

		final String methodName = "getBinaryList";

		ResponsePayload payload = new ResponsePayload();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			// Creating query to get list of Image Data from ES
			Map<String, String> queryBuilder = new HashMap<>();

			String vnfId = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNF_ID.getValue());

			if (vnfId != null) {
				queryBuilder.put(BinaryOperationConstantEnum.VNF_ID.getValue(), vnfId);
			}

			String vnfVersion = eventTracking.getRequestParams()
					.get(BinaryOperationConstantEnum.VNF_VERSION.getValue());

			if (vnfVersion != null) {
				queryBuilder.put(BinaryOperationConstantEnum.VNF_VERSION.getValue(), vnfVersion);
			}

			String vendorName = eventTracking.getRequestParams()
					.get(BinaryOperationConstantEnum.VENDOR_NAME.getValue());

			if (vendorName != null) {
				queryBuilder.put(BinaryOperationConstantEnum.VENDOR_NAME.getValue(), vendorName);
			}

			String vnfName = eventTracking.getRequestParams().get(BinaryOperationConstantEnum.VNF_NAME.getValue());

			if (vnfName != null) {
				queryBuilder.put(BinaryOperationConstantEnum.VNF_NAME.getValue(), vnfName);
			}

			JSONObject appData = new JSONObject();

			if (EsManager.getInstance().getVnfOperationImpl().listVNFCImages(queryBuilder) == null) {
				JSONArray emptyArray = new JSONArray();
				appData.put("vnfcImageList", emptyArray);
			} else {
				JSONArray finalJson = convertJSON(
						EsManager.getInstance().getVnfOperationImpl().listVNFCImages(queryBuilder));
				appData.put("vnfcImageList", finalJson);
			}

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			payload.setAppData(appData);

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_GET_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (JSONException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Image Data List from JSON Parsing", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.JSON_PARSING_ERROR_AT_SERVER.getValue());
			ccAsnPojo.addClearCode(ClearCodes.JSON_PARSING_ERROR_AT_SERVER_IN_LIST_VNF_IMAGES.getValue(),
					ClearCodeLevel.PROTOCOL);

		} catch (ESOperationException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Image Data List from Elastic", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.ES_READ_OPERATION_FAILURE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.ES_READ_OPERATION_FAILURE_IN_LIST_VNF_IMAGES.getValue(),
					ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	/**
	 * File Provisioning at Folder Structure
	 * 
	 * @param vnfcImage
	 * @param eventTracking
	 * @throws Exception
	 */

	private void provisionBinaryInRMR(VNFCImage vnfcImage, RMREventPojo eventTracking)
			throws ErrorInPullingThreadException {
		

		final String methodName = "provisionBinaryInRMR";

		DownloadBinaryThread downloadBinaryThread = null;

		loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName, null,
				"File Exist : " + vnfcImage.getImageName(), eventTracking.getFlowId(),
				eventTracking.getPublisherName());

		downloadBinaryThread = RtJioRMSCacheManager.getInstance().getUploadBinaryImageThread();

		if (downloadBinaryThread != null) {

			downloadBinaryThread.downloadBinary(vnfcImage, new ProcessListner() {

				@Override
				public void completed(BinaryUploadResponse response) {

					ResponsePayload payload = response.getResponse();

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, null, "payload = " + payload.toString(), eventTracking.getFlowId(),
							eventTracking.getPublisherName());

					ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

					if (payload.getType().equalsIgnoreCase(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue())) {

						loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
								methodName, null, "File Copied Successfully", eventTracking.getFlowId(),
								eventTracking.getPublisherName());

						String strUrl = "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
								+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
								+ RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue()
								+ RMSManagerBootstrap.rmsManager.getFolderStructureGenerator()
										.generateFolderStructure(vnfcImage, vnfcImage.getVnfcID())
								+ "?" + FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + "binary";

						vnfcImage.setFileUrl(strUrl);
						vnfcImage.setTimeStamp(System.currentTimeMillis());

						try {

							if (EsManager.getInstance().getVnfOperationImpl().uploadVNFCImage(vnfcImage.getVnfcID(),
									vnfcImage.toString())) {

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
										this.getClass().getName(), methodName, null,
										"Data written In ES Successfully : vnfc Id " + vnfcImage.getVnfcID()
												+ " | Data = " + vnfcImage.toString(),
										eventTracking.getFlowId(), eventTracking.getPublisherName());

								VNFCImage vnfcImageTemp = new VNFCImage();
								vnfcImageTemp.setFileUrl(RtJioCommonMethods.generateDownloadUrlForImage(vnfcImage));
								vnfcImageTemp.setImageName(vnfcImage.getImageName());
								vnfcImageTemp.setFormat(vnfcImage.getFormat());
								vnfcImageTemp.setVnfID(vnfcImage.getVnfID());
								vnfcImageTemp.setVnfcID(vnfcImage.getVnfcID());
								vnfcImageTemp.setVnfVersion(vnfcImage.getVnfVersion());
								vnfcImageTemp.setVnfcVersion(vnfcImage.getVnfcVersion());

								JSONObject vnfcIm = new JSONObject(vnfcImageTemp);

								RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
										RtJioRMSCacheManager.getInstance().getErmManager()
												.createNewEventBuilder(HttpMethod.POST)
												.addQueryParam(BinaryOperationConstantEnum.VNF_ID.getValue(),
														vnfcImageTemp.getVnfID())
												.addQueryParam(BinaryOperationConstantEnum.VNF_VERSION.getValue(),
														vnfcImageTemp.getVnfVersion())
												.addQueryParam(BinaryOperationConstantEnum.VNFC_VERSION.getValue(),
														vnfcImageTemp.getVnfcVersion())
												.addQueryParam(BinaryOperationConstantEnum.VNFC_ID.getValue(),
														vnfcImageTemp.getVnfcID()),
										RMSEventConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL.getValue(),
										vnfcIm.toString(), RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(),
										eventTracking.getFlowId());

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
										this.getClass().getName(), methodName, null,
										"Download Url Published to VNFC : " + vnfcIm.toString(),
										eventTracking.getFlowId(), eventTracking.getPublisherName());

								ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_SUCCESS.getValue(),
										ClearCodeLevel.PROTOCOL);

								// if
								// (!RtJioRMSConfigParamEnum.IS_USING_SHARED_RESOURCE.getBooleanValue())
								// {
								// // Sending broadcast request to all
								// // instances
								// RMRHAManager.getInstance().broadcastEvent(eventTracking);
								// }

							} else {

								loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
										this.getClass().getName(), methodName, null,
										"Error in Writing Data In ES : vnfc id = " + vnfcImage.getVnfcID()
												+ " | Data = " + vnfcImage.toString(),
										eventTracking.getFlowId(), eventTracking.getPublisherName());

								payload.setHttpStatusCode(500);
								payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
								payload.setErrorCode(ClearCodes.VNFC_IMAGE_UPLOAD_DATABASE_WRITE_FAILURE.getValue());
								ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_DATABASE_WRITE_FAILURE.getValue(),
										ClearCodeLevel.PROTOCOL);

							}

						} catch (ESOperationException e) {

							loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
									this.getClass().getName(), methodName, eventTracking.getFlowId(),
									eventTracking.getPublisherName(), e);

							payload.setHttpStatusCode(500);
							payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
							ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_UPLOAD_FAILURE.getValue(),
									ClearCodeLevel.PROTOCOL);
						}

					} else {

						loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
								methodName, null,
								"File Copied Failure : File Not copied to Location = " + payload.getErrorMessage(),
								eventTracking.getFlowId(), eventTracking.getPublisherName());

						payload.setHttpStatusCode(500);
						payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
						ccAsnPojo.addClearCode(payload.getErrorCode(), ClearCodeLevel.PROTOCOL);
					}

					RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload),
							null);
					ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

				}
			});

			RtJioRMSCacheManager.getInstance().getExecutorService().execute(downloadBinaryThread);

		} else {
			throw new ErrorInPullingThreadException();
		}

	}

	// convert JSon structure
	public JSONArray convertJSON(List<Object> appData) {

		final String methodName = "convertJSON";
		JSONArray finalData = new JSONArray();

		try {

			JSONArray vnfcImageList = new JSONArray(appData);
			HashMap<String, Integer> hashmap = new HashMap<String, Integer>();

			for (int i = 0; i < vnfcImageList.length(); i++) {

				String vendorName = (String) (((JSONObject) vnfcImageList.get(i)).get("vendorName"));
				String vnfName = (String) (((JSONObject) vnfcImageList.get(i)).get("vnfName"));
				String vnfVersion = (String) (((JSONObject) vnfcImageList.get(i)).get("vnfVersion"));

				String key = vendorName + vnfName + vnfVersion;

				if (hashmap.get(key) == null) {

					JSONObject data = new JSONObject();

					hashmap.put(key, new Integer(i));
					data.put("vendorName", ((JSONObject) vnfcImageList.get(i)).get("vendorName"));
					data.put("vendorID", ((JSONObject) vnfcImageList.get(i)).get("vendorID"));
					data.put("vnfName", ((JSONObject) vnfcImageList.get(i)).get("vnfName"));
					data.put("vnfVersion", ((JSONObject) vnfcImageList.get(i)).get("vnfVersion"));
					data.put("vnfID", ((JSONObject) vnfcImageList.get(i)).get("vnfID"));

					JSONObject arrayObject = new JSONObject();
					arrayObject.put("vnfcName", ((JSONObject) vnfcImageList.get(i)).get("vnfcName"));
					arrayObject.put("vnfcVersion", ((JSONObject) vnfcImageList.get(i)).get("vnfcVersion"));
					arrayObject.put("imageName", ((JSONObject) vnfcImageList.get(i)).get("imageName"));
					arrayObject.put("filePath", ((JSONObject) vnfcImageList.get(i)).get("filePath"));
					arrayObject.put("format", ((JSONObject) vnfcImageList.get(i)).get("format"));
					arrayObject.put("vnfcID", ((JSONObject) vnfcImageList.get(i)).get("vnfcID"));
					arrayObject.put("fileUrl", ((JSONObject) vnfcImageList.get(i)).get("fileUrl"));

					JSONArray array = new JSONArray();
					array.put(arrayObject);
					data.put("vnfcList", array);
					finalData.put(data);

				} else {

					int k = findIndex(vendorName, vnfName, vnfVersion, finalData);
					JSONObject jo = (JSONObject) finalData.get(k);

					JSONArray alreadyArray = (JSONArray) jo.get("vnfcList");
					JSONObject arrayObject = new JSONObject();
					arrayObject.put("vnfcName", ((JSONObject) vnfcImageList.get(i)).get("vnfcName"));
					arrayObject.put("vnfcVersion", ((JSONObject) vnfcImageList.get(i)).get("vnfcVersion"));
					arrayObject.put("imageName", ((JSONObject) vnfcImageList.get(i)).get("imageName"));
					arrayObject.put("filePath", ((JSONObject) vnfcImageList.get(i)).get("filePath"));
					arrayObject.put("format", ((JSONObject) vnfcImageList.get(i)).get("format"));
					arrayObject.put("vnfcID", ((JSONObject) vnfcImageList.get(i)).get("vnfcID"));
					arrayObject.put("fileUrl", ((JSONObject) vnfcImageList.get(i)).get("fileUrl"));
					alreadyArray.put(arrayObject);
				}
			}

		} catch (JSONException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Image Data List from JSON Parsing", e);
		}

		return finalData;

	}

	public int findIndex(String vendorName, String vnfName, String vnfVersion, JSONArray finalData) {
		String methodName = "findIndex";
		try {
			for (int j = 0; j < finalData.length(); j++) {
				JSONObject temp = (JSONObject) finalData.get(j);
				if (temp.get("vendorName").equals(vendorName) && temp.get("vnfName").equals(vnfName)
						&& temp.get("vnfVersion").equals(vnfVersion)) {
					return j;
				}

			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Image Data List from JSON Parsing", e);
		}
		return -1;

	}
}
