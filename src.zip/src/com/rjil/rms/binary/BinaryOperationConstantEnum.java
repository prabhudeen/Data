package com.rjil.rms.binary;

/**
 * Binary Operation Constant
 * 
 * @author kiran.jangid
 *
 */

public enum BinaryOperationConstantEnum {

	VNF_ID("vnfID"),

	VNF_NAME("vnfName"),

	VNF_VERSION("vnfVersion"),

	VNFC_VERSION("vnfcVersion"),

	VNFC_NAME("vnfcName"),

	VNFC_ID("vnfcID"),

	VENDOR_NAME("vendorName"),

	VENDOR_ID("vendorID"), 
	
	IMAGE_NAME("imageName"), 
	
	FORMAT("format"), 
	
	FILE_URL("fileUrl"), 
	
	FILE_PATH("filePath"),
	
	IMAGE_DESCRIPTION("imageDescription"),
	
	TIME_STAMP("timeStamp");

	private String value;

	private BinaryOperationConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
