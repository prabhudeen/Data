package com.rjil.rms.event;

import com.rjil.rms.binary.error.BinaryUploadResponse;

/**
 * Process Listener that provide async response of request
 * 
 * @author Kiran.Jangid
 *
 */
@FunctionalInterface
public interface ProcessListner {

	/**
	 * 
	 * @param response
	 */
	
	void completed(BinaryUploadResponse response);

}
