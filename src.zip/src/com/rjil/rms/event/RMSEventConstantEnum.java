package com.rjil.rms.event;

import com.rjil.rms.binary.RMSBinaryManager;
import com.rjil.rms.cnf.fcaps.RMRCNFAlarmDictionaryUpload;
import com.rjil.rms.cnf.fcaps.RMRCNFConfigDictionaryUpload;
import com.rjil.rms.cnf.fcaps.RMRCNFCounterDictionaryUload;
import com.rjil.rms.cnf.fcaps.RMRCNFFCAPSDictionaryDownloadEvent;
import com.rjil.rms.cnf.fcaps.RMRCNFGetAlarm;
import com.rjil.rms.cnf.fcaps.RMRCNFGetAllFAPS;
import com.rjil.rms.cnf.fcaps.RMRCNFGetConfig;
import com.rjil.rms.cnf.fcaps.RMRCNFGetCounter;
import com.rjil.rms.cnf.fcaps.RtJioRMRCNFDictTemplateDownload;
import com.rjil.rms.draft.RMRCNFDraftManager;
import com.rjil.rms.draft.RMRDraftManager;
import com.rjil.rms.fcaps.RMRFCAPSDictionaryDownloadEvent;
import com.rjil.rms.fcaps.RMRFCAPSTemplateDownloadEvent;
import com.rjil.rms.fcaps.RMSFCAPSManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.notification.RMRCNFDeletionNotification;
//import com.rjil.rms.notification.RMRCNFTerminationNotification;
import com.rjil.rms.notification.RMRVNFInstantiationNotification;
//import com.rjil.rms.notification.RMRVNFTerminationNotification;
import com.rjil.rms.notification.RMSEventNotificationManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.ui.metadata.RMRMetadataManager;

/**
 * 
 * Event Constant
 * 
 * @author kiran.jangid
 *
 */

public enum RMSEventConstantEnum {

	// VNFC Binary Image Event

	RMS_EVENT_BINARY_PROVISIONING("UPLOAD_VNFC_IMAGE") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	RMS_EVENT_BINARY_DOWNLOAD("DOWNLOAD_VNFC_IMAGE") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	RMS_EVENT_BINARY_DELETE("DELETE_VNFC_IMAGE") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	RMS_EVENT_BINARY_VIEW("GET_VNFC_IMAGE_DETAIL") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	RMS_EVENT_BINARY_UPDATE("MODIFY_VNFC_IMAGE_DETAIL") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	RMS_EVENT_BINARY_LIST("GET_VNFC_IMAGE_LIST") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSBinaryManager();
		}
	},

	// VNF FCAPS Dictionary Subscriber Event

	RMS_EVENT_ALARM_UPLOAD("CONFIGURE_VNF_ALARM_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_CONFIG_UPLOAD("CONFIGURE_VNF_CONFIGURATION_PARAMETER_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_COUNTER_UPLOAD("CONFIGURE_VNF_COUNTER_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_GET_ALARM("GET_VNF_ALARM_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_GET_CONFIGURATION("GET_VNF_CONFIGURATION_PARAMETER_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_GET_COUNTER("GET_VNF_COUNTER_DICTIONARY") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},

	RMS_EVENT_GET_FCAPS("GET_VNF_FCAPS_DETAILS") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	},
	
	
	
	
	// CNF FCAPS Dictionary Subscriber Event

		RMS_CNF_EVENT_ALARM_UPLOAD("CONFIGURE_CNF_ALARM_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFAlarmDictionaryUpload();
			}
		},
		

		RMS_CNF_EVENT_CONFIG_UPLOAD("CONFIGURE_CNF_CONFIGURATION_PARAMETER_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFConfigDictionaryUpload();
			}
		},

		RMS_CNF_EVENT_COUNTER_UPLOAD("CONFIGURE_CNF_COUNTER_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFCounterDictionaryUload();
			}
		},

		RMS_CNF_EVENT_GET_ALARM("GET_CNF_ALARM_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFGetAlarm();
			}
		},

		RMS_CNF_EVENT_GET_CONFIGURATION("GET_CNF_CONFIGURATION_PARAMETER_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFGetConfig();
			}
		},

		RMS_CNF_EVENT_GET_COUNTER("GET_CNF_COUNTER_DICTIONARY") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFGetCounter();
			}
		},

		RMS_CNF_EVENT_GET_FCAPS("GET_CNF_FCAPS_ALL_DETAILS") {
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				return new RMRCNFGetAllFAPS();
			}
		},
		
		RMS_CNF_EVENT_DOWNLOAD_DICTIONARY("RMS_CNF_EVENT_DOWNLOAD_FCAPS_DICTIONARY"){
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				 return new RMRCNFFCAPSDictionaryDownloadEvent();
			}
		},
		RMS_CNF_EVENT_DOWNLOAD_TEMPLATE("RMS_CNF_EVENT_DOWNLOAD_FCAPS_TEMPLATE"){
			@Override
			public RMREventProcessor getEventServiceObject(String event) {
				 return new RtJioRMRCNFDictTemplateDownload();
			}
		},
		
		
		// Publishing CNF Event to MS 
		AM_CNF_EVENT_ALARM_UPLOAD("PUBLISH_CNF_ALARM_DICTIONARY"),

		CM_CNF_EVENT_CONFIG_UPLOAD("PUBLISH_CNF_CONFIG_DICTIONARY"),

		PM_CNF_EVENT_COUNTER_UPLOAD("PUBLISH_CNF_COUNTER_DICTIONARY"),

	// Serving Draft Event

	RMS_EVENT_SAVE_AS_DRAFT("SAVE_AS_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	RMS_EVENT_GET_DRAFT("GET_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	RMS_EVENT_GET_DRAFT_STATUS("GET_DRAFT_STATUS") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	RMS_EVENT_UPDATE_DRAFT("UPDATE_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	RMS_EVENT_UPDATE_DRAFT_STATUS("UPDATE_DRAFT_STATUS") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	RMS_EVENT_DELETE_DRAFT("DELETE_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRDraftManager();
		}
	},

	// Serving CNF Draft Event

	RMS_EVENT_SAVE_AS_DRAFT_CNF("SAVE_CNF_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	RMS_EVENT_GET_DRAFT_CNF("GET_CNF_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	RMS_EVENT_GET_DRAFT_STATUS_CNF("GET_CNF_DRAFT_STATUS") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	RMS_EVENT_UPDATE_DRAFT_CNF("UPDATE_CNF_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	RMS_EVENT_UPDATE_DRAFT_STATUS_CNF("UPDATE_CNF_DRAFT_STATUS") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	RMS_EVENT_DELETE_DRAFT_CNF("DELETE_CNF_DRAFT") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDraftManager();
		}
	},

	// FCAPS Publish Event

	AM_EVENT_ALARM_UPLOAD("PUBLISH_VNF_ALARM_DICTIONARY"),

	CM_EVENT_CONFIG_UPLOAD("PUBLISH_VNF_CONFIGURATION_PARAMETER_DICTIONARY"),

	PM_EVENT_COUNTER_UPLOAD("PUBLISH_VNF_COUNTER_DICTIONARY"),

	// VNFC Publish Alarm

	PUBLISH_VNFC_IMAGE_WITH_HTTP_URL("PUBLISH_VNFC_IMAGE_WITH_HTTP_URL"),

	PUBLISH_DELETE_VNFC_IMAGE("PUBLISH_DELETE_VNFC_IMAGE"),

	// Serving METADATA Events

	RMS_EVENT_GET_METADATA("GET_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_EVENT_SET_METADATA("SET_UI_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_EVENT_ADD_METADATA("ADD_UI_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_EVENT_MODIFY_METADATA("MODIFY_UI_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_EVENT_DELETE_METADATA("DELETE_UI_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_EVENT_VIEW_METADATA("VIEW_UI_METADATA") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRMetadataManager();
		}
	},

	RMS_NOTIFICATION_EVENT_VNF_DELETION("NOTIFY_VNF_DELETION") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSEventNotificationManager();
		}
	},

	RMS_NOTIFICATION_EVENT_CNF_DELETION(RMSEventConstant.RMR_NOTIFICATION_EVENT_CNF_DELETION) {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRCNFDeletionNotification();
		}
	},

//	RMS_NOTIFICATION_EVENT_CNF_TERMINATION(RMSEventConstant.RMR_NOTIFICATION_EVENT_CNF_TERMINATION) {
//		@Override
//		public RMREventProcessor getEventServiceObject(String event) {
//			return new RMRCNFTerminationNotification();
//		}
//	},

//	RMS_NOTIFICATION_EVENT_VNF_TERMINATION(RMSEventConstant.RMR_NOTIFICATION_EVENT_VNF_TERMINATION) {
//		@Override
//		public RMREventProcessor getEventServiceObject(String event) {
//			return new RMRVNFTerminationNotification();
//		}
//	},

	RMS_NOTIFICATION_EVENT_VNF_INSTANTIATION(RMSEventConstant.RMR_NOTIFICATION_EVENT_VNF_INSTANTIATION) {

		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRVNFInstantiationNotification();
		}
	},

	RMS_EVENT_DOWNLOAD_FCAPS_DICTIONARY(RMSEventConstant.RMS_EVENT_DOWNLOAD_FCAPS_DICTIONARY) {

		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRFCAPSDictionaryDownloadEvent();
		}
	},

	RMS_EVENT_DOWNLOAD_FCAPS_TEMPLATE(RMSEventConstant.RMS_EVENT_DOWNLOAD_FCAPS_TEMPLATE) {

		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMRFCAPSTemplateDownloadEvent();
		}
	},

	UNKONWN("") {
		@Override
		public RMREventProcessor getEventServiceObject(String event) {
			return new RMSFCAPSManager();
		}
	};

	private String value;

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RMSEventConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	/**
	 * 
	 * @param event
	 * @return
	 */

	public RMREventProcessor getEventServiceObject(String event) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"getEventServiceObject", "Event : " + event);
		return new RMSBinaryManager();
	}
	
	/**
	 * 
	 * @param factory
	 * @param event
	 * @return
	 */

	public static RMREventProcessor getEventServiceObject(RMSEventConstantEnum factory, String event) {
		return factory.getEventServiceObject(event);

	}

}
