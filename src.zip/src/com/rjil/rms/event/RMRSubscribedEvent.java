package com.rjil.rms.event;

import java.util.HashMap;

import com.rjil.rms.rest.handlers.RMREventProcessor;

/**
 * 
 * Map of Subscribed Event in RMR
 * 
 * @author kiran.jangid
 *
 */

public class RMRSubscribedEvent {

	static HashMap<String, RMSEventConstantEnum> events = new HashMap<>();

	static {

		// VNFC Image Binary Event List
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_PROVISIONING.getValue(),
				RMSEventConstantEnum.RMS_EVENT_BINARY_PROVISIONING);
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_DOWNLOAD.getValue(),
				RMSEventConstantEnum.RMS_EVENT_BINARY_DOWNLOAD);
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_DELETE.getValue(),
				RMSEventConstantEnum.RMS_EVENT_BINARY_DELETE);
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_LIST.getValue(), RMSEventConstantEnum.RMS_EVENT_BINARY_LIST);
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_UPDATE.getValue(),
				RMSEventConstantEnum.RMS_EVENT_BINARY_UPDATE);
		events.put(RMSEventConstantEnum.RMS_EVENT_BINARY_VIEW.getValue(), RMSEventConstantEnum.RMS_EVENT_BINARY_VIEW);

		// FCAPS Event List
		events.put(RMSEventConstantEnum.RMS_EVENT_ALARM_UPLOAD.getValue(), RMSEventConstantEnum.RMS_EVENT_ALARM_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_ALARM.getValue(), RMSEventConstantEnum.RMS_EVENT_GET_ALARM);
		events.put(RMSEventConstantEnum.RMS_EVENT_CONFIG_UPLOAD.getValue(),
				RMSEventConstantEnum.RMS_EVENT_CONFIG_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_CONFIGURATION.getValue(),
				RMSEventConstantEnum.RMS_EVENT_GET_CONFIGURATION);
		events.put(RMSEventConstantEnum.RMS_EVENT_COUNTER_UPLOAD.getValue(),
				RMSEventConstantEnum.RMS_EVENT_COUNTER_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_COUNTER.getValue(), RMSEventConstantEnum.RMS_EVENT_GET_COUNTER);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_FCAPS.getValue(), RMSEventConstantEnum.RMS_EVENT_GET_FCAPS);

		// Draft Event List
		events.put(RMSEventConstantEnum.RMS_EVENT_SAVE_AS_DRAFT.getValue(),
				RMSEventConstantEnum.RMS_EVENT_SAVE_AS_DRAFT);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_DRAFT.getValue(), RMSEventConstantEnum.RMS_EVENT_GET_DRAFT);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_STATUS.getValue(),
				RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_STATUS);
		events.put(RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT.getValue(), RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT);
		events.put(RMSEventConstantEnum.RMS_EVENT_DELETE_DRAFT.getValue(), RMSEventConstantEnum.RMS_EVENT_DELETE_DRAFT);
		events.put(RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_STATUS.getValue(),
				RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_STATUS);

		// CNF Draft Event List
		events.put(RMSEventConstantEnum.RMS_EVENT_SAVE_AS_DRAFT_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_SAVE_AS_DRAFT_CNF);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_CNF);
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_STATUS_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_GET_DRAFT_STATUS_CNF);
		events.put(RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_CNF);
		events.put(RMSEventConstantEnum.RMS_EVENT_DELETE_DRAFT_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_DELETE_DRAFT_CNF);
		events.put(RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_STATUS_CNF.getValue(),
				RMSEventConstantEnum.RMS_EVENT_UPDATE_DRAFT_STATUS_CNF);

		// Metadata Event
		events.put(RMSEventConstantEnum.RMS_EVENT_GET_METADATA.getValue(), RMSEventConstantEnum.RMS_EVENT_GET_METADATA);
		events.put(RMSEventConstantEnum.RMS_EVENT_SET_METADATA.getValue(), RMSEventConstantEnum.RMS_EVENT_SET_METADATA);
		events.put(RMSEventConstantEnum.RMS_EVENT_ADD_METADATA.getValue(), RMSEventConstantEnum.RMS_EVENT_ADD_METADATA);
		events.put(RMSEventConstantEnum.RMS_EVENT_MODIFY_METADATA.getValue(),
				RMSEventConstantEnum.RMS_EVENT_MODIFY_METADATA);
		events.put(RMSEventConstantEnum.RMS_EVENT_DELETE_METADATA.getValue(),
				RMSEventConstantEnum.RMS_EVENT_DELETE_METADATA);
		events.put(RMSEventConstantEnum.RMS_EVENT_VIEW_METADATA.getValue(),
				RMSEventConstantEnum.RMS_EVENT_VIEW_METADATA);

		// Notification Event Coming from NSCM MS
		events.put(RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_DELETION.getValue(),
				RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_DELETION);
		// Notification Event Coming from CNFLM MS
		
//		events.put(RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_CNF_TERMINATION.getValue(),
//				RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_CNF_TERMINATION);
		
		// Notification Event Coming from NSCM MS
//		events.put(RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_TERMINATION.getValue(),
//				RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_TERMINATION);
		
		// Notification Event Coming from NSCM MS
		events.put(RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_INSTANTIATION.getValue(),
				RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_VNF_INSTANTIATION);
		// Notification Event Coming from CNFLM MS
		events.put(RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_CNF_DELETION.getValue(),
				RMSEventConstantEnum.RMS_NOTIFICATION_EVENT_CNF_DELETION);

		// event for fcaps dictionary and template download
		events.put(RMSEventConstantEnum.RMS_EVENT_DOWNLOAD_FCAPS_DICTIONARY.getValue(),
				RMSEventConstantEnum.RMS_EVENT_DOWNLOAD_FCAPS_DICTIONARY);

		events.put(RMSEventConstantEnum.RMS_EVENT_DOWNLOAD_FCAPS_TEMPLATE.getValue(),
				RMSEventConstantEnum.RMS_EVENT_DOWNLOAD_FCAPS_TEMPLATE);
		
		
		//CNF FCAPS event List
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_ALARM_UPLOAD.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_ALARM_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_GET_ALARM.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_GET_ALARM);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_CONFIG_UPLOAD.getValue(),
				RMSEventConstantEnum.RMS_CNF_EVENT_CONFIG_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_GET_CONFIGURATION.getValue(),
				RMSEventConstantEnum.RMS_CNF_EVENT_GET_CONFIGURATION);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_COUNTER_UPLOAD.getValue(),
				RMSEventConstantEnum.RMS_CNF_EVENT_COUNTER_UPLOAD);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_GET_COUNTER.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_GET_COUNTER);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_GET_FCAPS.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_GET_FCAPS);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_DOWNLOAD_DICTIONARY.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_DOWNLOAD_DICTIONARY);
		events.put(RMSEventConstantEnum.RMS_CNF_EVENT_DOWNLOAD_TEMPLATE.getValue(), RMSEventConstantEnum.RMS_CNF_EVENT_DOWNLOAD_TEMPLATE);
		

	}

	/**
	 * 
	 * @param event
	 * @return
	 */

	public RMREventProcessor getEventObject(String event) {
		return RMSEventConstantEnum.getEventServiceObject(events.getOrDefault(event, RMSEventConstantEnum.UNKONWN),
				event);
	}

}
