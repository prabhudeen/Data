package com.rjil.rms.exceptions;

/**
 * Invalid Configurable Parameter User defined Exception
 * 
 * @author kiran.jangid
 *
 */

public class EventAckParsingException extends Exception {

	/**
	 * Generated serial ID
	 */
	private static final long serialVersionUID = -8654886743119415410L;

	/**
	 * 
	 * @param message
	 */

	public EventAckParsingException(String message) {
		super(message);
	}

	/**
	 * Invalid Configuration Parameter
	 */

	public EventAckParsingException() {
		super();
	}
}
