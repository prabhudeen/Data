package com.rjil.rms.es.operation;

/**
 * Custom Exception for ES Operation
 * 
 * @author kiran.jangid
 *
 */

public class ESOperationException extends Exception {

	private static final long serialVersionUID = -4314229941136315057L;

	/**
	 * Default
	 */

	public ESOperationException() {
		super();
	}

	/**
	 * Error Message
	 * 
	 * @param message
	 */

	public ESOperationException(String message) {
		super(message);
	}

	/**
	 * Error Message with Cause
	 * 
	 * @param message
	 * @param cause
	 */

	public ESOperationException(String message, Throwable cause) {
		super(message, cause);
	}

}
