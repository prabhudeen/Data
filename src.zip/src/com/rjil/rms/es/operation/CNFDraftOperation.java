package com.rjil.rms.es.operation;

import java.util.List;

import com.rjil.rms.ui.metadata.error.DataNotAvailableError;

/**
 * 
 * @author Nikhil.Dosapati
 *
 */

public interface CNFDraftOperation {

	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */
	public boolean saveAsDraft(String cnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 * @throws DataNotAvailableError
	 */

	public Object getDraftInfo(String cnfId) throws ESOperationException, DataNotAvailableError;

	/**
	 * 
	 * @param status
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */
	public List<Object> getAllDraftInfo(String status, String operation)
			throws ESOperationException, DataNotAvailableError;

	/**
	 * 
	 * @param status
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */
	public int getDraftStatusInfo(String status, String operation) throws ESOperationException, DataNotAvailableError;

	/**
	 * 
	 * @param cnfId
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */
	public boolean deleteDraft(String cnfId, String operation) throws ESOperationException, DataNotAvailableError;

	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */
	public boolean updateDraft(String cnfId, String jsonStr) throws ESOperationException, DataNotAvailableError;

	/**
	 * 
	 * @param cnfId
	 * @param operation
	 * @param status
	 * @return
	 * @throws ESOperationException
	 */
	public boolean updateDraftStatus(String cnfId, String operation, String status)
			throws ESOperationException, DataNotAvailableError;

}
