package com.rjil.rms.es.operation;

import java.util.List;

/**
 * @author Kiran.Jangid
 *
 */
public interface FCAPSOperation {

	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForCounter(String vnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForConfig(String vnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForAlarm(String vnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForCounter(String vnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForConfig(String vnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForAlarm(String vnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForCounter(String vnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForConfig(String vnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForAlarm(String vnfId) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForCounter(String vnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForConfig(String vnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForAlarm(String vnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public List<String> getAllFCAPSSheetForVnfid(String vnfId) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public List<String> listFCAPSSheets(String vnfId) throws ESOperationException;
}
