package com.rjil.rms.es.operation;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.get.MultiGetItemResponse;
import org.elasticsearch.action.get.MultiGetResponse;
import org.elasticsearch.action.index.IndexResponse;

import com.rjil.rms.cnf.fcaps.CNFFcapOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.db.RtJioRMRElasticConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

public class CNFFCAPSOperationImpl implements FCAPSCNFOperation {
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public boolean uploadFCAPSSheetForCounter(String cnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue()) ||
					String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForCounter", "Error in upload FCAPS Sheet for CNF Counter ", e);
		}
		return isInserted;
	}

	@Override
	public boolean uploadFCAPSSheetForConfig(String cnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue()) ||
					String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForConfig", "Error in upload FCAPS Sheet for CNF Config ", e);
		}
		return isInserted;
	}

	@Override
	public boolean uploadFCAPSSheetForAlarm(String cnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue()) ||
					String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForAlarm", "Error in upload FCAPS Sheet for CNF Alarm ", e);
		}
		return isInserted;
	}

	@Override
	public boolean updateFCAPSSheetForCounter(String cnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForCounter", "Error in update FCAPS Sheet for Counter ", e);
		}
		return isUpdated;
	}

	@Override
	public boolean updateFCAPSSheetForConfig(String cnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForConfig", "Error in update FCAPS Sheet for Config ", e);
		}
		return isUpdated;
	}

	@Override
	public boolean updateFCAPSSheetForAlarm(String cnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForAlarm", "Error in Update Alarm Sheet ", e);
			throw new ESOperationException("Error in Update Alarm Sheet", e.getCause());
		}
		return isUpdated;
	}

	@Override
	public boolean deleteFCAPSSheetForCounter(String cnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForCounter", "Error in Delete Counter Sheet ", e);
			throw new ESOperationException("Error in Delete Counter Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public boolean deleteFCAPSSheetForConfig(String cnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForConfig", "Error in Delete Config Sheet ", e);
			throw new ESOperationException("Error in Delete Config Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public boolean deleteFCAPSSheetForAlarm(String cnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForAlarm", "Error in Delete Alarm Sheet ", e);
			throw new ESOperationException("Error in Delete Alarm Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public String getFCAPSSheetForCounter(String cnfId) throws ESOperationException {
		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForCounter", "Data does not exist for the ID: " + cnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForCounter", "Error in Get Counter Sheet ", e);
			throw new ESOperationException("Error in Get Counter Sheet", e.getCause());
		}
		return jsonString;
	}

	@Override
	public String getFCAPSSheetForConfig(String cnfId) throws ESOperationException {

		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForConfig", "Config Data does not exist for the ID: " + cnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForConfig", "Error in Get Alarm Details ", e);
			throw new ESOperationException("Error in Get Config Sheet", e.getCause());
		}
		return jsonString;

	}

	@Override
	public String getFCAPSSheetForAlarm(String cnfId) throws ESOperationException {
		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
							CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(),
							cnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
				System.out.println("ES ALARM JSON | "+jsonString);
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForAlarm", "Alarm Data does not exist for the ID: " + cnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForAlarm", "Error in Get Alarm Details ", e);
			throw new ESOperationException("Error in Get Alarm Sheet", e.getCause());
		}
		return jsonString;
	}

	@Override
	public List<String> getAllFCAPSSheetForcnfId(String cnfId) throws ESOperationException {
		List<String> arrayList = new ArrayList<>();
		MultiGetResponse multiGetItemResponses = EsManager.getInstance().getClient().prepareMultiGet()
				.add(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
						CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(),
						cnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
				.add(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
						CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(),
						cnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
				.add(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue(),
						CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(),
						cnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
				.get();

		for (MultiGetItemResponse itemResponse : multiGetItemResponses) {
			GetResponse response = itemResponse.getResponse();
			if (response.isExists()) {
				arrayList.add(response.getSourceAsString());
			}
		}
		return arrayList;
	}

	@Override
	public List<String> listFCAPSSheets(String cnfId) throws ESOperationException {
		return new ArrayList<>();
	}

}
