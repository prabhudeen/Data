package com.rjil.rms.es.operation;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.get.MultiGetItemResponse;
import org.elasticsearch.action.get.MultiGetResponse;
import org.elasticsearch.action.index.IndexResponse;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.db.RtJioRMRElasticConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * @author Pramod.Jundre
 *
 */
public class FCAPSOperationImpl implements FCAPSOperation {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public boolean uploadFCAPSSheetForCounter(String vnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForCounter", "Error in upload FCAPS Sheet for Counter ", e);
		}
		return isInserted;
	}

	@Override
	public boolean uploadFCAPSSheetForConfig(String vnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForConfig", "Error in upload FCAPS Sheet for Config ", e);
		}
		return isInserted;
	}

	@Override
	public boolean uploadFCAPSSheetForAlarm(String vnfId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.setSource(jsonStr).get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadFCAPSSheetForAlarm", "Error in upload FCAPS Sheet for Alarm ", e);
		}
		return isInserted;
	}

	@Override
	public boolean updateFCAPSSheetForCounter(String vnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForCounter", "Error in update FCAPS Sheet for Counter ", e);
		}
		return isUpdated;
	}

	@Override
	public boolean updateFCAPSSheetForConfig(String vnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForConfig", "Error in update FCAPS Sheet for Config ", e);
		}
		return isUpdated;
	}

	@Override
	public boolean updateFCAPSSheetForAlarm(String vnfId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient().prepareIndex()
					.setSource(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateFCAPSSheetForAlarm", "Error in Update Alarm Sheet ", e);
			throw new ESOperationException("Error in Update Alarm Sheet", e.getCause());
		}
		return isUpdated;
	}

	@Override
	public boolean deleteFCAPSSheetForCounter(String vnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForCounter", "Error in Delete Counter Sheet ", e);
			throw new ESOperationException("Error in Delete Counter Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public boolean deleteFCAPSSheetForConfig(String vnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForConfig", "Error in Delete Config Sheet ", e);
			throw new ESOperationException("Error in Delete Config Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public boolean deleteFCAPSSheetForAlarm(String vnfId) throws ESOperationException {
		boolean isDeleted = false;
		try {
			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				isDeleted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteFCAPSSheetForAlarm", "Error in Delete Alarm Sheet ", e);
			throw new ESOperationException("Error in Delete Alarm Sheet", e.getCause());
		}
		return isDeleted;
	}

	@Override
	public String getFCAPSSheetForCounter(String vnfId) throws ESOperationException {
		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForCounter", "Data does not exist for the ID: " + vnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForCounter", "Error in Get Counter Sheet ", e);
			throw new ESOperationException("Error in Get Counter Sheet", e.getCause());
		}
		return jsonString;
	}

	@Override
	public String getFCAPSSheetForConfig(String vnfId) throws ESOperationException {

		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForConfig", "Config Data does not exist for the ID: " + vnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForConfig", "Error in Get Alarm Details ", e);
			throw new ESOperationException("Error in Get Config Sheet", e.getCause());
		}
		return jsonString;

	}

	@Override
	public String getFCAPSSheetForAlarm(String vnfId) throws ESOperationException {
		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
							vnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getFCAPSSheetForAlarm", "Alarm Data does not exist for the ID: " + vnfId);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSSheetForAlarm", "Error in Get Alarm Details ", e);
			throw new ESOperationException("Error in Get Alarm Sheet", e.getCause());
		}
		return jsonString;
	}

	@Override
	public List<String> getAllFCAPSSheetForVnfid(String vnfId) throws ESOperationException {
		List<String> arrayList = new ArrayList<>();
		MultiGetResponse multiGetItemResponses = EsManager.getInstance().getClient().prepareMultiGet()
				.add(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
						RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
						vnfId + RtJioRMRElasticConstantsEnum.ALARM.getValue())
				.add(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
						RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
						vnfId + RtJioRMRElasticConstantsEnum.COUNTER.getValue())
				.add(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
						RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue(),
						vnfId + RtJioRMRElasticConstantsEnum.CONFIG.getValue())
				.get();

		for (MultiGetItemResponse itemResponse : multiGetItemResponses) {
			GetResponse response = itemResponse.getResponse();
			if (response.isExists()) {
				arrayList.add(response.getSourceAsString());
			}
		}
		return arrayList;
	}

	@Override
	public List<String> listFCAPSSheets(String vnfId) throws ESOperationException {
		return new ArrayList<>();
	}

}
