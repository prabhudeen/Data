package com.rjil.rms.es.operation;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkIndexByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.search.SearchHit;

import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.db.RtJioRMRElasticConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class HAOperationImpl implements HAOperation {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void dumpEventData(String identifier, String eventData) {

		final String methodName = "dumpEventData";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Writing Data in ES = " + eventData);

		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.HA_TYPE.getValue() + "",
							identifier)
					.setSource(eventData).get();

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue().toString())
					|| String.valueOf(response.getResult())
							.equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue().toString())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Event has been dump successfully");
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Event Dumping", e);
		}
	}

	@Override
	public String getEventData(String identifier) {

		final String methodName = "getEventData";

		String jsonString = null;

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Es Id = " + identifier);

		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.HA_TYPE.getValue() + "",
							identifier)
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in view Event Data");
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in view Event Data", e);
		}
		return jsonString;
	}

	@Override
	public void removeEventData(String identifier) {

		final String methodName = "removeEventData";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Deleting Data in ES = " + identifier);

		try {

			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.HA_TYPE.getValue() + "",
							identifier)
					.get();

			if (String.valueOf(response.getResult())
					.equals(RtJioRMRElasticConstantsEnum.DELETED.getValue().toString())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Event is removed from Dump");
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Removing Data from Dump", e);
		}

	}

	@Override
	public List<String> getAllEventData() {

		final String methodName = "getAllEventData";

		ArrayList<String> identifierList = new ArrayList<>();

		try {

			SearchResponse response = EsManager.getInstance().getClient()
					.prepareSearch(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
					.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
							+ RtJioRMRElasticConstantsEnum.HA_TYPE.getValue() + "")
					.setQuery(QueryBuilders.matchAllQuery()).setSize(500).get();

			for (SearchHit hit : response.getHits()) {
				String eventStr = hit.getSourceAsString();
				identifierList.add(eventStr);
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Event Json : " + eventStr);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in List Event Ids", e);
		}
		return identifierList;
	}

}
