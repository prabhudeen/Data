package com.rjil.rms.es.operation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.db.RtJioRMRElasticConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * @author Pramod.Jundre
 *
 */

public class VNFOperationImpl implements VNFOperation {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public boolean uploadVNFCImage(String vnfcId, String jsonStr) throws ESOperationException {
		boolean isInserted = false;
		try {
			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.TYPE.getValue().toString(),
							vnfcId)
					.setSource(jsonStr).get();

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue().toString())
					|| String.valueOf(response.getResult())
							.equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue().toString())) {
				isInserted = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"uploadVNFCImage", "Error in Upload VNFC Image", e);
		}
		return isInserted;
	}

	@Override
	public boolean updateVNFCImage(String vnfcId, String jsonStr) throws ESOperationException {
		boolean isUpdated = false;
		try {

			UpdateResponse response = EsManager.getInstance().getClient()
					.prepareUpdate(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.TYPE.getValue().toString(),
							vnfcId)
					.setDoc(jsonStr).get();

			if (String.valueOf(response.getResult())
					.equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue().toString())) {
				isUpdated = true;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateVNFCImage", "Error in Update VNFC Image", e);
		}
		return isUpdated;
	}

	@Override
	public boolean deleteVNFCImage(String vnfcId) throws ESOperationException {

		boolean isDeleted = false;

		try {

			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.TYPE.getValue().toString(),
							vnfcId)
					.get();
			if (String.valueOf(response.getResult())
					.equals(RtJioRMRElasticConstantsEnum.DELETED.getValue().toString())) {

				isDeleted = true;

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"deleteVNFCImage", "Image Deleted from ES");
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"deleteVNFCImage", "Error in Delete VNFC Image", e);
		}
		return isDeleted;
	}

	@Override
	public String getVNFCImage(String vnfcId) throws ESOperationException {
		String jsonString = null;
		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.TYPE.getValue().toString(),
							vnfcId)
					.get();
			if (response.isExists()) {
				jsonString = response.getSourceAsString();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"getVNFCImage", "Error in View VNFC Image");
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getVNFCImage", "Error in View VNFC Image", e);
		}
		return jsonString;
	}

	@Override
	public List<Object> listVNFCImages(String vnfId) throws ESOperationException {

		final String methodName = "listVNFCImages";

		List<Object> vnfcImage = new ArrayList<>();

		try {

			SearchResponse resp = EsManager.getInstance().getClient()
					.prepareSearch(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
					.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
							+ RtJioRMRElasticConstantsEnum.TYPE.getValue())
					.setQuery(
							QueryBuilders.matchQuery(RtJioRMRElasticConstantsEnum.VNF_ID.getValue().toString(), vnfId))
					.setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

			for (SearchHit hit : resp.getHits()) {
				Map<String, Object> dataSourceName = hit.getSource();
				vnfcImage.add(dataSourceName);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"List VNFC Image = " + vnfcImage);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in List VNFC Image", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.ES_DATA_READ_FAILURE_DURING_VNF_IMAGE_READ);
		}
		return vnfcImage;
	}

	@Override
	public List<Object> listVNFCImages(Map queryParameter) throws ESOperationException {

		List<Object> vnfcImage = new ArrayList<>();
		final String methodName = "listVNFCImages";

		@SuppressWarnings("unchecked")
		Iterator<String> imageList = queryParameter.keySet().iterator();

		BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();

		while (imageList.hasNext()) {
			String object = imageList.next();
			queryBuilder.must(QueryBuilders.matchQuery(object, queryParameter.get(object)));
		}

		try {

			SearchResponse resp = EsManager.getInstance().getClient()
					.prepareSearch(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
					.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
							+ RtJioRMRElasticConstantsEnum.TYPE.getValue())
					.setQuery(queryBuilder).setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

			for (SearchHit hit : resp.getHits()) {
				Map<String, Object> dataSourceName = hit.getSource();
				vnfcImage.add(dataSourceName);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"List VNFC Image = " + vnfcImage);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in List VNFC Image", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.ES_DATA_READ_FAILURE_DURING_VNF_IMAGE_READ);
		}
		return vnfcImage;
	}
}
