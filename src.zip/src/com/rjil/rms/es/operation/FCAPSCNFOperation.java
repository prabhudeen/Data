package com.rjil.rms.es.operation;

import java.util.List;

public interface FCAPSCNFOperation {
	
	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForCounter(String cnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForConfig(String cnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadFCAPSSheetForAlarm(String cnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForCounter(String cnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForConfig(String cnfId, String jsonStr) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateFCAPSSheetForAlarm(String cnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForCounter(String cnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForConfig(String cnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteFCAPSSheetForAlarm(String cnfId) throws ESOperationException;

	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForCounter(String cnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForConfig(String cnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public String getFCAPSSheetForAlarm(String cnfId) throws ESOperationException;
	
	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public List<String> getAllFCAPSSheetForcnfId(String cnfId) throws ESOperationException;

	/**
	 * 
	 * @param cnfId
	 * @return
	 * @throws ESOperationException
	 */

	public List<String> listFCAPSSheets(String cnfId) throws ESOperationException;

}
