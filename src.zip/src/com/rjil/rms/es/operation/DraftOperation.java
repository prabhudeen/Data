package com.rjil.rms.es.operation;

import java.util.List;

import com.rjil.rms.ui.metadata.error.DataNotAvailableError;

/**
 * @author Kiran.Jangid
 *
 */
public interface DraftOperation {

	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean saveAsDraft(String vnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public Object getDraftInfo(String vnfId) throws ESOperationException;

	/**
	 * 
	 * @param status
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */

	public List<Object> getAllDraftInfo(String status, String operation) throws ESOperationException;

	/**
	 * 
	 * @param status
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */

	public int getDraftStatusInfo(String status, String operation) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @param operation
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteDraft(String vnfId, String operation) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateDraft(String vnfId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * @param vnfId
	 * @param operation
	 * @param status
	 * @return
	 * @throws ESOperationException
	 * @throws DataNotAvailableError 
	 */

	public boolean updateDraftStatus(String vnfId, String operation, String status) throws ESOperationException, DataNotAvailableError;
}
