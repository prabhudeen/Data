package com.rjil.rms.es.operation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.SearchHit;
import org.json.JSONObject;

import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.db.RtJioRMRElasticConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;

/**
 * @author Nikhil.Dosapati
 */

public class CNFDraftOperationImpl implements CNFDraftOperation {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public boolean saveAsDraft(String identifier, String jsonStr) throws ESOperationException {

		boolean isInserted = false;

		try {

			IndexResponse response = EsManager.getInstance().getClient()
					.prepareIndex(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "",
							identifier)
					.setSource(jsonStr).get();

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.CREATED.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"saveAsDraft", "Data Write Successful for : id = " + identifier);
				isInserted = true;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"saveAsDraft", "Error in writing draft info in Elastic Database ", e);
		}
		return isInserted;
	}

	@Override
	public Object getDraftInfo(String identifier) throws ESOperationException, DataNotAvailableError {
		final String methodName = "getDraftInfo";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"DB Looking for Identifier : " + identifier);

		Object jsonString = null;

		try {
			GetResponse response = EsManager.getInstance().getClient()
					.prepareGet(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "",
							identifier)
					.get();
			if (response.isExists()) {

				jsonString = new JSONObject(response.getSource());

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Data exist for the ID : " + identifier + " | Data : " + jsonString);

			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Data does not exist for the ID: " + identifier);

				throw new DataNotAvailableError();
			}

		} catch (DataNotAvailableError e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Get Draft Data : Data Not Available", e);
			throw new DataNotAvailableError();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Get Draft Data", e);
			throw new ESOperationException("Error in Get Draft Data", e.getCause());
		}

		return jsonString;
	}

	@Override
	public List<Object> getAllDraftInfo(String status, String operation) throws ESOperationException {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "getAllDraftInfo",
				"DB Request for status : " + status + " | operation : " + operation);

		List<Object> arrayList = new ArrayList<>();

		try {

			if (status != null && !"all".equalsIgnoreCase(status)) {

				SearchResponse resp = EsManager.getInstance().getClient()
						.prepareSearch(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "")
						.setQuery(QueryBuilders.boolQuery()
								.must(QueryBuilders.matchQuery(DraftOperationConstantsEnum.STATUS.getValue(), status))
								.must(QueryBuilders.matchQuery(DraftOperationConstantsEnum.OPERATION.getValue(),
										operation)))
						.setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

				for (SearchHit hit : resp.getHits()) {
					Map<String, Object> dataSourceName = hit.getSource();
					arrayList.add(dataSourceName);
				}

			} else {

				SearchResponse resp = EsManager.getInstance().getClient()
						.prepareSearch(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "")
						.setQuery(QueryBuilders.matchQuery(DraftOperationConstantsEnum.OPERATION.getValue(), operation))
						.setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

				for (SearchHit hit : resp.getHits()) {
					Map<String, Object> dataSourceName = hit.getSource();
					arrayList.add(dataSourceName);
				}

			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getAllDraftInfo", "Error in Get All Draft Info ", e);
			throw new ESOperationException("Error in Get All Draft Info ", e.getCause());
		}

		return arrayList;
	}

	@Override
	public int getDraftStatusInfo(String status, String operation) throws ESOperationException {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"getDraftStatusInfo", "DB Request for status : " + status + " | operation : " + operation);

		try {

			if (status != null && !"all".equalsIgnoreCase(status)) {

				SearchResponse resp = EsManager.getInstance().getClient()
						.prepareSearch(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "")
						.setQuery(QueryBuilders.boolQuery()
								.must(QueryBuilders.matchQuery(DraftOperationConstantsEnum.STATUS.getValue(), status))
								.must(QueryBuilders.matchQuery(DraftOperationConstantsEnum.OPERATION.getValue(),
										operation)))
						.setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

				return resp.getHits().hits().length;

			} else {

				SearchResponse resp = EsManager.getInstance().getClient()
						.prepareSearch(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
								+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "")
						.setQuery(QueryBuilders.matchQuery(DraftOperationConstantsEnum.OPERATION.getValue(), operation))
						.setSize((Integer) RtJioRMRElasticConstantsEnum.DOC_COUNT.getValue()).get();

				return resp.getHits().hits().length;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getDraftStatusInfo", "Error in Get Draft Status ", e);
			throw new ESOperationException("Error in Get Draft Status ", e.getCause());
		}

	}

	@Override
	public boolean deleteDraft(String cnfId, String operation) throws ESOperationException {

		boolean isDelete = false;

		final String identifier = cnfId + "_" + operation;

		final String methodName = "deleteDraft";

		try {

			DeleteResponse response = EsManager.getInstance().getClient()
					.prepareDelete(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "",
							identifier)
					.get();

			response.status();

			if (response.status().equals(RestStatus.NOT_FOUND)) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Data Not available for : id = " + identifier);
				return true;
			}

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.DELETED.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Data Deleted Successful for : id = " + identifier);
				isDelete = true;
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Data  not deleted = " + String.valueOf(response.getResult()));
				isDelete = true;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Delete draft info in Elastic Database ", e);
		}
		return isDelete;
	}

	@Override
	public boolean updateDraft(String cnfId, String jsonStr) throws ESOperationException {

		boolean isUpdated = false;

		final String methodName = "updateDraft";

		try {

			UpdateResponse response = EsManager.getInstance().getClient()
					.prepareUpdate(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue(),
							RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
									+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "",
							cnfId)
					.setDoc(jsonStr).get();

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Data updating Successful for : id = " + cnfId);
				isUpdated = true;
			} else if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.NOOP.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "update Draft Already Updated : id = " + cnfId);
				isUpdated = true;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in updating draft info in Elastic Database ", e);
		}

		return isUpdated;
	}

	@Override
	public boolean updateDraftStatus(String cnfId, String operation, String status) throws ESOperationException {

		boolean isUpdated = false;

		final String methodName = "updateDraftStatus";

		try {

			final String identifier = cnfId + "_" + operation;

			Map<String, Object> jsonMap = new HashMap<>();
			jsonMap.put("status", status);
			jsonMap.put(DraftOperationConstantsEnum.LAST_MODIFIED.getValue(), System.currentTimeMillis());
			UpdateRequest request = new UpdateRequest(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue(),
					RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
							+ RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue() + "",
					identifier).doc(jsonMap);

			UpdateResponse response = EsManager.getInstance().getClient().update(request).get();

			if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.UPDATED.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "update Draft Status Successful for : id = " + cnfId);
				isUpdated = true;
			} else if (String.valueOf(response.getResult()).equals(RtJioRMRElasticConstantsEnum.NOOP.getValue())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "update Draft Already Updated : id = " + cnfId);
				isUpdated = true;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in update Draft Status info in Elastic Database ", e);
		}

		return isUpdated;
	}

}
