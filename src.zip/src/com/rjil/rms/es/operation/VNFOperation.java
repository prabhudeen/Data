package com.rjil.rms.es.operation;

import java.util.List;
import java.util.Map;

/**
 * @author Pramod.Jundre
 *
 */
public interface VNFOperation {

	/**
	 * input field vnfcId and Json
	 * 
	 * @param vnfcId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean uploadVNFCImage(String vnfcId, String jsonStr) throws ESOperationException;

	/**
	 * input field vnfcId and json that will be updated
	 * 
	 * @param vnfcId
	 * @param jsonStr
	 * @return
	 * @throws ESOperationException
	 */

	public boolean updateVNFCImage(String vnfcId, String jsonStr) throws ESOperationException;

	/**
	 * 
	 * Input field only vnfcId
	 * 
	 * @param vnfcId
	 * @return
	 * @throws ESOperationException
	 */

	public boolean deleteVNFCImage(String vnfcId) throws ESOperationException;

	/**
	 * 
	 * @param vnfcId
	 * @return
	 * @throws ESOperationException
	 */

	public String getVNFCImage(String vnfcId) throws ESOperationException;

	/**
	 * 
	 * Return list of VNFCImage json list
	 * 
	 * @param vnfId
	 * @return
	 * @throws ESOperationException
	 */

	public List<Object> listVNFCImages(String vnfId) throws ESOperationException;

	/**
	 * 
	 * @param queryParameter
	 * @return
	 * @throws ESOperationException
	 */

	public List<Object> listVNFCImages(Map queryParameter) throws ESOperationException;
}
