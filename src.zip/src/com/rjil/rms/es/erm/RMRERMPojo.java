package com.rjil.rms.es.erm;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMRERMPojo {

	private String ip;

	private int port;

	private boolean status;
	
	/**
	 * 
	 * @param ip
	 * @param port
	 * @param status
	 */

	public RMRERMPojo(String ip, int port, boolean status) {
		this.ip = ip;
		this.port = port;
		setStatus(status);
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
}
