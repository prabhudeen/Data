package com.rjil.rms.es.erm;

import java.util.HashMap;
import java.util.UUID;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;
import io.netty.handler.codec.http.HttpMethod;

/**
 * 
 * @author kiran.jangid
 * 
 */

public class RMRERMManager {
;
	private final LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final HashMap<Integer, String> statusCodeMap = new HashMap<>();
	static final int INITIAL_HOP_COUNT = 70;
	private String ermUrl;
	private String ermSubscriptionUrl;
	private String ermEventSendingUrl;
	private RMRERMPojo ermPojo;

	/**
	 * Error mapping for ERM response codes
	 */
	static {
		statusCodeMap.put(200, "Success");
		statusCodeMap.put(202, "Accepted");
		statusCodeMap.put(400, "Bad Request (Missing mandatory headers)");
		statusCodeMap.put(405, "HTTP method is not valid");
		statusCodeMap.put(500, "Internal Server error");
		statusCodeMap.put(600, "Event Name doesn't exist");
		statusCodeMap.put(601, "No subscriber for the given Event Name");
		statusCodeMap.put(602, "Micro-service name doesn't exist.");
	}

	/**
	 * 
	 * @param ip
	 * @param port
	 * @param status
	 */

	public void initialize(String ip, int port, boolean status) {
		if (this.ermPojo == null) {
			this.ermPojo = new RMRERMPojo(ip, port, status);
			this.ermUrl = new StringBuilder().append(RTJioRMSConstants.TAG_HTTP).append(ip)
					.append(RTJioRMSConstants.OP_COLON).append(port).toString();
			this.ermSubscriptionUrl = this.ermUrl + RtJioRMSConfigParamEnum.ERM_SUBSCRIPTION_CONTEXT.getStringValue();
			this.ermEventSendingUrl = this.ermUrl + RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "initialize",
					"Erm Url = " + this.ermUrl + "  || Sending Url = " + this.ermEventSendingUrl);
		} else
			this.ermPojo.setStatus(status);
	}

	/**
	 * This Method will re initialise Active ERM
	 */

	public void reInitialize() {

		final String methodName = "reInitialize";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Removing Inactive ERM-ELB and ReInitialising ERM-ELB URL");

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Available ERM-ELB in Cache : " + RtJioRMSCacheManager.getInstance().getErmELBList());

			RtJioRMSCacheManager.getInstance().getErmELBList().remove(0);

			if (RtJioRMSCacheManager.getInstance().getErmELBList().isEmpty()) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "No Active ELB is Available");
				return;
			}

			this.ermPojo = RtJioRMSCacheManager.getInstance().getErmELBList().get(0);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Active ERM-ELB is Now : " + "ip = " + this.ermPojo.getIp() + " | port = " + this.ermPojo.getPort()
							+ " | status = " + this.ermPojo.isStatus());

			if (this.ermPojo.isStatus()) {

				this.ermUrl = new StringBuilder().append(RTJioRMSConstants.TAG_HTTP).append(ermPojo.getIp())
						.append(RTJioRMSConstants.OP_COLON).append(ermPojo.getPort()).toString();
				this.ermSubscriptionUrl = this.ermUrl
						+ RtJioRMSConfigParamEnum.ERM_SUBSCRIPTION_CONTEXT.getStringValue();
				this.ermEventSendingUrl = this.ermUrl + RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue()
						+ "/?operation=All";

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Erm Url = " + this.ermUrl + "  || Sending Url = " + this.ermEventSendingUrl);

			} else {
				reInitialize();
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Re-Init Active ERM ELB : ", e);
		}

	}

	/**
	 * 
	 * @param eventName
	 */

	public void subscribeEvent(String eventName) {

		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_SUBSCRIBE_REQUESTS.increment();

		try {
			RestTalkResponse response = new RestTalkBuilder().Post(this.ermSubscriptionUrl)
					.addQueryParam(RMRERMHttpParametersAndHeadersIntf.ACTION,
							RMRERMHttpParametersAndHeadersIntf.ACTION_SUBSCRIBE)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME,
							RMRERMHttpParametersAndHeadersIntf.MY_EVENT)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.SRC_MS_IP_PORT,
							RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
									+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue())
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.MS_NAME,
							RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue())
					.send();
			int responseCode = response.getHttpStatusCode();

			if (responseCode >= 200 && responseCode < 300) {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"subscribeEvent", response.answeredContent().responseString(),
						"subscribe EventName = " + eventName, null, RTJioRMSConstants.MS_ERM);
				RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESSFUL_SUBSCRIBE_REQUESTS.increment();
			} else {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "run",
						response.answeredContent().responseString(), "subscribe EventName = " + eventName, null,
						RTJioRMSConstants.MS_ERM);
				RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_SUBSCRIBE_REQUESTS.increment();
			}
		} catch (Exception e) {
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_SUBSCRIBE_REQUESTS.increment();
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "run",
					null, RTJioRMSConstants.MS_ERM, e);
		}
	}

	/**
	 * 
	 * @param eventName
	 */

	public void unsubscribeEvent(String eventName) {

		RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_UNSUBSCRIBE_REQUESTS.increment();

		final String methodName = "unsubscribeEvent";

		try {

			RestTalkResponse response = new RestTalkBuilder().Delete(this.ermSubscriptionUrl)
					.addQueryParam(RMRERMHttpParametersAndHeadersIntf.ACTION,
							RMRERMHttpParametersAndHeadersIntf.ACTION_SUBSCRIBE)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME,
							RMRERMHttpParametersAndHeadersIntf.MY_EVENT)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.SRC_MS_IP_PORT,
							RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
									+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue())
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME,
							RMRERMHttpParametersAndHeadersIntf.MY_EVENT)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.MS_NAME,
							RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue())
					.send();

			int responseCode = response.getHttpStatusCode();
			if (responseCode >= 200 && responseCode < 300) {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						response.answeredContent().responseString(), "unsubscribeEvent EventName = " + eventName, null,
						RTJioRMSConstants.MS_ERM);
				RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESSFUL_UNSUBSCRIBE_REQUESTS.increment();
			} else {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						response.answeredContent().responseString(), "unsubscribeEvent EventName = " + eventName, null,
						RTJioRMSConstants.MS_ERM);
				RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_UNSUBSCRIBE_REQUESTS.increment();
			}
		} catch (Exception e) {
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					null, RTJioRMSConstants.MS_ERM, e);
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_UNSUBSCRIBE_REQUESTS.increment();
		}
	}

	/**
	 * creates a REST-Talk builder for a new event based on the method type
	 * 
	 * @param eventMethod
	 *            HTTP method of the event
	 * @return the builder instance
	 */
	public RestTalkBuilder createNewEventBuilder(HttpMethod eventMethod) {
		RestTalkBuilder builder = null;
		try {
			switch (eventMethod.name()) {
			case "POST":
				builder = new RestTalkBuilder().Post(this.ermEventSendingUrl);
				break;
			case "DELETE":
				builder = new RestTalkBuilder().Delete(this.ermEventSendingUrl);
				break;
			case "PUT":
				builder = new RestTalkBuilder().Put(this.ermEventSendingUrl);
				break;
			default:
				builder = new RestTalkBuilder().Get(this.ermEventSendingUrl);
				break;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"createNewEventBuilder", "Unable to borrow object from RestTalkBuilderPool ", e);
		}
		return builder;
	}

	/**
	 * creates a new Rest-Talk builder for a new event-ACK
	 * 
	 * @return the builder instance
	 */
	public RestTalkBuilder createNewEventAckBuilder() {
		return new RestTalkBuilder().Post(this.ermEventSendingUrl);
	}

	/**
	 * sends an event to Event Routing Manager
	 * 
	 * @param builder
	 *            builder instance
	 * @param eventName
	 *            name of the event to send
	 * @param messageBody
	 *            content body of the event (if applicable)
	 * @param targetMsName
	 *            name of the microservice for which this event is destined
	 */
	public void sendEvent(RestTalkBuilder builder, String eventName, String messageBody, String targetMsName) {
		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_SEND.increment();
		RMRERMEventSenderThread task;
		try {
			task = new RMRERMEventSenderThread();
			task.setParams(builder, eventName, messageBody, generateUUID(),
					RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_VALUE, targetMsName);
			task.setBranchId(generateUUID());
			RtJioRMSCacheManager.getInstance().getExecutorService().execute(task);
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_SEND.increment();
		} catch (Exception e) {
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND.increment();
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendEvent", "Unable to borrow ERMEventSenderThread from pool", e);
		}
	}

	/**
	 * 
	 * @param builder
	 * @param eventName
	 * @param messageBody
	 * @param targetMsName
	 * @param flowId
	 */

	public void sendEvent(RestTalkBuilder builder, String eventName, String messageBody, String targetMsName,
			String flowId) {
		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_SEND.increment();
		RMRERMEventSenderThread task;
		try {
			task = new RMRERMEventSenderThread();
			task.setParams(builder, eventName, messageBody, flowId,
					RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_VALUE, targetMsName);
			task.setBranchId(generateUUID());
			RtJioRMSCacheManager.getInstance().getExecutorService().execute(task);
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_SEND.increment();
		} catch (Exception e) {
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND.increment();
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendEvent", "Unable to borrow ERMEventSenderThread from pool for flow ID : " + flowId, e);
		}
	}

	/**
	 * 
	 * @param builder
	 * @param eventName
	 * @param messageBody
	 * @param targetMsName
	 * @param flowId
	 * @param branchId
	 */

	public void sendEvent(RestTalkBuilder builder, String eventName, String messageBody, String targetMsName,
			String flowId, String branchId) {
		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_SEND.increment();
		RMRERMEventSenderThread task;
		try {
			task = new RMRERMEventSenderThread();
			task.setParams(builder, eventName, messageBody, flowId,
					RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_VALUE, targetMsName);
			task.setBranchId(branchId);
			RtJioRMSCacheManager.getInstance().getExecutorService().execute(task);
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_SEND.increment();
		} catch (Exception e) {
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND.increment();
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendEvent", "Unable to borrow ERMEventSenderThread from pool for flow ID : " + flowId, e);
		}
	}

	/**
	 * sends an acknowledgement back for an event received to Event Routing
	 * Manager
	 * 
	 * @param builder
	 *            builder instance
	 * @param eventName
	 *            name of the event to send
	 * @param flowId
	 *            flowId received in the original event
	 * @param messageBody
	 *            content body of the event (if applicable)
	 * @param targetMsName
	 *            name of the microservice for which this event is destined
	 */
	public void sendEventAck(RestTalkBuilder builder, String eventName, String flowId, String messageBody,
			String targetMsName) {
		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_ACK_REQUESTS_SEND.increment();
		RMRERMEventSenderThread task;
		try {
			task = (RMRERMEventSenderThread) PoolingManager.getPoolingManager()
					.borrowObject(RMRERMEventSenderThread.class);
			task.setParams(builder, eventName, messageBody, generateUUID(),
					RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_ACK_VALUE, targetMsName);
			RtJioRMSCacheManager.getInstance().getExecutorService().execute(task);
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					"sendEventAck", "Flow Id = " + flowId);
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_ACK_REQUESTS_SEND.increment();

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendEventAck", "Unable to borrow ERMEventSenderThread from pool ", e);
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_SEND.increment();
		}
	}

	private String generateUUID() {
		return UUID.randomUUID().toString();
	}

	/**
	 * @return check if ELB of ERM is available
	 */
	public boolean isElbAvailable() {
		return this.ermPojo != null && this.ermPojo.isStatus();
	}

	public RMRERMPojo getERMPojo() {
		return this.ermPojo;
	}
}
