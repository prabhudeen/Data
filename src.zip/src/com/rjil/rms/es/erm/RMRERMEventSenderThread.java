package com.rjil.rms.es.erm;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.message.BasicHeader;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.resttalk.service.custom.exceptions.RestTalkInvalidURLException;
import com.jio.resttalk.service.custom.exceptions.RestTalkServerConnectivityError;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMRERMEventSenderThread implements Runnable {

	private final LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RestTalkBuilder builder;
	private String eventName;
	private String msgBody;
	private String flowId;
	private String msgType;
	private String targetMS;
	private String branchId;

	/**
	 * 
	 * @param builder
	 * @param eventName
	 * @param msgBody
	 * @param flowId
	 * @param msgType
	 * @param targetMS
	 */

	public void setParams(RestTalkBuilder builder, String eventName, String msgBody, String flowId, String msgType,
			String targetMS) {
		this.builder = builder;
		this.eventName = eventName;
		this.msgBody = msgBody;
		this.flowId = flowId;
		this.msgType = msgType;
		this.targetMS = targetMS;
	}

	@Override
	public void run() {

		if (this.msgType.equals(RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_VALUE)) {

			sendEvent();

		}
	}

	private void sendEvent() {

		final String methodName = "sendEvent";

		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_SEND.increment();

		RestTalkResponse response;

		try {

			response = this.builder.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME, this.eventName)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.SRC_MS_IP_PORT,
							RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
									+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue())
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.PUBLISHER_NAME,
							OamClientManager.getInstance().getOAMClientParam("componenttype"))
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.SRC_MS_CONTEXT,
							RtJioRMSConfigParamEnum.RMR_EVENT_CONTEXT.getStringValue())
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.FLOW_ID, this.flowId)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.BRANCH_ID, this.branchId)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.HOP_COUNT, RTJioRMSConstants.HOP_COUNT)
					.addCustomHeader(RMRERMHttpParametersAndHeadersIntf.MSG_TYPE, this.msgType)
					.addRequestData(this.msgBody).send();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Send Event to MS : Urls : " + this.builder.getUrl());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Send Event to MS : Parameters : " + this.builder.getQueryString());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Send Event to MS : Headers : " + getHeaders());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Send Event to MS : Request Body : " + this.builder.getRequestDataString());

			if (response.getHttpStatusCode() == RMRERMResponseCodes.SUCCESS.responseCode()) {
				RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_SEND.increment();
			} else {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "run",
						this.msgBody, response.answeredContent().responseString(), flowId, this.targetMS);
				RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND.increment();
			}

		} catch (RestTalkInvalidURLException | RestTalkServerConnectivityError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendResponseToMS", "Error in Sending Requst to ELB Probable Cause : ERM-ELB is Down : ", e);

			RtJioRMSCacheManager.getInstance().getErmManager().reInitialize();

			if (RtJioRMSCacheManager.getInstance().getErmManager().getERMPojo().isStatus()) {
				sendEvent();
			}

		} catch (Exception e) {
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "run",
					flowId, this.targetMS, e);
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND.increment();
		}

	}

	/**
	 * @return the branchId
	 */
	public String getBranchId() {
		return branchId;
	}

	/**
	 * @param branchId
	 *            the branchId to set
	 */
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	private Map getHeaders() {

		Map<String, String> headerMap = new HashMap<>();

		for (BasicHeader basicHeader : this.builder.getRestTalkHeaders()) {
			headerMap.put(basicHeader.getName(), basicHeader.getValue());
		}

		return headerMap;

	}
}
