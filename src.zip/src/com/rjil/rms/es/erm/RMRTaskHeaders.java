package com.rjil.rms.es.erm;

/**
 * Class to define various constants used for communication with SCM via ERM
 * 
 * @author kiran.jangid
 *
 */
public class RMRTaskHeaders {
	/**
	 * Constants for Task Handling
	 */
	public static final String TASK_NAME = "taskName";
	public static final String TASK_DESCRIPTION = "taskDescription";
	public static final String CRON_NAME = "cronName";
	public static final String COMPONENT_ID = "componentId";
	public static final String STARTFROM = "startFrom";
	public static final String STARTTIME = "startTime";
	public static final String ENDAT = "endAt";
	public static final String ENDTIME = "endTime";
	public static final String NOOFITERATION = "startFrom";
	public static final String ISCUSTOM = "iscustom";
	public static final String PERFORMINDEXING = "performIndexing";
	public static final String PRODUCTNAME = "productName";
	public static final String IP = "ip";
	public static final String PORT = "port";
	public static final String FTP_USERNAME = "username";
	public static final String FTP_CREDENTIAL = "password";
	public static final String DATE_FORMAT = "dateFormat";
	public static final String MULTIPLE_FOLDER_FORMAT = "multipleFolderFormat";
	public static final String FILE_LOCATION = "fileLocation";
	public static final String SELECTED_FOLDER_TYPE = "selectedFolderType";
	public static final String FILE_SEPARATOR = "fileSeperator";
	public static final String MULTIPLE_FOLDER_STATUS = "multipleFolderStatus";
	public static final String ZIP_FILE_LOCATION = "zipFileLocation";
	public static final String DATE_POSITION = "datePosition";
	public static final String MULTIPLE_FOLDER_TYPE = "multipleFolderType";
	public static final String ZIP_OR_TAR_STATUS = "zipOrTarStatus";
	public static final String FILE_FORMAT = "fileFormat";
	public static final String DELIMITER = "delimiter";

	private RMRTaskHeaders() {

	}
}
