package com.rjil.rms.es.erm;

/**
 * 
 * @author kiran.jangid
 *
 */

public enum RMRERMResponseCodes {

	SUCCESS(202),

	METHOD_OTHER_THAN_POST_DELETE(405),

	INTERNAL_SERVER_ERROR(500),

	EVENT_NAME_DOESNOT_EXIST(600),

	MICRO_SERVICE_NAME_DOESNOT_EXIST(602);

	private int responseCode;

	RMRERMResponseCodes(int responseCode) {
		this.responseCode = responseCode;
	}
	
	/**
	 * 
	 * @return
	 */

	public int responseCode() {
		return responseCode;
	}
}
