package com.rjil.rms.es.db;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

import org.elasticsearch.action.bulk.BackoffPolicy;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.xpack.client.PreBuiltXPackTransportClient;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.es.operation.CNFDraftOperationImpl;
import com.rjil.rms.es.operation.CNFFCAPSOperationImpl;
import com.rjil.rms.es.operation.DraftOperationImpl;
import com.rjil.rms.es.operation.FCAPSOperationImpl;
import com.rjil.rms.es.operation.HAOperation;
import com.rjil.rms.es.operation.HAOperationImpl;
import com.rjil.rms.es.operation.VNFOperationImpl;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;

/**
 * @author Pramod.Jundre
 *
 */
public class EsManager {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private TransportClient client;
	private BulkProcessor processor;
	private static EsManager connectionManager = new EsManager();

	public static final String ES_CLUSTER_NAME = "cluster.name";
	public static final String ES_XPACK_USER_AND_PASS_WD = "xpack.security.user";
	public static final String INDEX_DOC_LIMIT = "index.max_result_window";
	public static final long INDEX_DOC_LIMIT_VALUE = 500000;
	private VNFOperationImpl vnfOperationImpl = new VNFOperationImpl();
	private FCAPSOperationImpl fcapsOperationImpl = new FCAPSOperationImpl();
	private DraftOperationImpl draftOperationImpl = new DraftOperationImpl();
	private CNFDraftOperationImpl cnfdraftOperationImpl = new CNFDraftOperationImpl();
	private CNFFCAPSOperationImpl cnfFcapsOperationImpl = new CNFFCAPSOperationImpl();
	private HAOperation haOperation = new HAOperationImpl();

	private EsManager() {

	}

	public static EsManager getInstance() {
		if (connectionManager == null) {
			connectionManager = new EsManager();
		}
		return connectionManager;
	}

	/**
	 * 
	 * @param clusterName
	 * @param xpackUserName
	 * @param xpackPassword
	 * @param esNodesAddress
	 * @param indexName
	 * @return
	 */

	public boolean initESConnection(String clusterName, String xpackUserName, String xpackPassword,
			Map<String, String> esNodesAddress) {

		boolean isSuccess = false;

		try {

			if (this.createConnection(clusterName, xpackUserName, xpackPassword, esNodesAddress)) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"initESConnection", "DB Connection Successful");
				isSuccess = true;
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"initESConnection", "Error in ES Connection ", e);

			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.RMS_DATABASE_CONNECTION_FAILURE);
		}
		return isSuccess;
	}

	/**
	 * To create schema
	 */

	public void createSchema() {

		final String methodName = "createSchema";

		if (!ESSchemaGenerator.getInstance().createVNFCBinarySchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"VNFC Binary Schema Creation Failed");
		}

		if (!ESSchemaGenerator.getInstance().createVNFDraftSchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"VNF Draft Schema Creation Failed");
		}

		if (!ESSchemaGenerator.getInstance().createCNFDraftSchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"CNF Draft Schema Creation Failed");
		}

		if (!ESSchemaGenerator.getInstance().createVNFFCAPSSchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"FCAPS Schema Creation Failed");
		}
		
		
		if (!RtJioCNFSchemaGenerator.getInstance().createCNFFCAPSDictionary()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"CNF FCAPS Schema Creation Failed");
		}

	}

	private boolean createConnection(String clusterName, String xpackUserName, String xpackPassword,
			Map<String, String> esNodesAddress) {

		boolean isConnected = false;
		try {
			Settings settings = Settings.builder().put(ES_CLUSTER_NAME, clusterName)
					.put(ES_XPACK_USER_AND_PASS_WD, xpackUserName + ":" + xpackPassword).build();

			InetSocketTransportAddress[] transportAddresses = new InetSocketTransportAddress[esNodesAddress.size()];
			int addressPosition = 0;

			for (Map.Entry<String, String> ipPort : esNodesAddress.entrySet()) {

				transportAddresses[addressPosition] = new InetSocketTransportAddress(
						InetAddress.getByName(ipPort.getKey()), Integer.parseInt(ipPort.getValue()));
				addressPosition++;
			}

			client = new PreBuiltXPackTransportClient(settings);
			client.addTransportAddresses(transportAddresses);

			client.connectedNodes();

			isConnected = client.connectedNodes().isEmpty() ? false : true;
			if (!(isConnected && this.createBulkProcessor())) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"createConnection", "Error create bulk processor ");
			}

		} catch (UnknownHostException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"createConnection", "Error in create connection  ", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.RMS_DATABASE_CONNECTION_FAILURE);
		}
		return isConnected;
	}

	/**
	 * This method is used to create bulk processor for elasticsearch
	 * 
	 * @return true if processor init successful
	 */
	private boolean createBulkProcessor() {
		final String methodName = "createBulkProcessor";
		boolean processorFlag = false;
		processor = BulkProcessor.builder(client, new BulkProcessor.Listener() {
			@Override
			public void beforeBulk(long executionId, BulkRequest request) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Unsupported Operation");
			}

			@Override
			public void afterBulk(long executionId, BulkRequest request, BulkResponse response) {
				if (response.hasFailures()) {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "BULK FAILURE  ");
				}
			}

			@Override
			public void afterBulk(long executionId, BulkRequest request, Throwable failure) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, " Exception in bulk insertion " + failure);
			}
		}).setBulkActions(7500).setFlushInterval(TimeValue.timeValueSeconds(5)).setConcurrentRequests(2)
				.setBackoffPolicy(BackoffPolicy.exponentialBackoff(TimeValue.timeValueMillis(100), 3)).build();

		if (processor != null) {
			processorFlag = true;
		}
		return processorFlag;
	}

	/**
	 * This method is used to check is index exist for given index name
	 * 
	 * @param indexName
	 * @return
	 */

	public boolean isIndexExist(String indexName) {

		boolean isExist = false;
		try {
			isExist = EsManager.getInstance().getClient().admin().indices().prepareExists(indexName).get().isExists();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"isIndexExist", "Index Check Error  ", e);
		}
		return isExist;
	}

	/**
	 * 
	 * @param indexName
	 * @return
	 */

	public boolean createIndex(String indexName) {
		boolean flag = false;
		try {

			if (isIndexExist(indexName)) {
				return true;
			}

			flag = client.admin().indices().prepareCreate(indexName)
					.setSettings(Settings.builder().put(INDEX_DOC_LIMIT, INDEX_DOC_LIMIT_VALUE)).get().isAcknowledged();
			
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"createIndex", "Create Index Failure  ", e);
		}
		return flag;
	}

	public FCAPSOperationImpl getFcapsOperationImpl() {
		return fcapsOperationImpl;
	}

	public DraftOperationImpl getDraftOperationImpl() {
		return draftOperationImpl;
	}

	public CNFDraftOperationImpl getCnfdraftOperationImpl() {
		return cnfdraftOperationImpl;
	}
	
	public CNFFCAPSOperationImpl getCNFFcapsOperationImpl() {
		return cnfFcapsOperationImpl;
	}

	/**
	 * @return the haOperation
	 */
	public HAOperation getHaOperation() {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "getHaOperation",
				"HAOperation : " + haOperation.getClass().getName());

		return haOperation;
	}

	public TransportClient getClient() {
		return client;
	}

	public BulkProcessor getProcessor() {
		return processor;
	}

	public VNFOperationImpl getVnfOperationImpl() {
		return vnfOperationImpl;
	}

}
