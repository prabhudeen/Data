package com.rjil.rms.es.db;

/**
 * Elastic Constant Used to Index Data
 * 
 * @author kiran.jangid
 *
 */

public enum RtJioRMRElasticConstantsEnum {

	CREATED("CREATED"),

	DELETED("DELETED"),

	UPDATED("UPDATED"),

	NOOP("NOOP"),

	VNF_ID("vnfId"),

	CNF_ID("cnfId"),

	TYPE("_typeimage"),

	FCAPS_TYPE("_typefcaps"),

	DRAFT_TYPE("_typedraft"),

	CNF_DRAFT_TYPE("_typecnfdraft"),

	HA_TYPE("_typeha"),

	COUNTER("_counter"),

	CONFIG("_config"),

	ALARM("_alarm"),

	DOC_COUNT(1000),

	DYNAMIC("dynamic"),

	PROPERTIES("properties"),

	KEYWORD_STR("keyword"),

	COMPLETE_JSON("comleteJson"),

	TEXT_STR("text"),

	ANALYZER_STR("analyzer"),

	STANDARD_STR("standard"),

	FIELDDATA_STR("fielddata"),

	FIELDS_STR("fields"),

	RAW_STR("raw"),

	TYPE_STR("type"),

	FALSE_BOOL(false),

	FALSE_STR("false"),

	TRUE_BOOL(true),

	TRUE_STR("true"),

	DATE_STR("date");

	private Object value;

	private RtJioRMRElasticConstantsEnum(Object value) {
		this.value = value;
	}

	public Object getValue() {
		return value;
	}

}
