package com.rjil.rms.es.db;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import org.elasticsearch.action.admin.indices.mapping.put.PutMappingResponse;
import org.elasticsearch.common.xcontent.XContentBuilder;

import com.rjil.rms.cnf.fcaps.CNFFcapOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

public class RtJioCNFSchemaGenerator {
	
	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static RtJioCNFSchemaGenerator generator;

	private RtJioCNFSchemaGenerator() {
	}

	public static RtJioCNFSchemaGenerator getInstance() {
		if (generator == null) {
			generator = new RtJioCNFSchemaGenerator();
		}
		return generator;
	}
	
	
	public boolean createCNFFCAPSAlarmDictonarySchema() {

		boolean mappingFlag = false;

		final String methodName = "createCNFFCAPSAlarmDictonarySchema";

		try {

			XContentBuilder vnfcBinaryBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.TIME_STAMP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
						.setTypes(CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
							.setType(CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue())
							.setSource(vnfcBinaryBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For CNF FCAPS Alarm Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist For CNF FCAPS Alarm Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping For CNF FCAPS Alarm Data ");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping For CNF FCAPS Alarm Data ", e);
		}

		return mappingFlag;

	}
	
	public boolean createCNFFCAPSConfigDictonarySchema() {

		boolean mappingFlag = false;

		final String methodName = "createCNFFCAPSConfigDictonarySchema";

		try {

			XContentBuilder vnfcBinaryBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.TIME_STAMP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
						.setTypes(CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
							.setType(CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue())
							.setSource(vnfcBinaryBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For CNF FCAPS Config Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist For CNF FCAPS Config Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping For CNF FCAPS Config Data ");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping For CNF FCAPS Config Data ", e);
		}

		return mappingFlag;

	}
	
	public boolean createCNFFCAPSCounterDictonarySchema() {

		boolean mappingFlag = false;

		final String methodName = "createCNFFCAPSCounterDictonarySchema";

		try {

			XContentBuilder vnfcBinaryBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFFcapOperationConstantsEnum.TIME_STAMP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
						.setTypes(CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_INDEX_NAME.getStringValue())
							.setType(CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue())
							.setSource(vnfcBinaryBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For CNF FCAPS Counter Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist For CNF FCAPS Counter Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping For CNF FCAPS Counter Data ");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping For CNF FCAPS Counter Data ", e);
		}

		return mappingFlag;

	}
	
	public boolean  createCNFFCAPSDictionary() {
		String methodName = "createCNFFCAPSDictionary";
		//creating CNF ALARM Dictionary Schema
		if(!createCNFFCAPSAlarmDictonarySchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"CNF FCAPS Alarm Schema Creation Failed");
			return false;
			
		}
		
		//creating CNF Config Dictionary Schema
		if(!createCNFFCAPSConfigDictonarySchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"CNF FCAPS Config Schema Creation Failed");
			return false;
		}
				
		//creating CNF Counter Dictionary Schema
		if(!createCNFFCAPSCounterDictonarySchema()) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"CNF FCAPS Counter Schema Creation Failed");
			return false;
		}
		
		return true;
		
	}

}
