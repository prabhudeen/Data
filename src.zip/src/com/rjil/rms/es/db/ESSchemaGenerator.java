package com.rjil.rms.es.db;

import org.elasticsearch.common.xcontent.XContentBuilder;
import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import org.elasticsearch.action.admin.indices.mapping.put.PutMappingResponse;

import com.rjil.rms.binary.BinaryOperationConstantEnum;
import com.rjil.rms.cnf.fcaps.CNFFcapOperationConstantsEnum;
import com.rjil.rms.draft.CNFDraftOperationConstantsEnum;
import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * 
 * Class to create ES Schema for vnfc binary, Draft and HA
 * 
 * @author Kiran.Jangid
 *
 */

public class ESSchemaGenerator {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static ESSchemaGenerator generator;

	private ESSchemaGenerator() {
	}

	public static ESSchemaGenerator getInstance() {
		if (generator == null) {
			generator = new ESSchemaGenerator();
		}
		return generator;
	}

	/**
	 * To create VNFC Binary Image Schema or Mapping in ES
	 * 
	 * @return
	 */

	public boolean createVNFCBinarySchema() {

		boolean mappingFlag = false;

		final String methodName = "createVNFCBinarySchema";

		try {

			XContentBuilder vnfcBinaryBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(BinaryOperationConstantEnum.VNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.IMAGE_DESCRIPTION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.IMAGE_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.FORMAT.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.FILE_URL.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.FILE_PATH.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.TIME_STAMP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ (String) RtJioRMRElasticConstantsEnum.TYPE.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
							.setType(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ (String) RtJioRMRElasticConstantsEnum.TYPE.getValue())
							.setSource(vnfcBinaryBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For VNFC Binary Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist for VNFC Binary Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping for VNFC Binary Data", e);
		}

		return mappingFlag;

	}

	/**
	 * To create VNF Draft Schema or Mapping in ES
	 * 
	 * @return
	 */

	public boolean createVNFDraftSchema() {

		boolean mappingFlag = false;

		final String methodName = "createVNFDraftSchema";

		try {

			XContentBuilder vnfDraftBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(DraftOperationConstantsEnum.VNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.VNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.OPERATION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.STATUS.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.STEP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.LAST_MODIFIED.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.USERNAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.USER_STATUS.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ (String) RtJioRMRElasticConstantsEnum.DRAFT_TYPE.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
							.setType(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ (String) RtJioRMRElasticConstantsEnum.DRAFT_TYPE.getValue())
							.setSource(vnfDraftBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For VNF Draft Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist for VNF Draft Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping VNF Draft Data");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping for VNF Draft Data", e);
		}

		return mappingFlag;

	}

	/**
	 * To create CNF Draft Schema or Mapping in ES
	 * 
	 * @return
	 */

	public boolean createCNFDraftSchema() {

		boolean mappingFlag = false;

		final String methodName = "createCNFDraftSchema";

		try {

			XContentBuilder cnfDraftBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(CNFDraftOperationConstantsEnum.CNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.CNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.OPERATION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.STATUS.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.STEP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.LAST_MODIFIED.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject(DraftOperationConstantsEnum.USERNAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(CNFDraftOperationConstantsEnum.USER_STATUS.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
								+ (String) RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue())
							.setType(RtJioRMSConfigParamEnum.RMR_CNF_DRAFT_INDEX_NAME.getStringValue()
									+ (String) RtJioRMRElasticConstantsEnum.CNF_DRAFT_TYPE.getValue())
							.setSource(cnfDraftBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For CNF Draft Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist for CNF Draft Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping VNF Draft Data");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping for CNF Draft Data", e);
		}

		return mappingFlag;

	}

	/**
	 * To create HA Schema or Mapping in ES
	 * 
	 * @return
	 */

	public boolean createHADataSchema() {

		boolean mappingFlag = false;

		final String methodName = "createHADataSchema";

		try {

			XContentBuilder connectionPointBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(BinaryOperationConstantEnum.VNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VNFC_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(BinaryOperationConstantEnum.VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ (String) RtJioRMRElasticConstantsEnum.TYPE.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
							.setType(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ (String) RtJioRMRElasticConstantsEnum.TYPE.getValue())
							.setSource(connectionPointBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For HA Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist for HA Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rmr data  And then Create Mapping For HA Data ");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping For HA Data ", e);
		}

		return mappingFlag;

	}

	/**
	 * To create VNF FCAPS Data Schema or Mapping in ES
	 * 
	 * @return
	 */

	public boolean createVNFFCAPSSchema() {

		boolean mappingFlag = false;

		final String methodName = "createVNFFCAPSSchema";

		try {

			XContentBuilder vnfcBinaryBuilder = jsonBuilder().startObject()
					.field((String) RtJioRMRElasticConstantsEnum.DYNAMIC.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.FALSE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.PROPERTIES.getValue())

					.startObject(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_VNF_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.startObject(FCAPSOperationConstantsEnum.TIME_STAMP.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.DATE_STR.getValue())
					.endObject()

					.startObject((String) RtJioRMRElasticConstantsEnum.COMPLETE_JSON.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.TEXT_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.ANALYZER_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.STANDARD_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.FIELDDATA_STR.getValue(),
							(boolean) RtJioRMRElasticConstantsEnum.TRUE_BOOL.getValue())

					.startObject((String) RtJioRMRElasticConstantsEnum.FIELDS_STR.getValue())
					.startObject((String) RtJioRMRElasticConstantsEnum.RAW_STR.getValue())
					.field((String) RtJioRMRElasticConstantsEnum.TYPE_STR.getValue(),
							(String) RtJioRMRElasticConstantsEnum.KEYWORD_STR.getValue())
					.endObject()

					.endObject()

					.endObject()

					.endObject().endObject();

			boolean respFlag = EsManager.getInstance().getClient().admin().indices()
					.prepareExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()).get().isExists();

			if (respFlag) {

				respFlag = EsManager.getInstance().getClient().admin().indices()
						.prepareTypesExists(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
						.setTypes(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
								+ (String) RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue())
						.get().isExists();

				if (!respFlag) {

					PutMappingResponse resp = EsManager.getInstance().getClient().admin().indices()
							.preparePutMapping(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue())
							.setType(RtJioRMSConfigParamEnum.RMR_BINARY_INDEX_NAME.getStringValue()
									+ (String) RtJioRMRElasticConstantsEnum.FCAPS_TYPE.getValue())
							.setSource(vnfcBinaryBuilder).get();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Created Successfully For VNF FCAPS Data : " + resp.isAcknowledged());

				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Mapping Already Exist For VNF FCAPS Data ");
				}

				mappingFlag = true;

			} else {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "First Create Index for rms data And then Create Mapping For VNF FCAPS Data ");
			}

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in ES Mapping For VNF FCAPS Data ", e);
		}

		return mappingFlag;

	}
	
	

}
