package com.rjil.rms.rest.handlers;

/**
 * 
 * Constant to Build Response
 * 
 * @author kiran.jangid
 *
 */

public enum ResponseConstantsEnum {

	RESPONSE_SUCCESS("SUCCESS"),

	RESPONSE_INTERNAL_SERVICE_ERROR("Internal Service Error"),

	RESPONSE_MANDATORY_PARAMETER_MISSING("Mandatory Parameter Missing"),

	RESPONSE_DUPLICATE_DATA_ENTRY("Duplicate Data Entry"),

	RESPONSE_ERROR("ERROR"),

	TYPE_METADATA_PARAMETER_MISSING_OR_INVALID("Type Parameter is missing or invalid"),

	CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID("Category Parameter is missing or invalid"),

	PARAMETER_AND_VALUES_INVALID("Parameter/Value is missing or invalid"),

	RESPONSE_DATA_NOT_AVAILABLE("Data doesnot available"),

	REQUEST_JSON_INVALID("Request Json is missing or Invalid"),
	
	JSON_PARSING_ERROR_AT_SERVER("Internal Server Error in JSON Parsing"),
	
	ES_READ_OPERATION_FAILURE("Database read operation failure"),
	
	RECEIVED_INVALID_DATA("Invalid Data Received"),
	
	IVALID_EVENT("Event not fount"),
	
	EVENT_NOT_AVAILABLE("RMR not subscriber for this event");

	private String value;

	private ResponseConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
