package com.rjil.rms.rest.handlers;

import org.json.JSONObject;

/**
 * 
 * @author kiran.jangid
 *
 */

public class ResponsePayload {

	private int httpStatusCode;

	private String errorCode;

	private String errorMessage;

	private Object appData;

	private String type;

	private String log;

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public Object getAppData() {
		return appData;
	}

	public void setAppData(JSONObject appData) {
		this.appData = appData;
	}

	@Override
	public String toString() {
		JSONObject obj = new JSONObject(this);
		return obj.toString();
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
