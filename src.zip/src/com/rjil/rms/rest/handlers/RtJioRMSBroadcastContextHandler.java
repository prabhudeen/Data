package com.rjil.rms.rest.handlers;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.broadcast.manager.BroadCastHeadersEnum;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.erm.RMRERMPojo;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.ha.DumpEventProcessTask;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.OAMERMConstantEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * Context handler to receive broadcast events sent by OAM
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMSBroadcastContextHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		final String methodName = "doPost";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Received POST request in Broadcast handler.");

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request Params : " + req.getParameterMap() + " | Broadcast Action : "
							+ req.getHeader(BroadCastHeadersEnum.BROADCAST_ACTION.getValue())
							+ " | Broadcast Microservice : "
							+ req.getHeader(BroadCastHeadersEnum.INSTANCE_ID.getValue()));

			// processing RMR HA Request Data
			if (req.getHeader(BroadCastHeadersEnum.BROADCAST_ACTION.getValue()) != null
					&& !req.getHeader(BroadCastHeadersEnum.INSTANCE_ID.getValue())
							.equals(RtJioRMSCacheManager.getInstance().getMicroserviceId())) {

				RMRBroadcastPojo broadcastData = RtJioCommonMethods.getBroadcastDataFromRequest(req);
				RMRHAManager.getInstance().broadcastListener(broadcastData);
				return;
			}

			String requestData = IOUtils.toString(req.getInputStream());

			if (requestData == null || "NA".equals(requestData)) {
				return;
			}

			JSONObject broadCastJson = new JSONObject(requestData);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request Body of Broadcast Data : " + broadCastJson.toString() + " | Request Params : "
							+ req.getParameterMap() + " | Request Headers : " + req.getHeaderNames());

			// Processing ELB Instance Data
			if (broadCastJson.has(OAMERMConstantEnum.EDGELB.getValue())) {
				parseBroadCastJson(broadCastJson);
				return;
			}

			// Processing RMR Instance Data
			if (broadCastJson.has(OAMERMConstantEnum.MS_RMR.getValue())) {
				parseRMRBoardCastJson(broadCastJson);
				return;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Internal Service Error", e);
		} finally {

			try {
				resp.sendError(HttpServletResponse.SC_OK);
			} catch (Exception e2) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in JSON parsing", e2);
			}
		}
	}

	private void parseBroadCastJson(JSONObject broadCastJson) throws JSONException {

		JSONArray edgeLBobj = broadCastJson.getJSONArray(OAMERMConstantEnum.EDGELB.getValue());

		for (int k = 0; k < edgeLBobj.length(); k++) {

			JSONObject eObj = edgeLBobj.getJSONObject(k);

			boolean activeLb = eObj.getBoolean(OAMERMConstantEnum.ACTIVE.getValue());

			if (!activeLb) {
				continue;
			}

			JSONArray subsctype = edgeLBobj.getJSONObject(k)
					.getJSONArray(OAMERMConstantEnum.SUBSCRIBECOMPONENTTYPE.getValue());

			for (int i = 0; i < subsctype.length(); i++) {

				if (subsctype.getString(i).equals(OAMERMConstantEnum.MS_ERM.getValue())) {

					RtJioRMSCacheManager.getInstance().getErmManager().initialize(
							eObj.getString(OAMERMConstantEnum.IP.getValue()),
							eObj.getInt(OAMERMConstantEnum.PORT.getValue()), activeLb);

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(),
							"parseBroadCastJson", "ID is broadcast for  : " + OAMERMConstantEnum.MS_ERM.getValue()
									+ "   is  : " + eObj.getString(OAMERMConstantEnum.ID.getValue()));

					RtJioRMSCacheManager.getInstance().getErmELBList()
							.add(new RMRERMPojo(eObj.getString(OAMERMConstantEnum.IP.getValue()),
									eObj.getInt(OAMERMConstantEnum.PORT.getValue()), activeLb));

				} else if (subsctype.getString(i).equals(OAMERMConstantEnum.MS_RMR.getValue())
						&& !RtJioRMSCacheManager.getInstance().getElbComponentIds()
								.contains(eObj.getString(OAMERMConstantEnum.ID.getValue()))) {

					RtJioRMSCacheManager.getInstance().getElbComponentIds()
							.add(eObj.getString(OAMERMConstantEnum.ID.getValue()));

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(),
							"parseBroadCastJson", "ID is broadcast for  : " + OAMERMConstantEnum.MS_RMR.getValue()
									+ "   is  : " + eObj.getString(OAMERMConstantEnum.ID.getValue()));

				}

			}
		}

	}

	/**
	 * Parsing RMR Broadcast Data
	 * 
	 * @return
	 * @throws JSONException
	 */

	void parseRMRBoardCastJson(JSONObject broadCastJson) throws JSONException {

		JSONArray rmrInstanceList = broadCastJson.getJSONArray(OAMERMConstantEnum.MS_RMR.getValue());

		boolean isCallForInstanceDown = false;

		for (int k = 0; k < rmrInstanceList.length(); k++) {

			JSONObject eObj = rmrInstanceList.getJSONObject(k);

			boolean activeInstance = eObj.getBoolean(OAMERMConstantEnum.ACTIVE.getValue());

			if (!activeInstance) {
				isCallForInstanceDown = true;
			}

		}

		if (isCallForInstanceDown) {

			int highestPriority = 0;

			for (int k = 0; k < rmrInstanceList.length(); k++) {

				JSONObject eObj = rmrInstanceList.getJSONObject(k);

				boolean activeInstance = eObj.getBoolean(OAMERMConstantEnum.ACTIVE.getValue());

				if (!activeInstance) {
					continue;
				}

				int instancePriority = eObj.getInt(OAMERMConstantEnum.MS_PRIORITY.getValue());

				if (highestPriority < instancePriority) {
					highestPriority = instancePriority;
				}

			}

			for (int k = 0; k < rmrInstanceList.length(); k++) {

				JSONObject eObj = rmrInstanceList.getJSONObject(k);

				boolean activeInstance = eObj.getBoolean(OAMERMConstantEnum.ACTIVE.getValue());

				if (!activeInstance) {
					continue;
				}

				int instancePriority = eObj.getInt(OAMERMConstantEnum.MS_PRIORITY.getValue());

				if ((highestPriority == instancePriority) && eObj.getString(OAMERMConstantEnum.ID.getValue())
						.equalsIgnoreCase(RtJioRMSCacheManager.getInstance().getMicroserviceId())) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							"parseRMRBoardCastJson", "ID is Processing Dump Queued Event  : "
									+ eObj.getString(OAMERMConstantEnum.ID.getValue()));

					// Processing Dump Event if Any
					processDumpEvent();
				}

			}

		}

	}

	/**
	 * Method to Process All Dump Event
	 */

	private void processDumpEvent() {

		List<String> eventString = EsManager.getInstance().getHaOperation().getAllEventData();

		Iterator<String> eventList = eventString.iterator();

		RMREventPojo eventPojo = new RMREventPojo();

		while (eventList.hasNext()) {

			String eventStr = eventList.next();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(),
					"processDumpEvent", "Processing Data = " + eventStr);

			RMREventPojo eventData;

			try {

				eventData = eventPojo.getEventPojo(eventStr);
				RtJioRMSCacheManager.getInstance().getThreadPoolExecutor().execute(new DumpEventProcessTask(eventData));

			} catch (JSONException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						"processDumpEvent", "Error in parsing Event Json to build Event Pojo " + eventStr, e);
			}

		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final String methodName = "doGet";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Received GET request in Broadcast handler.");

			String action = request.getParameter("operation");

			if ("reRegister".equalsIgnoreCase(action)) {
				processOAMRegisteration(request, response, ccAsnPojo);
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Invalid request recieved : " + action);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				ccAsnPojo.addClearCode(ClearCodes.OAM_REGISTERATION_INVALID.getValue(), ClearCodeLevel.INTERNAL);
			}

		} catch (Exception e) {
			ccAsnPojo.addClearCode(ClearCodes.OAM_REGISTERATION_FAILURE.getValue(), ClearCodeLevel.INTERNAL);
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Internal Service Error", e);
		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void processOAMRegisteration(HttpServletRequest request, HttpServletResponse response,
			ClearCodeAsnPojo ccAsnPojo) {

		final String methodName = "processOAMRegisteration";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Checking Registeration = " + OamClientManager.getInstance().isAlreadyConnectedToOAM());

		if (OamClientManager.getInstance().isAlreadyConnectedToOAM()) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"OAM Already Registered");
			ccAsnPojo.addClearCode(ClearCodes.OAM_ALREADY_REGISTERED.getValue(), ClearCodeLevel.INTERNAL);
			return;
		}

		String ip = request.getHeader("ip");
		String port = request.getHeader("port");
		String nettyPort = request.getHeader("nettyPort");

		try {

			OamClientManager.getInstance().setOAMDetails(ip, port, nettyPort);
			response.setStatus(HttpServletResponse.SC_OK);
			RtJioRMSCacheManager.getInstance().registerToOAM();

		} catch (IOException e) {
			ccAsnPojo.addClearCode(ClearCodes.OAM_CONFIG_REGISTRATION_FAILURE.getValue(), ClearCodeLevel.INTERNAL);
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Registration Failure Due to Configuration Error ", e);
		}

	}

}
