package com.rjil.rms.rest.handlers;

import javax.servlet.AsyncContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.jio.telco.framework.logger.Constants;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMRSubscribedEvent;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMSAsyncRequestDispatcher implements Runnable {

	private static final Logger logger = LogManager.getLogger(RMSAsyncRequestDispatcher.class);
	private AsyncContext asyncContext;
	private RMREventPojo eventTracking;

	public RMSAsyncRequestDispatcher() {
		/**
		 * Default Constructor
		 */
	}

	/**
	 * 
	 * @param eventTracking
	 * @param asyncCtx
	 */

	public RMSAsyncRequestDispatcher(RMREventPojo eventTracking, AsyncContext asyncCtx) {
		this.eventTracking = eventTracking;
		this.asyncContext = asyncCtx;
	}

	@Override
	public void run() {

		try {

			HttpServletResponse httpResp = (HttpServletResponse) asyncContext.getResponse();
			httpResp.setStatus(HttpStatus.SC_ACCEPTED);
			asyncContext.complete();
			RMRSubscribedEvent subscribedEvent = new RMRSubscribedEvent();
			RMREventProcessor processEvent = subscribedEvent.getEventObject(eventTracking.getEventName());
			processEvent.processEvent(eventTracking);

		} catch (Exception e) {
			asyncContext.complete();
			ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger).setException(e)
					.setClassMethodName("RMSAsyncRequestDispatcher:run").writeExceptionLog();
		}

	}
}