package com.rjil.rms.rest.handlers;

import javax.servlet.AsyncContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.jio.telco.framework.logger.Constants;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.eventack.EventAckProcessor;
import com.rjil.rms.eventack.RMRSubscribedEventAck;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMSEventAckRequestDispatcher implements Runnable {

	private static final Logger logger = LogManager.getLogger(RMSEventAckRequestDispatcher.class);
	private AsyncContext asyncContext;
	private RMREventPojo eventTracking;

	public RMSEventAckRequestDispatcher() {
		/**
		 * Default Constructor
		 */
	}
	
	/**
	 * 
	 * @param eventTracking
	 * @param asyncCtx
	 */

	public RMSEventAckRequestDispatcher(RMREventPojo eventTracking, AsyncContext asyncCtx) {
		this.eventTracking = eventTracking;
		this.asyncContext = asyncCtx;
	}

	@Override
	public void run() {

		try {

			HttpServletResponse httpResp = (HttpServletResponse) asyncContext.getResponse();
			httpResp.setStatus(HttpStatus.SC_ACCEPTED);
			asyncContext.complete();

			RMRSubscribedEventAck subEventAck = new RMRSubscribedEventAck();
			EventAckProcessor processEventAck = subEventAck.getEventObject(this.eventTracking.getEventName());
			processEventAck.processEventAck(this.eventTracking);

		} catch (Exception e) {
			asyncContext.complete();
			ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger).setException(e)
					.setClassMethodName("RMSAsyncRequestDispatcher:run").writeExceptionLog();
		}

	}
}