package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.jio.telco.framework.logger.Constants;
import com.jio.telco.framework.resource.ResourceBuilder;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMSAppAsyncListener implements AsyncListener {

	private static final Logger logger = LogManager.getLogger(RtJioRMSAppAsyncListener.class);

	@Override
	public void onComplete(AsyncEvent asynEvent) throws IOException {
		ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_INFO).setLogger(logger)
				.setServiceStatusDescription("ASYNC EVENT Successfully Executed ........ ")
				.setClassMethodName("RtJioRMSAppAsyncListener:onComplete").writeLog();
	}

	@Override
	public void onError(AsyncEvent arg0) throws IOException {
		ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger)
				.setServiceStatusDescription("ASYNC EVENT Failed ........ ")
				.setClassMethodName("RtJioRMSAppAsyncListener:onError").writeLog();
	}

	@Override
	public void onStartAsync(AsyncEvent arg0) throws IOException {
		ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_INFO).setLogger(logger)
				.setServiceStatusDescription("ASYNC EVENT OnstartAsync Executed ........ ")
				.setClassMethodName("RtJioRMSAppAsyncListener:onStartAsync").writeLog();
	}

	@Override
	public void onTimeout(AsyncEvent arg0) throws IOException {
		ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger)
				.setServiceStatusDescription("ASYNC EVENT Timeout ........ ")
				.setClassMethodName("RtJioRMSAppAsyncListener:onTimeout").writeLog();
	}

}
