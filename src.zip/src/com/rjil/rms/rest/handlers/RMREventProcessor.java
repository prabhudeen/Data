package com.rjil.rms.rest.handlers;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * @author kiran.jangid
 *
 */
@FunctionalInterface
public interface RMREventProcessor {

	/**
	 * 
	 * @param eventTracking
	 */
	public void processEvent(RMREventPojo eventTracking);

}
