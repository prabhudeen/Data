package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Context handler to receive FM internal configuration parameters events
 */
public class RtJioRMSConfigContextHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int responseCode = OamClientManager.getOamClientForConfiguration().pushConfigurationsToOamServer(
				RtJioRMSCacheManager.getInstance().getConfigurationManager().fetchConfigParamPojo());

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "doGet",
				"Received Response from OAM for POST of configuration parameters with status : " + responseCode);

		response.setStatus(HttpStatus.SC_OK);
	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String param = request.getHeader(RTJioRMSConstants.PARAMETER_SCALAR_PARAM);
		String value = request.getHeader(RTJioRMSConstants.PARAMETER_SCALAR_VALUE);

		if (param != null && value != null) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "doPut",
					"This is a PUT request for single set of parameter '" + param + "' with value '" + value + "'");
			response.setStatus(
					RtJioRMSCacheManager.getInstance().getConfigurationManager().updateParam(param, value, false, false)
							? HttpStatus.SC_OK : HttpStatus.SC_INTERNAL_SERVER_ERROR);
			return;
		}

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "doPut",
				"Invalid parameter values received for POST request from OAM. Sending " + HttpStatus.SC_BAD_REQUEST
						+ " to OAM");

		response.setStatus(HttpStatus.SC_BAD_REQUEST);
	}
}
