package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.management.alarm.AlarmManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Context handler to receive FM internal alarm events
 */
public class RtJioRMSAlarmContextHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final String methodName = "doGet";

		String level = request.getParameter(RTJioRMSConstants.PARAMETER_LEVEL);
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Got a GET request from OAM for alarms with level = " + level);
		try {
			String alarmXml = AlarmManager.getInstance().getAlarmsStringAsXML(level);
			response.sendError(HttpStatus.SC_OK);
			if (alarmXml != null && !alarmXml.equals(RTJioRMSConstants.EMPTY_ALARM_TAG)) {
				int responseCode = OamClientManager.getOamClientForAlarm().raiseBulkAlarms(alarmXml,
						RTJioRMSConstants.BULK_RESPONSE_FOR_POST, level);
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Alarm POST has been sent.Received response with status code " + responseCode);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Alarm Get Request", e);
		}
	}

	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String level = request.getParameter(RTJioRMSConstants.PARAMETER_LEVEL);
		String id = request.getParameter(RTJioRMSConstants.PARAMETER_ID);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "doDelete",
				"Alarm Level : " + level + " | " + "Alarm ID : " + id);

		try {
			if (level != null) {
				OamClientManager.getOamClientForAlarm().clearAlarmByLevel(level, false);
			} else {
				OamClientManager.getOamClientForAlarm().clearAlarmByName(id, false);
			}
			response.sendError(HttpStatus.SC_OK);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doDelete", "Error in Alarm Delete Request", e);
		}
	}
}
