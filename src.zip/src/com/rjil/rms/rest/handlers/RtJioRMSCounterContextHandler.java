package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Context handler to receive FM internal counter events
 */
public class RtJioRMSCounterContextHandler extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final String methodName = "doGet";

		String type = request.getHeader(RTJioRMSConstants.PARAMETER_TYPE);
		String reset = request.getHeader(RTJioRMSConstants.PARAMETER_RESET);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Got a GET request from OAM for '" + type + "' performance counters with reset parameter set to = "
						+ reset);
		try {

			String counterXml = RtJioRMSCacheManager.getInstance().getCounterManager().fetchAllCounterAsXml();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(), methodName,
					"Counter XML \n" + counterXml);

			response.sendError(HttpStatus.SC_OK);

			int result = OamClientManager.getOamClientForCounter().pushCountersToOamServer(counterXml, reset, type);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Response received for POST request sent for counter reset : " + result);

			if (result == HttpStatus.SC_OK && "1".equals(reset))
				RtJioRMSCacheManager.getInstance().getCounterManager().resetCounterForSpecificType(type, false);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Counter fetch request ", e);
		}
	}
}
