package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.jio.telco.framework.logger.Constants;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.es.erm.RMRERMHttpParametersAndHeadersIntf;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMRSubscribedEvent;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * 
 * Event Handler for Both Event and Event Ack Received form ERM
 * 
 * @author Kiran.Jangid
 *
 */

public class RMSEventHandler extends HttpServlet {

	private static final Logger logger = LogManager.getLogger(RMSEventHandler.class);
	private static final LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws ServletException, IOException {

		final String methodName = "service";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"received request on event Handdler ");

			if (!validate(httpRequest, httpResponse)) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "invalid request on event Handler .. ELB validation			 Failure.");
				RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_REQUESTS_RECEIVE.increment();
				httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST);
				return;
			}

			String eventName = httpRequest.getHeader(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME);
			String taskType = httpRequest.getHeader(RMRERMHttpParametersAndHeadersIntf.MSG_TYPE);

			if (eventName != null && taskType != null) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "event name is : " + eventName + "   and message type is : " + taskType);

				switch (taskType) {
				case RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_VALUE:
					processEvent(httpRequest, httpResponse);
					break;
				case RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_ACK_VALUE:
					processEventAck(httpRequest, httpResponse);
					break;
				case RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_DELIVERY_REPORT:
					processDeliveryReport(eventName, httpRequest, httpResponse);
					break;
				case RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_ACK_REPORT:
					processAckReport(eventName, httpRequest, httpResponse);
					break;
				default:
					RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_REQUESTS_RECEIVE.increment();
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, "message type is not appropriate so sending bad request");
					httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST);
					break;
				}

			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "invalid request on event Handdler ..as event name or msg type is null");
				RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_REQUESTS_RECEIVE.increment();
				httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST);
				return;
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "exception :  ", e);
			httpResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}

	}

	private void processEventAck(HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws IOException {

		final String methodName = "processEventAck";

		try {

			AsyncContext asyncCtx = httpRequest.startAsync();
			asyncCtx.addListener(new RtJioRMSAppAsyncListener());
			RMREventPojo eventTracking = RtJioCommonMethods.getEventAckDataFromRequest(httpRequest);

			if (eventTracking != null) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "event name header is not null  so processing the request : ");
				RtJioRMSCacheManager.getInstance().getThreadPoolExecutor()
						.execute(new RMSEventAckRequestDispatcher(eventTracking, asyncCtx));
				RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_ACK_REQUESTS_RECEIVE.increment();
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "event name header is null  so sending bad request : ");
				RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_RECEIVE.increment();
				httpResponse.setStatus(HttpStatus.SC_BAD_REQUEST);
			}

		} catch (Exception e) {
			ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger).setException(e)
					.setClassMethodName("RMSEventHandler:processEventAck").writeExceptionLog();
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_RECEIVE.increment();
			httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST);
			return;
		} finally {
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_ACK_REQUESTS_RECEIVE.increment();
			httpResponse.sendError(HttpServletResponse.SC_ACCEPTED);
		}

	}

	private void processEvent(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {

		final String methodName = "processEvent";

		AsyncContext asyncCtx = httpRequest.startAsync();
		asyncCtx.addListener(new RtJioRMSAppAsyncListener());
		RMREventPojo eventTracking = RtJioCommonMethods.getEventDataFromRequest(httpRequest);

		RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_RECEIVE.increment();

		if (eventTracking != null) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"event name header is not null  so processing the request : ");
			RtJioRMSCacheManager.getInstance().getThreadPoolExecutor()
					.execute(new RMSAsyncRequestDispatcher(eventTracking, asyncCtx));
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_RECEIVE.increment();
		} else {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"event name header is null  so sending bad request : ");
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_RECEIVE.increment();
			httpResponse.setStatus(HttpStatus.SC_BAD_REQUEST);
			asyncCtx.complete();
		}
	}

	private void processDeliveryReport(String eventName, HttpServletRequest httpRequest,
			HttpServletResponse httpResponse) throws IOException {

		final String methodName = "processDeliveryReport";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"processing Delivery Report ");

		try {
			new RMRSubscribedEvent().getEventObject(eventName);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Delivery report for event'" + eventName + "' is not supported", e);

			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_RECEIVE.increment();
			httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST);
			return;
		}
		RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_RECEIVE.increment();

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Delivery report for event '" + eventName + "' is :>\n"
						+ IOUtils.toString(httpRequest.getInputStream()));

		httpResponse.sendError(HttpServletResponse.SC_ACCEPTED);
	}

	private void processAckReport(String eventName, HttpServletRequest httpRequest, HttpServletResponse httpResponse)
			throws IOException {

		final String methodName = "processAckReport";

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"processing Ack Report ");

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"Ack for event '" + eventName + "' is :>\n" + IOUtils.toString(httpRequest.getInputStream()));

		httpResponse.sendError(HttpServletResponse.SC_ACCEPTED);
	}

	private boolean validate(HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws IOException {

		final String methodName = "validate";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"validating the request ");

			String elbId = httpRequest.getHeader(RMRERMHttpParametersAndHeadersIntf.LB_ID);

			if (!RtJioRMSCacheManager.getInstance().getElbComponentIds().contains(elbId)) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "ELB is not authorized ");

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, elbId + " is not in Components id  : "
								+ RtJioRMSCacheManager.getInstance().getElbComponentIds());

				httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
				return false;
			}
			String hopCount = httpRequest.getHeader(RMRERMHttpParametersAndHeadersIntf.HOP_COUNT);
			if (Integer.parseInt(hopCount) <= 0) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "hop count is not valid and its value is : " + hopCount);

				httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
				return false;
			}
		} catch (Exception e) {
			httpResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "exception : ", e);

			return false;
		}
		return true;
	}

}
