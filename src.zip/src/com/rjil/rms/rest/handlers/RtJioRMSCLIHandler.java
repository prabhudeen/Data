package com.rjil.rms.rest.handlers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRCliCommandEnum;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * CLI Handler for RMR
 * 
 * @author Kiran.Jangid
 *
 */

public class RtJioRMSCLIHandler extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		final String methodName = "doPost";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"received command from CLI");

			RMRCLIPojo cliData = RtJioCommonMethods.getCliDataFromRequest(req);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Command '" + cliData.getCommandName());

			RTJioRMRCliCommandEnum cliCommandEnum = RTJioRMRCliCommandEnum
					.getEnumFromCommandName(cliData.getCommandName());

			if (cliCommandEnum == null) {
				String errDescription = "Command '" + cliData.getCommandName() + "' is not a valid command";
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, errDescription);
				sendResponse(resp, errDescription, HttpStatus.SC_BAD_REQUEST);
				return;
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					" executing command : " + cliData.getCommandName());

			sendResponse(resp, cliCommandEnum.execute(cliData), HttpStatus.SC_OK);

		} catch (RTJioRMRCliCommandExecutionException e) {
			sendResponse(resp, e);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Exception in sending ", e);
		}
	}

	private void sendResponse(HttpServletResponse response, RTJioRMRCliCommandExecutionException e) {
		sendResponse(response, e.getMessage(), e.getStatus());
	}

	private void sendResponse(HttpServletResponse response, String body, int status) {
		try {
			response.getWriter().write(body);
			response.getWriter().flush();
			response.setStatus(status);
		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendResponse  : ", "IOexception  :  ", e);
		}
	}

}
