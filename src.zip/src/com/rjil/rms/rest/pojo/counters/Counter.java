package com.rjil.rms.rest.pojo.counters;

import java.util.ArrayList;
import java.util.List;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import com.atom.OAM.Client.ems.pojo.config.Param;

/**
 * 
 * Class to create all the parameter information in a specific format.
 * e.g.
 *
 * <counter type="">
 * <param name="" value="">
 * --------------
 * --------------
 * <param name="" value="">
 * </counter>
 *
 */

@Root(name="counter")
public class Counter {

	@ElementList(name = "param", empty = false, inline = true, required = true, type = Param.class)
	private List<Param> param;

	@Attribute(name="type", required=true)
	private String counterType;

	/**
	 * Counter Constructor
	 */
	
	public Counter(){
		param = new ArrayList<>();
	}
	
	/**
	 * 
	 * @return
	 */
	
	public List<Param> getParam() {
		return param;
	}
	
	/**
	 * 
	 * @param param
	 */
	
	public void setParam(List<Param> param) {
		this.param = param;
	}
	
	/**
	 * 
	 * @param par
	 */

	public void addToParamList(Param par){
		param.add(par);
	}
	
	/**
	 * 
	 * @return
	 */

	public String getCounterType() {
		return counterType;
	}
	
	/**
	 * 
	 * @param counterType
	 */
	
	public void setCounterType(String counterType) {
		this.counterType = counterType;
	}
}

