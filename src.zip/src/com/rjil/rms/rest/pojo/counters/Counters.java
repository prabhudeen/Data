package com.rjil.rms.rest.pojo.counters;

import java.util.ArrayList;
import java.util.List;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 * 
 * @author kiran.jangid
 *
 */

@Root(name="counters")
public class Counters {

	@ElementList(name = "counter", empty = false, required = true, inline = true, type = Counter.class)
	private ArrayList<Counter> counter;
	
	/**
	 * Counters Constructor
	 */
	
	public Counters(){
		counter = new ArrayList<>();
	}
	
	public List<Counter> getCounter() {
		return counter;
	}
	
	public void setCounter(List<Counter> cntr){
		this.counter.addAll(cntr);
	}
	
	/**
	 * 
	 * @param cntr
	 */
	
	public void addToCounterList(Counter cntr){
		if(cntr != null)
			this.counter.add(cntr);
	}
}