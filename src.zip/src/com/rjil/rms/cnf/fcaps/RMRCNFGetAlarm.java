package com.rjil.rms.cnf.fcaps;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.json.JSONObject;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.util.RtJioCNFFCAPSFolderStructureGenerator;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * to get cnf alarm dictionary
 * 
 * @author kiran.jangid
 *
 */
public class RMRCNFGetAlarm implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		final String methodName = "processEvent";

		String fileName = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String cnfId = eventTracking.getRequestParams().get(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue());
		String cnfVersion = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue());
		String vendorName = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue());
		String cnfName = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue());

		// building target path
		String targetPath = RtJioCNFFCAPSFolderStructureGenerator.generateCNFFcapsRep(
				CNFFcapOperationConstantsEnum.FCAPS_ALARM.getValue(), vendorName, cnfName, cnfVersion, false);

		if (cnfVersion == null && cnfName == null && vendorName == null && cnfId != null) {
			try {
				String cnfString = com.rjil.rms.es.db.EsManager.getInstance().getCNFFcapsOperationImpl()
						.getFCAPSSheetForAlarm(cnfId);
				JSONObject cnfObj = new JSONObject(cnfString);
				targetPath = cnfObj.getString(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue());
			} catch (Exception e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Get Alarm Sheet Service for CNFId ", e);
			}

		}

		try  {
			InputStream fis = new FileInputStream(new File(targetPath, fileName));
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
		    System.out.println("indisde alamr handler cath function ... ");
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Get Alarm Sheet Service ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}

	}

}
