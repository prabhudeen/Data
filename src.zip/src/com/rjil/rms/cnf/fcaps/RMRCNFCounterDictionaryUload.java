package com.rjil.rms.cnf.fcaps;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstantEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCNFFCAPSFolderStructureGenerator;
import com.rjil.rms.util.RtJioCommonRequestHandler;

import io.netty.handler.codec.http.HttpMethod;

/**
 * to upload counter dictionary
 * 
 * @author kiran.jangid
 *
 */
public class RMRCNFCounterDictionaryUload implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {
		final String methodName = "uploadCounterSheet";

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String fileName = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String cnfName = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue());
			String cnfId = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue());
			String cnfVersion = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue());
			String vendorId = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
			String vendorName = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue());

			// building target path
			String targetPath = RtJioCNFFCAPSFolderStructureGenerator.generateCNFFcapsRep(
					CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(), vendorName, cnfName, cnfVersion, true);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					targetPath, "Uploading counter sheet", eventTracking.getFlowId(), eventTracking.getPublisherName());

			FileUtils.writeByteArrayToFile(new File(targetPath, fileName), eventTracking.getRequestStream());

			JSONObject appData = new JSONObject();
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue(), cnfId);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue(), cnfVersion);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue(), cnfName);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue(), vendorName);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue(), fileName);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue(), targetPath);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue(), vendorId);
			appData.put(CNFFcapOperationConstantsEnum.APPDATA_DOWNLOAD_URL.getValue(),
					RtJioCNFFCAPSFolderStructureGenerator.generateDownloadUrlForCNF(
							CNFFcapOperationConstantsEnum.FCAPS_COUNTER.getValue(), vendorName, cnfName, cnfVersion,
							fileName));

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			// Code to write Data in ES
			if (EsManager.getInstance().getCNFFcapsOperationImpl().uploadFCAPSSheetForCounter(cnfId,
					appData.toString())) {

				RtJioRMSCacheManager.getInstance().getErmManager().sendEvent(
						RtJioRMSCacheManager.getInstance().getErmManager().createNewEventBuilder(HttpMethod.POST),
						RMSEventConstantEnum.PM_CNF_EVENT_COUNTER_UPLOAD.getValue(), appData.toString(),
						RtJioRMSConfigParamEnum.ERM_EVENT_CONTEXT.getStringValue(), eventTracking.getFlowId());

				payload.setAppData(appData);
				payload.setHttpStatusCode(200);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
				ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(),
						ClearCodeLevel.PROTOCOL);

				// sending broadcast to upload Alarms at All Instances
				RMRHAManager.getInstance().broadcastEvent(eventTracking);
			} else {
				payload.setHttpStatusCode(500);
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_FAILURE.getValue(),
						ClearCodeLevel.PROTOCOL);
			}

		} catch (Exception e) {
			
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload Counter Sheet", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

}
