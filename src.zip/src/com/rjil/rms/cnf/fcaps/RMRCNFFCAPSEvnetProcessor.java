package com.rjil.rms.cnf.fcaps;

import com.rjil.rms.es.operation.ESOperationException;
import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * @author kiran.jangid
 *
 */

@FunctionalInterface
public interface RMRCNFFCAPSEvnetProcessor {

	/**
	 * 
	 * @param eventTracking
	 */
	public void processEvent(RMREventPojo eventTracking) throws ESOperationException;

}
