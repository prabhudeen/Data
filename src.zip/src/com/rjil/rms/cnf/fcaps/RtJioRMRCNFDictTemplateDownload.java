package com.rjil.rms.cnf.fcaps;

import java.io.File;
import java.io.FileInputStream;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RTJioRMSConstants;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMRCNFDictTemplateDownload implements RMREventProcessor {

	private static final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		final String methodName = "downloadFile";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		ResponsePayload payload = new ResponsePayload();

		try {

			String targetPath = null;

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"processing event : " + eventTracking.getEventName());

			String fcapsType = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_TYPE.getValue());

			if (fcapsType == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue() + ", Type is Missing");
				return;
			}

			targetPath = RtJioRMSConfigParamEnum.RMR_DICT_TEMPLATE_CONTEXT.getValue().toString() + "/"
					+ CNFFcapOperationConstantsEnum.CNF_TEMPLATE_PATH.getValue() + "/" + fcapsType;

			String fileName = null;
			switch (fcapsType) {
			case RTJioRMSConstants.FCAP_TYPE_ALARM:
				fileName = RtJioRMSConfigParamEnum.RMR_CNF_TEMPLATE_ALARM_FILE_NAME.getValue().toString();
				break;
			case RTJioRMSConstants.FCAP_TYPE_CONFIG:
				fileName = RtJioRMSConfigParamEnum.RMR_CNF_TEMPLATE_CONFIG_FILE_NAME.getValue().toString();
				break;
			case RTJioRMSConstants.FCAP_TYPE_COUNTER:
				fileName = RtJioRMSConfigParamEnum.RMR_CNF_TEMPLATE_COUNTER_FILE_NAME.getValue().toString();
				break;
			default:
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "fcapsType is null : ");
			}

			File file = new File(targetPath, fileName);
			byte[] b = new byte[1];
			FileInputStream f = null;
			if (file.exists()) {
				f = new FileInputStream(file);
				b = new byte[f.available()];
				f.read(b);
				f.close();
			}
			JSONObject appData = new JSONObject();

			appData.put("fileName", fileName);
			appData.put("fileData", b);
			appData.put("fileFormat", "xlsx");
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

		} catch (Exception e1) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "IO exception in sending bad request", e1);
			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DOWNLOAD_CNF_TEMPLATE_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
