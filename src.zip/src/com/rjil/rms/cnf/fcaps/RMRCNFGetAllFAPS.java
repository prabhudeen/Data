package com.rjil.rms.cnf.fcaps;

import org.json.JSONArray;
import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMRCNFGetAllFAPS implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String cnfId = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue());

			JSONObject appData = new JSONObject();

			JSONArray arry = new JSONArray();

			for (String string : EsManager.getInstance().getCNFFcapsOperationImpl().getAllFCAPSSheetForcnfId(cnfId)) {
				arry.put(new JSONObject(string));
			}

			appData.put("fcaps", arry);

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			payload.setAppData(appData);
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSDetails", "Error in Get FCAPS Details ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getFCAPSDetails", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_UPLOAD_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);
		}

		RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
		ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);

	}

}
