package com.rjil.rms.cnf.fcaps;

public enum CNFFcapOperationConstantsEnum {

	APPDATA_FCAPS_TYPE("fcapType"),

	APPDATA_TYPE("type"),
	
	FCAPS_ALARM("alarm"),

	FCAPS_COUNTER("counter"),

	FCAPS_CONFIG("config"),

	APPDATA_CNF_ID("cnf-id"),

	APPDATA_CNF_VERSION("cnf-version"),

	APPDATA_CNF_NAME("cnf-name"),

	APPDATA_VENDOR_ID("cnf-vendor-id"),

	APPDATA_VENDOR_NAME("cnf-vendor-name"),

	APPDATA_FILE_NAME("file-name"),

	APPDATA_REPOSITORY_PATH("repository-path"),

	APPDATA_DOWNLOAD_URL("download-url"),

	TIME_STAMP("time-stamp"),
	
	CNF_TEMPLATE_PATH("cnf-template");

	private String value;

	private CNFFcapOperationConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
