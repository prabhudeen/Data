package com.rjil.rms.cnf.fcaps;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.util.RtJioCNFFCAPSFolderStructureGenerator;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * to get configuration sheet
 * 
 * @author kiran.jangid
 *
 */
public class RMRCNFGetConfig implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		String fileName = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String cnfId = eventTracking.getRequestParams().get(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue());
		String cnfVersion = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue());
		String vendorId = eventTracking.getRequestParams()
				.get(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());

		// building target path
		String targetPath = RtJioCNFFCAPSFolderStructureGenerator.generateCNFFcapsRep(
				CNFFcapOperationConstantsEnum.FCAPS_CONFIG.getValue(), vendorId, cnfId, cnfVersion, false);

		try (InputStream fis = new FileInputStream(new File(targetPath, fileName))) {

			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, null, fis);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getConfigSheet", "Error in Get Config Sheet Service ", e);
			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"getConfigSheet", eventTracking.getFlowId(), eventTracking.getPublisherName(), e);
		}

	}

}
