package com.rjil.rms.cnf.fcaps;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RtJioCNFFCAPSFolderStructureGenerator;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMSDownloadCNFFCAPSFileHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CONTENT_TYPE_OCTET = "application/octet-stream";
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "attachment; filename=\"";
	private ClearCodeAsnPojo ccAsnPojo = null;
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		this.ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		
		try {

			downloadFcaps(request, response);
			ccAsnPojo.setStartTime();
			
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doGet", "Error in Handling VNFC Image Download Request", e);

			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}
	}

	private void downloadFcaps(HttpServletRequest request, HttpServletResponse response) {

		final String methodName = "downloadFcaps";

		String fileName = request.getParameter(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String cnfName = request.getParameter(CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue());
		String cnfVersion = request.getParameter(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue());
		String vendorName = request.getParameter(CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue());
		String fcapsType = request.getParameter(CNFFcapOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue());

		String targetPath = RtJioCNFFCAPSFolderStructureGenerator.generateCNFFcapsRep(fcapsType, vendorName, cnfName,
				cnfVersion, false);
		int bufferSize = 1024 * RtJioRMSConfigParamEnum.SIZE_OF_CHUNK.getIntValue();
		byte[] buffer = new byte[bufferSize];
		File file = new File(targetPath, fileName);
		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file)) {

				response.setContentType(CONTENT_TYPE_OCTET);
				response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
				response.setContentLength((int) file.length());
				OutputStream os = response.getOutputStream();

				int byteRead = 0;
				while ((byteRead = fis.read(buffer)) != -1) {
					os.write(buffer, 0, byteRead);

				}
				os.flush();

			} catch (Exception e) {
				try {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST);
				} catch (IOException e1) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), methodName, "IO exception in sending bad request", e1);
				}
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Download template CNF FCAPS", e);

				printFCAPSClearCode(fcapsType);

			}
		} else {

			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "IO exception in sending bad request", e);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"file does not exists: ");

			printFileMissingClearCode(fcapsType);
		}

	}

	private void printFileMissingClearCode(String fcapsType) {

		switch (fcapsType) {
		case "alarm":
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "config":
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "counter":
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		default:
			break;
		}

	}

	private void printFCAPSClearCode(String fcapsType) {
		switch (fcapsType) {
		case "alarm":
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "config":
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "counter":
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		default:
			break;
		}

	}

}