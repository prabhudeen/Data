package com.rjil.rms.cnf.fcaps;

import java.io.File;
import java.io.FileInputStream;

import org.json.JSONObject;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * To download Dictionary
 * 
 * @author kiran.jangid
 *
 */

public class RMRCNFFCAPSDictionaryDownloadEvent implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		final String methodName = "processEvent";

		ResponsePayload payload = new ResponsePayload();
		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String cnfId = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_ID.getValue());
			String cnfVersion = eventTracking.getRequestParams()
					.get(CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue());
			String type = eventTracking.getRequestParams().get(CNFFcapOperationConstantsEnum.APPDATA_TYPE.getValue());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"cnf id = " + cnfId + ", type = " + type + ", cnf version = " + cnfVersion);

			if (cnfId == null || type == null) {
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue()
						+ ", cnf-id or Type is Missing");
				return;
			}

			JSONObject object;

			switch (type) {
			case "alarm":
				object = new JSONObject(
						EsManager.getInstance().getCNFFcapsOperationImpl().getFCAPSSheetForAlarm(cnfId));
				break;
			case "config":
				object = new JSONObject(
						EsManager.getInstance().getCNFFcapsOperationImpl().getFCAPSSheetForConfig(cnfId));
				break;
			case "counter":
				object = new JSONObject(
						EsManager.getInstance().getCNFFcapsOperationImpl().getFCAPSSheetForCounter(cnfId));
				break;
			default:
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue()
						+ ", Type value should be alarm, config or counter");
				return;
			}

			String fileName = (String) object.get(CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
			String targetPath = object.getString(CNFFcapOperationConstantsEnum.APPDATA_REPOSITORY_PATH.getValue());

			if (targetPath == null || fileName == null) {
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
				return;
			}

			FileInputStream f = new FileInputStream(new File(targetPath, fileName));
			byte[] b = new byte[f.available()];
			int a = f.read(b);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Download File Size : " + a);

			JSONObject appData = new JSONObject();
			appData.put("fileName", fileName);
			appData.put("fileData", b);
			appData.put("fileFormat", "xlsx");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					appData.toString());

			payload.setAppData(appData);
			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			f.close();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Download FCAPs Dictionary", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DICTIONARY_DOWNLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}