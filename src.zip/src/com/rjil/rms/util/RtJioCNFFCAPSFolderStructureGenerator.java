package com.rjil.rms.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rjil.rms.cnf.fcaps.CNFFcapOperationConstantsEnum;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

public class RtJioCNFFCAPSFolderStructureGenerator {
	
	private static LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static Logger logger = LogManager.getLogger(RtJioCommonMethods.class);

	private static final String CLASSNAME = "RtJioCommonMethods";

	private RtJioCNFFCAPSFolderStructureGenerator() {
		
	}

	/**
	 * 
	 * @param fcapsName
	 * @param vendorIdentifier
	 * @param cnfIdentifier
	 * @param cnfVersion
	 * @param fileName
	 * @return
	 */
	
	
	public static String generateCNFFcapsRep(String fcapsName, String vendorIdentifier, String cnfIdentifier,
			String cnfVersion,boolean uploadFlag) {
        String methodName="generateCNFFcapsRep";
		String path = RtJioRMSConfigParamEnum.RMR_CNF_FCAPS_REPOSITORY_PATH.getStringValue() +"/" + vendorIdentifier + "/"
				+ cnfIdentifier + "/" + cnfVersion + "/" + fcapsName;

		if (!new File(path).exists()) {
			new File(path).mkdirs();
		}else if(uploadFlag) {
			try {
				FileUtils.deleteDirectory(new File(path));
				new File(path).mkdirs();
			} catch (IOException e) {
				
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(),RtJioCommonMethods.class.getName(), methodName,
						"Exception while deletig folder structure...");
			}
		}
		

		return path;

	}

	/**
	 * 
	 * @param fcapsName
	 * @param vendorIdentifier
	 * @param cnfIdentifier
	 * @param cnfVersion
	 * @param fileName
	 * @return
	 */
	
	public static String generateDownloadUrlForCNF(String fcapsName, String vendorIdentifier, String cnfIdentifier,
			String cnfVersion, String fileName) {

		return "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
				+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
				+ RtJioRMSConfigParamEnum.RMR_CNF_DOWNLOAD_SYNC_CONTEXT.getStringValue() + "?"
				+ CNFFcapOperationConstantsEnum.APPDATA_VENDOR_NAME.getValue() + "=" + vendorIdentifier + "&"
				+ CNFFcapOperationConstantsEnum.APPDATA_CNF_NAME.getValue() + "=" + cnfIdentifier + "&"
				+ CNFFcapOperationConstantsEnum.APPDATA_CNF_VERSION.getValue() + "=" + cnfVersion + "&"
				+ CNFFcapOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + fcapsName + "&"
				+ CNFFcapOperationConstantsEnum.APPDATA_FILE_NAME.getValue() + "=" + fileName;

	}

}
