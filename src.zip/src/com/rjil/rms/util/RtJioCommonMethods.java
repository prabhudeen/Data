package com.rjil.rms.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.NoSuchFileException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.google.gson.Gson;
import com.jio.telco.framework.logger.Constants;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.broadcast.manager.BroadCastHeadersEnum;
import com.rjil.rms.broadcast.manager.RMRBroadcastPojo;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventHeaderEnum;
import com.rjil.rms.exceptions.EventAckParsingException;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.ha.EventDumpTask;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.startup.RMSManagerBootstrap;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RtJioCommonMethods {

	private static LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static Logger logger = LogManager.getLogger(RtJioCommonMethods.class);

	private static final String CLASSNAME = "RtJioCommonMethods";

	private RtJioCommonMethods() {
	}

	/**
	 * 
	 * @param fcapsName
	 * @param vendorIdentifier
	 * @param vnfIdentifier
	 * @param vnfVersion
	 * @param fileName
	 * @return
	 */

	public static String generateFCAPSRep(String fcapsName, String vendorIdentifier, String vnfIdentifier,
			String vnfVersion) {

		String path = RtJioRMSConfigParamEnum.RMR_FCAPS_REPOSITORY_PATH.getStringValue() + "/" + vendorIdentifier + "/"
				+ vnfIdentifier + "/" + vnfVersion + "/" + fcapsName;

		if (!new File(path).exists()) {
			new File(path).mkdirs();
		}

		return path;

	}

	/**
	 * 
	 * @param fcapsName
	 * @param vendorIdentifier
	 * @param vnfIdentifier
	 * @param vnfVersion
	 * @param fileName
	 * @return
	 */

	public static String generateDownloadUrl(String fcapsName, String vendorIdentifier, String vnfIdentifier,
			String vnfVersion, String fileName) {

		return "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
				+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
				+ RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue() + "?"
				+ FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue() + "=" + vendorIdentifier + "&"
				+ FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue() + "=" + vnfIdentifier + "&"
				+ FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue() + "=" + vnfVersion + "&"
				+ FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + fcapsName + "&"
				+ FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue() + "=" + fileName;

	}

	/**
	 * Generating Download Url
	 * 
	 * @param vnfcImage
	 * @return
	 */

	public static String generateDownloadUrlForImage(VNFCImage vnfcImage) {

		String vnfcPath = RMSManagerBootstrap.rmsManager.getFolderStructureGenerator()
				.generateFolderStructure(vnfcImage, vnfcImage.getVnfcID());

		return "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
				+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
				+ RtJioRMSConfigParamEnum.RMR_SYNC_CONTEXT.getStringValue() + vnfcPath + "?"
				+ FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue() + "=" + "binary";

	}

	/**
	 * 
	 * @return
	 */

	public static int generateProcessId() {

		int processId = 0;

		try {
			if (System.getProperty("os.name").indexOf("nux") >= 0) {
				String curDir = System.getProperty("user.dir");
				Process jpsProcess = Runtime.getRuntime().exec(new String[] { "bash", "-c",
						"jps | grep " + RMSManagerBootstrap.class.getSimpleName() + " | awk '{print $1}'" });
				jpsProcess.waitFor();
				BufferedReader reader = new BufferedReader(new InputStreamReader(jpsProcess.getInputStream()));
				String pid;
				Process pwdxProcess;
				String pwdxOutput;
				while ((pid = reader.readLine()) != null) {
					pwdxProcess = Runtime.getRuntime()
							.exec(new String[] { "bash", "-c", "pwdx " + pid + " | awk '{print $2}'" });
					pwdxProcess.waitFor();
					pwdxOutput = new BufferedReader(new InputStreamReader(pwdxProcess.getInputStream())).readLine();
					if (pwdxOutput.equals(curDir)) {
						processId = Integer.parseInt(pid);
						break;
					}
				}
			} else {
				processId = 0;
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, "generateProcessId",
					"Error in generating process id", e);
			processId = 0;
		}

		return processId;
	}

	/**
	 * This Method will generate event pojo that have all parameter need for
	 * event orchestration
	 * 
	 * @param httpRequest
	 * @return
	 */

	public static RMREventPojo getEventDataFromRequest(HttpServletRequest httpRequest) {

		try {

			if (httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_EVENT_NAME.getValue()) == null) {
				return null;
			}

			RMREventPojo eventTracking = new RMREventPojo();
			eventTracking.setBranchId(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_BRANCH_ID.getValue()));
			eventTracking.setEventName(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_EVENT_NAME.getValue()));
			eventTracking.setServiceContext(
					httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SERVICE_CONTEXT.getValue()));
			eventTracking.setFlowId(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_FLOW_ID.getValue()));
			eventTracking.setHopCount(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_HOP_COUNT.getValue()));
			eventTracking.setMessageType(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_MESSAGE_TYPE.getValue()));
			eventTracking.setServiceIp(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SERVICE_IP.getValue()));
			eventTracking
					.setPublisherName(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_PUBLISHER_NAME.getValue()));

			eventTracking.setTimeStamp(System.currentTimeMillis());
			eventTracking.setRequest(httpRequest);

			// header introduced in 2.1 ELB
			eventTracking.setLbUrl(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_LB_URL.getValue()));
			eventTracking
					.setSocketAddress(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SOCKET_ADDRESS.getValue()));
			eventTracking.setUsername(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_USERNAME.getValue()));

			// header introduced in 2.1 ERM
			eventTracking
					.setErmIdentifier(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_ERM_IDENTIFIER.getValue()));
			eventTracking.setTargetErm(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_TARGET_ERM.getValue()));

			// adding all query parameters
			Enumeration<String> en = httpRequest.getParameterNames();
			Map<String, String> params = new HashMap<>();

			while (en.hasMoreElements()) {
				String paramName = en.nextElement();
				params.put(paramName, httpRequest.getParameter(paramName));
			}

			eventTracking.setRequestParams(params);

			// adding all headers in headers map
			Enumeration<String> headerKeys = httpRequest.getHeaderNames();
			Map<String, String> headers = new HashMap<>();

			while (headerKeys.hasMoreElements()) {
				String headerName = headerKeys.nextElement();
				headers.put(headerName, httpRequest.getHeader(headerName));
			}

			eventTracking.setRequestHeaders(headers);

			// adding request Body
			eventTracking.setRequestStream(IOUtils.toByteArray(httpRequest.getInputStream()));

			// Executing Task to Dump Event Dumping Event Data
			RtJioRMSCacheManager.getInstance().getThreadPoolExecutor().execute(new EventDumpTask(eventTracking));

			return eventTracking;

		} catch (Exception e) {
			ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger).setException(e)
					.setClassMethodName("RtJioCommonMethods:getEventDataFormRequest").writeExceptionLog();
			return null;
		}

	}

	/**
	 * This Method will generate cli pojo that have all parameter need for cli
	 * orchestration
	 * 
	 * @param httpRequest
	 * @return
	 */

	public static RMRCLIPojo getCliDataFromRequest(HttpServletRequest httpRequest) {

		try {

			if (httpRequest.getHeader(RTJioRMRCliOptionEnum.COMMAND_NAME.getName()) == null) {
				return null;
			}

			RMRCLIPojo cliTracking = new RMRCLIPojo();
			cliTracking.setCommandName(httpRequest.getHeader(RTJioRMRCliOptionEnum.COMMAND_NAME.getName()));
			cliTracking.setStatus(httpRequest.getHeader(RTJioRMRCliOptionEnum.STATUS.getName()));
			cliTracking.setModule(httpRequest.getHeader(RTJioRMRCliOptionEnum.MODULE.getName()));
			cliTracking.setVnfId(httpRequest.getHeader(RTJioRMRCliOptionEnum.VNF_ID.getName()));
			cliTracking.setRequest(httpRequest);

			Enumeration<String> en = httpRequest.getParameterNames();
			Map<String, String> params = new HashMap<>();

			while (en.hasMoreElements()) {
				String paramName = en.nextElement();
				params.put(paramName, httpRequest.getParameter(paramName));
			}

			cliTracking.setRequestParams(params);
			cliTracking.setRequestStream(IOUtils.toByteArray(httpRequest.getInputStream()));

			return cliTracking;

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME,
					"getCliDataFromRequest", "Error in generating cli request data", e);

			return null;
		}

	}

	/**
	 * 
	 * @param vendor
	 * @param deviceType
	 * @param model
	 * @param softwareVersion
	 * @param fileName
	 * @return
	 */

	public static String generateNBIotFilePath(String vendor, String deviceType, String model, String softwareVersion,
			String fileName) {

		return preparePath(vendor, deviceType, model, softwareVersion, fileName);

	}

	private static String preparePath(String vendor, String deviceType, String model, String softwareVersion,
			String fileName) {

		String path = RtJioRMSConfigParamEnum.NB_IOT_FILE_PATH.getStringValue() + "/" + vendor + "/" + model + "/"
				+ softwareVersion + "/" + deviceType + "/";

		if (fileName != null) {
			return path + fileName;
		}

		File file = new File(path);

		if (!file.exists()) {
			file.mkdirs();
		}

		return path;

	}

	/**
	 * 
	 * @param vendor
	 * @param deviceType
	 * @param model
	 * @param softwareVersion
	 * @param fileName
	 * @return
	 */

	public static String generateNBIotDownloadPath(String vendor, String deviceType, String model,
			String softwareVersion, String fileName) {

		return "http://" + RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue() + ":"
				+ RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getIntValue()
				+ RtJioRMSConfigParamEnum.RMR_FILE_UPLOADER_CONTEXT.getStringValue() + "?" + "vendor=" + vendor
				+ "&model=" + model + "&softwareVersion=" + softwareVersion + "&deviceType=" + deviceType + "&fileName="
				+ fileName;

	}

	/**
	 * 
	 * @param vendor
	 * @param deviceType
	 * @param model
	 * @param softwareVersion
	 * @param fileName
	 * @param srcFilePath
	 * @return
	 */

	public static boolean moveFileToDestination(String vendor, String deviceType, String model, String softwareVersion,
			String fileName, String srcFilePath) {
		return copyFile(srcFilePath + "/" + fileName,
				generateNBIotFilePath(vendor, deviceType, model, softwareVersion, null));
	}

	/**
	 * 
	 * @param sourcePath
	 * @param destinationPath
	 * @return
	 */

	public static boolean copyFile(String sourcePath, String destinationPath) {

		final String methodName = "copyFile";

		try {

			File sourceFile = new File(sourcePath);

			FileUtils.copyFileToDirectory(sourceFile, new File(destinationPath));

			File destinationFile = new File(destinationPath, sourceFile.getName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASSNAME, methodName,
					" file : Source = " + sourceFile.length() + " | Dest = " + destinationFile.length());

			if (sourceFile.length() != destinationFile.length()) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, methodName,
						"Error in copying file : fileCorrupted");
				if (destinationFile.delete()) {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, methodName,
							"Corrupt File Deleted");
				}
				return false;
			}

			return true;
		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, methodName,
					"Error in copying file", e);
			return false;
		}

	}

	/**
	 * 
	 * Common method to delete VNFC Image File
	 * 
	 * @param vnfcImage
	 * @return
	 * @throws NoSuchFileException
	 */

	public static boolean deleteFileFromDestination(VNFCImage vnfcImage) throws NoSuchFileException {
		return RMSManagerBootstrap.rmsManager.getFolderStructureGenerator().deleteFileAndFolder(vnfcImage,
				vnfcImage.getVnfcID());
	}

	/**
	 * To generate Broadcast data from request
	 * 
	 * @param httpRequest
	 * @return
	 */

	public static RMRBroadcastPojo getBroadcastDataFromRequest(HttpServletRequest httpRequest) {

		try {

			RMRBroadcastPojo broadcastData = new RMRBroadcastPojo();
			broadcastData.setBroadcastAction(httpRequest.getHeader(BroadCastHeadersEnum.BROADCAST_ACTION.getValue()));
			broadcastData.setInstanceId(httpRequest.getHeader(BroadCastHeadersEnum.INSTANCE_ID.getValue()));

			Enumeration<String> en = httpRequest.getParameterNames();
			Map<String, String> params = new HashMap<>();

			while (en.hasMoreElements()) {
				String paramName = en.nextElement();
				params.put(paramName, httpRequest.getParameter(paramName));
			}

			broadcastData.setRequestParams(params);

			Enumeration<String> headersName = httpRequest.getHeaderNames();
			Map<String, String> headersMap = new HashMap<>();

			while (headersName.hasMoreElements()) {
				String headerName = headersName.nextElement();
				headersMap.put(headerName, httpRequest.getHeader(headerName));
			}

			broadcastData.setRequestHeaders(headersMap);
			broadcastData.setRequestStream(IOUtils.toByteArray(httpRequest.getInputStream()));

			return broadcastData;

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME,
					"getBroadcastDataFromRequest", "Error in creating broadcast json", e);

			return null;
		}

	}

	/**
	 * 
	 * @param requestParams
	 * @return
	 */

	public static String generateQueryBuilder(Map<String, String> requestParams) {

		Iterator<Entry<String, String>> map = requestParams.entrySet().iterator();

		StringBuilder queryStr = new StringBuilder();

		while (map.hasNext()) {
			Map.Entry<String, String> entry = map.next();
			queryStr.append(entry.getKey() + "=" + entry.getValue() + "&");
		}

		String queryTemp = queryStr.substring(0, queryStr.length() - 1);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASSNAME, "generateQueryBuilder",
				"Query Builder : " + queryTemp);

		return queryTemp;

	}

	/**
	 * 
	 * @param eventAckData
	 * @return
	 * @throws EventAckParsingException
	 */

	public static ResponsePayload getResponseEventAck(String eventAckData) throws EventAckParsingException {

		ResponsePayload payload = null;

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASSNAME, "getResponseEventAck",
					"Event Ack Data : " + eventAckData);

			Gson gson = new Gson();
			payload = gson.fromJson(eventAckData, ResponsePayload.class);

			return payload;

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME,
					"getResponseEventAck", "Error in parsing Event Ack", e);
			throw new EventAckParsingException();
		}

	}

	/**
	 * 
	 * @param httpRequest
	 * @return
	 */

	public static RMREventPojo getEventAckDataFromRequest(HttpServletRequest httpRequest) {

		try {

			if (httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_EVENT_NAME.getValue()) == null) {
				return null;
			}

			RMREventPojo eventTracking = new RMREventPojo();
			eventTracking.setBranchId(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_BRANCH_ID.getValue()));
			eventTracking.setEventName(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_EVENT_NAME.getValue()));
			eventTracking.setServiceContext(
					httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SERVICE_CONTEXT.getValue()));
			eventTracking.setFlowId(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_FLOW_ID.getValue()));
			eventTracking.setHopCount(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_HOP_COUNT.getValue()));
			eventTracking.setMessageType(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_MESSAGE_TYPE.getValue()));
			eventTracking.setServiceIp(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SERVICE_IP.getValue()));
			eventTracking
					.setPublisherName(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_PUBLISHER_NAME.getValue()));

			eventTracking.setTimeStamp(System.currentTimeMillis());
			eventTracking.setRequest(httpRequest);

			// header introduced in 2.1 ELB
			eventTracking.setLbUrl(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_LB_URL.getValue()));
			eventTracking
					.setSocketAddress(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_SOCKET_ADDRESS.getValue()));
			eventTracking.setUsername(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_USERNAME.getValue()));

			// header introduced in 2.1 ERM
			eventTracking
					.setErmIdentifier(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_ERM_IDENTIFIER.getValue()));
			eventTracking.setTargetErm(httpRequest.getHeader(RMSEventHeaderEnum.HEADER_NAME_TARGET_ERM.getValue()));

			// adding query parameters
			Enumeration<String> en = httpRequest.getParameterNames();
			Map<String, String> params = new HashMap<>();

			while (en.hasMoreElements()) {
				String paramName = en.nextElement();
				params.put(paramName, httpRequest.getParameter(paramName));
			}

			eventTracking.setRequestParams(params);
			
			// adding headers
			Enumeration<String> headerKeys = httpRequest.getParameterNames();
			Map<String, String> headers = new HashMap<>();

			while (headerKeys.hasMoreElements()) {
				String paramName = headerKeys.nextElement();
				headers.put(paramName, httpRequest.getParameter(paramName));
			}

			eventTracking.setRequestParams(headers);
			
			// adding request Body
			eventTracking.setRequestStream(IOUtils.toByteArray(httpRequest.getInputStream()));

			return eventTracking;

		} catch (Exception e) {
			ResourceBuilder.logger().setLogType(Constants.LOG_LEVEL_ERROR).setLogger(logger).setException(e)
					.setClassMethodName("RtJioCommonMethods:getEventDataFormRequest").writeExceptionLog();
			return null;
		}

	}

}
