package com.rjil.rms.util;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jio.resttalk.service.custom.exceptions.RestTalkServerConnectivityError;
import com.jio.resttalk.service.impl.RestTalkBuilder;
import com.jio.resttalk.service.response.RestTalkResponse;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.erm.RMRERMHttpParametersAndHeadersIntf;
import com.rjil.rms.es.erm.RMRERMResponseCodes;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventHeaderEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import io.netty.handler.codec.http.HttpMethod;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RtJioCommonRequestHandler {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final RtJioCommonRequestHandler INSTANCE = new RtJioCommonRequestHandler();

	private Map<String, String> tokenUserMap = new ConcurrentHashMap<>();
	private Map<String, ArrayList<String>> userTokenReverseMap = new ConcurrentHashMap<>();

	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
	private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
	private static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
	private static final String ACCESS_CONTROL_ALLOW_METHOD = "Access-Control-Allow-Methods";
	private static final String CONTENT_TYPE_JSON = "application/json";
	private static final String ALLOW_METHOD = "GET,PUT,POST,DELETE";

	private String methodName;

	private RtJioCommonRequestHandler() {
	}

	public static RtJioCommonRequestHandler getInstance() {
		return INSTANCE;
	}

	public Map<String, String> getTokenUserMap() {
		return tokenUserMap;
	}

	public void setTokenUserMap(Map<String, String> tokenUserMap) {
		this.tokenUserMap = tokenUserMap;
	}

	public Map<String, ArrayList<String>> getUserTokenReverseMap() {
		return userTokenReverseMap;
	}

	public void setUserTokenReverseMap(Map<String, ArrayList<String>> userTokenReverseMap) {
		this.userTokenReverseMap = userTokenReverseMap;
	}

	/**
	 * 
	 * @param httpServletResponse
	 * @param code
	 * @param body
	 * @param log
	 * @param requestHeader
	 */

	public void sendResponse(HttpServletResponse httpServletResponse, int code, String body, String log,
			String requestHeader) {

		methodName = "sendResponse";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"log=" + log + " | body=" + body);

			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");

			if (requestHeader != null) {
				httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_HEADERS, requestHeader);
			}

			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_METHOD, ALLOW_METHOD);

			httpServletResponse.setStatus(code);
			httpServletResponse.setContentType(CONTENT_TYPE_JSON);
			httpServletResponse.getWriter().println(body);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Sending Response", e);
		}

	}

	/**
	 * 
	 * @param httpServletResponse
	 * @param httpCode
	 * @param errorCode
	 * @param type
	 * @param appData
	 * @param log
	 */

	public void sendResponse(HttpServletResponse httpServletResponse, int httpCode, int errorCode, String type,
			JSONObject appData, String log) {

		methodName = "sendResponse";

		try {
			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
			httpServletResponse.setHeader(ACCESS_CONTROL_ALLOW_METHOD, ALLOW_METHOD);
			httpServletResponse.setContentType(CONTENT_TYPE_JSON);

			JSONObject json = new JSONObject();
			JSONObject statusCode = new JSONObject();

			statusCode.put("httpstatuscode", Integer.toString(httpCode));
			statusCode.put("opStatusCode", Integer.toString(errorCode));
			statusCode.put("type", type);
			if (appData != null) {
				statusCode.put("AppData", appData);
			}
			json.put("statusCode", statusCode);

			httpServletResponse.getWriter().println(json.toString());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"log=" + log + " | body=" + json.toString());

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Sending Response", e);
		}

	}

	/**
	 * 
	 * @param eventPojo
	 * @param appData
	 * @param inputStream
	 */

	public void sendResponseToMS(RMREventPojo eventPojo, JSONObject appData, InputStream inputStream) {

		methodName = "sendResponseToMS";

		try {

			Map<String, String> headerMap = new HashMap<>();
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.FLOW_ID, eventPojo.getFlowId());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.BRANCH_ID, eventPojo.getBranchId());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.EVENT_NAME, eventPojo.getEventName());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.HOP_COUNT, eventPojo.getHopCount());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.SRC_MS_IP_PORT, eventPojo.getServiceIp());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.SRC_MS_CONTEXT, eventPojo.getServiceContext());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.MSG_TYPE,
					RMRERMHttpParametersAndHeadersIntf.MSG_TYPE_EVENT_ACK_VALUE);
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.PUBLISHER_NAME, eventPojo.getPublisherName());
			headerMap.put(RMRERMHttpParametersAndHeadersIntf.SUBSCRIBER_NAME,
					RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue());

			// header introduced in 2.1 ELB
			if (eventPojo.getLbUrl() != null)
				headerMap.put(RMSEventHeaderEnum.HEADER_NAME_LB_URL.getValue(), eventPojo.getLbUrl());
			if (eventPojo.getSocketAddress() != null)
				headerMap.put(RMSEventHeaderEnum.HEADER_NAME_SOCKET_ADDRESS.getValue(), eventPojo.getSocketAddress());
			if (eventPojo.getUsername() != null)
				headerMap.put(RMSEventHeaderEnum.HEADER_NAME_USERNAME.getValue(), eventPojo.getUsername());

			// header introduced in 2.1 ERM
			if (eventPojo.getErmIdentifier() != null)
				headerMap.put(RMSEventHeaderEnum.HEADER_NAME_ERM_IDENTIFIER.getValue(), eventPojo.getErmIdentifier());
			if (eventPojo.getTargetErm() != null)
				headerMap.put(RMSEventHeaderEnum.HEADER_NAME_TARGET_ERM.getValue(), eventPojo.getTargetErm());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Event Ack : Sending Headers  ---- " + headerMap);

			RestTalkBuilder builder = RtJioRMSCacheManager.getInstance().getErmManager()
					.createNewEventBuilder(HttpMethod.POST);

			if (appData != null) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "Event Ack : Sending Body ---- " + appData.toString());
				builder.addRequestData(appData.toString());
			}

			if (inputStream != null) {
				builder.addRequestData(inputStream);
			}

			builder.addCustomHeaders(headerMap);

			RestTalkResponse httpPostResponse = builder.send();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Event Ack : Response Status Code ---- " + httpPostResponse.getHttpStatusCode());

			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_ACK_REQUESTS_SEND.increment();

			if (httpPostResponse.getHttpStatusCode() == RMRERMResponseCodes.SUCCESS.responseCode()) {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, httpPostResponse.answeredContent().responseString(), eventPojo.getFlowId(),
						eventPojo.getPublisherName());
				RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_ACK_REQUESTS_SEND.increment();

				// Removing Event from Dump
				EsManager.getInstance().getHaOperation()
						.removeEventData(eventPojo.getFlowId() + "_" + eventPojo.getBranchId());

			} else {
				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, httpPostResponse.answeredContent().responseString(), eventPojo.getFlowId(),
						eventPojo.getPublisherName());
				RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_SEND.increment();
			}

		} catch (RestTalkServerConnectivityError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Sending Requst to ELB Probable Cause : ELB is Down : ", e);

			RtJioRMSCacheManager.getInstance().getErmManager().reInitialize();

			if (RtJioRMSCacheManager.getInstance().getErmManager().getERMPojo().isStatus()) {
				sendResponseToMS(eventPojo, appData, inputStream);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Sending Requst to ELB", e);
		}
	}

}
