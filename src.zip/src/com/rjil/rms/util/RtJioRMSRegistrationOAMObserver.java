package com.rjil.rms.util;

import java.util.Observable;
import java.util.Observer;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.management.alarm.AlarmConditionCntrListener;
import com.rjil.management.alarm.AlarmLoggingCallbackHandler;
import com.rjil.management.alarm.ApplicationMemoryUsageListener;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * This class is the handler to receive registration events from OAM
 * 
 * @author arun.dewna
 *
 */
public class RtJioRMSRegistrationOAMObserver implements Observer {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private int counterRetry;
	private AlarmLoggingCallbackHandler alarmLoggingCallbackHandler;
	private AlarmConditionCntrListener alarmConditionCntrListener;
	private ApplicationMemoryUsageListener applicationMemoryUsageListener;

	/**
	 * constructor
	 * 
	 * @param alarmLoggingCallbackHandler
	 * @param alarmConditionCntrListener
	 * @param applicationMemoryUsageListener
	 */
	public RtJioRMSRegistrationOAMObserver(AlarmLoggingCallbackHandler alarmLoggingCallbackHandler,
			AlarmConditionCntrListener alarmConditionCntrListener,
			ApplicationMemoryUsageListener applicationMemoryUsageListener) {
		this.alarmLoggingCallbackHandler = alarmLoggingCallbackHandler;
		this.alarmConditionCntrListener = alarmConditionCntrListener;
		this.applicationMemoryUsageListener = applicationMemoryUsageListener;
	}

	@Override
	public void update(Observable arg0, Object arg) {
		if (arg instanceof String) {
			if ("200".equals(arg.toString())) {
				counterRetry = 0;
			} else {
				try {
//					if (++counterRetry <= 5) {
//						OamClientRegistrationNotifier.getInstance().addObserver(this);
//
//						Logger logger = LogManager.getRootLogger();
//						OamClientManager.getInstance().initialize(logger, RTJioRMSConstants.OAM_CONFIG_FILE_PATH,
//								this.alarmLoggingCallbackHandler, this.alarmConditionCntrListener, null,
//								this.applicationMemoryUsageListener, true);
//						return;
//					}
					OamClientManager.getInstance().disconnect();
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							"update", "OAM registration failed and disconnected with OAM");

				} catch (Exception e) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), "update", "Error in update Observer", e);
				}
			}
		}
	}

	/**
	 * @return the alarm logging callback handler
	 */
	public AlarmLoggingCallbackHandler getAlarmLoggingCallbackHandler() {
		return alarmLoggingCallbackHandler;
	}

	/**
	 * @return the alarm conditional counter listener
	 */
	public AlarmConditionCntrListener getAlarmConditionCntrListener() {
		return alarmConditionCntrListener;
	}

	/**
	 * @return the memory usage listener
	 */
	public ApplicationMemoryUsageListener getApplicationMemoryUsageListener() {
		return applicationMemoryUsageListener;
	}
}
