package com.rjil.rms.util;

import java.io.File;

/**
 * 
 * @author kiran.jangid
 *
 */

public interface RTJioRMSConstants {

	/**
	 * System constants
	 */
	public static final String CONFIGURATION_FILE_PATH = "../configuration/ConfigParamSheet.xlsx";
	public static final String OAM_CONFIG_FILE_PATH = "../configuration/OAM_Client_Config.xlsx";
	public static final String BULK = "bulk";

	/**
	 * MBean names for FCAPs
	 */
	public static final String MBEAN_NAME_COUNTER = "com.rjil.rms.counters:rtJIO_ReleaseManager=Counters";
	public static final String MBEAN_NAME_CONFIG = "com.rjil.rms.config:rtJIO_ReleaseManager=Config";
	public static final String MBEAN_NAME_ALARM = "com.rjil.rms.alarm:rtJIO_ReleaseManager=Alarm";
	public static final String MBEAN_NAME_STATISTICS = "com.rjil.rms.statistics:rtJIO_ReleaseManager=Statistics";

	/**
	 * Operators
	 */
	
	public static final String OP_ADD = "+";
	public static final String OP_MINUS = "-";
	public static final String OP_EQUALS = "=";
	public static final String OP_AT = "@";
	public static final String OP_UNDERSCORE = "_";
	public static final String OP_PERCENTAGE = "%";
	public static final String OP_LESS_THAN = "<";
	public static final String OP_GREATER_THAN = ">";
	public static final String OP_COLON = ":";
	public static final String OP_SEMI_COLON = ";";
	public static final String OP_COMMA = ",";
	public static final String OP_LINE_FEED = "\r\n";
	public static final String OP_DOUBLE_LINE_FEED = "\r\n\r\n";
	public static final String WHITE_SPACE = "[ |\t]+";

	/**
	 * Configuration parameter validators
	 */
	public static final String VALIDATOR_STRING = "string";
	public static final String VALIDATOR_BOOLEAN = "boolean";
	public static final String VALIDATOR_LONG = "long";
	public static final String VALIDATOR_DOMAIN = "domain";
	public static final String VALIDATOR_URL = "url";
	public static final String VALIDATOR_INTEGER = "integer";
	public static final String VALIDATOR_UNSIGNED_INTEGER = "unsigninteger";
	public static final String VALIDATOR_COMBOBOX = "combobox";
	public static final String VALIDATOR_ADDRESS = "address";
	public static final String VALIDATOR_IPV4 = "ipv4";
	public static final String VALIDATOR_IPV6 = "ipv6";
	public static final String VALIDATOR_IPV4V6 = "Ipv4v6";
	public static final String VALIDATOR_EMAIL = "email";
	public static final String VALIDATOR_FLOAT = "float";
	public static final String VALIDATOR_DOUBLE = "double";

	/**
	 * Constants related to dumping of alarms, counters and params
	 */

	final String USER_DIR = "user.dir";
	final String DUMP = "dumps";

	public static final String DUMP_PATH_PARAMS = System.getProperty(USER_DIR) + File.separator + ".." + File.separator
			+ DUMP + File.separator + "ConfigParams";
	public static final String DUMP_PATH_COUNTERS = System.getProperty(USER_DIR) + File.separator + ".."
			+ File.separator + DUMP + File.separator + "Counters";
	public static final String DUMP_PATH_ALARMS = System.getProperty(USER_DIR) + File.separator + ".." + File.separator
			+ DUMP + File.separator + "Alarms";
	public static final String DUMP_ALARMS_FILE_PREFIX = "_Alarm_";
	public static final String DUMP_COUNTERS_FILE_PREFIX = "_Counter_";
	public static final String DUMP_PARAMS_FILE_PREFIX = "_ConfigParam_";
	public static final String XML = "XML_";
	public static final String CSV = "CSV_";
	public static final String DUMP_FILE_EXTENSION_XML = ".xml";
	public static final String DUMP_FILE_EXTENSION_CSV = ".csv";
	public static final String CSV_HEADER_PARAMS = "Type,Name,Value,ReadOnly,Validator,MaxRange,MinRange,Required\n";
	public static final String CSV_HEADER_COUNTERS = "Type,Name,Value\n";
	public static final String CSV_HEADER_ALARMS = ".csv";

	/**
	 * HTTP headers and parameters (FCAPs)
	 */
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_TYPE = "type";
	public static final String PARAMETER_RESET = "reset";
	public static final String PARAMETER_PARAM = "param";
	public static final String PARAMETER_SCALAR_PARAM = "scalarparam";
	public static final String PARAMETER_SCALAR_VALUE = "scalarvalue";
	public static final String PARAMETER_PARAM_NAME = "paramname";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_PARAM_VALUE = "paramvalue";
	public static final String PARAMETER_LEVEL = "level";
	public static final String PARAMETER_ID = "id";
	public static final String PARAMETER_CATEGORY = "category";
	public static final String PARAMETER_TABLENAME = "tablename";
	public static final String PARAMETER_INDEX = "index";
	public static final String HEADER_TEMPLATE_REQUEST_ID = "applyTemplateRequestId";
	public static final String HEADER_TEMPLATE_REQUEST_STATUS = "applyTemplateRequestStatus";
	public static final String HEADER_TEMPLATE_REQUEST_STATUS_REASON = "applyTemplateRequestStatusReason";
	public static final String HEADER_TEMPLATE_REQUEST_TIMESTAMP = "applyTemplateRequestTimestamp";
	public static final String HEADER_TEMPLATE_PRODUCT_VERSION = "applyTemplateRequestNodeVersion";
	public static final String HEADER_PRODUCT_VERSION = "product_version";
	public static final String HEADER_BULK_RESPONSE = "bulkResponse";
	public static final String HEADER_URL = "url";
	public static final String HEADER_IP = "ip";
	public static final String HEADER_PORT = "port";
	public static final String HEADER_CATEGORY = "category";
	public static final String HEADER_TIMESTAMP = "timestamp";
	public static final String TAG_HTTP = "http://";
	public static final String PARAMETER_LEVEL_VALUE_MINOR = "Minor";
	public static final String PARAMETER_ACTION_VALUE_BULK = "bulk";
	public static final String PARAMETER_CATEGORY_VALUE_TABULAR = "Tabular";
	public static final String PARAMETER_ACTION_VALUE_SETCONFIGPARAM = "setConfigParam";
	public static final String PARAMETER_ACTION_VALUE_ADDCONFIGPARAM = "addConfigParam";
	public static final String PARAMETER_ACTION_VALUE_DELETECONFIGPARAM = "deleteConfigParam";
	public static final String PARAMETER_ACTION_VALUE_GETCOUNTERS = "getCounters";
	public static final String TEMPLATE_REQUEST_STATUS_INITIATED = "initiated";
	public static final String EMPTY_ALARM_TAG = "<alarms/>";
	public static final String BULK_RESPONSE_FOR_POST = "1";

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String FATAL = "FATAL";
	public static final String WARNING = "WARNING";
	public static final String HOP_COUNT = "70";

	public static final String MS_ERM = "ERM";
	public static final String BOOL_TRUE = "true";
	public static final String BOOL_FALSE = "false";
	
	public static final String FCAP_TYPE_ALARM = "alarm";
	public static final String FCAP_TYPE_COUNTER = "counter";
	public static final String FCAP_TYPE_CONFIG = "config";
}

