package com.rjil.rms.util;

/**
 * 
 * @author kiran.jangid
 *
 */

public enum OAMERMConstantEnum {

	// Header Name

	HEADER_EVENT("X-Event-Name"),

	EDGELB("EdgeLB"),

	SUBSCRIBECOMPONENTTYPE("subscribecomponenttype"),

	ID("id"),

	IP("ip"),

	PORT("port"),

	ACTIVE("active"),

	MS_ERM("ERM"),

	MS_RMR("RMR"),

	MS_PRIORITY("PriorityDetails");

	private String value;

	private OAMERMConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
