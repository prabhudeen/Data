package com.rjil.rms.util;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.validator.routines.DomainValidator;
import org.apache.commons.validator.routines.DoubleValidator;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.FloatValidator;
import org.apache.commons.validator.routines.InetAddressValidator;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.commons.validator.routines.LongValidator;
import org.apache.commons.validator.routines.UrlValidator;

import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;



/**
 * Enumeration for validation of data type of a configration parameter
 * 
 * @author arun.dewna
 *
 */
public enum RMRDataValidationType {

	STRING("string") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (configParamEnum.getParamRange() == null)
				return true;
			int length = paramValue.length();
			if (length >= configParamEnum.getParamRange().getMinValue()
					&& length <= configParamEnum.getParamRange().getMaxValue())
				return true;
			return false;
		}
	},
	BOOLEAN("boolean") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (RTJioRMSConstants.BOOL_TRUE.equalsIgnoreCase(paramValue)
					|| RTJioRMSConstants.BOOL_FALSE.equalsIgnoreCase(paramValue))
				return true;
			return false;
		}
	},
	LONG("long") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (LongValidator.getInstance().isValid(paramValue))
				return checkRange(Long.parseLong(paramValue), configParamEnum);
			return false;
		}
	},
	URL("url") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return UrlValidator.getInstance().isValid(paramValue);
		}
	},
	DOMAIN("domain") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return DomainValidator.getInstance().isValid(paramValue);
		}
	},
	INTEGER("integer") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (IntegerValidator.getInstance().isValid(paramValue))
				return checkRange(Integer.parseInt(paramValue), configParamEnum);
			return false;
		}
	},
	UNSIGNED_INTEGER("unsigninteger") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (!paramValue.startsWith(RTJioRMSConstants.OP_MINUS)
					&& LongValidator.getInstance().isValid(paramValue))
				return checkRange(Long.parseLong(paramValue), configParamEnum);
			return false;
		}
	},
	COMBOBOX("combobox") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (configParamEnum.getParamRange() == null)
				return true;
			List<String> list = configParamEnum.getParamRange().getList();
			for (String element : list) {
				if (element.equalsIgnoreCase(paramValue))
					return true;
			}
			return false;
		}
	},
	ADDRESS("address") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return true;
		}
	},
	IPV4("ipv4") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return InetAddressValidator.getInstance().isValidInet4Address(
					paramValue);
		}
	},
	IPV6("ipv6") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return InetAddressValidator.getInstance().isValidInet6Address(
					paramValue);
		}
	},
	IPV4V6("Ipv4v6") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return InetAddressValidator.getInstance().isValidInet4Address(
					paramValue)
					|| InetAddressValidator.getInstance().isValidInet6Address(
							paramValue);
		}
	},
	EMAIL("email") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			return EmailValidator.getInstance().isValid(paramValue);
		}
	},
	FLOAT("float") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (FloatValidator.getInstance().isValid(paramValue))
				return checkRange(Float.parseFloat(paramValue), configParamEnum);
			return false;
		}
	},
	DOUBLE("double") {
		@Override
		public boolean validate(String paramValue,
				RtJioRMSConfigParamEnum configParamEnum) {
			if (DoubleValidator.getInstance().isValid(paramValue))
				return checkRange(Double.parseDouble(paramValue),
						configParamEnum);
			return false;
		}
	};

	private String name;
	private static final HashMap<String, RMRDataValidationType> map = new HashMap<>();
	static {
		for (RMRDataValidationType dataValidationType : RMRDataValidationType
				.values())
			map.put(dataValidationType.name, dataValidationType);
	}

	private RMRDataValidationType(String name) {
		this.name = name;
	}

	/**
	 * returns the enumeration instance from the validator name
	 * 
	 * @param name
	 *            validator name
	 * @return the enumeration instance
	 */
	public static final RMRDataValidationType getEnumFromName(String name) {
		return map.get(name);
	}

	/**
	 * validates the value of a parameter against its data-type
	 * 
	 * @param paramValue
	 *            value of a parameter
	 * @param configParamEnum
	 *            enumeration instance
	 * @return the validation status
	 */
	public abstract boolean validate(String paramValue,
			RtJioRMSConfigParamEnum configParamEnum);

	private static boolean checkRange(long value,
			RtJioRMSConfigParamEnum configParamEnum) {
		if (configParamEnum.getParamRange() == null)
			return true;
		if (value >= configParamEnum.getParamRange().getMinValue()
				&& value <= configParamEnum.getParamRange().getMaxValue())
			return true;
		return false;
	}

	private static boolean checkRange(double value,
			RtJioRMSConfigParamEnum configParamEnum) {
		if (configParamEnum.getParamRange() == null)
			return true;
		if (value >= configParamEnum.getParamRange().getMinValue()
				&& value <= configParamEnum.getParamRange().getMaxValue())
			return true;
		return false;
	}
}
