package com.rjil.rms.clearcode;

import com.jio.telco.framework.clearcode.XdrAsnCallBackIntf;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Class for receiving call back from XDR events
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRAsnCallBackIntfImpl implements XdrAsnCallBackIntf {

	private static final String CLASS_NAME = RMRAsnCallBackIntfImpl.class.getSimpleName();

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String ERROR_MESSAGE = "ERROR in xdr processing: ";

	@Override
	public void authFailForXDR(String arg0) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, "authFailForXDR",
				ERROR_MESSAGE + arg0);

	}

	@Override
	public void connectFailForXDR(String arg0) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, "connectFailForXDR",
				ERROR_MESSAGE + arg0);

	}

	@Override
	public void ftpFailForXDR(String arg0) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, "ftpFailForXDR",
				ERROR_MESSAGE + arg0);

	}

	@Override
	public void noSpaceForXDR(String arg0) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, "noSpaceForXDR",
				ERROR_MESSAGE + arg0);

	}

	@Override
	public void writeFailForXDR(String arg0) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASS_NAME, "writeFailForXDR",
				ERROR_MESSAGE + arg0);

	}

}
