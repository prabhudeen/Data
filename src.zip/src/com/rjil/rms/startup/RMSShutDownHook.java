package com.rjil.rms.startup;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RMSShutDownHook extends Thread {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void run() {

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(), "run",
					"Started Shutdown Hook");

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"run", "Error in Shutdown ", e);
		}

	}
}
