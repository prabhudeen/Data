package com.rjil.rms.startup;

import java.util.HashMap;
import java.util.Map;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * 
 * @author Sandeep.Narula
 *
 */

public class RMSManagerBootstrap {

	private String className = "RMSManagerBootstrap";
	public static final RMSManagerBootstrap rmsManager = new RMSManagerBootstrap();
	private Map<String, String> vnfcUrlToBinaryPathMap = new HashMap<>();
	private FolderStructureGenerator folderStructureGenerator = new FolderStructureGenerator();

	/**
	 * Start Point of EPS SMP Server Application
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		RMSManagerBootstrap.rmsManager.initializeSystem();
	}

	/**
	 * Initialising System
	 */

	public void initializeSystem() {

		// Initializing Excel
		RtJioRMSCacheManager.getInstance().initExcelWorkbookLoader();

		try {
			RtJioRMSCacheManager.getInstance().setMicroserviceId(
					OamClientManager.getInstance().readOamClientConfig(RTJioRMSConstants.OAM_CONFIG_FILE_PATH));
		} catch (Exception e) {
			LoggerWriter.getInstance().writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), className,
					"initializeSystem", "Error While Reading OAM Client Configuration", e);
		}

		// Initializing Logger
		RtJioRMSCacheManager.getInstance().initLoggingConfiguration();

		// Init Metadata v2.1
		RtJioRMSCacheManager.getInstance().initMetadata();

		// Initializing Rest talk
		RtJioRMSCacheManager.getInstance().initRestTalkManager();

		// Initializing Configuration param
		RtJioRMSCacheManager.getInstance().initConfigurationManager();

		// Initializing Counter Manager
		RtJioRMSCacheManager.getInstance().initCounterManager();

		// Initializing Thread Pooling
		RtJioRMSCacheManager.getInstance().initThreadPoolExecutor();

		// Initializing Jetty Interface
		RtJioRMSCacheManager.getInstance().initJettyServer();

		Runtime.getRuntime().addShutdownHook(new RMSShutDownHook());

		// Initializing Elastic DB CLient
		RtJioRMSCacheManager.getInstance().initElasticDb();

		// Initializing ERM Manager
		RtJioRMSCacheManager.getInstance().initErmManager();

		Runnable taskOAMRegistration = () -> RtJioRMSCacheManager.getInstance().registerToOAM();

		new Thread(taskOAMRegistration).start();

		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			LoggerWriter.getInstance().writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), className,
					"initializeSystem", "thread sleep error", e);
		}

		RtJioRMSCacheManager.getInstance().initStatisticsManager();

		RtJioRMSCacheManager.getInstance().setMSUpTime();

		RtJioRMSCacheManager.getInstance().setHostName();

		RtJioRMSCacheManager.getInstance().initClearCodeManager();

		// raise process init success alarm

		OamClientManager.getOamClientForAlarm().raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.RMS_STARTUP_SUCCESS);
	}

	public Map<String, String> getVnfcUrlToBinaryPathMap() {
		return this.vnfcUrlToBinaryPathMap;
	}

	public FolderStructureGenerator getFolderStructureGenerator() {
		return folderStructureGenerator;
	}

}
