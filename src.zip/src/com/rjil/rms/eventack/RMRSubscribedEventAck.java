package com.rjil.rms.eventack;

import java.util.HashMap;

/**
 * 
 * Map of Subscribed Event Ack in RMR
 * 
 * @author kiran.jangid
 *
 */

public class RMRSubscribedEventAck {

	static HashMap<String, RMSEventAckConstantEnum> events = new HashMap<>();

	static {

		events.put(RMSEventAckConstantEnum.GET_CNF_DEPLOYMENT_STATUS.getValue(),
				RMSEventAckConstantEnum.GET_CNF_DEPLOYMENT_STATUS);
		events.put(RMSEventAckConstantEnum.PUBLISH_ALARM_DICTIONARY.getValue(),
				RMSEventAckConstantEnum.PUBLISH_ALARM_DICTIONARY);
		events.put(RMSEventAckConstantEnum.PUBLISH_CONFIG_DICTIONARY.getValue(),
				RMSEventAckConstantEnum.PUBLISH_CONFIG_DICTIONARY);
		events.put(RMSEventAckConstantEnum.PUBLISH_COUNTER_DICTIONARY.getValue(),
				RMSEventAckConstantEnum.PUBLISH_COUNTER_DICTIONARY);
		events.put(RMSEventAckConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL.getValue(),
				RMSEventAckConstantEnum.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL);
		events.put(RMSEventAckConstantEnum.GET_VNF_DEPLOYMENT_STATUS.getValue(),
				RMSEventAckConstantEnum.GET_VNF_DEPLOYMENT_STATUS);
	}
	/**
	 * 
	 * @param event
	 * @return
	 */

	public EventAckProcessor getEventObject(String event) {
		return RMSEventAckConstantEnum
				.getEventAckServiceObject(events.getOrDefault(event, RMSEventAckConstantEnum.UNKONWN), event);
	}

}
