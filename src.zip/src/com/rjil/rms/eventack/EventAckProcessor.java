package com.rjil.rms.eventack;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * @author Kiran.Jangid
 *
 */
@FunctionalInterface
public interface EventAckProcessor {

	/**
	 * 
	 * @param eventTracking
	 */
	public void processEventAck(RMREventPojo eventTracking);

}
