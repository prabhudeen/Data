package com.rjil.rms.eventack;

import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class UNknownEventAck implements EventAckProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String CLASS_NAME = "UNknownEventAck";

	@Override
	public void processEventAck(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "processEventAck",
				"Processing Event Ack for : " + eventTracking.getEventName() + " | Data : ");

	}

}
