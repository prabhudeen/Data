package com.rjil.rms.eventack;

import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */


public class PublishCounterDictionaryEventAck implements EventAckProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String CLASS_NAME = "PublishCounterDictionaryEventAck";

	@Override
	public void processEventAck(RMREventPojo eventTracking) {

		final String methodName = "processEventAck";

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
					"Processing Event Ack for : " + eventTracking.getEventName());

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Receiving Event Ack", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);
		}

	}

}
