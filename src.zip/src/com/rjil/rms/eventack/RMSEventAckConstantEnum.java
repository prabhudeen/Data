package com.rjil.rms.eventack;

import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * Event Constant
 * 
 * @author kiran.jangid
 *
 */

public enum RMSEventAckConstantEnum {

	GET_CNF_DEPLOYMENT_STATUS(RMSEventConstant.GET_CNF_DEPLOYMENT_STATUS) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new GetCNFDeploymentStatusEventAck();
		}
	},
	
	GET_VNF_DEPLOYMENT_STATUS(RMSEventConstant.GET_VNF_DEPLOYMENT_STATUS) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new GetVNFDeploymentStatusEventAck();
		}
	},
	
	PUBLISH_ALARM_DICTIONARY(RMSEventConstant.PM_EVENT_COUNTER_UPLOAD) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new PublishAlarmDictionaryEventAck();
		}
	},

	PUBLISH_COUNTER_DICTIONARY(RMSEventConstant.AM_EVENT_ALARM_UPLOAD) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new PublishCounterDictionaryEventAck();
		}
	},

	PUBLISH_CONFIG_DICTIONARY(RMSEventConstant.CM_EVENT_CONFIG_UPLOAD) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new PublishConfigDictionaryEventAck();
		}
	},

	PUBLISH_VNFC_IMAGE_WITH_HTTP_URL(RMSEventConstant.PUBLISH_VNFC_IMAGE_WITH_HTTP_URL) {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new PublishVNFBinaryDownloadUrlEventAck();
		}
	},

	UNKONWN("") {
		@Override
		public EventAckProcessor getEventAckServiceObject(String event) {
			return new UNknownEventAck();
		}
	};

	private String value;

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private RMSEventAckConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	/**
	 * 
	 * @param event
	 * @return
	 */

	public EventAckProcessor getEventAckServiceObject(String event) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"getEventServiceObject", "Event : " + event);
		return new GetCNFDeploymentStatusEventAck();
	}

	/**
	 * 
	 * @param factory
	 * @param event
	 * @return
	 */

	public static EventAckProcessor getEventAckServiceObject(RMSEventAckConstantEnum factory, String event) {
		return factory.getEventAckServiceObject(event);
	}

}
