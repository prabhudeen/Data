package com.rjil.rms.eventack;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.rjil.rms.draft.CNFDraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.exceptions.EventAckParsingException;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonMethods;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class GetCNFDeploymentStatusEventAck implements EventAckProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String CLASS_NAME = "GetCNFDeploymentStatusEventAck";

	@Override
	public void processEventAck(RMREventPojo eventTracking) {

		final String methodName = "processEventAck";
		
		String eventData = EsManager.getInstance().getHaOperation()
				.getEventData(eventTracking.getFlowId() + "_" + eventTracking.getBranchId());
		
		RMREventPojo eventPojo = new RMREventPojo();

		ResponsePayload payloadNew = null;

		try {
			
			eventPojo.buildEventPojo(eventData);
			
			payloadNew = RtJioCommonMethods.getResponseEventAck(new String(eventTracking.getRequestStream()));

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
					"Processing Event Ack for : " + eventTracking.getEventName() + " | Data : "
							+ payloadNew.toString());

			if (payloadNew.getHttpStatusCode() != 200 && payloadNew.getHttpStatusCode() != 202) {
				return;
			}

			JSONArray json = new JSONArray((List) payloadNew.getAppData());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					json.toString(), "Request : " + json.toString(), eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			boolean isActive = false;

			for (int k = 0; k < json.length(); k++) {

				JSONObject eObj = json.getJSONObject(k);

				String activeInstance = eObj.getString("cnf-status");

				if ("running".equals(activeInstance) || "pending".equals(activeInstance)) {
					isActive = true;
				}

			}

			if (!isActive) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, methodName,
						"All Instance are down updating draft status");
		

				String cnfId = eventPojo.getRequestParams().get(CNFDraftOperationConstantsEnum.CNF_ID.getValue());

				EsManager.getInstance().getCnfdraftOperationImpl().updateDraftStatus(cnfId,
						CNFDraftOperationConstantsEnum.OPERATION_INSTANTIATE.getValue(),
						CNFDraftOperationConstantsEnum.PENDING.getValue());

			}
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_SUCCESS.increment();
			payloadNew.setHttpStatusCode(HttpServletResponse.SC_OK);
			payloadNew.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			payloadNew.setAppData(null);
			payloadNew.setErrorCode(null);

		} catch (EventAckParsingException ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Event Ack Parsing Error ", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payloadNew = new ResponsePayload();
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_FAILURE.increment();
			payloadNew.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			payloadNew.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payloadNew.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

		} catch (Exception ex) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in updating cnf draft status", ex);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), ex);

			payloadNew = new ResponsePayload();

			payloadNew.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			payloadNew.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payloadNew.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventPojo, new JSONObject(payloadNew), null);
		}

	}

}
