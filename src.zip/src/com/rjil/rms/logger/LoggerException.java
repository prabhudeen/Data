package com.rjil.rms.logger;

/**
 * Invalid Configurable Parameter User defined Exception
 * 
 * @author kiran.jangid
 *
 */

public class LoggerException extends RuntimeException {

	/**
	 * Generated serial ID
	 */
	private static final long serialVersionUID = -8654886743119415410L;

	/**
	 * 
	 * @param message
	 */

	public LoggerException(String message) {
		super(message);
	}

	/**
	 * Invalid Configuration Parameter
	 */

	public LoggerException() {
		super();
	}
}
