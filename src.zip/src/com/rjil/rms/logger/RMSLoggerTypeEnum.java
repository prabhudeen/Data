package com.rjil.rms.logger;

/**
 * 
 * @author kiran.jangid
 *
 */

public enum RMSLoggerTypeEnum {

	INFO("INFO"),

	ERROR("ERROR"),

	WARNING("WARNING"),

	FATAL("FATAL"),

	TRACE("TRACE"),

	DEBUG("DEBUG");

	private String value;

	private RMSLoggerTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
