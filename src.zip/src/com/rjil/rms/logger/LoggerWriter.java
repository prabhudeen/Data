package com.rjil.rms.logger;

import com.jio.telco.framework.resource.ResourceBuilder;

/**
 * 
 * @author kiran.jangid
 *
 */

public class LoggerWriter {

	private static LoggerWriter loggerWriter = new LoggerWriter();

	public static LoggerWriter getInstance() {
		return loggerWriter;
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param description
	 */

	public void writeClassLevelLog(String logType, String className, String methodName, String description) {
		ResourceBuilder.logger().setLogType(logType).setServiceStatusDescription(description)
				.setClassMethodName(className + ":" + methodName).writeLog();
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param description
	 * @param exception
	 */

	public void writeClassLevelExceptionLog(String logType, String className, String methodName, String description,
			Exception exception) {
		ResourceBuilder.logger().setLogType(logType).setServiceStatusDescription(description).setException(exception)
				.setClassMethodName(className + ":" + methodName).writeExceptionLog();
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param description
	 */

	public void writeApiLevelLog(String logType, String className, String methodName, String description) {
		ResourceBuilder.logger().setLogType(logType).setApiRequestData("").setApiRequestMethod("")
				.setServiceStatusDescription(description).setApiResponseCode(12).setApiResponseType("")
				.setResponseDescription("").setTargetMicroservice("")
				.setClassMethodName(className + ":" + methodName).writeLog();
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param description
	 * @param flowId
	 * @param targetMS
	 */

	public void writeApiLevelLog(String logType, String className, String methodName, String description, String flowId,
			String targetMS) {
		ResourceBuilder.logger().setLogType(logType).setApiRequestData("").setApiRequestMethod("").setRequestId(flowId)
				.setServiceStatusDescription(description).setApiResponseCode(12).setApiResponseType("")
				.setResponseDescription("").setTargetMicroservice(targetMS)
				.setClassMethodName(className + ":" + methodName).writeLog();
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param apiData
	 * @param description
	 * @param flowId
	 * @param targetMS
	 */

	public void writeApiLevelLog(String logType, String className, String methodName, String apiData,
			String description, String flowId, String targetMS) {
		ResourceBuilder.logger().setLogType(logType).setApiRequestData(apiData).setApiRequestMethod("")
				.setRequestId(flowId).setServiceStatusDescription(description).setApiResponseCode(12)
				.setApiResponseType("").setResponseDescription("")
				.setTargetMicroservice(targetMS).setClassMethodName(className + ":" + methodName).writeLog();
	}

	/**
	 * 
	 * @param logType
	 * @param className
	 * @param methodName
	 * @param apiData
	 * @param description
	 * @param flowId
	 * @param targetMS
	 * @param exception
	 */

	public void writeApiExceptionLog(String logType, String className, String methodName, String flowId,
			String targetMS, Exception exception) {
		ResourceBuilder.logger().setLogType(logType).setApiRequestMethod("").setRequestId(flowId).setApiResponseCode(12)
				.setApiResponseType("").setResponseDescription("").setServiceStatusDescription("")
				.setException(exception).setTargetMicroservice(targetMS)
				.setClassMethodName(className + ":" + methodName).writeExceptionLog();
	}

	/**
	 * 
	 * @param logLevel
	 */

	public void setLogLevel(String logLevel) {
		try {
			ResourceBuilder.logger().setSystemLogLevel(logLevel).updateLoggers();
		} catch (Exception e) {
			writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), "setLogLevel",
					"Error in Set Log Level", e);
		}
	}

	/**
	 * 
	 * @param logFilePath
	 * @param componentId
	 * @param microserviceIp
	 * @param processId
	 * @param microserviceHost
	 * @param microserviceName
	 * @param maxFileSize
	 * @param maxBackupIndex
	 * @throws Exception
	 */

	public void initializeLogger(String componentId, String microserviceIp, String processId, String microserviceHost,
			String microserviceName, int maxFileSize, int maxBackupIndex,int totalLogFileSize,int expireTimeForLogs) throws LoggerException {

		ResourceBuilder.logger().setMicroserviceName(microserviceName).setMicroserviceHost(microserviceHost)
				.setMsIpAddress(microserviceIp).setComponentId(componentId).setProcessId(processId)
				.setMaxFileSize(maxFileSize).setMaxBackupIndex(maxBackupIndex)
				  .setArchiveRetentionPolicyAccumulatedFileSize(totalLogFileSize)     // this is for file size
                  .setArchiveRetentionPolicyAgeInDays(expireTimeForLogs)                            // this is for days
			      .initializeLogger();

	}

	/**
	 * 
	 * @param logFilePath
	 */

	public void changeLogPath(String logFilePath) {
		ResourceBuilder.logger().setLogFilePath(logFilePath).updateLogFilePath();
	}

	/**
	 * 
	 * @param maxLogSize
	 */

	public void changeLogFileSize(int maxLogSize) {
		ResourceBuilder.logger().setMaxFileSize(maxLogSize).updateLogMaxFileSize();
	}

	/**
	 * 
	 * @param maxBackupIndex
	 */

	public void changMaxBackupLogFileCount(int maxBackupIndex) {
		ResourceBuilder.logger().setMaxBackupIndex(maxBackupIndex).updateLogMaxBackupIndex();
	}

}