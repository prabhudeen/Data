package com.rjil.rms.sync.request;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * Handler to Download File Synchronously
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMRFileUploaderContextHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final long serialVersionUID = 1L;

	private static final String CONTENT_TYPE_OCTET = "application/octet-stream";
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "inline; filename=\"";

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final String methodName = "doPost";

		try {

			if (request.getHeader("Content-Type") != null
					&& request.getHeader("Content-Type").startsWith("multipart/form-data")) {

				processFileStreamData(request, response);

			} else {
				processNormalRequest(request, response);
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload File", e);
		}

	}

	private void processFileStreamData(HttpServletRequest request, HttpServletResponse response) {

		final String methodName = "processPartRequest";

		try {

			String vendor = request.getParameter(NBIOTFileConstantEnum.VENDOR.getValue());
			String deviceType = request.getParameter(NBIOTFileConstantEnum.DEVICE_TYPE.getValue());
			String model = request.getParameter(NBIOTFileConstantEnum.MODEL.getValue());
			String softwareVersion = request.getParameter(NBIOTFileConstantEnum.SOFTWARE_VERSION.getValue());
			String fileName = request.getParameter(NBIOTFileConstantEnum.FILE_NAME.getValue());

			// constructs path of the directory to save uploaded file
			String uploadFilePath = RtJioCommonMethods.generateNBIotFilePath(vendor, deviceType, model, softwareVersion,
					null);

			byte[] byteArray = IOUtils.toByteArray(request.getInputStream());

			FileUtils.writeByteArrayToFile(new File(uploadFilePath, fileName), byteArray);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Upload File Directory=" + uploadFilePath);

			File fileUpdate = new File(uploadFilePath, fileName);

			if (byteArray.length != fileUpdate.length()) {
				fileUpdate.delete();
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "File Corrupted");
				return;
			}

			JSONObject json = new JSONObject();
			json.put("fileName", fileName);
			json.put("downloadPath",
					RtJioCommonMethods.generateNBIotDownloadPath(vendor, deviceType, model, softwareVersion, fileName));

			sendResponse(response, HttpServletResponse.SC_OK, json, "File uploaded successfully!");

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload File", e);
		}

	}

	private void processNormalRequest(HttpServletRequest request, HttpServletResponse response) {

		final String methodName = "processNormalRequest";

		try {

			String requestBody = IOUtils.toString(request.getInputStream(), "UTF-8");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request Body : " + requestBody);

			JSONObject strObj = new JSONObject(requestBody);

			String vendor = strObj.getString(NBIOTFileConstantEnum.VENDOR.getValue());
			String deviceType = strObj.getString(NBIOTFileConstantEnum.DEVICE_TYPE.getValue());
			String model = strObj.getString(NBIOTFileConstantEnum.MODEL.getValue());
			String softwareVersion = strObj.getString(NBIOTFileConstantEnum.SOFTWARE_VERSION.getValue());
			String fileName = strObj.getString(NBIOTFileConstantEnum.FILE_NAME.getValue());
			String sourceFilePath = strObj.getString(NBIOTFileConstantEnum.FILE_PATH.getValue());

			if (!RtJioCommonMethods.moveFileToDestination(vendor, deviceType, model, softwareVersion, fileName,
					sourceFilePath)) {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Failure in File Uplaod May be Curropted");
				return;
			}

			JSONObject json = new JSONObject();
			json.put("fileName", fileName);
			json.put("downloadPath",
					RtJioCommonMethods.generateNBIotDownloadPath(vendor, deviceType, model, softwareVersion, fileName));

			sendResponse(response, HttpServletResponse.SC_OK, json, "File uploaded successfully!");

		} catch (NullPointerException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "IO exception in sending bad request file does exist", e);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "IO exception in sending bad request file does exist", e);

		}
	}

	private void processPartRequest(HttpServletRequest request, HttpServletResponse response) {

		final String methodName = "processPartRequest";

		try {

			String vendor = request.getParameter(NBIOTFileConstantEnum.VENDOR.getValue());
			String deviceType = request.getParameter(NBIOTFileConstantEnum.DEVICE_TYPE.getValue());
			String model = request.getParameter(NBIOTFileConstantEnum.MODEL.getValue());
			String softwareVersion = request.getParameter(NBIOTFileConstantEnum.SOFTWARE_VERSION.getValue());
			String fileName = request.getParameter(NBIOTFileConstantEnum.FILE_NAME.getValue());

			// constructs path of the directory to save uploaded file
			String uploadFilePath = RtJioCommonMethods.generateNBIotFilePath(vendor, deviceType, model, softwareVersion,
					fileName);

			// creates the save directory if it does not exists
			File fileSaveDir = new File(uploadFilePath);

			if (!fileSaveDir.exists()) {
				fileSaveDir.mkdirs();
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Upload File Directory=" + fileSaveDir.getAbsolutePath());

			fileName = null;
			// Get all the parts from request and write it to the file on server
			for (Part part : request.getParts()) {
				fileName = getFileName(part);
				part.write(uploadFilePath + File.separator + fileName);
			}

			JSONObject json = new JSONObject();
			json.put("fileName", fileName);
			json.put("downloadPath",
					RtJioCommonMethods.generateNBIotDownloadPath(vendor, deviceType, model, softwareVersion, fileName));

			sendResponse(response, HttpServletResponse.SC_OK, json, "File uploaded successfully!");

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Upload File", e);
		}

	}

	private void sendResponse(HttpServletResponse response, int status, JSONObject resBody, String string) {

		try {

			response.setStatus(status);
			if (resBody != null) {
				response.getWriter().println(resBody.toString());
				response.setContentType("application/json");
			}
			response.flushBuffer();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					"sendResponse", "Sending Response : " + status + " | Message : " + resBody + " | Log : " + string);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"sendResponse", "Error in Building Response", e);
		}

	}

	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		System.out.println("content-disposition header= " + contentDisp);
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length() - 1);
			}
		}
		return "";
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		final String methodName = "doGet";

		String vendor = request.getParameter(NBIOTFileConstantEnum.VENDOR.getValue());
		String deviceType = request.getParameter(NBIOTFileConstantEnum.DEVICE_TYPE.getValue());
		String model = request.getParameter(NBIOTFileConstantEnum.MODEL.getValue());
		String softwareVersion = request.getParameter(NBIOTFileConstantEnum.SOFTWARE_VERSION.getValue());
		String fileName = request.getParameter(NBIOTFileConstantEnum.FILE_NAME.getValue());

		String targetPath = RtJioCommonMethods.generateNBIotFilePath(vendor, deviceType, model, softwareVersion, null);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "sendResponse",
				"Target Path : " + targetPath);

		int bufferSize = RtJioRMSConfigParamEnum.SIZE_OF_CHUNK.getIntValue();
		byte[] buffer = new byte[bufferSize];
		File file = new File(targetPath, fileName);

		if (file.exists()) {

			try (FileInputStream fis = new FileInputStream(file)) {

				response.setContentType(CONTENT_TYPE_OCTET);
				response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
				response.setContentLength((int) file.length());
				OutputStream os = response.getOutputStream();

				int byteRead = 0;
				while ((byteRead = fis.read(buffer)) != -1) {
					os.write(buffer, 0, byteRead);
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), this.getClass().getName(),
							"sendResponse", "Byte written in Response : " + byteRead);
				}
				os.flush();

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"sendResponse", "File Downloaded : " + fileName);

			} catch (Exception e) {

				try {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST);
				} catch (IOException e1) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), methodName, "IO exception in sending bad request", e1);
				}
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Download template FCAPS", e);

			}

		} else {

			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "IO exception in sending bad request", e);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"file does not exists: ");

		}

	}

}
