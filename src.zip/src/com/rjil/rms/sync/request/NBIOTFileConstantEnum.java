package com.rjil.rms.sync.request;

/**
 * 
 * @author kiran.jangid
 *
 */

public enum NBIOTFileConstantEnum {

	VENDOR("vendor"),

	MODEL("model"),

	SOFTWARE_VERSION("softwareVersion"),
	
	DEVICE_TYPE("deviceType"),
	
	FILE_PATH("filePath"),

	FILE_NAME("fileName");

	private String value;

	private NBIOTFileConstantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
