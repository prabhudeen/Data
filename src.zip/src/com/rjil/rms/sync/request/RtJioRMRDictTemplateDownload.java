package com.rjil.rms.sync.request;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Handler to Download File Synchronously
 * 
 * @author kiran.jangid
 *
 */
public class RtJioRMRDictTemplateDownload extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CONTENT_TYPE_OCTET = "application/octet-stream";
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "attachment; filename=\"";

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			downloadFile(request, response);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doGet", "Error in Download FCAPS template", e);
		}
	}

	private void downloadFile(HttpServletRequest request, HttpServletResponse response) throws IOException {

		final String methodName = "downloadFile";

		String fcapsType = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue());

		String targetPath = RtJioRMSConfigParamEnum.BINARY_SOURCE_HOME_PATH.getValue().toString() + "/" + fcapsType;
		String fileName = null;
		switch (fcapsType) {
		case RTJioRMSConstants.FCAP_TYPE_ALARM:
			fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_ALARM_FILE_NAME.getValue().toString();
			break;
		case RTJioRMSConstants.FCAP_TYPE_CONFIG:
			fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_CONFIG_FILE_NAME.getValue().toString();
			break;
		case RTJioRMSConstants.FCAP_TYPE_COUNTER:
			fileName = RtJioRMSConfigParamEnum.RMR_TEMPLATE_COUNTER_FILE_NAME.getValue().toString();
			break;
		default:
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"fcapsType is null : ");
			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e1) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
						this.getClass().getName(), methodName, "IO exception in sending bad request", e1);
			}
		}

		int bufferSize = 1024 * RtJioRMSConfigParamEnum.SIZE_OF_CHUNK.getIntValue();

		byte[] buffer = new byte[bufferSize];
		File file = new File(targetPath, fileName);

		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file)) {

				response.setContentType(CONTENT_TYPE_OCTET);
				response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
				response.setContentLength((int) file.length());
				OutputStream os = response.getOutputStream();

				int byteRead = 0;
				while ((byteRead = fis.read(buffer)) != -1) {
					os.write(buffer, 0, byteRead);
				}
				os.flush();

			} catch (Exception e) {
				try {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST);
				} catch (IOException e1) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), methodName, "IO exception in sending bad request", e1);
				}
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Download template FCAPS", e);
			}
		} else {

			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "IO exception in sending bad request file does exist", e);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"file does not exists: ");
		}

	}

}
