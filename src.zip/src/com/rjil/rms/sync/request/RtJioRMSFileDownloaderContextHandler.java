package com.rjil.rms.sync.request;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.eclipse.jetty.io.EofException;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.binary.VNFCImage;
import com.rjil.rms.binary.error.BinaryUploadResponse;
import com.rjil.rms.binary.error.NoSuchBinaryFile;
import com.rjil.rms.binary.util.FolderStructureGenerator;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.es.operation.ESOperationException;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.fcaps.FCAPSOperationConstantsEnum;
import com.rjil.rms.hdfs.HDFSTaskListener;
import com.rjil.rms.hdfs.RtJioRMShdfsConstants;
import com.rjil.rms.hdfs.RtJioRMShdfsGetFile;
import com.rjil.rms.hdfs.RtJioRMShdfsProcess;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.startup.RMSManagerBootstrap;
import com.rjil.rms.util.RtJioCommonMethods;

/**
 * Handler to Download File Synchronously
 * 
 * @author kiran.jangid
 *
 */
public class RtJioRMSFileDownloaderContextHandler extends HttpServlet {

	private final transient LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CONTENT_TYPE_OCTET = "application/octet-stream";
	private static final String CONTENT_DISPOSIOTION = "Content-Disposition";
	private static final String CONTENT_ATTACHMENT = "attachment; filename=\"";
	private String coreSiteXmlPath = RtJioRMShdfsConstants.CORE_SITE_XML;
    private String hdfsSiteXmlPath = RtJioRMShdfsConstants.HDFS_SITE_XML;
    private String vnfcPath;
    private String vnfcImageName;
    
	private static final String IMAGE_NAME_PARAM = "imageName";

	private static final long serialVersionUID = 1L;

	private static final ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
	
	 
	  public boolean ifExists (Path source) throws IOException {

          Configuration config = new Configuration();
          config.addResource(new Path(coreSiteXmlPath));
          config.addResource(new Path(hdfsSiteXmlPath));
          //            config.addResource(new Path(mapredSiteXmlPath));
          
          FileSystem hdfs = FileSystem.get(config);
          boolean isExists = hdfs.exists(source);
          return isExists;
          
   }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			String fcapsType = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue());

			if ("binary".equalsIgnoreCase(fcapsType)) {
				downloadBinary(request, response);
				return;
			}

			downloadFcaps(request, response);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doGet", "Error in Handling VNFC Image Download Request", e);
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "doGet",
					"Request Url = " + request.getRequestURI());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "doGet",
					"Request Query = " + request.getQueryString());

			String action = request.getParameter("action");

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "doGet",
					"Action = " + action);

			if (action != null ? "getImageSize".equalsIgnoreCase(action) : false) {
				getCheckOfVNFCImage(request, response);
				return;
			} else {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Action not found");
			}

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"doGet", "Error in Handling VNFC Image Download Request", e);
			ccAsnPojo.addClearCode(ClearCodes.FCAPS_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
			response.flushBuffer();
		}

	}

	private void getCheckOfVNFCImage(HttpServletRequest request, HttpServletResponse response) throws IOException, ESOperationException {

		final String methodName = "getCheckOfVNFCImage";
		JSONObject jsonData =null;
		File file=null;

		try {

			String subContext = request.getPathInfo();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Path Received in Request = " + subContext);

			String pathToBinary = RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().get(subContext);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Local Path of Image = " + pathToBinary);

			if (pathToBinary == null) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "vnfc image not found in cache : looking into ES database");

				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_NOT_FOUND_IN_CACHE.getValue(), ClearCodeLevel.PROTOCOL);

				if (!checkVnfcInEs(subContext)) {

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "vnfc image not found in es database ");

					ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_NOT_FOUND_IN_ES.getValue(), ClearCodeLevel.PROTOCOL);

					response.sendError(HttpServletResponse.SC_BAD_REQUEST, "VNFC Image doesnot exist at Server Side");

					return;

				}

			}

			long imageFileSize =0;
			if(RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue()) {
				
					 Configuration conf = new Configuration();
			          conf.addResource(new Path(coreSiteXmlPath));
			          conf.addResource(new Path(hdfsSiteXmlPath));
			          //            conf.addResource(new Path(mapredSiteXmlPath));
			          
			           FileSystem fileSystem = FileSystem.get(conf);
			           String[] contextData = subContext.split("/");
						String vnfcId = contextData[contextData.length - 1];
						String vnfcImageJson = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);
			            
						if (vnfcImageJson != null) {

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
									methodName,
									"vnfc image exists in es :  checking whether file exist folder structure with Json Body : \n"
											+ vnfcImageJson);

							JsonObject jsonObject = (new JsonParser().parse(vnfcImageJson)).getAsJsonObject();

							Gson gsonObj = new Gson();
							VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

							this.vnfcPath = RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue()
									               + FolderStructureGenerator.generateHDFSDriectroy(vnfcImage)+"/"+vnfcImage.getImageName();
			                
							

							loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
									methodName, "file exist in folder structure : " + this.vnfcPath + "vnfId = "+vnfcImage.getVnfID()+" vnfcId = "+
							    vnfcImage.getVnfcID());
							Path imagePath = new Path(this.vnfcPath);
							if (ifExists(imagePath)) {

								imageFileSize = fileSystem.getFileStatus(imagePath).getLen();
							}
							
							 jsonData = new JSONObject();
							jsonData.put(IMAGE_NAME_PARAM, vnfcImage.getImageName());
							jsonData.put("imagesize", String.valueOf(imageFileSize));
			          
				       }else {
				    		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
									"vnfc Image Not Found In ES for Id := " + vnfcId);
				    		response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
									"Internal Server Error Due to Json Parsing or IO Operation");
				       }
				  
				
			}else {

				pathToBinary = RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().get(subContext);
	            
				file = new File(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + pathToBinary);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						"vnfc Image Found In Local Storage : " + file.getName());
				    imageFileSize = file.length();
				    jsonData = new JSONObject();
					jsonData.put(IMAGE_NAME_PARAM, file.getName());
					jsonData.put("imagesize", String.valueOf(imageFileSize));
	            
			}
			

			response.setContentType("application/json");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().println(jsonData.toString());

		} catch (JSONException | IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Internal Server Error Due to Json Parsing or IO Operation", e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"Internal Server Error Due to Json Parsing or IO Operation");
		}

	}

	private void downloadFcaps(HttpServletRequest request, HttpServletResponse response) {

		final String methodName = "downloadFcaps";

		String fileName = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_FILE_NAME.getValue());
		String vnfId = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_VNF_ID.getValue());
		String vnfVersion = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_VNF_VERSION.getValue());
		String vendorId = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_VENDOR_ID.getValue());
		String fcapsType = request.getParameter(FCAPSOperationConstantsEnum.APPDATA_FCAPS_TYPE.getValue());

		String targetPath = RtJioCommonMethods.generateFCAPSRep(fcapsType, vendorId, vnfId, vnfVersion);

		int bufferSize = 1024 * RtJioRMSConfigParamEnum.SIZE_OF_CHUNK.getIntValue();
		byte[] buffer = new byte[bufferSize];
		File file = new File(targetPath, fileName);
		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file)) {

				response.setContentType(CONTENT_TYPE_OCTET);
				response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
				response.setContentLength((int) file.length());
				OutputStream os = response.getOutputStream();

				int byteRead = 0;
				while ((byteRead = fis.read(buffer)) != -1) {
					os.write(buffer, 0, byteRead);

				}
				os.flush();

			} catch (Exception e) {
				try {
					response.sendError(HttpServletResponse.SC_BAD_REQUEST);
				} catch (IOException e1) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), methodName, "IO exception in sending bad request", e1);
				}
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Download template FCAPS", e);

				printFCAPSClearCode(fcapsType);

			}
		} else {

			try {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			} catch (IOException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "IO exception in sending bad request", e);
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"file does not exists: ");

			printFileMissingClearCode(fcapsType);
		}

	}

	private void printFileMissingClearCode(String fcapsType) {

		switch (fcapsType) {
		case "alarm":
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "config":
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "counter":
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_NOT_FOUND_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		default:
			break;
		}

	}

	private void printFCAPSClearCode(String fcapsType) {
		switch (fcapsType) {
		case "alarm":
			ccAsnPojo.addClearCode(ClearCodes.ALARM_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "config":
			ccAsnPojo.addClearCode(ClearCodes.CONFIG_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		case "counter":
			ccAsnPojo.addClearCode(ClearCodes.COUNTER_DICTIONARY_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
			break;
		default:
			break;
		}

	}

	private void downloadBinary(HttpServletRequest request, HttpServletResponse response) throws IOException {

		final String methodName = "downloadBinary";
		String subContext = request.getPathInfo();
		String action = request.getParameter("action");

		if (action != null) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST,
					"Invalid Url Received ! action parameter is not required");
		}

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"subContext = " + subContext);

		String pathToBinary = RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().get(subContext);

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"pathToBinary    " + pathToBinary);

		boolean toDownload = true;

		if (pathToBinary == null) {

			toDownload = false;
            
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"vnfc image not found in cache : ");

			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_NOT_FOUND_IN_CACHE.getValue(), ClearCodeLevel.PROTOCOL);

			if (checkVnfcInEs(subContext)) {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "vnfc image found in es : ");
				pathToBinary = RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().get(subContext);
				toDownload = true;
			} else {
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "vnfc image not found in es : ");
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_NOT_FOUND_IN_ES.getValue(), ClearCodeLevel.PROTOCOL);
			}

		}

		if (toDownload) {

			try {

				if(RtJioRMSConfigParamEnum.IS_USING_HDFS.getBooleanValue()) {
					downloadFromHDFS(response);
				}
				else {
					
					int bufferSize = 1024 * RtJioRMSConfigParamEnum.SIZE_OF_CHUNK.getIntValue();
					byte[] buffer = new byte[bufferSize];
					File file = new File(RtJioRMSConfigParamEnum.BINARY_DESTINATION_HOME_PATH.getStringValue() + pathToBinary);
					FileInputStream fis = new FileInputStream(file);

					BufferedInputStream bufInputStream = new BufferedInputStream(fis);

					response.setContentType(CONTENT_TYPE_OCTET);
					response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + file.getName() + "\"");
					response.setHeader("Content-Length", Long.toString(file.length()));
					OutputStream os = response.getOutputStream();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "Download File Lenght : " + file.length());

					int byteRead = 0;
					while ((byteRead = bufInputStream.read(buffer)) != -1) {
						os.write(buffer, 0, byteRead);
					}

					os.flush();
					bufInputStream.close();
					os.close();
				}
				
		          
			}catch(NoSuchBinaryFile e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Eof Download binary", e);
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_NOT_FOUND_IN_HDFS.getValue(), ClearCodeLevel.PROTOCOL);
			}
			catch (EofException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Eof Download binary", e);
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DWONLOAD_ERROR_EOF.getValue(), ClearCodeLevel.PROTOCOL);
			} catch (Exception excp) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error in Download binary", excp);
				ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DOWNLOAD_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
			}
		} else {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			ccAsnPojo.addClearCode(ClearCodes.VNFC_IMAGE_DOWNLOAD_ERROR.getValue(), ClearCodeLevel.PROTOCOL);
		}
	}
	
	/*
	 * method to download binary file form HDFS file System
	 */
	
	private void downloadFromHDFS(HttpServletResponse response) throws NoSuchBinaryFile,IOException {
		
		String methodName="downloadFromHDFS";
		response.setContentType(CONTENT_TYPE_OCTET);
		response.setHeader(CONTENT_DISPOSIOTION, CONTENT_ATTACHMENT + this.vnfcImageName + "\"");
		
		  loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"inside DownloadBinary METHOD =" +vnfcPath);
          Configuration conf = new Configuration();
          conf.addResource(new Path(coreSiteXmlPath));
          conf.addResource(new Path(hdfsSiteXmlPath));
          //            conf.addResource(new Path(mapredSiteXmlPath));
          
          FileSystem fileSystem = FileSystem.get(conf);

          Path path = new Path(vnfcPath);
          if (!fileSystem.exists(path)) {
               throw new NoSuchBinaryFile();
          }
          loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File path available in HDFS =" +vnfcPath);
       
          long length = fileSystem.getFileStatus(path).getLen();
          response.setHeader("Content-Length", Long.toString(length));
        
          
          FSDataInputStream in = fileSystem.open(path);
          System.out.println("path : "+ path); 
  
          OutputStream os = response.getOutputStream();

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName, "Download File Lenght : " + length);
          try {
     
          byte[] b = new byte[1024];
          int numBytes = 0;
          while ((numBytes = in.read(b)) > 0) {
                 os.write(b, 0, numBytes);     
          }
          
          }finally {
        	  
        		os.flush();
				os.close();
	            in.close();
	            fileSystem.close();
          }
          
          loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "run",
					"File Download from HDFS Completed on file Path =" +vnfcPath);

	}

	/**
	 * 
	 * Check VNFC Details in Database
	 * 
	 * @param subContext
	 * @return
	 */

	public boolean checkVnfcInEs(String subContext) {

		final String methodName = "checkVnfcInEs";

		boolean isInEs = false;

		try {

			String[] contextData = subContext.split("/");
			String vnfcId = contextData[contextData.length - 1];
			String vnfcImageJson = EsManager.getInstance().getVnfOperationImpl().getVNFCImage(vnfcId);
            
			if (vnfcImageJson != null) {

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName,
						"vnfc image exists in es :  checking whether file exist folder structure with Json Body : \n"
								+ vnfcImageJson);

				JsonObject jsonObject = (new JsonParser().parse(vnfcImageJson)).getAsJsonObject();

				Gson gsonObj = new Gson();
				VNFCImage vnfcImage = gsonObj.fromJson(jsonObject, VNFCImage.class);

				this.vnfcPath = RtJioRMSConfigParamEnum.HDFS_DESTINATION_HOME_PATH.getStringValue()
						               + FolderStructureGenerator.generateHDFSDriectroy(vnfcImage);
                
				

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, "file exist in folder structure : " + this.vnfcPath + "vnfId = "+vnfcImage.getVnfID()+" vnfcId = "+
				    vnfcImage.getVnfcID());
							
				if (ifExists(new Path(this.vnfcPath))) {

					isInEs = true;
                    this.vnfcPath += "/" +vnfcImage.getImageName();
					RMSManagerBootstrap.rmsManager.getVnfcUrlToBinaryPathMap().put(vnfcPath,
							vnfcPath);
					this.vnfcImageName =vnfcImage.getImageName();

					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "file exist in folder structure , so cache updated");
				} else {
					loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, "file doesn't exist in folder structure , so returning false");
				}
			}

		} catch (ESOperationException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName, "ESOperationException in checkVnfcInEs", e);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName, "exception in checkVnfcInEs", e);
		}
		return isInEs;
	}
	
	
	

}
