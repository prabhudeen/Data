package com.rjil.rms.ui.metadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.rjil.rms.ui.metadata.error.DataNotAvailableError;
import com.rjil.rms.ui.metadata.error.DuplicateElementError;

/**
 * Concrete class that will implement all provisioning operation on metadata
 * 
 * @author Kiran.Jangid
 *
 */

public class MetadataOperationImpl implements MetadataOperation {

	@Override
	public Map getMetadata(String key) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key) == null) {
			throw new DataNotAvailableError();
		}

		return MetadataManager.getInstance().getMetadataMap().get(key);
	}

	@Override
	public Object getMetadataKeyValue(String key, String parameter) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key).get(parameter) == null) {
			throw new DataNotAvailableError();
		}

		return MetadataManager.getInstance().getMetadataMap().get(key).get(parameter);
	}

	@Override
	public boolean setMetadataKeyValue(String key, String parameter, Object value) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key) == null) {
			throw new DataNotAvailableError();
		}

		MetadataManager.getInstance().getMetadataMap().get(key).put(parameter, value);
		MetadataManager.getInstance().dumpMetadata();
		return true;
	}

	@Override
	public boolean addMetadata(String key, Map mapOfValues) throws DuplicateElementError {

		if (MetadataManager.getInstance().getMetadataMap().get(key) != null) {
			throw new DuplicateElementError();
		}

		MetadataManager.getInstance().getMetadataMap().put(key, mapOfValues);
		MetadataManager.getInstance().dumpMetadata();
		return true;
	}

	@Override
	public boolean addMetadata(String key, String parameter, Object value) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key) == null) {
			throw new DataNotAvailableError();
		}

		MetadataManager.getInstance().getMetadataMap().get(key).put(parameter, value);
		MetadataManager.getInstance().dumpMetadata();
		return true;
	}

	@Override
	public List getMetadataCategory() throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().isEmpty()) {
			throw new DataNotAvailableError();
		}

		Set<String> catelist = MetadataManager.getInstance().getMetadataMap().keySet();

		return new ArrayList<>(catelist);

	}

	@Override
	public boolean deleteMetadata(String key) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key) == null) {
			throw new DataNotAvailableError();
		}

		MetadataManager.getInstance().getMetadataMap().remove(key);
		MetadataManager.getInstance().dumpMetadata();
		return true;
	}

	@Override
	public boolean deleteMetadata(String key, String parameter) throws DataNotAvailableError {

		if (MetadataManager.getInstance().getMetadataMap().get(key).get(parameter) == null) {
			throw new DataNotAvailableError();
		}

		MetadataManager.getInstance().getMetadataMap().get(key).remove(parameter);
		MetadataManager.getInstance().dumpMetadata();
		return true;
	}

}
