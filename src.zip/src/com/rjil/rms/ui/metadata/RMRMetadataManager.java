package com.rjil.rms.ui.metadata;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.broadcast.manager.RMRHAManager;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.ui.metadata.error.DataNotAvailableError;
import com.rjil.rms.ui.metadata.error.DuplicateElementError;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * Metadata Manager that will handle Different Event comes from ERM.
 * 
 * <br>
 * 
 * Events : <b>GET_METADATA, ADD_METADATA, MODIFY_METADATA, DELETE_METADATA,
 * VIEW_METADATA, SET_METADATA</b>
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRMetadataManager implements RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "processEvent",
				"processing event in RMRMetadataManager for eventTracking.getEventName() ");

		switch (eventTracking.getEventName()) {
		case RMSEventConstant.RMR_EVENT_GET_METADATA:
			getMetadata(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_SET_METADATA:
			setMetadata(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_ADD_METADATA:
			addMetadata(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_MODIFY_METADATA:
			modifyMetadata(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_DELETE_METADATA:
			deleteMetadata(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_VIEW_METADATA:
			viewMetadata(eventTracking);
			break;
		default:
			break;
		}

	}

	private void viewMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "viewMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_REQUEST.increment();

		try {

			String type = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.TYPE.getValue());

			// validate type value
			if (type == null || "".equals(type) || !(type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())
					|| type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue()))) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(
						ClearCodes.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID_IN_VIEW_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_INVALID.increment();

				return;
			}

			// check type is category and add multiple parameter in metadata
			// file
			if (type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())) {

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "Category List : " + MetadataManager.getInstance().getOperation().getMetadataCategory(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				JSONObject object = new JSONObject();
				object.put("categoryList", MetadataManager.getInstance().getOperation().getMetadataCategory());
				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setAppData(object);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_SUCCESS.increment();

				return;

			}

			String category = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

			// validate category value
			if (category == null || "".equals(category.trim())) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(
						ClearCodes.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID_IN_VIEW_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_INVALID.increment();

				return;
			}

			JSONObject object = new JSONObject(MetadataManager.getInstance().getOperation().getMetadata(category));

			payload.setHttpStatusCode(HttpServletResponse.SC_OK);
			payload.setAppData(object);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_SUCCESS.increment();

			return;

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in view metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DATA_NOT_AVAILABLE_IN_VIEW_METADATA.getValue(), ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_INVALID.increment();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in view metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_VIEW_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void deleteMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "deleteMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_REQUEST.increment();

		try {

			String type = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.TYPE.getValue());

			// validate type value
			if (type == null || "".equals(type) || !(type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())
					|| type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue()))) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(
						ClearCodes.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID_IN_DELETE_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_INVALID.increment();

				return;
			}

			String category = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

			// validate category value
			if (category == null || "".equals(category.trim())) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(
						ClearCodes.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID_IN_DELETE_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_INVALID.increment();

				return;
			}

			// check type is parameter and add single parameter in metadata file
			if (type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue())) {

				String parameter = eventTracking.getRequestParams()
						.get(MetadataOperationConstantsEnum.PARAMETER.getValue());

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null,
						"Request to delete Metadata Info for | parameter = " + parameter + " | category = " + category,
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				// validate parameter and value
				if (parameter == null || "".equals(parameter)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue());
					ccAsnPojo.addClearCode(ClearCodes.PARAMETER_AND_VALUES_INVALID_IN_DELETE_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_INVALID.increment();

					return;

				}

				// check parameter deleted successful or not
				if (!MetadataManager.getInstance().getOperation().deleteMetadata(category, parameter)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

					ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_DELETE_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_FAILURE.increment();

					return;
				}

				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_SUCCESS.increment();
				
				// broadcast event to other instance
				RMRHAManager.getInstance().broadcastEvent(eventTracking);

				return;

			}

			// check type is category and add multiple parameter in metadata
			// file
			if (type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())) {

				// check category deleted successful or not
				if (!MetadataManager.getInstance().getOperation().deleteMetadata(category)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

					ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_DELETE_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_FAILURE.increment();

					return;
				}

				// Setting Success Response
				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_SUCCESS.increment();
				// broadcast event to other instance
				RMRHAManager.getInstance().broadcastEvent(eventTracking);

				return;

			}

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in delete metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DATA_NOT_AVAILABLE_IN_DELETE_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);

			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_INVALID.increment();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in delete metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_DELETE_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);

			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void modifyMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "modifyMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_REQUEST.increment();

		try {

			String category = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

			// validate category value
			if (category == null || "".equals(category.trim())) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(
						ClearCodes.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID_IN_MODIFY_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_INVALID.increment();

				return;
			}

			String parameter = eventTracking.getRequestParams()
					.get(MetadataOperationConstantsEnum.PARAMETER.getValue());
			String value = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.VALUE.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					methodName, null, "Request to modify Metadata Info for | category = " + category + " , parameter = "
							+ parameter + " , value = " + value,
					eventTracking.getFlowId(), eventTracking.getPublisherName());

			// validate parameter and value
			if (parameter == null || value == null || "".equals(parameter) || "".equals(value)) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue());
				ccAsnPojo.addClearCode(ClearCodes.PARAMETER_AND_VALUES_INVALID_IN_MODIFY_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue(), eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_INVALID.increment();

				return;

			}

			String format = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.FORMAT.getValue());

			Object valueNew;

			if (format.equals(MetadataOperationConstantsEnum.STRING.getValue())) {
				valueNew = value;
			} else if (format.equals(MetadataOperationConstantsEnum.NUMBER.getValue())) {
				valueNew = Integer.valueOf(value);
			} else {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue());
				ccAsnPojo.addClearCode(ClearCodes.VALUE_FORMAT_INVALID_IN_MODIFY_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue(), eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_INVALID.increment();

				return;
			}

			// check parameter modifying successful or not
			if (!MetadataManager.getInstance().getOperation().setMetadataKeyValue(category, parameter, valueNew)) {

				payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

				ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_MODIFY_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_FAILURE.increment();

				return;
			}

			payload.setHttpStatusCode(HttpServletResponse.SC_OK);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_SUCCESS.increment();
			
			// broadcast event to other instance
			RMRHAManager.getInstance().broadcastEvent(eventTracking);

			return;

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in modify metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DATA_NOT_AVAILABLE_IN_MODIFY_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_INVALID.increment();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in modify metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_MODIFY_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	@SuppressWarnings("unchecked")
	private void addMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "addMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();
		RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_REQUEST.increment();

		try {

			String type = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.TYPE.getValue());

			// validate type value
			if (type == null || "".equals(type) || !(type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())
					|| type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue()))) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(ClearCodes.TYPE_PARAMETER_MISSING_OR_INVALID_IN_ADD_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.TYPE_METADATA_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

				return;
			}

			String category = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.CATEGORY.getValue());

			// validate category value
			if (category == null || "".equals(category.trim())) {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue());
				ccAsnPojo.addClearCode(ClearCodes.CATEGORY_PARAMETER_MISSING_OR_INVALID_IN_ADD_METADATA.getValue(),
						ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.CATEGORY_MANDATORY_PARAMETER_MISSING_OR_INVALID.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

				return;
			}

			// check type is parameter and add single parameter in metadata file
			if (type.equals(MetadataOperationConstantsEnum.PARAMETER.getValue())) {

				String parameter = eventTracking.getRequestParams()
						.get(MetadataOperationConstantsEnum.PARAMETER.getValue());
				String value = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.VALUE.getValue());

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						methodName, null, "Request to add Metadata Info for | parameter = " + parameter + " | key = "
								+ category + " | value = " + value,
						eventTracking.getFlowId(), eventTracking.getPublisherName());

				// validate parameter and value
				if (parameter == null || value == null || "".equals(parameter) || "".equals(value)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue());
					ccAsnPojo.addClearCode(ClearCodes.PARAMETER_AND_VALUES_INVALID_IN_ADD_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

					return;

				}

				String format = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.FORMAT.getValue());

				Object valueNew;

				if (format.equals(MetadataOperationConstantsEnum.STRING.getValue())) {
					valueNew = value;
				} else if (format.equals(MetadataOperationConstantsEnum.NUMBER.getValue())) {
					valueNew = Integer.valueOf(value);
				} else {

					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue());
					ccAsnPojo.addClearCode(ClearCodes.VALUE_FORMAT_INVALID_IN_ADD_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.PARAMETER_AND_VALUES_INVALID.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

					return;
				}

				// check parameter added successful or not
				if (!MetadataManager.getInstance().getOperation().addMetadata(category, parameter, valueNew)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

					ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_ADD_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_FAILURE.increment();

					return;
				}

				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
				RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_SUCCESS.increment();

				// broadcast event to other instance
				RMRHAManager.getInstance().broadcastEvent(eventTracking);

				return;

			}

			// check type is category and add multiple parameter in metadata
			// file
			if (type.equals(MetadataOperationConstantsEnum.CATEGORY.getValue())) {

				String parameterList = new String(eventTracking.getRequestStream());

				Gson gsonParser = new Gson();

				LinkedHashMap<String, Object> paramMap = gsonParser.fromJson(parameterList, LinkedHashMap.class);

				// check parameter added successful or not
				if (!MetadataManager.getInstance().getOperation().addMetadata(category, paramMap)) {

					payload.setHttpStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_ADD_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);

					RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_FAILURE.increment();

					return;
				}

				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_SUCCESS.increment();

				// broadcast event to other instance
				RMRHAManager.getInstance().broadcastEvent(eventTracking);

				return;

			}

		} catch (DuplicateElementError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in add metadata due to data is duplicate available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DUPLICATE_DATA_ENTRY.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DUPLICATE_DATA_ENTRY_IN_ADD_METADATA.getValue(), ClearCodeLevel.PROTOCOL);

			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in add metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DATA_NOT_AVAILABLE_IN_ADD_METADATA.getValue(), ClearCodeLevel.PROTOCOL);

			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID.increment();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in add metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_ADD_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);

			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	/**
	 * 
	 * @param eventTracking
	 */

	private void setMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "setMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String key = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.KEY.getValue());
			String parameter = eventTracking.getRequestParams()
					.get(MetadataOperationConstantsEnum.PARAMETER.getValue());
			String value = eventTracking.getRequestParams().get(MetadataOperationConstantsEnum.VALUE.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(),
					this.getClass().getName(), methodName, null, "Request to set Metadata Info for | parameter = "
							+ parameter + " | key = " + key + " | value = " + value,
					eventTracking.getFlowId(), eventTracking.getPublisherName());

			if (key != null && parameter != null && value != null) {

				MetadataManager.getInstance().getOperation().setMetadataKeyValue(key, parameter, value);

				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				ccAsnPojo.addClearCode(ClearCodes.METADATA_PARAMETER_SET.getValue(), ClearCodeLevel.PROTOCOL);

				// broadcast event to other instance
				RMRHAManager.getInstance().broadcastEvent(eventTracking);

			} else {

				payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.METADATA_PARAMETER_MISSING.getValue(), ClearCodeLevel.PROTOCOL);

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
						null, ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue(),
						eventTracking.getFlowId(), eventTracking.getPublisherName());
			}

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in set metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue());
			ccAsnPojo.addClearCode(ClearCodes.METADATA_PARAMETER_MISSING.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in set metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.ERROR_IN_METADATA_PARAMETER_SET.getValue(), ClearCodeLevel.PROTOCOL);

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	/**
	 * 
	 * Method to handle GET_METADATA event. This will accept parameter in query
	 * parameter or json body.
	 * 
	 * <p>
	 * <b> example :</b>
	 * </p>
	 * 
	 * /?parameter=trigger-value
	 * 
	 * <br>
	 * or
	 * 
	 * <p>
	 * { parameter : ["trigger-value", "trigger-name"] }
	 * </p>
	 * 
	 * @param eventTracking
	 */

	@SuppressWarnings("unchecked")
	private void getMetadata(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "getMetadata";

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_REQUEST.increment();

		try {

			String parameter = eventTracking.getRequestParams()
					.get(MetadataOperationConstantsEnum.PARAMETER.getValue());

			if (parameter != null) {

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "Request to get Metadata Info for | parameter = " + parameter, eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				JSONObject metadataStr = new JSONObject(
						MetadataManager.getInstance().getOperation().getMetadata(parameter));

				loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						null, "Metadata = " + metadataStr.toString(), eventTracking.getFlowId(),
						eventTracking.getPublisherName());

				payload.setAppData(metadataStr);
				payload.setHttpStatusCode(HttpServletResponse.SC_OK);
				payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

				ccAsnPojo.addClearCode(ClearCodes.GET_METADATA_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

				RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_SUCCESS.increment();

				return;

			} else {

				String parameterList = new String(eventTracking.getRequestStream());

				JSONObject parametersObject = new JSONObject(parameterList);

				JSONArray parameters = parametersObject
						.getJSONArray(MetadataOperationConstantsEnum.PARAMETER.getValue());

				if (parameters != null) {

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, null,
							"Request to get Metadata Info for | parameters = " + parameters.toString(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());

					Map<String, Map<String, String>> newList = new HashMap<>();

					for (int i = 0; i < parameters.length(); i++) {
						newList.put(parameters.getString(i),
								MetadataManager.getInstance().getOperation().getMetadata(parameters.getString(i)));
					}

					JSONObject metadataStr = new JSONObject(newList);

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
							methodName, null, "Metadata = " + metadataStr.toString(), eventTracking.getFlowId(),
							eventTracking.getPublisherName());

					payload.setAppData(metadataStr);
					payload.setHttpStatusCode(HttpServletResponse.SC_OK);
					payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

					ccAsnPojo.addClearCode(ClearCodes.GET_METADATA_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

					RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_SUCCESS.increment();

					return;

				} else {

					payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
					payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
					payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue());

					ccAsnPojo.addClearCode(ClearCodes.PARAMETER_MISSING_IN_GET_METADATA.getValue(),
							ClearCodeLevel.PROTOCOL);
					RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_INVALID.increment();

					loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
							methodName, null, ResponseConstantsEnum.RESPONSE_MANDATORY_PARAMETER_MISSING.getValue(),
							eventTracking.getFlowId(), eventTracking.getPublisherName());
				}
			}

		} catch (DataNotAvailableError e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get metadata due to data is not available", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_NOT_FOUND);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_DATA_NOT_AVAILABLE.getValue());
			ccAsnPojo.addClearCode(ClearCodes.DATA_NOT_AVAILABLE_IN_GET_METADATA.getValue(), ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_INVALID.increment();

		} catch (JSONException e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(HttpServletResponse.SC_BAD_REQUEST);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.REQUEST_JSON_INVALID.getValue());
			ccAsnPojo.addClearCode(ClearCodes.REQUEST_JSON_INVALID_IN_GET_METADATA.getValue(), ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_INVALID.increment();

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get metadata ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			ccAsnPojo.addClearCode(ClearCodes.INTERNAL_SERVICE_ERROR_IN_GET_METADATA.getValue(),
					ClearCodeLevel.PROTOCOL);
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_FAILURE.increment();

		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
