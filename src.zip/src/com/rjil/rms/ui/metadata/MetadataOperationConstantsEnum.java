package com.rjil.rms.ui.metadata;

/**
 * 
 * Constant to operate provisioning operation on metadata
 * 
 * <br>
 * list : <b>key, value, type, category, parameter</b>
 * 
 * @author kiran.jangid
 *
 */

public enum MetadataOperationConstantsEnum {

	KEY("key"),

	VALUE("value"),

	TYPE("type"),

	CATEGORY("category"),

	PARAMETER("parameter"),

	FORMAT("format"),

	STRING("string"),

	NUMBER("number");

	private String value;

	private MetadataOperationConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
