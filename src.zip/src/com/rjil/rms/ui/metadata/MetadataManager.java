package com.rjil.rms.ui.metadata;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.atom.OAM.Client.Management.OamClientManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.alarms.RtJioRMSAlarmNameIntf;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;

/**
 * Metadata Manager that will store metadata in cache and manage it in yml file
 * 
 * @author Kiran.Jangid
 *
 */

public class MetadataManager {

	private static MetadataManager manager;

	private Map<String, Map<String, Object>> metadataMap;

	private MetadataOperation operation = new MetadataOperationImpl();

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private MetadataManager() {
	}

	public static MetadataManager getInstance() {

		if (manager == null) {
			synchronized (MetadataManager.class) {

				if (manager == null) {
					manager = new MetadataManager();
				}

			}
		}

		return manager;

	}

	/**
	 * 
	 * @return
	 */

	@SuppressWarnings("unchecked")
	public boolean loadMetadata() {

		ObjectMapper mapper = new YAMLMapper();

		try {

			metadataMap = mapper.readValue(new File(RtJioRMSConfigParamEnum.UI_METADATA_FILE.getStringValue()),
					LinkedHashMap.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					"loadMetadata", "Loaded Metadata : " + metadataMap);

			return true;

		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"loadMetadata", "loading Metadata", e);
			return false;
		}

	}

	/**
	 * 
	 * @return
	 */

	@SuppressWarnings("unchecked")
	public boolean reloadMetadata() {

		ObjectMapper mapper = new YAMLMapper();

		try {

			metadataMap = mapper.readValue(new File(RtJioRMSConfigParamEnum.UI_METADATA_FILE.getStringValue()),
					LinkedHashMap.class);

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					"reloadMetadata", "Reloaded Metadata : " + metadataMap);
			return true;

		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"reloadMetadata", "loading Metadata", e);
			return false;
		}
	}

	boolean dumpMetadata() {

		try {

			YAMLFactory yf = new YAMLFactory();

			FileOutputStream fos = new FileOutputStream(
					new File(RtJioRMSConfigParamEnum.UI_METADATA_FILE.getStringValue()));

			YAMLGenerator ymlGen = yf.createGenerator(fos);
			ymlGen.setCodec(new ObjectMapper());
			ymlGen.writeObject(metadataMap);

			return true;

		} catch (FileNotFoundException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"dumpMetadata", "Dump Metadata File Not Found Failure", e);
			OamClientManager.getOamClientForAlarm()
					.raiseAlarmToOamServer(RtJioRMSAlarmNameIntf.FILE_NOT_FOUND_DURING_UPDATING_METADATA_FILE);
			return false;
		} catch (IOException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"dumpMetadata", "Dump Metadata IO Failure", e);
			OamClientManager.getOamClientForAlarm().raiseAlarmToOamServer(
					RtJioRMSAlarmNameIntf.FILE_IO_OPERATION_FAILURE_DURING_UPDATING_METADATA_FILE);
			return false;
		}

	}

	/**
	 * @return the metadataMap
	 */
	public Map<String, Map<String, Object>> getMetadataMap() {
		return metadataMap;
	}

	/**
	 * @return the operation
	 */
	public MetadataOperation getOperation() {
		return operation;
	}

}
