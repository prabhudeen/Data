package com.rjil.rms.ui.metadata;

import java.util.List;
import java.util.Map;

import com.rjil.rms.ui.metadata.error.DataNotAvailableError;
import com.rjil.rms.ui.metadata.error.DuplicateElementError;

/**
 * 
 * To provide interface for provisioning metadata
 * 
 * @author Kiran.Jangid
 *
 */

public interface MetadataOperation {

	/**
	 * To get all parameter for particular category given in argument
	 * 
	 * @param key
	 * @return
	 */

	Map getMetadata(String key) throws DataNotAvailableError;

	/**
	 * To get value of parameter
	 * 
	 * @param key
	 * @param parameter
	 * @return
	 */

	Object getMetadataKeyValue(String key, String parameter) throws DataNotAvailableError;

	/**
	 * To add or modify existing parameter
	 * 
	 * @param key
	 * @param parameter
	 * @param value
	 * @return
	 */

	boolean setMetadataKeyValue(String key, String parameter, Object value) throws DataNotAvailableError;

	/**
	 * To add parameter in particular category given in argument
	 * 
	 * @param key
	 * @param mapOfValues
	 * @return
	 */

	boolean addMetadata(String key, Map mapOfValues) throws DuplicateElementError;

	/**
	 * To add parameter in particular category given in argument
	 * 
	 * @param key
	 * @param parameter
	 * @param value
	 * @return
	 */

	boolean addMetadata(String key, String parameter, Object value) throws DataNotAvailableError;

	/**
	 * To get list of category
	 * 
	 * @return
	 */

	List getMetadataCategory() throws DataNotAvailableError;

	/**
	 * To Delete categry in UI Metadata
	 * 
	 * @param key
	 *            : category name that will be deleted
	 * @return
	 * @throws DataNotAvailableError
	 */

	boolean deleteMetadata(String key) throws DataNotAvailableError;

	/**
	 * To delete parameter in UI metadata
	 * 
	 * @param key
	 *            : category name that should have parameter
	 * @param parameter
	 *            : parameter name that will be deleted
	 * @return
	 */

	boolean deleteMetadata(String key, String parameter) throws DataNotAvailableError;

}
