package com.rjil.rms.ui.metadata.error;

/**
 * Custom Error "Data Duplicate"
 * 
 * @author Kiran.Jangid
 *
 */

public class DuplicateElementError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Data Already Available, Can't Add Duplicate Element";
	}

}
