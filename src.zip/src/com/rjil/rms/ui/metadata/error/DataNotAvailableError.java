package com.rjil.rms.ui.metadata.error;

/**
 * Custom Error "Data Not Available"
 * 
 * @author Kiran.Jangid
 *
 */

public class DataNotAvailableError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Data Not Available";
	}

}
