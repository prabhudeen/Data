package com.rjil.rms.ui.metadata.error;

/**
 * Custom Error "Metadata Parsing Exception"
 * 
 * @author Kiran.Jangid
 *
 */

public class MetadataParsingError extends Throwable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Metadata Parsing Exception";
	}

}
