package com.rjil.rms.registration;

/**
 * 
 * @author kiran.jangid
 *
 */

@FunctionalInterface
public interface Observer {

	/**
	 * 
	 * @param query
	 * @param httpBody
	 * @param method
	 * @param serverState
	 */
	
	public void update(String query,String httpBody,String method,String serverState);
}
