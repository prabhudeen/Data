package com.rjil.rms.registration;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMSObserver implements Observer {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void update(String query, String httpBody, String method, String serverState) {

		final String methodName = "update";
		if ("200".equals(serverState)) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Registered ... ");
		} else {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"Not Registered ... ");
		}

	}

}
