package com.rjil.rms.registration;

/**
 * 
 * Observer interface to add, remove observer
 * 
 * @author kiran.jangid
 *
 */

public interface ObservableIntf {

	/**
	 * to add observer
	 * 
	 * @param o
	 */

	public void addObserver(Observer o);

	/**
	 * to add observer
	 * 
	 * @param o
	 */

	public void deleteObserver(Observer o);

	/**
	 * to delete observer
	 */

	public void deleteObservers();

	/**
	 * 
	 * to notify observer
	 * 
	 * @param reason
	 * @param httpBody
	 * @param method
	 * @param serverState
	 */

	public void notifyObservers(String reason, String httpBody, String method, String serverState);

	/**
	 * to notify observer
	 * 
	 * @param o
	 * @param reason
	 * @param httpBody
	 * @param method
	 * @param serverState
	 */

	public void notifyObserver(Observer o, String reason, String httpBody, String method, String serverState);

	/**
	 * Check Observer presence
	 * 
	 * @param o
	 * @return
	 */

	public boolean contains(Observer o);

}
