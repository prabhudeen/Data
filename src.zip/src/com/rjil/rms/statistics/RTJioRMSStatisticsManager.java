package com.rjil.rms.statistics;

import java.io.File;
import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import com.jio.telco.framework.pool.PoolingManager;
import com.rjil.rms.es.erm.RMRERMPojo;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Manager class for statistics of the application
 * 
 * @author arun.dewna
 *
 */
public class RTJioRMSStatisticsManager implements RTJioRMSStatisticsManagerMBean {

	private static final int STR_FORMAT_LEN = 40;

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	
	/**
	 * start the statistics manager mbean
	 * 
	 * @throws Exception
	 */
	public void startService() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "startService",
				"starting the service");
		try {
			MBeanServer server = ManagementFactory.getPlatformMBeanServer();
			ObjectName adapterName = new ObjectName(
					RTJioRMSConstants.MBEAN_NAME_STATISTICS);
			server.registerMBean(this, adapterName);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"start", "Exception in starting the Mbean ", e);
		}
	}

	/**
	 * stops the statistics manager mbean
	 */
	public void stop() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "stop",
				"stopping the service");
		try {
			ManagementFactory.getPlatformMBeanServer().unregisterMBean(
					new ObjectName(RTJioRMSConstants.MBEAN_NAME_STATISTICS));
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"stop", "Exception in stopping the Mbean ", e);
		}
	}

	@Override
	public boolean dumpHealthStats() {
		return false;
	}

	@Override
	public String fetchModulesStatusDescription() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "fetchModulesStatusDescription",
				"fetching Modules Status Description");
		StringBuilder desc = new StringBuilder();
		desc.append("################################################\n");
		desc.append(format("ERM Reachability"))
				.append(RtJioRMSCacheManager.getInstance()
						.getErmManager().isElbAvailable())
				.append("\n");
		desc.append(format("OAM Registration"))
				.append(RtJioRMSCacheManager.getInstance()
						.isOAMRegistered())
				.append("\n");
		desc.append(format("Jetty Server Initialization : "))
				.append(RtJioRMSCacheManager.getInstance()
						.isJettyInitialized()).append("\n");
		desc.append(format("ES Database Connection"))
				.append(RtJioRMSCacheManager.getInstance()
						.isEsDbConnected()).append("\n");
		desc.append("################################################\n");
		return desc.toString();
	}

	@Override
	public boolean ftpLogFiles() {
		return false;
	}

	@Override
	public void deleteLogFiles() {
		
		final String methodName = "";
		
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
				"delete Log Files");
		File folder = new File("." + File.separator + ".." + File.separator
				+ "logs");
		File[] filesList = folder.listFiles();
		if (filesList == null) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"No log files to delete");
			return;
		}
		// delete the backup logs
		for (File file : filesList) {
			if (file.getName().contains(".log.") && file.delete())
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
						"No log files to delete");
		}
	}

	@Override
	public String fetchThreadPoolInfo() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "fetchThreadPoolInfo",
				"fetching Thread Pool Info");
		return RtJioRMSCacheManager.getInstance().getThreadPoolExecutor()
				.getThreadPoolInfo();
	}

	@Override
	public String fetchErmInfo() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "fetchErmInfo",
				"fetching ERM Info");
		RMRERMPojo edgeLbPojo = RtJioRMSCacheManager.getInstance()
				.getErmManager().getERMPojo();
		if (edgeLbPojo == null)
			return "";
		
		StringBuilder sbr = new StringBuilder();
		sbr.append("------------------------------------------\n");
		sbr.append("Name    : RMR ERM Info \n IP : ");
		sbr.append(edgeLbPojo.getIp());
		sbr.append("\n Port      : ");
		sbr.append(edgeLbPojo.getPort());
		sbr.append("\n------------------------------------------\n");
		return sbr.toString();
	}

	@Override
	public String fetchElbInfo() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "fetchElbInfo",
				"fetching ELB Info");
		StringBuilder sbr = new StringBuilder();
		sbr.append("------------------------------------------\n");
		sbr.append("Name    : RMR ELB Info : ");
		for(String id:RtJioRMSCacheManager.getInstance().getElbComponentIds()){
			sbr.append("\n ID      : "+id);
		}
		sbr.append("\n------------------------------------------\n");
		return sbr.toString();
	}

	@Override
	public String fetchPoolingManagerInfo() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "fetchPoolingManagerInfo",
				"fetching Pooling manager Info");
		return PoolingManager.getPoolingManager().getPoolStatistics();
	}

	/**
	 * @return the micro-service up time
	 */
	public String getMSUpTime() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "getMSUpTime",
				"fetching microservice uptime");
		return RtJioRMSCacheManager.getInstance().getMSUpTime();
	}

	/**
	 * @return process ID of the running JVM
	 */
	public int getProcessId() {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "getProcessId",
				"fetching process id");
		return RtJioRMSCacheManager.getInstance().getProcessId();
	}

	private String format(String strKeyConstant) {
		return String.format(strKeyConstant + "%"
				+ (STR_FORMAT_LEN - strKeyConstant.length()) + "s", "=   ");
	}
}