package com.rjil.rms.cli;

import java.util.HashMap;

import com.rjil.rms.cli.commands.RTJioRMRApplicationInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRClearAlarmCommand;
import com.rjil.rms.cli.commands.RTJioRMRDeRegisterOAMCommand;
import com.rjil.rms.cli.commands.RTJioRMRDraftInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRDraftStatusCommand;
import com.rjil.rms.cli.commands.RTJioRMRElbInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRErmInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRForceRegisterOAMCommand;
import com.rjil.rms.cli.commands.RTJioRMRGetAlarmsCommand;
import com.rjil.rms.cli.commands.RTJioRMRGetCountersCommand;
import com.rjil.rms.cli.commands.RTJioRMRGetModStatCommand;
import com.rjil.rms.cli.commands.RTJioRMRGetParamCommand;
import com.rjil.rms.cli.commands.RTJioRMRGetParamsCommand;
import com.rjil.rms.cli.commands.RTJioRMRPoolInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRReloadMetadataCommand;
import com.rjil.rms.cli.commands.RTJioRMRReregisterOAMCommand;
import com.rjil.rms.cli.commands.RTJioRMRSetParamCommand;
import com.rjil.rms.cli.commands.RTJioRMRThreadInfoCommand;
import com.rjil.rms.cli.commands.RTJioRMRsetMetadataCommand;

/**
 * Enumeration for all the commands used in CLI application
 * 
 * @author arun.dewna
 *
 */
public enum RTJioRMRCliCommandEnum {

	GET_PARAM("getparam", new RTJioRMRGetParamCommand()),

	GET_PARAMS("getparams", new RTJioRMRGetParamsCommand()),

	SET_PARAM("setparam", new RTJioRMRSetParamCommand()),

	GET_ALARMS("getalarms", new RTJioRMRGetAlarmsCommand()),

	CLEAR_ALARM("clearalarm", new RTJioRMRClearAlarmCommand()),

	GET_COUNTERS("getcounters", new RTJioRMRGetCountersCommand()),

	//RESET_COUNTERS("resetcounters", new RTJioRMRResetCountersCommand()),

	GET_MOD_STAT("getmodstat", new RTJioRMRGetModStatCommand()),

	APP_INFO("appinfo", new RTJioRMRApplicationInfoCommand()),

	ERM_INFO("erminfo", new RTJioRMRErmInfoCommand()),

	ELB_INFO("elbinfo", new RTJioRMRElbInfoCommand()),

	THREAD_INFO("threadinfo", new RTJioRMRThreadInfoCommand()),

	POOL_INFO("poolinfo", new RTJioRMRPoolInfoCommand()),
	
	RE_REGISTER_TO_OAM("reRegisterOAM", new RTJioRMRReregisterOAMCommand()),
	
	DE_REGISTER_TO_OAM("deRegisterOAM", new RTJioRMRDeRegisterOAMCommand()),
	
	GET_DRAFT_INFO("getdraftinfo", new RTJioRMRDraftInfoCommand()),
	
	GET_DRAFT_STATUS("getvnfstatus", new RTJioRMRDraftStatusCommand()),
	
	RELOAD_METADATA("loadmetadata", new RTJioRMRReloadMetadataCommand()),
	
	SET_METADATA("setmetadata", new RTJioRMRsetMetadataCommand()),
	
	FORCEFUL_REGISTRATION("doForcefulReregistration", new RTJioRMRForceRegisterOAMCommand());

	private String commandName;
	private RTJioRMRAbstractCliCommand command;
	private static final HashMap<String, RTJioRMRCliCommandEnum> commandEnumMap = new HashMap<>();

	static {
		for (RTJioRMRCliCommandEnum commandEnum : RTJioRMRCliCommandEnum.values()) {
			commandEnumMap.put(commandEnum.getCommandName(), commandEnum);
			commandEnum.command.setCommandName(commandEnum.commandName);
		}
	}

	private RTJioRMRCliCommandEnum(String commandName, RTJioRMRAbstractCliCommand command) {
		this.commandName = commandName;
		this.command = command;
	}

	/**
	 * executes a CLI command and return its output
	 * 
	 * @param jsonObject
	 *            the input JSON object
	 * @return the output of command (if applicable)
	 */
	public String execute(RMRCLIPojo cliData) {
		return this.command.execute(cliData);
	}

	String getCommandName() {
		return commandName;
	}

	RTJioRMRAbstractCliCommand getCommand() {
		return command;
	}

	/**
	 * returns the enumeration instance from the command name
	 * 
	 * @param command
	 *            name of the command
	 * @return the enumeration instance
	 */
	public static final RTJioRMRCliCommandEnum getEnumFromCommandName(String command) {
		return commandEnumMap.get(command);
	}
}
