package com.rjil.rms.cli;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Abstract implementation of all the CLI commands
 * 
 * @author arun.dewna
 *
 */
public abstract class RTJioRMRAbstractCliCommand {

	protected LoggerWriter loggerWriter = LoggerWriter.getInstance();

	protected void printInvalidOptionValueMessage(String optionName, String optionValue) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(),
				this.getClass().getEnclosingClass().getName(), this.getClass().getEnclosingMethod().getName(),
				"InvalidOptionValue from CLI " + "optionName : " + optionName + "   " + "optionValue : " + optionValue);
	}

	protected void printJsonParsingException(Exception e) {
		loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
				e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(),
				"JsonParsingException from CLI ", e);
	}

	protected void doNothing(Exception e) {
		loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
				e.getStackTrace()[0].getClassName(), e.getStackTrace()[0].getMethodName(), "doNothing ", e);
	}

	/**
	 * executes the CLI command and returns its output
	 * 
	 * @param cliData
	 *            input JSON object
	 * @return the output of the command (if applicable)
	 */
	public abstract String execute(RMRCLIPojo cliData);

	void setCommandName(String commandName) {
	}
}
