package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;

import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.util.RMRDataValidationType;

/**
 * Command to update a parameter value from CLI application
 */
public class RTJioRMRSetParamCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		try {
			String paramName = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.NAME.getName());
			RtJioRMSConfigParamEnum configEnum = RtJioRMSConfigParamEnum.getEnumFromCliName(paramName);
			if (configEnum == null || configEnum.isReadOnly()) {
				printInvalidOptionValueMessage(RTJioRMRCliOptionEnum.NAME.getName(), paramName);
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid value '" + paramName + "' for option '" + RTJioRMRCliOptionEnum.NAME.getName(),
						HttpStatus.SC_BAD_REQUEST);
			}
			String paramValue = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.VALUE.getName());
			if (!RMRDataValidationType.getEnumFromName(configEnum.getValidator()).validate(paramValue, configEnum)) {
				printInvalidOptionValueMessage(RTJioRMRCliOptionEnum.VALUE.getName(), paramValue);
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid value '" + paramValue + "' for option '" + RTJioRMRCliOptionEnum.VALUE.getName(),
						HttpStatus.SC_BAD_REQUEST);
			}
			if(configEnum.setValue(paramValue, true, false)) {
			if(paramName.equals("totalLogFileSize")) {
				ResourceBuilder.logger().setArchiveRetentionPolicyAccumulatedFileSize(Integer.parseInt(paramValue)).updateArchiveRetentionPolicyAccumulatedFileSize();
			}
			
			if(paramName.equals("expireTimeForLogs")) {
				ResourceBuilder.logger().setArchiveRetentionPolicyAgeInDays(Integer.parseInt(paramValue)).updateArchiveRetentionPolicyAge();
			}
			return paramName+" successfully updated to "+paramValue;
			
			}else {
				return paramName+" not able to update";
			}
			
		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Error parsing JSON", HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}
}
