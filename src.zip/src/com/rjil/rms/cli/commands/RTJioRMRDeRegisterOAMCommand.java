package com.rjil.rms.cli.commands;

import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Command to de-register with OAM
 */
public class RTJioRMRDeRegisterOAMCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		String msg;
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		if (RtJioRMSCacheManager.getInstance().deRegisterOAM()) {
			msg = "OAM has been de-registred successfully.";
		} else {
			msg = "OAM de-registration failed.";
		}
		return msg;
	}
}
