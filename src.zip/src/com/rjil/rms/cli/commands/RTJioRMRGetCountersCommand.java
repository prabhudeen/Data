package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Command to get performance counters of a given category or all
 */
public class RTJioRMRGetCountersCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		String category = null;
		try {
			category = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.CATEGORY.getName());
			String output = RtJioRMSCacheManager.getInstance()
					.getCounterManager()
					.fetchCounterDescriptionForSpecificType(category);
			if (output == null) {
				printInvalidOptionValueMessage(
						RTJioRMRCliOptionEnum.CATEGORY.getName(), category);
				throw new RTJioRMRCliCommandExecutionException("Invalid value '"
						+ category + "' for option '"
						+ RTJioRMRCliOptionEnum.CATEGORY.getName(),
						HttpStatus.SC_BAD_REQUEST);
			}
			return output;
		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException(
					"Internal server error:JSON parsing",
					HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}
}
