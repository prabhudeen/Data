package com.rjil.rms.cli.commands;

import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Command to get the information about the all the threads created by the
 * application
 */
public class RTJioRMRThreadInfoCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		return RtJioRMSCacheManager.getInstance().getStatisticsManager()
				.fetchThreadPoolInfo();
	}
}
