package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;
import org.json.JSONObject;

import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.draft.DraftOperationConstantsEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Implementing command to get draft information
 * 
 * @author kiran.jangid
 *
 */

public class RTJioRMRDraftStatusCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		String status = null;
		String operation = null;
		try {

			status = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.STATUS.getName());
			operation = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.MODULE.getName());

			JSONObject obj = new JSONObject();

			if (status != null && !"all".equalsIgnoreCase(status)) {
				obj.put(DraftOperationConstantsEnum.STATUS.getValue(),
						EsManager.getInstance().getDraftOperationImpl().getDraftStatusInfo(status, operation));
			} else {
				JSONObject obj1 = new JSONObject();
				obj1.put(DraftOperationConstantsEnum.COMPLETED.getValue(),
						EsManager.getInstance().getDraftOperationImpl()
								.getDraftStatusInfo(DraftOperationConstantsEnum.COMPLETED.getValue(), operation));
				obj1.put(DraftOperationConstantsEnum.DRAFT.getValue(), EsManager.getInstance().getDraftOperationImpl()
						.getDraftStatusInfo(DraftOperationConstantsEnum.DRAFT.getValue(), operation));
				obj.put(DraftOperationConstantsEnum.STATUS.getValue(), obj1);
			}

			return obj.toString();

		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Internal server error:JSON parsing",
					HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}

	}

}
