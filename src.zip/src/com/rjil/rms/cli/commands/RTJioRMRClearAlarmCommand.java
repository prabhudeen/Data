package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;
import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.management.alarm.AlarmManager;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Command to clear an alarm by its identifier
 */
public class RTJioRMRClearAlarmCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		try {
			String identifier = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.ID.getName());
			if (AlarmManager.getInstance().getAlarm(identifier) == null) {
				printInvalidOptionValueMessage(RTJioRMRCliOptionEnum.ID.getName(), identifier);
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid value '" + identifier + "' for option '" + RTJioRMRCliOptionEnum.ID.getName(),
						HttpStatus.SC_BAD_REQUEST);
			}
			if (!OamClientManager.getOamClientForAlarm().clearAlarmByName(identifier, true))
				throw new RTJioRMRCliCommandExecutionException("Internal server error:clear alarm",
						HttpStatus.SC_INTERNAL_SERVER_ERROR);
			return null;
		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Internal server error:JSON parsing",
					HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}
}
