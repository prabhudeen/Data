package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;

import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.ui.metadata.MetadataManager;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RTJioRMRReloadMetadataCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		try {

			if (!MetadataManager.getInstance().reloadMetadata()) {
				throw new RTJioRMRCliCommandExecutionException("File Is not available or Corrupted",
						HttpStatus.SC_INTERNAL_SERVER_ERROR);
			}

			return "Successfully Executed !!";

		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Error parsing JSON", HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}

}
