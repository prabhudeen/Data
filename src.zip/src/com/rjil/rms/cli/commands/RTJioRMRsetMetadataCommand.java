package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;

import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.ui.metadata.MetadataManager;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RTJioRMRsetMetadataCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		try {

			String param = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.PARAM.getName());

			String key = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.KEY.getName());

			String value = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.VALUE.getName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
					"executing the cli command for options : param = " + param + " : key = " + key + " : value = "
							+ value);

			if (param == null || "".equals(param.trim())) {
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid param '" + param + RTJioRMRCliOptionEnum.PARAM.getName(), HttpStatus.SC_BAD_REQUEST);
			}

			if (key == null || "".equals(key.trim())) {
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid key '" + key + RTJioRMRCliOptionEnum.KEY.getName(), HttpStatus.SC_BAD_REQUEST);
			}

			if (value == null || "".equals(value.trim())) {
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid value '" + value + RTJioRMRCliOptionEnum.VALUE.getName(), HttpStatus.SC_BAD_REQUEST);
			}

			MetadataManager.getInstance().getOperation().setMetadataKeyValue(param, key, value);

			return "Successfully Executed !!";
		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Error parsing JSON", HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}

}
