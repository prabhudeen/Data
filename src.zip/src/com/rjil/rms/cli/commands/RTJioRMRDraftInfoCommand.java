package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Implementing command to get draft information
 * 
 * @author kiran.jangid
 *
 */

public class RTJioRMRDraftInfoCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");

		String name = null;
		String status = null;
		String module = null;
		try {

			name = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.NAME.getName());
			status = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.STATUS.getName());
			module = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.MODULE.getName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
					"executing the cli command : name = " + name + " | status = " + status + " | module = " + module);

			StringBuilder strBuild = new StringBuilder();

			if (name == null || name.isEmpty() || "all".equalsIgnoreCase(name) || "".equalsIgnoreCase(name)) {

				for (Object item : EsManager.getInstance().getDraftOperationImpl().getAllDraftInfo(status, module)) {
					strBuild.append(item.toString());
				}

			} else {
				String identifier = name + "_" + module;
				strBuild.append(EsManager.getInstance().getDraftOperationImpl().getDraftInfo(identifier).toString());
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
					"Response to CLI : " + strBuild.toString());

			return strBuild.toString();

		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Internal server error",
					HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}

	}

}
