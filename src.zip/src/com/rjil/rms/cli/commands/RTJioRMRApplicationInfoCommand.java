package com.rjil.rms.cli.commands;

import com.atom.OAM.Client.Management.OamClientManager;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Command to get the release specific information of the application
 */
public class RTJioRMRApplicationInfoCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		StringBuilder sbr = new StringBuilder();
		sbr.append("------------------------------------------\n");
		sbr.append("Name    : RMR Manager\nVersion : ");
		sbr.append(OamClientManager.getInstance().getOAMClientParam(
				"productversion"));
		sbr.append("\nID      : ");
		sbr.append(RtJioRMSCacheManager.getInstance().getMicroserviceId());
		sbr.append("\nHostName: ");
		sbr.append(RtJioRMSCacheManager.getInstance().getHostName());
		sbr.append("\nIP      : ");
		sbr.append(RtJioRMSConfigParamEnum.HTTP_HOST_IP_FOR_RMS.getStringValue());
		sbr.append("\nPort    : ");
		sbr.append(RtJioRMSConfigParamEnum.HTTP_PORT_FOR_RMS.getStringValue());
		sbr.append("\n------------------------------------------\n");
		return sbr.toString();
	}
}
