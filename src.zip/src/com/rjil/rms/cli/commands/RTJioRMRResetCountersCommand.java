package com.rjil.rms.cli.commands;

import org.apache.http.HttpStatus;
import com.rjil.rms.cli.RMRCLIPojo;
import com.rjil.rms.cli.RTJioRMRAbstractCliCommand;
import com.rjil.rms.cli.RTJioRMRCliCommandExecutionException;
import com.rjil.rms.cli.RTJioRMRCliOptionEnum;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Command to reset all performance counters or by category
 */
public class RTJioRMRResetCountersCommand extends RTJioRMRAbstractCliCommand {

	@Override
	public String execute(RMRCLIPojo cliData) {
		String category = null;
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "execute",
				"executing the cli command ");
		try {
			category = cliData.getRequest().getHeader(RTJioRMRCliOptionEnum.CATEGORY.getName());
			if (RtJioRMSCacheManager.getInstance().getCounterManager().resetCounterForSpecificType(category,
					true) != 0) {
				printInvalidOptionValueMessage(RTJioRMRCliOptionEnum.CATEGORY.getName(), category);
				throw new RTJioRMRCliCommandExecutionException(
						"Invalid value '" + category + "' for option '" + RTJioRMRCliOptionEnum.CATEGORY.getName(),
						HttpStatus.SC_BAD_REQUEST);
			}
			return null;
		} catch (Exception e) {
			printJsonParsingException(e);
			throw new RTJioRMRCliCommandExecutionException("Internal server error:JSON parsing",
					HttpStatus.SC_INTERNAL_SERVER_ERROR);
		}
	}
}
