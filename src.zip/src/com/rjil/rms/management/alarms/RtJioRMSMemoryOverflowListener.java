package com.rjil.rms.management.alarms;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rjil.management.alarm.ApplicationMemoryUsageListener;

/**
 * Listener to listen for memory overflow events
 */
public class RtJioRMSMemoryOverflowListener implements ApplicationMemoryUsageListener {

	private static final Logger logger = LogManager.getLogger(RtJioRMSMemoryOverflowListener.class);

	@Override
	public void memoryUsage(String alarmName, long used, long max, long percentage) {
		logger.info("Memory [used=" + used + " bytes, max=" + max + " bytes, percentage=" + percentage + " %]");
	}
}
