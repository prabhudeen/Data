package com.rjil.rms.management.alarms;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rjil.management.alarm.AlarmLoggingCallbackHandler;

/**
 * Listener to get all the logging callbacks from alarm manager
 */
public class RtJioAlarmLoggingListener implements AlarmLoggingCallbackHandler {

	private static final Logger logger = LogManager.getLogger(RtJioAlarmLoggingListener.class);

	@Override
	public void debug(String arg0, String arg1) {
		logger.debug((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

	@Override
	public void error(String arg0, String arg1) {
		logger.error((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

	@Override
	public void fatal(String arg0, String arg1) {
		logger.fatal((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

	@Override
	public void info(String arg0, String arg1) {
		logger.info((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

	@Override
	public void trace(String arg0, String arg1) {
		logger.trace((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

	@Override
	public void warn(String arg0, String arg1) {
		logger.warn((arg1 != null) ? arg1 + " > " + arg0 : arg0);
	}

}
