package com.rjil.rms.management.alarms;

/**
 * Interface listing the names of all the alarms
 */
public class RtJioRMSAlarmNameIntf {

	public static final String RMS_STARTUP_SUCCESS = "RMS_STARTUP_SUCCESS";

	public static final String RMS_DATABASE_CONNECTION_SUCCESS = "RMS_DATABASE_CONNECTION_SUCCESS";

	public static final String RMS_DATABASE_CONNECTION_FAILURE = "RMS_DATABASE_CONNECTION_FAILURE";

	public static final String RMS_LOG_FTP_FAILURE = "RMS_LOG_FTP_FAILURE";

	public static final String RMS_LOG_FTP_SUCCESS = "RMS_LOG_FTP_SUCCESS";

	public static final String RMS_OAM_CONNECTION_SUCCESS = "RMS_OAM_CONNECTION_SUCCESS";

	public static final String RMS_OAM_CONNECTION_FAILURE = "RMS_OAM_CONNECTION_FAILURE";

	public static final String RMS_FCAPS_DIRECTORY_ERROR = "RMS_FCAPS_DIRECTORY_ERROR";

	public static final String RMS_BINARY_PATH_ERROR = "RMS_BINARY_PATH_ERROR";

	public static final String RMS_DRAFT_INFO_INSERTION_FAILED_IN_DB = "RMS_DRAFT_INFO_INSERTION_FAILED_IN_DB";

	public static final String NO_SPACE_AVAILABLE_IN_SERVER = "NO_SPACE_AVAILABLE_IN_SERVER";

	// Introduced in v2.3

	public static final String FILE_NOT_FOUND_DURING_UPDATING_METADATA_FILE = "FILE_NOT_FOUND_DURING_UPDATING_METADATA_FILE";

	public static final String FILE_IO_OPERATION_FAILURE_DURING_UPDATING_METADATA_FILE = "FILE_IO_OPERATION_FAILURE_DURING_UPDATING_METADATA_FILE";

	public static final String ES_DATA_READ_FAILURE_DURING_VNF_IMAGE_READ = "ES_DATA_READ_FAILURE_DURING_VNF_IMAGE_READ";

	private RtJioRMSAlarmNameIntf() {

	}
}
