package com.rjil.rms.management.counters;

import java.util.HashMap;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Enumeration for all the categories of the performance counters
 */
public enum RtJioRMSCounterCategoryEnum {

	RMR_ES_CLIENT("esclient", RtJioRMSCounterNameEnum.CNTR_ES_INDEX_CREATION_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ES_INDEX_CREATION_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_ES_INDEX_CREATION_FAILURE, RtJioRMSCounterNameEnum.CNTR_ES_DOCUMENTS_CREATED,
			RtJioRMSCounterNameEnum.CNTR_ES_DOCUMENTS_CREATION_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_ES_DOCUMENTS_CREATION_FAILURE, RtJioRMSCounterNameEnum.CNTR_ES_SEARCH_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ES_SEARCH_SUCCESS, RtJioRMSCounterNameEnum.CNTR_ES_SEARCH_FAILURE),

	RMR_VNFC_RELEASE("vnfcImage", RtJioRMSCounterNameEnum.CNTR_RMR_VNFC_BINARY_DOWNLOAD_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_VNFC_BINARY_DOWNLOAD_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_VNFC_BINARY_DOWNLOAD_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_VNFC_BINARY_DOWNLOAD_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_VNFC_IMAGE_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_VNFC_IMAGE_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_VNFC_IMAGE_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_VNFC_IMAGE_INVALID),

	RMR_FCAPS("fcaps", RtJioRMSCounterNameEnum.CNTR_RMR_ALARM_DICTIONARY_DOWNLOAD_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_ALARM_DICTIONARY_DOWNLOAD_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_ALARM_DICTIONARY_DOWNLOAD_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_ALARM_DICTIONARY_DOWNLOAD_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_COUNTER_DICTIONARY_DOWNLOAD_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_COUNTER_DICTIONARY_DOWNLOAD_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_COUNTER_DICTIONARY_DOWNLOAD_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_COUNTER_DICTIONARY_DOWNLOAD_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_CONFIG_DICTIONARY_DOWNLOAD_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_CONFIG_DICTIONARY_DOWNLOAD_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_CONFIG_DICTIONARY_DOWNLOAD_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_CONFIG_DICTIONARY_DOWNLOAD_INVALID),

	RMR_ERM("ermclient", RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_ACK_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_ACK_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_ACK_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_RECEIVE,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_SUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_SUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_UNSUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESSFUL_SUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_UNSUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESSFUL_UNSUBSCRIBE_REQUESTS,
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_TOTAL_EVENT_ACK_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_SUCCESS_EVENT_ACK_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_INVALID_EVENT_ACK_REQUESTS_SEND,
			RtJioRMSCounterNameEnum.CNTR_ERM_FAILED_EVENT_ACK_REQUESTS_SEND),

	RMR_DRAFT("draft", RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_INVALID),

	RMR_CNF_DRAFT("cnfdraft", RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_CNF_DRAFT_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_CNF_DRAFT_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_CNF_DRAFT_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_CNF_DRAFT_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_INFO_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_INFO_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_INFO_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_INFO_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_STATUS_INFO_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_STATUS_INFO_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_STATUS_INFO_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_CNF_DRAFT_STATUS_INFO_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_CNF_DRAFT_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_CNF_DRAFT_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_CNF_DRAFT_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_CNF_DRAFT_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_CNF_DRAFT_STATUS_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_CNF_DRAFT_STATUS_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_CNF_DRAFT_STATUS_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_CNF_DRAFT_STATUS_INVALID),

	RMR_NOTIFY("notify", RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_VNF_DELETION_INVALID,
	        RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_REQUEST,
	        RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_INVALID,
	        RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_FAILURE,
	        RtJioRMSCounterNameEnum.CNTR_RMR_NOTIFY_CNF_DELETION_SUCCESS),

	RMR_METADATA("metadata", RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_ADD_METADATA_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_MODIFY_METADATA_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_METADATA_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_VIEW_METADATA_INVALID,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_FAILURE,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_REQUEST,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_SUCCESS,
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_METADATA_INVALID);

	private RtJioRMSCounterNameEnum[] counterNames;
	private String cliName;
	private static HashMap<String, RtJioRMSCounterCategoryEnum> cliNameVsEnumMap = new HashMap<>();
	private static final int FORMAT_BORDER = 55;

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	static {
		RtJioRMSCounterCategoryEnum[] counterCategories = RtJioRMSCounterCategoryEnum.values();
		for (RtJioRMSCounterCategoryEnum counterCategory : counterCategories)
			cliNameVsEnumMap.put(counterCategory.getCliName(), counterCategory);
	}

	private RtJioRMSCounterCategoryEnum(String cliName, RtJioRMSCounterNameEnum... counterNames) {
		this.cliName = cliName;
		this.counterNames = counterNames;
	}

	/**
	 * @return all the counters in this category in a map with key as counter
	 *         name and value as its current value
	 */
	HashMap<String, Long> getCounterMap() {
		HashMap<String, Long> cmap = new HashMap<>();
		for (RtJioRMSCounterNameEnum counterNameEnum : this.counterNames)
			cmap.put(counterNameEnum.name(), counterNameEnum.getValue());
		return cmap;
	}

	/**
	 * reset all the performance counters that belongs to this category
	 */
	void reset() {
		for (RtJioRMSCounterNameEnum counterName : this.counterNames)
			counterName.reset();
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"generateFolderStructure",
				"All performance counters of category '" + this.name() + "' have been reset");
	}

	/**
	 * @return the name to be used as a CLI argument to fetch/reset counters by
	 *         category
	 */
	String getCliName() {
		return cliName;
	}

	/**
	 * returns the enumeration instance from the name of the CLI argument
	 * 
	 * @param arg
	 *            name of the CLI argument
	 * @return the enumeration instance from the name of the CLI argument
	 */
	static RtJioRMSCounterCategoryEnum getEnumFromCliArg(String arg) {
		return cliNameVsEnumMap.get(arg);
	}

	/**
	 * @return return the counters in a readable format to be displayed in CLI
	 */
	StringBuilder formatCounters() {
		StringBuilder counterDump = new StringBuilder();
		String s;
		String format;
		String key;
		for (RtJioRMSCounterNameEnum counterNameEnum : this.counterNames) {
			key = counterNameEnum.name();
			format = key + "%" + (FORMAT_BORDER - key.length()) + "s";
			s = String.format(format, "=   ");
			counterDump.append(s + counterNameEnum.getValue() + "\n");
		}
		counterDump.insert(0, "\n    List of Counters of type = " + this.cliName + "\n")
				.append("######################################\n");
		return counterDump;
	}
}
