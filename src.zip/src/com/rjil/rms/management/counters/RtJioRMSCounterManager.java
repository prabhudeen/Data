package com.rjil.rms.management.counters;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.management.ManagementFactory;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import com.atom.OAM.Client.ems.pojo.config.Param;
import com.googlecode.jcsv.CSVStrategy;
import com.googlecode.jcsv.writer.CSVEntryConverter;
import com.googlecode.jcsv.writer.CSVWriter;
import com.googlecode.jcsv.writer.internal.CSVWriterBuilder;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.pojo.counters.Counter;
import com.rjil.rms.rest.pojo.counters.CounterCSV;
import com.rjil.rms.rest.pojo.counters.Counters;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Manager class for performance counters
 */
public class RtJioRMSCounterManager implements RtJioRMSCounterManagerMBean {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private CSVCounterEntryConverter csConverter = new CSVCounterEntryConverter();
	private Serializer serializer = new Persister();
	private TimerTask counterTimerTask = null;
	private long counterPurgeDuration = -1;
	private Format formatter = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

	/**
	 * start and register counter MBean.
	 */
	public void startService() {
		try {
			MBeanServer server = ManagementFactory.getPlatformMBeanServer();
			// register the jmx html adapter
			ObjectName adapterName = new ObjectName(RTJioRMSConstants.MBEAN_NAME_COUNTER);
			server.registerMBean(this, adapterName);
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
					"startService", "Counter manager started successfully");
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"startService", "Error registering the MBean to the JVM MBean server", e);
		}
	}

	/**
	 * method to stop counter service
	 */
	public void stopService() {

		final String methodName = "stopService";

		try {
			ManagementFactory.getPlatformMBeanServer()
					.unregisterMBean(new ObjectName(RTJioRMSConstants.MBEAN_NAME_COUNTER));
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"Fault Manager configuration manager has been stopped");
		} catch (InstanceNotFoundException | MBeanRegistrationException | MalformedObjectNameException
				| NullPointerException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error un-registering the MBean..instance does not exist\n", e);
		}
	}

	@Override
	public int resetCounterForSpecificType(String cntrType, boolean sentByCli) {

		final String methodName = "resetCounterForSpecificType";

		if (RTJioRMSConstants.BULK.equals(cntrType)) {
			RtJioRMSCounterCategoryEnum[] counterCategories = RtJioRMSCounterCategoryEnum.values();
			for (RtJioRMSCounterCategoryEnum counterCategory : counterCategories)
				counterCategory.reset();
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"All performance counters have been reset successfully");
			return 0;
		}
		RtJioRMSCounterCategoryEnum counterCategory = null;
		if (sentByCli)
			counterCategory = RtJioRMSCounterCategoryEnum.getEnumFromCliArg(cntrType);
		else {
			try {
				counterCategory = RtJioRMSCounterCategoryEnum.valueOf(cntrType);
			} catch (IllegalArgumentException e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
						methodName, "Error un-registering the MBean, null pointer exception\n", e);
			}
		}
		if (counterCategory == null) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Counter category '" + cntrType + "' is unknown : ");
			return -1;
		}
		counterCategory.reset();
		return 0;
	}

	@Override
	public String fetchAllCounterAsXml() {
		Counters counterList = new Counters();
		Counter counter = new Counter();
		counter.setCounterType(RtJioRMSCacheManager.getInstance().getMicroserviceId());
		RtJioRMSCounterNameEnum[] counterNames = RtJioRMSCounterNameEnum.values();
		for (RtJioRMSCounterNameEnum counterName : counterNames)
			counter.addToParamList(new Param(counterName.name(), Long.toString(counterName.getValue())));
		counterList.addToCounterList(counter);
		StringWriter stringWriter = new StringWriter();
		try {
			this.serializer.write(counterList, stringWriter);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"fetchAllCounterAsXml", "Error fetch counter ", e);
			return null;
		}
		return stringWriter.toString();
	}

	@Override
	public String fetchCounterForSpecificTypeAsXml(String cntrType) {

		Counters counterList = new Counters();
		if (RTJioRMSConstants.BULK.equals(cntrType)) {
			RtJioRMSCounterCategoryEnum[] counterCategories = RtJioRMSCounterCategoryEnum.values();
			for (RtJioRMSCounterCategoryEnum counterCategory : counterCategories)
				counterList.addToCounterList(getCounter(counterCategory));
		} else {
			RtJioRMSCounterCategoryEnum counterCategory = RtJioRMSCounterCategoryEnum.valueOf(cntrType);
			counterList.addToCounterList(getCounter(counterCategory));
		}
		StringWriter stringWriter = new StringWriter();
		try {
			this.serializer.write(counterList, stringWriter);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"fetchCounterForSpecificTypeAsXml", "Error fetch counter ", e);
			return null;
		}
		return stringWriter.toString();
	}

	private Counter getCounter(RtJioRMSCounterCategoryEnum counterCategory) {
		Counter counter = new Counter();
		counter.setCounterType(counterCategory.name());
		Set<Map.Entry<String, Long>> set = counterCategory.getCounterMap().entrySet();
		for (Entry<String, Long> entry : set)
			counter.addToParamList(new Param(entry.getKey(), Long.toString(entry.getValue())));
		return counter;
	}

	@Override
	public String fetchAllCountersAsCSV() throws IOException {
		Writer writer = new StringWriter();
		CSVWriter<CounterCSV> csvWriter = new CSVWriterBuilder<CounterCSV>(writer).strategy(CSVStrategy.UK_DEFAULT)
				.entryConverter(this.csConverter).build();
		RtJioRMSCounterCategoryEnum[] counterCategories = RtJioRMSCounterCategoryEnum.values();
		CounterCSV cntrCsv;
		for (RtJioRMSCounterCategoryEnum counterCategory : counterCategories) {
			cntrCsv = new CounterCSV();
			Set<Entry<String, Long>> set = counterCategory.getCounterMap().entrySet();
			for (Entry<String, Long> entry : set)
				cntrCsv.addToCounterList(new CounterCSV(counterCategory.name(), entry.getKey(), entry.getValue()));
			csvWriter.writeAll(cntrCsv.getCounterList());
		}
		return RTJioRMSConstants.CSV_HEADER_COUNTERS + writer.toString();
	}

	private class CSVCounterEntryConverter implements CSVEntryConverter<CounterCSV> {
		@Override
		public String[] convertEntry(CounterCSV counter) {
			String[] cntrCsv = new String[3];
			cntrCsv[0] = counter.getCounterType();
			cntrCsv[1] = counter.getCounterName();
			cntrCsv[2] = String.valueOf(counter.getCount());
			return cntrCsv;
		}
	}

	@Override
	public String fetchCounterDescriptionForSpecificType(String cntrType) {
		if (RTJioRMSConstants.BULK.equals(cntrType)) {
			RtJioRMSCounterCategoryEnum[] counterCategories = RtJioRMSCounterCategoryEnum.values();
			StringBuilder counterDump = new StringBuilder();
			for (RtJioRMSCounterCategoryEnum counterCategory : counterCategories)
				counterDump.append(counterCategory.formatCounters());
			return counterDump.toString();
		}
		RtJioRMSCounterCategoryEnum counterCategory = RtJioRMSCounterCategoryEnum.getEnumFromCliArg(cntrType);
		if (counterCategory == null)
			return null;
		return counterCategory.formatCounters().toString();
	}

	@Override
	public void startCounterPurging(long duration) {
		Timer timer = new Timer();
		if (this.counterTimerTask != null) {
			this.counterTimerTask.cancel();
			this.counterTimerTask = null;
		}
		this.counterTimerTask = new RtJioRMSCounterTimerTask();
		this.counterPurgeDuration = duration;
		timer.schedule(this.counterTimerTask, duration * 1000, duration * 1000);
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"startCounterPurging", "Counter purge timer Started with duration = " + duration + " seconds");
	}

	@Override
	public void stopCounterPurging() {

		final String methodName = "stopCounterPurging";

		if (this.counterTimerTask != null) {
			this.counterTimerTask.cancel();
			this.counterTimerTask = null;
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Counter purging timer has been stopped");
		} else {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Counter purging timer is already stopped");
		}
		this.counterPurgeDuration = -1;
	}

	@Override
	public long getCounterPurgeDuration() {
		return counterPurgeDuration;
	}

	@Override
	public boolean dumpCounters() {
		try {

			File file = new File(RTJioRMSConstants.DUMP_PATH_COUNTERS);
			if (!file.exists())
				file.mkdir();
			// XML FILE
			String countersAsXML = this.fetchCounterForSpecificTypeAsXml(RTJioRMSConstants.BULK);
			String fileFormatXML = RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue()
					+ RTJioRMSConstants.DUMP_COUNTERS_FILE_PREFIX + RTJioRMSConstants.XML + formatter.format(new Date())
					+ RTJioRMSConstants.DUMP_FILE_EXTENSION_XML;
			FileWriter fileWriter1 = new FileWriter(
					RTJioRMSConstants.DUMP_PATH_COUNTERS + File.separator + fileFormatXML, false);
			fileWriter1.write(countersAsXML);
			fileWriter1.close();
			// CSV FILE
			String countersAsCSV = fetchAllCountersAsCSV();
			String fileFormatCSV = RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue()
					+ RTJioRMSConstants.DUMP_COUNTERS_FILE_PREFIX + RTJioRMSConstants.CSV + formatter.format(new Date())
					+ RTJioRMSConstants.DUMP_FILE_EXTENSION_CSV;
			FileWriter fileWriter2 = new FileWriter(
					RTJioRMSConstants.DUMP_PATH_COUNTERS + File.separator + fileFormatCSV, false);
			fileWriter2.write(countersAsCSV);
			fileWriter2.close();
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"dumpCounters", "Dump Counter Error ", e);
			return false;
		}
		return true;
	}
}
