package com.rjil.rms.management.counters;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimerTask;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Timer task to dump performance counters at regular basis
 */
public class RtJioRMSCounterTimerTask extends TimerTask {

	private static final Logger logger = LogManager.getLogger(RtJioRMSCounterTimerTask.class);
	private String fileName = "FMCounterPurgeTask";
	private String dirName = "../purge";

	@Override
	public void run() {
		File dir = new File(this.dirName);
		boolean success = false;
		if (!dir.exists())
			success = dir.mkdir();
		if (success && logger.isInfoEnabled())
			logger.info("Purge Directory Created");
		try (FileOutputStream fout = new FileOutputStream(new File(
				dirName + "/" + fileName + "-" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()))
				+ ".txt")) {
			String s = RtJioRMSCacheManager.getInstance().getCounterManager()
					.fetchCounterDescriptionForSpecificType(RTJioRMSConstants.BULK);
			fout.write(s.getBytes());
			if (logger.isInfoEnabled())
				logger.info("Purging of counters complete...");
		} catch (IOException e) {
			logger.error("Error in Timer task : " + e);
		}
	}
}
