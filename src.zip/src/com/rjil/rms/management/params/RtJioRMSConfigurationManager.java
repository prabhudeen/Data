package com.rjil.rms.management.params;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.management.ManagementFactory;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.XML;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import com.atom.OAM.Client.Management.OamClientManager;
import com.atom.OAM.Client.Management.OamClientRegistrationNotifier;
import com.atom.OAM.Client.ems.pojo.config.ComboValue;
import com.atom.OAM.Client.ems.pojo.config.ConfigParamCategory;
import com.atom.OAM.Client.ems.pojo.config.ConfigParamList;
import com.atom.OAM.Client.ems.pojo.config.Param;
import com.googlecode.jcsv.CSVStrategy;
import com.googlecode.jcsv.writer.CSVEntryConverter;
import com.googlecode.jcsv.writer.CSVWriter;
import com.googlecode.jcsv.writer.internal.CSVWriterBuilder;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.util.RTJioRMSConstants;

/**
 * Manager class for Configuration parameters
 */
public class RtJioRMSConfigurationManager implements RtJioRMSConfigurationManagerMBean {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private final Format formatter = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
	private Serializer serializer = new Persister();
	private CSVParamEntryConverter paramEntryConverter = new CSVParamEntryConverter();

	/**
	 * loads all the configurations and initialises the configuration manager
	 */
	public void start() {
		RtJioRMSCacheManager.getInstance().getExcelWorkbookLoader().loadConfigParams();
		startService();
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "start",
				"Fault Manager configuration manager has been initialized.");
	}

	/**
	 * start the configuration engine
	 * 
	 * @throws Exception
	 */
	private void startService() {
		try {
			MBeanServer server = ManagementFactory.getPlatformMBeanServer();
			ObjectName adapterName = new ObjectName(RTJioRMSConstants.MBEAN_NAME_CONFIG);
			server.registerMBean(this, adapterName);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"startService", "Error registering the MBean to the JVM MBean ", e);
		}
	}

	/**
	 * stops the configuration engine
	 */
	public void stop() {

		final String methodName = "stop";

		try {
			ManagementFactory.getPlatformMBeanServer()
					.unregisterMBean(new ObjectName(RTJioRMSConstants.MBEAN_NAME_CONFIG));
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					"Fault Manager configuration manager has been stopped");
		} catch (InstanceNotFoundException | MBeanRegistrationException | MalformedObjectNameException
				| NullPointerException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error un-registering the MBean..instance does not exist\n", e);
		}
	}

	@Override
	public boolean dumpConfigParams() {
		try {
			// XML FILE
			String paramsAsXML = this.fetchAllParamsAsXml();
			ConfigParamList configList = this.serializer.read(ConfigParamList.class, paramsAsXML);
			for (ConfigParamCategory configParamCategory : configList.getConfigParam()) {
				for (Param param : configParamCategory.getParamList()) {
					param.setComboValueList(null);
					param.setMaxRange(null);
					param.setMinRange(null);
					param.removeReadOnlyFlag();
					param.setValidator(null);
					param.setRequired(null);
				}
			}
			Serializer serializer2 = new Persister();
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream);

			serializer2.write(configList, outputStreamWriter);
			String xmlMsg = byteArrayOutputStream.toString();
			File file = new File(RTJioRMSConstants.DUMP_PATH_PARAMS);
			if (!file.exists())
				file.mkdir();
			String fileFormatXML = RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue()
					+ RTJioRMSConstants.DUMP_PARAMS_FILE_PREFIX + RTJioRMSConstants.XML
					+ this.formatter.format(new Date()) + RTJioRMSConstants.DUMP_FILE_EXTENSION_XML;
			FileWriter fileWriter = new FileWriter(RTJioRMSConstants.DUMP_PATH_PARAMS + File.separator + fileFormatXML,
					false);
			fileWriter.write(xmlMsg);
			fileWriter.close();

			// CSV FILE
			String paramsAsCSV = this.fetchAllParamsAsCSV();

			String fileFormatCSV = RtJioRMSConfigParamEnum.MICROSERVICE_NAME.getStringValue()
					+ RTJioRMSConstants.DUMP_PARAMS_FILE_PREFIX + RTJioRMSConstants.CSV
					+ this.formatter.format(new Date()) + RTJioRMSConstants.DUMP_FILE_EXTENSION_CSV;
			FileWriter fileWriter2 = new FileWriter(RTJioRMSConstants.DUMP_PATH_PARAMS + File.separator + fileFormatCSV,
					false);
			fileWriter2.write(paramsAsCSV);
			fileWriter2.close();

			return true;
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"dumpConfigParams", "Error in dump Config", e);
			return false;
		}
	}

	@Override
	public String fetchAllParamsAsPlainText() {
		StringBuilder paramDump = new StringBuilder();
		paramDump.append("    List of Configurable Parameters\n").append("######################################\n\n");
		String value;
		String emmtyStr = "<Empty>";
		for (RtJioRMSConfigParamEnum paramEnum : RtJioRMSConfigParamEnum.values()) {
			if (paramEnum.getCliArg() == null)
				continue;
			value = paramEnum.getStringValue();
			paramDump.append(String.format("%s = ", paramEnum.name())
					+ ((value == null || value.isEmpty()) ? emmtyStr : value) + "\n");
		}
		return new String(paramDump);
	}

	@Override
	public String fetchAllParamsAsXml() {
		StringWriter stringWriter = new StringWriter();
		try {
			this.serializer.write(fetchConfigParamPojo(), stringWriter);
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"fetchAllParamsAsXml", "Error in fetch all param xml", e);
			return null;
		}
		return stringWriter.toString();
	}

	@Override
	public String fetchAllParamsAsJSON() {
		String xmlData = fetchAllParamsAsXml();
		if (xmlData == null)
			return null;
		try {
			return XML.toJSONObject(xmlData).toString();
		} catch (JSONException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"fetchAllParamsAsJSON", "Error in fetch param in json", e);
			return null;
		}
	}

	@Override
	public String fetchAllParamsAsCSV() throws IOException {
		Writer writer = new StringWriter();
		CSVWriter<RtJioRMSParamCSV> csvWriter = new CSVWriterBuilder<RtJioRMSParamCSV>(writer)
				.strategy(CSVStrategy.UK_DEFAULT).entryConverter(this.paramEntryConverter).build();
		ArrayList<RtJioRMSParamCSV> params = new ArrayList<>();
		for (RtJioRMSConfigParamEnum paramEnum : RtJioRMSConfigParamEnum.values()) {
			if (paramEnum.getParamRange() == null || (paramEnum.getParamRange().getList() != null
					&& paramEnum.getValidator().equals(RTJioRMSConstants.VALIDATOR_COMBOBOX))) {
				String paramValue = paramEnum.getStringValue();
				params.add(new RtJioRMSParamCSV(paramEnum.getCategory(), paramEnum.name(), paramValue,
						paramEnum.getValidator(), paramEnum.isReadOnly(), paramEnum.isValueRequired()));
			} else if (paramEnum.getParamRange().getList() == null)
				params.add(new RtJioRMSParamCSV(paramEnum.getCategory(), paramEnum.name(), paramEnum.getStringValue(),
						paramEnum.getValidator(), paramEnum.isReadOnly(), paramEnum.isValueRequired(),
						paramEnum.getParamRange().getMinValue(), paramEnum.getParamRange().getMaxValue()));
		}
		csvWriter.writeAll(params);
		return RTJioRMSConstants.CSV_HEADER_PARAMS + writer.toString();
	}

	@Override
	public Object fetchParam(String param) {
		RtJioRMSConfigParamEnum paramEnum = null;
		try {
			paramEnum = RtJioRMSConfigParamEnum.valueOf(param.trim());
		} catch (IllegalArgumentException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"fetchAllParamsAsJSON", "Parameter <" + param + "> not found", e);
			return null;
		}
		return paramEnum.getValue();
	}

	@Override
	public boolean updateParam(String param, Object value, boolean sentByCli, boolean isBulkset) {
		if (RtJioRMSConfigParamEnum.valueOf(param).setValue(value, sentByCli, isBulkset)) {
			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"updateParam", "Parameter " + param + " value has been changed to " + value);
			return true;
		} else
			return false;
	}

	@Override
	public int sendParamsToOAM() throws IOException {
		return OamClientManager.getOamClientForConfiguration().pushConfigurationsToOamServer(fetchConfigParamPojo());
	}

	@Override
	public boolean reRegisterToOAM() {
		try {
			OamClientRegistrationNotifier.getInstance()
					.addObserver(RtJioRMSCacheManager.getInstance().getOamRegistrationObserver());
			Logger logger = LogManager.getRootLogger();

			OamClientManager.getInstance().initializeWithExcel(logger, RTJioRMSConstants.OAM_CONFIG_FILE_PATH,
					RtJioRMSCacheManager.getInstance().getOamRegistrationObserver().getAlarmLoggingCallbackHandler(),
					RtJioRMSCacheManager.getInstance().getOamRegistrationObserver().getAlarmConditionCntrListener(),
					null,
					RtJioRMSCacheManager.getInstance().getOamRegistrationObserver().getApplicationMemoryUsageListener(),
					false, null);
			return true;
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"reRegisterToOAM", "Error in reRegister to OAM ", e);
		}
		return false;
	}

	@Override
	public void deRegisterFromOAM() {
		OamClientManager.getInstance().disconnect();
	}

	/**
	 * @return the configuration parameter root pojo for serialization
	 */
	public ConfigParamList fetchConfigParamPojo() {
		ConfigParamList configParamList = new ConfigParamList();
		Param param;
		List<String> list;
		ConfigParamCategory paramCategory = new ConfigParamCategory();
		paramCategory.setParamType(RtJioRMSCacheManager.getInstance().getMicroserviceId());
		for (RtJioRMSConfigParamEnum paramEnum : RtJioRMSConfigParamEnum.values()) {
			if (!paramEnum.isVisibilityInOAM())
				continue;
			if (paramEnum.getParamRange() == null)
				param = new Param(paramEnum.name(), paramEnum.getStringValue(), paramEnum.getValidator(),
						paramEnum.isReadOnly(), paramEnum.isValueRequired());
			else if (paramEnum.getValidator().equals(RTJioRMSConstants.VALIDATOR_COMBOBOX)) {
				String paramValue = paramEnum.getStringValue();
				param = new Param(paramEnum.name(), paramValue, paramEnum.getValidator(), paramEnum.isReadOnly(),
						paramEnum.isValueRequired());
				list = paramEnum.getParamRange().getList();
				for (String element : list)
					param.addToComboValueList(new ComboValue(element));
			} else
				param = new Param(paramEnum.name(), paramEnum.getStringValue(), paramEnum.getValidator(),
						paramEnum.isReadOnly(), paramEnum.isValueRequired(), paramEnum.getParamRange().getMinValue(),
						paramEnum.getParamRange().getMaxValue());
			paramCategory.addToParamList(param);
		}
		configParamList.addToConfigParamList(paramCategory);
		return configParamList;
	}

	private class CSVParamEntryConverter implements CSVEntryConverter<RtJioRMSParamCSV> {
		private static final int SIZE = 8;
		private static final int INDEX_0 = 0;
		private static final int INDEX_1 = 1;
		private static final int INDEX_2 = 2;
		private static final int INDEX_3 = 3;
		private static final int INDEX_4 = 4;
		private static final int INDEX_5 = 5;
		private static final int INDEX_6 = 6;
		private static final int INDEX_7 = 7;

		@Override
		public String[] convertEntry(RtJioRMSParamCSV param) {
			String[] configParam = new String[SIZE];
			configParam[INDEX_0] = param.getParamType();
			configParam[INDEX_1] = param.getName();
			configParam[INDEX_2] = param.getValue();
			configParam[INDEX_3] = param.getValidator();
			configParam[INDEX_4] = String.valueOf(param.isReadOnly());
			configParam[INDEX_5] = String.valueOf(param.getMaxRange());
			configParam[INDEX_6] = String.valueOf(param.getMinRange());
			configParam[INDEX_7] = String.valueOf(param.getRequired());
			return configParam;
		}
	}
}