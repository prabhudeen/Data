package com.rjil.rms.management.params;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import com.atom.OAM.Client.Management.OamClientManager;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;

/**
 * Enumeration for all the configuration parameters of RMS
 * 
 * @author kiran.jangid
 *
 */
public enum RtJioRMSConfigParamEnum {

	MICROSERVICE_NAME,

	APPLICATION_LOG_LEVEL,

	HTTP_HOST_IP_FOR_RMS,

	HTTP_PORT_FOR_RMS,

	RMR_ALARM_CONTEXT,

	RMR_COUNTER_CONTEXT,

	RMR_CONFIG_CONTEXT,

	RMR_BROADCAST_CONTEXT,

	CORE_POOL_SIZE,

	MAXIMUM_POOL_SIZE,
	
	MINIMUM_POOL_SIZE,

	KEEP_ALIVE_TIME,

	RMR_EVENT_CONTEXT,

	SIZE_OF_CHUNK,

	BINARY_DESTINATION_HOME_PATH,

	ES_CLUSTERNAME,

	ES_XPACKUNAME,

	ES_XPACKPASSWORD,

	ES_COORDINATORNODE_IPANDPORT,

	RMR_BINARY_INDEX_NAME,

	BINARY_SOURCE_HOME_PATH,

	RMR_FCAPS_REPOSITORY_PATH,

	MAX_LOG_FILE_SIZE,

	MAX_LOG_BACKUP_INDEX,

	LOG_FILE_PATH,

	ERM_SUBSCRIPTION_CONTEXT,

	ERM_EVENT_CONTEXT,
	
	RMR_SYNC_CONTEXT,

	RMR_CLI_CONTEXT,
	
	RMR_TEMPLATE_ALARM_FILE_NAME,
	
	RMR_TEMPLATE_CONFIG_FILE_NAME,
	
	RMR_TEMPLATE_COUNTER_FILE_NAME,
	
	RMR_DICT_TEMPLATE_CONTEXT,
	
	UI_METADATA_FILE,
	
	XDR_RECORD_LIMIT_PER_FILE, 
	
	XDR_LOCAL_DUMP_PATH, 
	
	XDR_FTP_ENABLED, 
	
	XDR_REMOTE_ADDRESSES, 
	
	XDR_REMOTE_USER_NAME, 
	
	XDR_REMOTE_DUMP_PATH, 
	
	XDR_REMOTE_PASSWORD,
	
	RMR_FILE_UPLOADER_CONTEXT,
	
	NB_IOT_FILE_PATH,
	
	IS_USING_SHARED_RESOURCE,
	
	ES_NODE_SEPARATOR,
	
	ES_PORT_SEPARATOR,
	
	RMR_CNF_DRAFT_INDEX_NAME,
	
	IS_USING_HDFS,
	
	HDFS_DESTINATION_HOME_PATH,
	
	IS_ERM_ELB_FQDN,
	
	ERM_ELB_FQDN,
	
	CONTAINERIZED_INTERFACE,
	
	TOTAL_LOGS_FILE_SIZE,
	
	EXPIRE_TIME_FOR_LOGS_FILES,
	
	RMR_CNF_FCAPS_REPOSITORY_PATH,
	
	RMR_CNF_FCAPS_INDEX_NAME,
	
	RMR_CNF_DICT_TEMPLATE_CONTEXT,
	
	RMR_CNF_TEMPLATE_ALARM_FILE_NAME,
	
	RMR_CNF_TEMPLATE_CONFIG_FILE_NAME,
	
	RMR_CNF_TEMPLATE_COUNTER_FILE_NAME,
	
	RMR_CNF_DOWNLOAD_SYNC_CONTEXT;

	private static HashMap<String, RtJioRMSConfigParamEnum> enumCliMap = new HashMap<>();
	private Object value;
	private String cliArg;
	private String description;
	private boolean readOnly;
	private String category;
	private String validator;
	private RtJioRMSConfigParamRange paramRange;
	private boolean visibilityInOAM;
	private boolean valueRequired;

	/**
	 * private constructor
	 */
	private RtJioRMSConfigParamEnum() {

	}

	/**
	 * @return the value of this parameter as plain java object
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * @return the integer representation of the value of this parameter
	 */
	public int getIntValue() {
		return Integer.parseInt(value + "");
	}

	/**
	 * @return the long representation of the value of this parameter
	 */
	public long getLongValue() {
		return Long.parseLong(value + "");
	}

	/**
	 * @return the string representation of the value of this parameter
	 */
	public String getStringValue() {
		return (value == null) ? null : (value + "");
	}

	/**
	 * @return the byte representation of the value of this parameter
	 */
	public byte getByteValue() {
		return Byte.parseByte(value + "");
	}

	/**
	 * @return the float representation of the value of this parameter
	 */
	public float getFloatValue() {
		return Float.parseFloat(value + "");
	}

	/**
	 * @return the double representation of the value of this parameter
	 */
	public double getDoubleValue() {
		return Double.parseDouble(value + "");
	}

	/**
	 * @return the boolean representation of the value of this parameter
	 */
	public boolean getBooleanValue() {
		return Boolean.parseBoolean(value + "");
	}

	/**
	 * @return the atomic boolean representation of the value of this parameter
	 */
	public AtomicBoolean getAtomicBooleanValue() {
		return (AtomicBoolean) value;
	}

	/**
	 * @return the argument to be used in RMS CLI application for GET/SET
	 *         operation
	 */
	public String getCliArg() {
		return cliArg;
	}

	/**
	 * @return the brief description of the parameter
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return flag indicating if the parameter is read-only or editable
	 */
	public boolean isReadOnly() {
		return readOnly;
	}

	/**
	 * @return the name of the category to which this parameter belongs
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @return the type of validation to be performed for the value of this
	 *         parameter
	 */
	public String getValidator() {
		return validator;
	}

	/**
	 * @return the range of the value of this parameter
	 */
	public RtJioRMSConfigParamRange getParamRange() {
		return paramRange;
	}

	/**
	 * @return the flag indicating if this parameter is to be sent to OAM
	 */
	public boolean isVisibilityInOAM() {
		return visibilityInOAM;
	}

	/**
	 * @return the flag indicating if the value of this parameter is optional or
	 *         not
	 */
	public boolean isValueRequired() {
		return valueRequired;
	}

	/**
	 * set the CLI argument
	 * 
	 * @param cliArg
	 */
	protected void setCliArg(String cliArg) {
		this.cliArg = cliArg;
	}

	/**
	 * sets the flag indicating if the value of this parameter is optional (can
	 * be null)
	 * 
	 * @param valueRequired
	 */
	protected void setValueRequired(boolean valueRequired) {
		this.valueRequired = valueRequired;
	}

	/**
	 * sets the flag indicating if the parameter is to be sent to OAM
	 * 
	 * @param visibilityInOAM
	 */
	protected void setVisibilityInOAM(boolean visibilityInOAM) {
		this.visibilityInOAM = visibilityInOAM;
	}

	/**
	 * sets this parameter as read-only/editable
	 * 
	 * @param readOnly
	 */
	protected void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	/**
	 * sets the name of the category to which this parameter belongs
	 * 
	 * @param category
	 */
	protected void setCategory(String category) {
		this.category = category;
	}

	/**
	 * sets the range for the value of this parameter
	 * 
	 * @param paramRange
	 */
	protected void setParamRange(RtJioRMSConfigParamRange paramRange) {
		this.paramRange = paramRange;
	}

	/**
	 * sets the validator for the value of this parameter
	 * 
	 * @param validator
	 */
	protected void setValidator(String validator) {
		this.validator = validator;
	}

	/**
	 * sets the description of this parameter
	 * 
	 * @param description
	 */
	protected void setDescription(String description) {
		this.description = description;
	}

	/**
	 * set/update the value of this parameter
	 * 
	 * @param value
	 *            the updated value
	 * @param sentByCli
	 *            flag indicating if the parameter is being updated by CLI
	 *            application
	 * @param isBulkSet
	 *            flag indicating if the value update is part of template
	 *            application
	 * @return flag indicating the status of the update
	 */
	public boolean setValue(Object value, boolean sentByCli, boolean isBulkSet) {

		LoggerWriter loggerWriter = LoggerWriter.getInstance();

		String newValue = String.valueOf(value);
		try {
			if (this == APPLICATION_LOG_LEVEL)
				ResourceBuilder.logger().setSystemLogLevel(newValue.toLowerCase()).updateLoggers();
			// Update Excel Sheet with updated value
			if (!isBulkSet)
				RtJioRMSCacheManager.getInstance().getExcelWorkbookLoader().updateParamsExcelSheet(this.name(),
						newValue);
			this.value = value;
			// notify changes to the parameter to OAM if it is updated by CLI
			if (sentByCli) {
				int responseCode = OamClientManager.getOamClientForConfiguration()
						.pushScalarConfigParamModificationToOamServer(this.name(), newValue);
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"setValue", "Parameter change notified to OAM. Response received : " + responseCode);
			}
		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"setValue", "Error in Set Value ", e);
			return false;
		}
		return true;
	}

	/**
	 * sets the updated value of this parameter
	 * 
	 * @param value
	 *            updated value
	 */
	protected void setValue(Object value) {
		this.value = value;
	}

	/**
	 * returns the count of the configurable parameters in this enumeration
	 * 
	 * @return size
	 */
	public static int size() {
		return RtJioRMSConfigParamEnum.values().length;
	}
	
	/**
	 * load Enum value into CLI
	 */
	
	public static void loadEnumCliMap() {
		for (RtJioRMSConfigParamEnum configParamEnum : RtJioRMSConfigParamEnum.values())
			if (configParamEnum.cliArg != null)
				enumCliMap.put(configParamEnum.cliArg, configParamEnum);
	}

	/**
	 * returns the enumeration constant corresponding to the CLI argument
	 * 
	 * @param cliArgName
	 *            the CLI argument
	 * @return the enumeration constant
	 */
	public static RtJioRMSConfigParamEnum getEnumFromCliName(String cliArgName) {
		return enumCliMap.get(cliArgName);
	}
}
