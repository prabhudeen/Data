package com.rjil.rms.management.params;

import java.io.IOException;

/**
 * Runtime Configuration Engine MBean
 * 
 * @author arun.dewna
 *
 */
public interface RtJioRMSConfigurationManagerMBean {

	/**
	 * dumps all the parameters with their current configuration
	 * 
	 * @return status of dump
	 */
	public boolean dumpConfigParams();

	/**
	 * @return the current configuration as text/plain string
	 */
	public String fetchAllParamsAsPlainText();

	/**
	 * @return the current configuration as XML string
	 */
	public String fetchAllParamsAsXml();

	/**
	 * @return the current configuration as JSON string
	 */
	public String fetchAllParamsAsJSON();

	/**
	 * @return the current configuration as CSV string
	 */
	public String fetchAllParamsAsCSV() throws IOException;

	/**
	 * @param param
	 *            of the configuration parameter
	 * @return the current value of the configuration parameter
	 */
	public Object fetchParam(String param);

	/**
	 * update a single configuration parameter
	 * 
	 * @param param
	 *            name of the configuration parameter
	 * @param value
	 *            updated value of the configuration parameter
	 * @param sentByCli
	 *            flag indicating whether the update is initiated by the CLI/GUI
	 * @param isBulkset
	 *            flag indicating whether the update is initiated by the
	 *            application of a configuration template
	 * @return a boolean value representing the status of the update
	 */
	public boolean updateParam(String param, Object value, boolean sentByCli,
			boolean isBulkset);

	/**
	 * send all the configuration parameters with their current values to OAM
	 * 
	 * @return the response status-code
	 * @throws IOException
	 */
	public int sendParamsToOAM() throws IOException;

	/**
	 * try to re-connect and re-register the application to OAM
	 * 
	 * @return the connection status
	 */
	public boolean reRegisterToOAM();

	/**
	 * disconnects/de-register the application from OAM
	 */
	public void deRegisterFromOAM();
}
