package com.rjil.rms.management.params;

import java.util.List;

/**
 * Range Class to define minimum and maximum values that each configurable
 * parameter can take
 */
public class RtJioRMSConfigParamRange {

	private static final byte RANGE_TYPE_LIST = 0;
	private static final byte RANGE_TYPE_RANGE = 1;
	private long minValue;
	private long maxValue;
	private List<String> list;

	/**
	 * constructor to take minimum and maximum values of a configuration
	 * parameter value
	 * 
	 * @param minValue
	 *            minimum value
	 * @param maxValue
	 *            maximum value
	 */
	public RtJioRMSConfigParamRange(Long minValue, Long maxValue) {
		this.minValue = minValue;
		this.maxValue = maxValue;
	}

	/**
	 * constructor to take range in the form of allowed set of values for a
	 * configuration parameter
	 * 
	 * @param list
	 *            list of allowed values
	 */
	public RtJioRMSConfigParamRange(List<String> list) {
		this.list = list;
	}

	/**
	 * @return the least possible value allowed for a configuration parameter
	 */
	public long getMinValue() {
		return minValue;
	}

	/**
	 * sets the minimum value of a configuration parameter
	 * 
	 * @param minValue
	 */
	public void setMinValue(long minValue) {
		this.minValue = minValue;
	}

	/**
	 * @return the maximum possible value allowed for a configuration parameter
	 */
	public long getMaxValue() {
		return maxValue;
	}

	/**
	 * sets the maximum value of a configuration parameter
	 * 
	 * @param minValue
	 */
	public void setMaxValue(long maxValue) {
		this.maxValue = maxValue;
	}

	/**
	 * @return the list of values allowed for a configuration parameter
	 */
	public List<String> getList() {
		return list;
	}

	/**
	 * @return the type of range (min/max or list)
	 */
	public byte type() {
		return (this.list == null) ? RANGE_TYPE_RANGE : RANGE_TYPE_LIST;
	}

}
