package com.rjil.rms.management.params;

/**
 * Pojo of Param to build Parameter in CVS
 * 
 * @author kiran.jangid
 *
 */

public class RtJioRMSParamCSV {

	private String paramType;
	private String name;
	private String value;
	private Boolean readOnly;
	private String validator;
	private Long minRange;
	private Boolean required;
	private Long maxRange;
	
	/**
	 * 
	 * @param paramType
	 * @param name
	 * @param value
	 */

	public RtJioRMSParamCSV(String paramType, String name, String value) {
		this.paramType = paramType;
		this.name = name;
		this.value = value;
	}
	
	/**
	 * 
	 * @param paramType
	 * @param name
	 * @param value
	 * @param validator
	 * @param readOnly
	 * @param required
	 */

	public RtJioRMSParamCSV(String paramType, String name, String value, String validator, Boolean readOnly,
			Boolean required) {
		this.paramType = paramType;
		this.name = name;
		this.value = value;
		this.validator = validator;
		this.readOnly = readOnly;
		this.required = required;
	}
	
	/**
	 * 
	 * @param paramType
	 * @param name
	 * @param value
	 * @param validator
	 * @param readOnly
	 * @param required
	 * @param range
	 */

	public RtJioRMSParamCSV(String paramType, String name, String value, String validator, Boolean readOnly,
			Boolean required, Long ... range) {
		this.paramType = paramType;
		this.name = name;
		this.value = value;
		this.validator = validator;
		this.readOnly = readOnly;
		this.maxRange = range[0];
		this.minRange = range[1];
		this.required = required;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(Boolean readOnly) {
		this.readOnly = readOnly;
	}

	public String getValidator() {
		return validator;
	}

	public void setValidator(String validator) {
		this.validator = validator;
	}

	public Long getMinRange() {
		return minRange;
	}

	public void setMinRange(Long minRange) {
		this.minRange = minRange;
	}

	public Long getMaxRange() {
		return maxRange;
	}

	public void setMaxRange(Long maxRange) {
		this.maxRange = maxRange;
	}
	
	/**
	 * to remove read only flag
	 */

	public void removeReadOnlyFlag() {
		this.readOnly = null;
	}

	public Boolean getRequired() {
		return required;
	}

	public void setRequired(Boolean required) {
		this.required = required;
	}

	public Boolean getReadOnly() {
		return readOnly;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
}
