package com.rjil.rms.management.params;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.rjil.rms.management.params.RtJioRMSConfigParamRange;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMSAsyncRequestDispatcher;
import com.rjil.rms.rest.handlers.RMSEventAckRequestDispatcher;
import com.rjil.rms.management.params.RtJioRMSConfigParamEnum;
import com.rjil.rms.util.RTJioRMSConstants;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.pool.PoolBuilder;
import com.jio.telco.framework.resource.ResourceBuilder;
import com.rjil.modules.pool.factory.BroadCastEventProcessTaskFactory;
import com.rjil.modules.pool.factory.BroadCastListenerProcessTaskFactory;
import com.rjil.modules.pool.factory.DumpEventProcessTaskFactory;
import com.rjil.modules.pool.factory.EventDumpTaskFactory;
import com.rjil.modules.pool.factory.RMRClearCodeAsnPojoFactory;
import com.rjil.modules.pool.factory.RMSAsyncRequestDispatcherFactory;
import com.rjil.modules.pool.factory.RMSEventAckRequestDispatcherFactory;
import com.rjil.modules.pool.factory.VNFCBinaryUploadTaskFactory;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.broadcast.listener.BroadCastListenerProcessTask;
import com.rjil.rms.broadcast.sender.BroadCastEventProcessTask;
import com.rjil.rms.exceptions.InvalidConfigParamException;
import com.rjil.rms.ha.DumpEventProcessTask;
import com.rjil.rms.ha.EventDumpTask;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * Class that facilitates reading/loading the configuration from the excel sheet
 */
public class RtJioRMSExcelWorkbookLoader {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	public static final byte INDEX_PARAM_NAME = 1;
	public static final byte INDEX_PARAM_TYPE = 2;
	public static final byte INDEX_PARAM_VALUE = 3;
	public static final byte INDEX_RUNTIME_CONFIG = 4;
	public static final byte INDEX_STARTUP_CONFIG = 5;
	public static final byte INDEX_DESCRIPTION = 6;
	public static final byte INDEX_POSSIBLE_VALUES = 7;
	public static final byte INDEX_OAM_VISIBILITY = 8;
	public static final byte INDEX_VALUE_REQUIRED = 9;
	public static final byte INDEX_CLI_ARGUMENT = 10;

	public static final byte INDEX_CONFIG_SHEET = 0;
	public static final byte INDEX_POOLING_SHEET = 1;

	private XSSFSheet configSheet;
	private XSSFSheet poolingSheet;

	private XSSFWorkbook workbook;

	/**
	 * initializes the configurations from excel workbook
	 * 
	 * @throws IOException
	 */
	public void initialize() throws IOException {
		FileInputStream fileInputStream = new FileInputStream(new File(RTJioRMSConstants.CONFIGURATION_FILE_PATH));
		this.workbook = new XSSFWorkbook(fileInputStream);
		this.configSheet = this.workbook.getSheetAt(INDEX_CONFIG_SHEET);
		this.configSheet.removeRow(this.configSheet.getRow(0));
		this.poolingSheet = this.workbook.getSheetAt(INDEX_POOLING_SHEET);
		this.poolingSheet.removeRow(this.poolingSheet.getRow(0));
		fileInputStream.close();
		loadConfigParams();
		loadPoolingSheet();
		RtJioRMSConfigParamEnum.loadEnumCliMap();
	}

	/**
	 * loads the pooling sheet and initialises the pools
	 */

	private void loadPoolingSheet() {

		String poolName;
		Cell poolCell;
		Row poolRow;
		PoolBuilder builder;
		for (int i = 1; i <= this.poolingSheet.getPhysicalNumberOfRows(); i++) {
			builder = ResourceBuilder.objectPool();
			poolRow = this.poolingSheet.getRow(i);
			poolName = poolRow.getCell(0).getStringCellValue().trim();

			poolCell = poolRow.getCell(1);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setMaxActive(Integer.parseInt(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(2);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setMaxIdle(Integer.parseInt(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(3);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setMaxWait(Long.parseLong(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(4);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setMinEvictableIdleTimeMillis(Long.parseLong(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(5);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setMinIdle(Integer.parseInt(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(6);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setNumTestsPerEviction(Integer.parseInt(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(7);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setTestOnBorrow(Boolean.parseBoolean(poolCell.getStringCellValue().trim().toLowerCase()));

			poolCell = poolRow.getCell(8);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setTestOnReturn(Boolean.parseBoolean(poolCell.getStringCellValue().trim().toLowerCase()));

			poolCell = poolRow.getCell(9);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setTestWhileIdle(Boolean.parseBoolean(poolCell.getStringCellValue().trim().toLowerCase()));

			poolCell = poolRow.getCell(10);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setTimeBetweenEvictionRunsMillis(Long.parseLong(poolCell.getStringCellValue().trim()));

			poolCell = poolRow.getCell(11);
			poolCell.setCellType(Cell.CELL_TYPE_STRING);
			builder.setWhenExhaustAction(Boolean.parseBoolean(poolCell.getStringCellValue().trim().toLowerCase()));

			switch (poolName) {
			case "VNFCBinaryUploadTask":
				builder.createObjectPool(new VNFCBinaryUploadTaskFactory(), DownloadBinaryThread.class);
				break;
			case "RMRClearCodeAsnPojo":
				builder.createObjectPool(new RMRClearCodeAsnPojoFactory(), ClearCodeAsnPojo.class);
				break;
			case "RMSAsyncRequestDispatcher":
				builder.createObjectPool(new RMSAsyncRequestDispatcherFactory(), RMSAsyncRequestDispatcher.class);
				break;
			case "EventDumpTask":
				builder.createObjectPool(new EventDumpTaskFactory(), EventDumpTask.class);
				break;
			case "DumpEventProcessTask":
				builder.createObjectPool(new DumpEventProcessTaskFactory(), DumpEventProcessTask.class);
				break;
			case "BroadCastEventProcessTask":
				builder.createObjectPool(new BroadCastEventProcessTaskFactory(), BroadCastEventProcessTask.class);
				break;
			case "BroadCastListenerProcessTask":
				builder.createObjectPool(new BroadCastListenerProcessTaskFactory(), BroadCastListenerProcessTask.class);
				break;
			case "RMSEventAckRequestDispatcher":
				builder.createObjectPool(new RMSEventAckRequestDispatcherFactory(), RMSEventAckRequestDispatcher.class);
				break;
			default:
				break;
			}
		}
	}

	/**
	 * @return the handle of the sheet that contains the configuration of the
	 *         microservice
	 */
	public XSSFSheet getConfigSettingsSheet() {
		return configSheet;
	}

	/**
	 * @return the handle of the configuration workbook
	 */
	public XSSFWorkbook getWorkbook() {
		return workbook;
	}

	/**
	 * reset all the member variables
	 */
	public void reset() {
		this.configSheet = null;
		this.workbook = null;
		this.poolingSheet = null;
	}

	/**
	 * loads all configuration parameters from the excel sheet
	 */
	public void loadConfigParams() {
		Iterator<Row> rowIterator = this.configSheet.iterator();

		while (rowIterator.hasNext()) {

			XSSFRow row = (XSSFRow) rowIterator.next();

			setParameterInApplicationCache(row);

		}
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"loadConfigParams", "Configuration parameters have been successfully loaded");
		for (RtJioRMSConfigParamEnum param : RtJioRMSConfigParamEnum.values())
			param.setCategory(RtJioRMSCacheManager.getInstance().getMicroserviceId());

	}

	private void setParameterInApplicationCache(XSSFRow row) {

		String paramName;
		String paramValue;
		String paramCategory;
		String paramValidator;
		boolean isReadOnly;
		String description;
		String possibleValues;
		boolean startupConfig;
		RtJioRMSConfigParamRange paramRange = null;
		boolean emsVisibility;
		boolean valueRequired;
		String cliArgument = null;
		XSSFCell cell;
		RtJioRMSConfigParamEnum paramEnum;
		int rowNum;

		rowNum = row.getRowNum();
		// Read the Parameter_Type column value from excel sheet
		cell = row.getCell(INDEX_PARAM_TYPE);
		if (cell == null)
			throw new InvalidConfigParamException("Parameter Type field has been left empty in row [" + rowNum + "]");
		cell.setCellType(XSSFCell.CELL_TYPE_STRING);
		if (cell.getStringCellValue().trim().isEmpty())
			throw new InvalidConfigParamException("Parameter Type field has been left empty in row [" + rowNum + "]");
		String[] str = cell.getStringCellValue().trim().split("/");
		if (str.length == 1)
			throw new InvalidConfigParamException("Parameter validator not specified in row [" + rowNum + "]");
		paramCategory = str[0].trim();
		paramValidator = str[1].trim().toLowerCase();
		// Read the Parameter_Name column value from excel sheet
		cell = row.getCell(INDEX_PARAM_NAME);
		if (cell == null)
			throw new InvalidConfigParamException("Parameter Name field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		paramName = cell.getStringCellValue().trim();
		if (paramName.isEmpty())
			throw new InvalidConfigParamException("Parameter Name field has been left empty in row [" + rowNum + "]");
		try {
			paramEnum = RtJioRMSConfigParamEnum.valueOf(paramName);
		} catch (IllegalArgumentException e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					"loadConfigParams", "initialize excel loader error", e);
			throw new InvalidConfigParamException(
					"Parameter Name  = " + paramName + " at row [" + rowNum + "] has not been declared and defined");
		}
		// Read the Startup_Configurable column value from excel sheet
		cell = row.getCell(INDEX_STARTUP_CONFIG);
		if (cell == null)
			throw new InvalidConfigParamException(
					"Startup Configurable field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		if (cell.getStringCellValue().trim().isEmpty())
			throw new InvalidConfigParamException(
					"Startup Configurable field has been left empty in row [" + rowNum + "]");
		startupConfig = "YES".equalsIgnoreCase(cell.getStringCellValue().trim()) ? true : false;
		// Read the Runtime_Configurable column value from excel sheet
		cell = row.getCell(INDEX_RUNTIME_CONFIG);
		if (cell == null)
			throw new InvalidConfigParamException(
					"Runtime Configurable field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		if (cell.getStringCellValue().trim().isEmpty())
			throw new InvalidConfigParamException(
					"Runtime Configurable field has been left empty in row [" + rowNum + "]");
		isReadOnly = "YES".equalsIgnoreCase(cell.getStringCellValue().trim()) ? false : true;
		// Read the Parameter_Value column value from excel sheet
		cell = row.getCell(INDEX_PARAM_VALUE);
		if (paramEnum.isValueRequired() && startupConfig) {
			if (cell == null)
				throw new InvalidConfigParamException(
						"Parameter Value field has been left empty in row [" + rowNum + "]");
			cell.setCellType(Cell.CELL_TYPE_STRING);
			paramValue = cell.getStringCellValue().trim();
			if (paramValue.isEmpty())
				throw new InvalidConfigParamException(
						"Parameter Value field has been left empty in row [" + rowNum + "]");
		} else {
			cell.setCellType(Cell.CELL_TYPE_STRING);
			paramValue = cell.getStringCellValue();
		}
		// Read the Description column value from excel sheet
		cell = row.getCell(INDEX_DESCRIPTION);
		if (cell == null)
			throw new InvalidConfigParamException("Description field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		description = cell.getStringCellValue().trim();
		if (description.isEmpty())
			throw new InvalidConfigParamException("Description field has been left empty in row [" + rowNum + "]");
		// Read the Possible_Values column value from excel sheet
		cell = row.getCell(INDEX_POSSIBLE_VALUES);
		if (cell != null) {
			cell.setCellType(Cell.CELL_TYPE_STRING);
			possibleValues = cell.getStringCellValue().trim();
			if (possibleValues.isEmpty() && paramValidator.equals(RTJioRMSConstants.VALIDATOR_COMBOBOX))
				throw new InvalidConfigParamException(
						"Possible values not supplied for " + paramName + " at row [" + rowNum + "]");
			String[] arr;
			if (possibleValues.indexOf(',') >= 0) {
				arr = possibleValues.split(",");
				ArrayList<String> list = new ArrayList<>();
				for (String element : arr)
					list.add(element.trim());
				paramRange = new RtJioRMSConfigParamRange(list);
			} else if (possibleValues.indexOf('-') >= 0) {
				arr = possibleValues.split("-");
				if (arr.length != 2)
					throw new InvalidConfigParamException("Invalid Paramenter Range Supplied in row [" + rowNum + "]");
				long minValue;
				long maxValue;
				try {
					minValue = Long.parseLong(arr[0].trim());
				} catch (NumberFormatException e) {
					throw new InvalidConfigParamException(
							"Invalid Minimum value supplied for range in row [" + rowNum + "].");
				}
				try {
					maxValue = Long.parseLong(arr[1].trim());
				} catch (NumberFormatException e) {
					throw new InvalidConfigParamException(
							"Invalid Maximum value supplied for range in row [" + rowNum + "].");
				}
				paramRange = new RtJioRMSConfigParamRange(minValue, maxValue);
			}
		} else {
			if (paramValidator.equals(RTJioRMSConstants.VALIDATOR_COMBOBOX))
				throw new InvalidConfigParamException(
						"Possible values not supplied for combobox in row [" + rowNum + "]");
		}
		// Read the EMS Visibility column value from excel sheet
		cell = row.getCell(INDEX_OAM_VISIBILITY);
		if (cell == null)
			throw new InvalidConfigParamException("EMS Visibility field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		if (cell.getStringCellValue().trim().isEmpty())
			throw new InvalidConfigParamException("EMS Visibility field has been left empty in row [" + rowNum + "]");
		emsVisibility = "YES".equalsIgnoreCase(cell.getStringCellValue().trim()) ? true : false;
		// Read the Value Required column value from excel sheet
		cell = row.getCell(INDEX_VALUE_REQUIRED);
		if (cell == null)
			throw new InvalidConfigParamException("Value Required field has been left empty in row [" + rowNum + "]");
		cell.setCellType(Cell.CELL_TYPE_STRING);
		if (cell.getStringCellValue().trim().isEmpty())
			throw new InvalidConfigParamException("Value Required field has been left empty in row [" + rowNum + "]");
		valueRequired = "YES".equalsIgnoreCase(cell.getStringCellValue().trim()) ? true : false;
		// Read the CLI Argument column value from excel sheet
		cell = row.getCell(INDEX_CLI_ARGUMENT);
		if (cell != null) {
			cell.setCellType(Cell.CELL_TYPE_STRING);
			cliArgument = cell.getStringCellValue().trim();
			if (cliArgument.isEmpty())
				cliArgument = null;
		}
		if (startupConfig)
			paramEnum.setValue(paramValue, false, false);
		paramEnum.setValidator(paramValidator);
		paramEnum.setReadOnly(isReadOnly);
		paramEnum.setCategory(paramCategory);
		paramEnum.setDescription(description);
		paramEnum.setParamRange(paramRange);
		paramEnum.setVisibilityInOAM(emsVisibility);
		paramEnum.setValueRequired(valueRequired);
		paramEnum.setCliArg(cliArgument);

	}

	/**
	 * update a single configuration parameter in excel sheet
	 * 
	 * @param param
	 *            name of the configuration parameter
	 * @param value
	 *            updated value of the parameter
	 * @throws IOException
	 */
	public void updateParamsExcelSheet(String param, Object value) throws IOException {
		File file = new File(RTJioRMSConstants.CONFIGURATION_FILE_PATH);
		try (FileInputStream inFile = new FileInputStream(file)) {
			XSSFWorkbook workbookTemp = new XSSFWorkbook(inFile);
			XSSFSheet sheet = workbookTemp.getSheetAt(INDEX_CONFIG_SHEET);
			int i = 0;
			int rowNum = 0;
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				if (row.getCell(INDEX_PARAM_NAME) != null
						&& param.equals(row.getCell(INDEX_PARAM_NAME).getStringCellValue().trim())) {
					Cell valueCell = row.getCell(INDEX_PARAM_VALUE);
					valueCell.setCellType(Cell.CELL_TYPE_STRING);
					valueCell.setCellValue(value + "");
					i++;
					rowNum = row.getRowNum();
					break;
				}
			}
			if (i == 0)
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"updateParamsExcelSheet", "Parameter " + param + " is not found in ParamsExcelSheet.");
			else {
				FileOutputStream outFile = new FileOutputStream(file);
				workbookTemp.write(outFile);
				outFile.close();
				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
						"updateParamsExcelSheet",
						"Parameter " + param + " value is updated in ParamsExcelSheet at row [" + rowNum + "]");
			}
		}
	}

	/**
	 * update the entire configuration sheet with the updated system values
	 * 
	 * @throws IOException
	 */
	public void updateParamsExcelSheetAllParams() throws IOException {
		File file = new File(RTJioRMSConstants.CONFIGURATION_FILE_PATH);
		try (FileInputStream inFile = new FileInputStream(file)) {
			this.workbook = new XSSFWorkbook(inFile);
			XSSFSheet sheet = this.workbook.getSheetAt(INDEX_CONFIG_SHEET);
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				RtJioRMSConfigParamEnum confParamEnum = null;
				try {
					confParamEnum = RtJioRMSConfigParamEnum
							.valueOf(row.getCell(INDEX_PARAM_NAME).getStringCellValue().trim());
				} catch (Exception e) {
					loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(),
							this.getClass().getName(), "updateParamsExcelSheetAllParams", "Error in Update Excel Sheet",
							e);
					continue;
				}
				String value = confParamEnum.getStringValue();
				Cell valueCell = row.getCell(INDEX_PARAM_VALUE);
				valueCell.setCellType(Cell.CELL_TYPE_STRING);
				valueCell.setCellValue(value);
			}
		}
		FileOutputStream outFile = new FileOutputStream(file);
		this.workbook.write(outFile);
		outFile.close();
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(),
				"updateParamsExcelSheetAllParams", "All Parameters Updated using bulk set");
	}
}
