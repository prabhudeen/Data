package com.rjil.rms.shutdown;

import java.io.FileInputStream;
import java.util.Properties;

import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author kiran.jangid
 *
 */
public class GracefulShutdown {

	LoggerWriter loggerWriter = LoggerWriter.getInstance();

	private static final String CLASSNAME = "GracefulShutdown";

	private GracefulShutdown() {

	}

	/**
	 * Gracefully shutdown application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		final String className = "main";

		LoggerWriter loggerWriter = LoggerWriter.getInstance();

		String jmxIP;
		String jmxPort;

		Properties env = new Properties();

		String os = System.getProperty("os.name").toLowerCase();

		if (os.indexOf("win") >= 0) {

			try (FileInputStream f = new FileInputStream("./run-as.bat")) {

				int i;
				StringBuilder str = new StringBuilder();
				while ((i = f.read()) != -1)
					str.append((char) i);
				f.close();

				String[] str1 = new String(str).split("jmxport=");
				jmxPort = str1[1].substring(0, str1[1].indexOf('\n') - 1);

				String[] str2 = new String(str).split("jmxip=");
				jmxIP = str2[1].substring(0, str2[1].indexOf('\n') - 1);

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), CLASSNAME, className,
						"JMX IP:Port : " + jmxIP + ":" + jmxPort);

			} catch (Exception e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, className,
						"Error in Shutdown", e);
			}

		} else {

			try (FileInputStream f = new FileInputStream("./run-as.sh")) {
				env.load(f);
				jmxIP = env.getProperty("jmxip");
				jmxPort = env.getProperty("jmxport");

				loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.DEBUG.getValue(), CLASSNAME, className,
						"JMX IP:Port : " + jmxIP + ":" + jmxPort);

			} catch (Exception e) {
				loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), CLASSNAME, className,
						"Error in Shutdown", e);
			}

		}

	}

}
