package com.rjil.rms.draft;

/**
 * 
 * @author Annasamudram.H
 *
 */

public enum CNFDraftOperationErrorMessageEnum {

	STATUS("status"),

	ERROR_MESSAGE_CNF_ID_OR_OPERATION_IS_MISSING("cnf id or operation is missing"),

	ERROR_MESSAGE_DRAFT_DATA_NOT_AVAILABLE("Draft Data is not available");

	private String value;

	private CNFDraftOperationErrorMessageEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
