package com.rjil.rms.draft;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.clearcode.ClearCodeAsnUtility;
import com.jio.telco.framework.clearcode.ClearCodeLevel;
import com.rjil.rms.clearcode.ClearCodes;
import com.rjil.rms.es.db.EsManager;
import com.rjil.rms.event.RMREventPojo;
import com.rjil.rms.event.RMSEventConstant;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.management.counters.RtJioRMSCounterNameEnum;
import com.rjil.rms.manager.RtJioRMSCacheManager;
import com.rjil.rms.rest.handlers.RMREventProcessor;
import com.rjil.rms.rest.handlers.ResponseConstantsEnum;
import com.rjil.rms.rest.handlers.ResponsePayload;
import com.rjil.rms.util.RtJioCommonRequestHandler;

/**
 * This Class Implement all operation related to FCAPS. for example upload of
 * alarm, counter and configuration sheet
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRDraftManager implements DraftManager, RMREventProcessor {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();

	@Override
	public void processEvent(RMREventPojo eventTracking) {

		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), "processEvent",
				"processing event in RMRDraftManager for eventTracking.getEventName() ");

		switch (eventTracking.getEventName()) {
		case RMSEventConstant.RMR_EVENT_SAVE_AS_DRAFT:
			saveAsDraft(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_GET_DRAFT:
			getDraftInfo(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_GET_DRAFT_STATUS:
			getDraftStatus(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_UPDATE_DRAFT:
			updateDraft(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_DELETE_DRAFT:
			deleteDraft(eventTracking);
			break;
		case RMSEventConstant.RMR_EVENT_UPDATE_DRAFT_STATUS:
			updateDraftStatus(eventTracking);
			break;
		default:
			break;
		}

	}

	@Override
	public void saveAsDraft(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "saveAsDraft";

		RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String provisionBinaryJson = new String(eventTracking.getRequestStream());

			JsonObject jsonObject = (new JsonParser().parse(provisionBinaryJson)).getAsJsonObject();
			jsonObject.addProperty(DraftOperationConstantsEnum.LAST_MODIFIED.getValue(), System.currentTimeMillis());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					jsonObject.toString(), "Request Data", eventTracking.getFlowId(), eventTracking.getPublisherName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request : " + jsonObject.toString());

			JsonElement vnfId = jsonObject.get(DraftOperationConstantsEnum.VNF_ID.getValue());
			JsonElement operation = jsonObject.get(DraftOperationConstantsEnum.OPERATION.getValue());

			if (vnfId == null || operation == null) {
				RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_INVALID.increment();
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						VNFDraftOperationErrorMessageEnum.ERROR_MESSAGE_VNF_ID_OR_OPERATION_IS_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_INVALID.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"VNF ID Recieved : " + vnfId.getAsString() + ", Operation : " + operation.getAsString());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					provisionBinaryJson, "save draft information in database", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			// Code to write Data in ES

			String identifier = vnfId.getAsString() + "_" + operation.getAsString();

			EsManager.getInstance().getDraftOperationImpl().saveAsDraft(identifier, jsonObject.toString());

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_SUCCESS.increment();

			ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Save as Draft", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	@Override
	public void getDraftInfo(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "getDraftInfo";

		RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String vnfId = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.VNF_ID.getValue());
			String status = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.STATUS.getValue());
			String operation = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.OPERATION.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "Request to get Draft Info for | vnf Id = " + vnfId + " | status = " + status
							+ " | operation = " + operation,
					eventTracking.getFlowId(), eventTracking.getPublisherName());

			if (vnfId != null && operation != null) {

				String identifier = vnfId + "_" + operation;

				JSONObject obj = new JSONObject(
						EsManager.getInstance().getDraftOperationImpl().getDraftInfo(identifier).toString());

				payload.setAppData(obj);

			} else {
				JSONObject obj = new JSONObject();
				obj.put("vnfStatus", new JSONArray(
						EsManager.getInstance().getDraftOperationImpl().getAllDraftInfo(status, operation)));
				payload.setAppData(obj);
			}

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					payload.toString(), "get draft information from database", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_SUCCESS.increment();
			ccAsnPojo.addClearCode(ClearCodes.GET_DRAFT_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in get Draft Info ", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_INFO_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.GET_DRAFT_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void getDraftStatus(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "getDraftStatus";

		RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String status = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.STATUS.getValue());
			String operation = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.OPERATION.getValue());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request to get Draft Status for " + status);

			JSONObject obj = new JSONObject();

			if (status != null && !"all".equalsIgnoreCase(status)) {
				obj.put(DraftOperationConstantsEnum.STATUS.getValue(),
						EsManager.getInstance().getDraftOperationImpl().getDraftStatusInfo(status, operation));
			} else {
				JSONObject obj1 = new JSONObject();
				obj1.put(DraftOperationConstantsEnum.COMPLETED.getValue(),
						EsManager.getInstance().getDraftOperationImpl()
								.getDraftStatusInfo(DraftOperationConstantsEnum.COMPLETED.getValue(), operation));
				obj1.put(DraftOperationConstantsEnum.DRAFT.getValue(), EsManager.getInstance().getDraftOperationImpl()
						.getDraftStatusInfo(DraftOperationConstantsEnum.DRAFT.getValue(), operation));
				obj1.put(DraftOperationConstantsEnum.PENDING.getValue(), EsManager.getInstance().getDraftOperationImpl()
						.getDraftStatusInfo(DraftOperationConstantsEnum.PENDING.getValue(), operation));
				obj.put(DraftOperationConstantsEnum.STATUS.getValue(), obj1);
			}

			payload.setAppData(obj);

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					payload.toString(), "get draft status from database", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Response Send : " + payload.toString());

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_SUCCESS.increment();
			ccAsnPojo.addClearCode(ClearCodes.GET_DRAFT_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Getting Draft Info", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_GET_DRAFT_STATUS_INFO_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.GET_DRAFT_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	@Override
	public void updateDraft(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "updateDraft";

		RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String provisionBinaryJson = new String(eventTracking.getRequestStream());

			JsonObject jsonObject = (new JsonParser().parse(provisionBinaryJson)).getAsJsonObject();
			jsonObject.addProperty(DraftOperationConstantsEnum.LAST_MODIFIED.getValue(), System.currentTimeMillis());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					jsonObject.toString(), "Request Data", eventTracking.getFlowId(), eventTracking.getPublisherName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request : " + jsonObject.toString());

			JsonElement vnfId = jsonObject.get(DraftOperationConstantsEnum.VNF_ID.getValue());
			JsonElement operation = jsonObject.get(DraftOperationConstantsEnum.OPERATION.getValue());

			if (vnfId == null || operation == null) {
				RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_INVALID.increment();
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						VNFDraftOperationErrorMessageEnum.ERROR_MESSAGE_VNF_ID_OR_OPERATION_IS_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_INVALID.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"VNF ID Recieved : " + vnfId.getAsString() + ", Operation : " + operation.getAsString());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					provisionBinaryJson, "save draft information in database", eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			// Code to write Data in ES

			String identifier = vnfId.getAsString() + "_" + operation.getAsString();

			EsManager.getInstance().getDraftOperationImpl().saveAsDraft(identifier, jsonObject.toString());

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_SUCCESS.increment();

			ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Save as Draft", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_SAVE_AS_DRAFT_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.SAVE_AS_DRAFT_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	@Override
	public void deleteDraft(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "deleteDraft";

		RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String vnfId = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.VNF_ID.getValue());
			String operation = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.OPERATION.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"vnf Id = " + vnfId, "Request API ", eventTracking.getFlowId(), eventTracking.getPublisherName());

			loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					"Request : vnf Id = " + vnfId);

			if (vnfId == null) {
				RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_INVALID.increment();
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						VNFDraftOperationErrorMessageEnum.ERROR_MESSAGE_VNF_ID_OR_OPERATION_IS_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.DELETE_DRAFT_REQUEST_INVALID.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			EsManager.getInstance().getDraftOperationImpl().deleteDraft(vnfId, operation);

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());

			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_SUCCESS.increment();

			ccAsnPojo.addClearCode(ClearCodes.DELETE_DRAFT_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {

			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Delete Draft", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_DELETE_DRAFT_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.DELETE_DRAFT_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

	private void updateDraftStatus(RMREventPojo eventTracking) {

		ResponsePayload payload = new ResponsePayload();

		final String methodName = "updateDraftStatus";

		RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_REQUEST.increment();

		ClearCodeAsnPojo ccAsnPojo = RtJioRMSCacheManager.getInstance().getClearCodeObj();

		try {

			String vnfId = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.VNF_ID.getValue());
			String operation = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.OPERATION.getValue());
			String status = eventTracking.getRequestParams().get(DraftOperationConstantsEnum.STATUS.getValue());

			loggerWriter.writeApiLevelLog(RMSLoggerTypeEnum.INFO.getValue(), this.getClass().getName(), methodName,
					null, "Request Parameters : " + vnfId + ", " + operation + ", " + status, eventTracking.getFlowId(),
					eventTracking.getPublisherName());

			if (vnfId == null || operation == null || status == null) {
				RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_INVALID.increment();
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						VNFDraftOperationErrorMessageEnum.ERROR_MESSAGE_VNF_ID_OR_OPERATION_IS_MISSING.getValue());
				ccAsnPojo.addClearCode(ClearCodes.UPDATE_DRAFT_STATUS_INVALID.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			if (!(status.equals(DraftOperationConstantsEnum.PENDING.getValue())
					|| status.equals(DraftOperationConstantsEnum.COMPLETED.getValue())
					|| status.equals(DraftOperationConstantsEnum.DRAFT.getValue()))) {
				RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_INVALID.increment();
				payload.setHttpStatusCode(400);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						"Status value is invalid, Should be one of " + DraftOperationConstantsEnum.PENDING.getValue()
								+ ", " + DraftOperationConstantsEnum.COMPLETED.getValue() + ", "
								+ DraftOperationConstantsEnum.DRAFT.getValue());
				ccAsnPojo.addClearCode(ClearCodes.UPDATE_DRAFT_STATUS_INVALID.getValue(), ClearCodeLevel.PROTOCOL);
				return;
			}

			// Code to update Data in ES

			if (!EsManager.getInstance().getDraftOperationImpl().updateDraftStatus(vnfId, operation, status)) {
				RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_FAILURE.increment();
				payload.setHttpStatusCode(404);
				payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
				payload.setErrorMessage(
						VNFDraftOperationErrorMessageEnum.ERROR_MESSAGE_DRAFT_DATA_NOT_AVAILABLE.getValue());
				ccAsnPojo.addClearCode(ClearCodes.UPDATE_DRAFT_STATUS_DATA_NOT_AVAILABLE.getValue(),
						ClearCodeLevel.PROTOCOL);
				return;
			}

			payload.setHttpStatusCode(200);
			payload.setType(ResponseConstantsEnum.RESPONSE_SUCCESS.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_SUCCESS.increment();
			ccAsnPojo.addClearCode(ClearCodes.UPDATE_DRAFT_STATUS_SUCCESS.getValue(), ClearCodeLevel.PROTOCOL);

		} catch (Exception e) {
			loggerWriter.writeClassLevelExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(),
					methodName, "Error in Update Draft Status", e);

			loggerWriter.writeApiExceptionLog(RMSLoggerTypeEnum.ERROR.getValue(), this.getClass().getName(), methodName,
					eventTracking.getFlowId(), eventTracking.getPublisherName(), e);

			payload.setHttpStatusCode(500);
			payload.setType(ResponseConstantsEnum.RESPONSE_ERROR.getValue());
			payload.setErrorMessage(ResponseConstantsEnum.RESPONSE_INTERNAL_SERVICE_ERROR.getValue());
			RtJioRMSCounterNameEnum.CNTR_RMR_UPDATE_DRAFT_STATUS_FAILURE.increment();
			ccAsnPojo.addClearCode(ClearCodes.UPDATE_DRAFT_STATUS_FAILURE.getValue(), ClearCodeLevel.PROTOCOL);
		} finally {
			RtJioCommonRequestHandler.getInstance().sendResponseToMS(eventTracking, new JSONObject(payload), null);
			ClearCodeAsnUtility.getASNInstance().writeASNForClearCode(ccAsnPojo);
		}

	}

}
