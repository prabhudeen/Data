package com.rjil.rms.draft;

/**
 * 
 * Constant to build Json FCAPS to write in ES
 * 
 * @author kiran.jangid
 *
 */

public enum DraftOperationConstantsEnum {

	STATUS("status"),

	COMPLETED("completed"),
	
	PENDING("pending"),

	DRAFT("draft"),

	VNF_ID("vnfID"),

	OPERATION("operation"),

	VNF_NAME("vnfName"),

	VENDOR_ID("vendorID"),

	VENDOR_NAME("vendorName"),

	LAST_MODIFIED("lastModified"),
	
	OPERATION_ONBOARD("onboard"),
	
	OPERATION_DEPLOYMENT("deployment"),
	
	OPERATION_INSTANTIATE("instantiate"),

	STEP("step"), 
	
	USERNAME("userName"), 
	
	USER_STATUS("userStatus");

	private String value;

	private DraftOperationConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
