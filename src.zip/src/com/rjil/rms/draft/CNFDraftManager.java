package com.rjil.rms.draft;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * @author Nikhil.Dosapati
 *
 */

public interface CNFDraftManager {
	
	/**
	 * 
	 * Interface to save Draft Info
	 * 
	 * @param eventTracking
	 */
	
	void saveAsDraft(RMREventPojo eventTracking);

	/**
	 * 
	 * Interface to get draft info
	 * 
	 * @param eventTracking
	 */

	void getDraftInfo(RMREventPojo eventTracking);

	/**
	 * Interface to update draft information
	 * 
	 * @param eventTracking
	 */

	void updateDraft(RMREventPojo eventTracking);

	/**
	 * Interface to delete draft Data
	 * 
	 * @param eventTracking
	 */

	void deleteDraft(RMREventPojo eventTracking);

}
