package com.rjil.rms.draft;

/**
 * 
 * @author Annasamudram.H
 *
 */

public enum CNFDraftOperationConstantsEnum {
	
	STATUS("status"),

	COMPLETED("completed"),
	
	PENDING("pending"),

	DRAFT("draft"),

	CNF_ID("cnf-id"),

	OPERATION("operation"),

	CNF_NAME("cnf-name"),

	VENDOR_ID("cnf-vendor-id"),

	VENDOR_NAME("cnf-vendor-name"),

	LAST_MODIFIED("lastModified"),
	
	OPERATION_ONBOARD("onboard"),
	
	OPERATION_DEPLOYMENT("deployment"),
	
	OPERATION_INSTANTIATE("instantiate"),

	STEP("step"), 
	
	USERNAME("userName"), 
	
	USER_STATUS("userStatus");

	private String value;

	private CNFDraftOperationConstantsEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	

}
