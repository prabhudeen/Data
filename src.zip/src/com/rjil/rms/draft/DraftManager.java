package com.rjil.rms.draft;

import com.rjil.rms.event.RMREventPojo;

/**
 * 
 * Interface that provide Draft Operations
 * 
 * @author Kiran.Jangid
 *
 */

public interface DraftManager {

	/**
	 * 
	 * Interface to save draft info
	 * 
	 * @param eventTracking
	 */

	void saveAsDraft(RMREventPojo eventTracking);

	/**
	 * 
	 * Interface to get draft info
	 * 
	 * @param eventTracking
	 */

	void getDraftInfo(RMREventPojo eventTracking);

	/**
	 * Interface to update draft information
	 * 
	 * @param eventTracking
	 */

	void updateDraft(RMREventPojo eventTracking);

	/**
	 * Interface to delete draft Data
	 * 
	 * @param eventTracking
	 */

	void deleteDraft(RMREventPojo eventTracking);

}
