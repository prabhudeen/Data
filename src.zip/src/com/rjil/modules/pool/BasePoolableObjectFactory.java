
package com.rjil.modules.pool;

/**
 * A base implementation of <code>PoolableObjectFactory</code>.
 * <p>
 * All operations defined here are essentially no-op's.
 *
 * @see PoolableObjectFactory
 * @see BaseKeyedPoolableObjectFactory
 * 
 * @author aayush.bhatnagar
 */
public abstract class BasePoolableObjectFactory implements PoolableObjectFactory {
    public abstract Object makeObject()
        throws Exception;

    /** No-op. */
    public void destroyObject(Object obj)
        throws Exception  {
    }

    /**
     * This implementation always returns <tt>true</tt>.
     * @return <tt>true</tt>
     */
    public boolean validateObject(Object obj) {
        return true;
    }

    /** No-op. */
    public void activateObject(Object obj)
        throws Exception {
    }

    /** No-op. */
    public void passivateObject(Object obj)
        throws Exception {
    }
}
