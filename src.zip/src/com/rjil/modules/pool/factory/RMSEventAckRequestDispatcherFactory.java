package com.rjil.modules.pool.factory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;
import com.rjil.rms.rest.handlers.RMSEventAckRequestDispatcher;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMSEventAckRequestDispatcherFactory implements PooledObjectFactory<RMSEventAckRequestDispatcher> {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String OBJECT_NAME = "RMSEventAckRequestDispatcherFactory";
	private static final String CLASS_NAME = RMSEventAckRequestDispatcherFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<RMSEventAckRequestDispatcher> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "activateObject",
				"Activating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public void destroyObject(PooledObject<RMSEventAckRequestDispatcher> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "destroyObject",
				"Destroying object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public PooledObject<RMSEventAckRequestDispatcher> makeObject() throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "makeObject",
				"Creating object from the object pool of " + OBJECT_NAME);
		return new DefaultPooledObject<>(new RMSEventAckRequestDispatcher());
	}

	@Override
	public void passivateObject(PooledObject<RMSEventAckRequestDispatcher> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "passivateObject",
				"Passivating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public boolean validateObject(PooledObject<RMSEventAckRequestDispatcher> arg0) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "validateObject",
				"Validating object from the object pool of " + OBJECT_NAME);
		return false;
	}

}
