package com.rjil.modules.pool.factory;

import com.jio.telco.framework.clearcode.ClearCodeAsnPojo;
import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class RMRClearCodeAsnPojoFactory implements PooledObjectFactory<ClearCodeAsnPojo> {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String OBJECT_NAME = "ClearCodeAsnPojo";
	private static final String CLASS_NAME = RMRClearCodeAsnPojoFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<ClearCodeAsnPojo> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "activateObject",
				"Activating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public void destroyObject(PooledObject<ClearCodeAsnPojo> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "destroyObject",
				"Destroying object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public PooledObject<ClearCodeAsnPojo> makeObject() throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "makeObject",
				"Creating object from the object pool of " + OBJECT_NAME);
		return new DefaultPooledObject<>(new ClearCodeAsnPojo());
	}

	@Override
	public void passivateObject(PooledObject<ClearCodeAsnPojo> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "passivateObject",
				"Passivating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public boolean validateObject(PooledObject<ClearCodeAsnPojo> arg0) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "validateObject",
				"Validating object from the object pool of " + OBJECT_NAME);
		return false;
	}
}