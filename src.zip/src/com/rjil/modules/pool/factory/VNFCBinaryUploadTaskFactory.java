package com.rjil.modules.pool.factory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;
import com.rjil.rms.binary.util.DownloadBinaryThread;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class VNFCBinaryUploadTaskFactory implements PooledObjectFactory<DownloadBinaryThread> {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String OBJECT_NAME = "DownloadBinaryThread";
	private static final String CLASS_NAME = VNFCBinaryUploadTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<DownloadBinaryThread> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "activateObject",
				"Activating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public void destroyObject(PooledObject<DownloadBinaryThread> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "destroyObject",
				"Destroying object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public PooledObject<DownloadBinaryThread> makeObject() throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "makeObject",
				"Creating object from the object pool of " + OBJECT_NAME);
		return new DefaultPooledObject<>(new DownloadBinaryThread());
	}

	@Override
	public void passivateObject(PooledObject<DownloadBinaryThread> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "passivateObject",
				"Passivating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public boolean validateObject(PooledObject<DownloadBinaryThread> arg0) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "validateObject",
				"Validating object from the object pool of " + OBJECT_NAME);
		return false;
	}

}
