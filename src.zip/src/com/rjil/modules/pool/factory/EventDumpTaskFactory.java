package com.rjil.modules.pool.factory;

import com.jio.telco.framework.pool.PooledObject;
import com.jio.telco.framework.pool.PooledObjectFactory;
import com.jio.telco.framework.pool.impl.DefaultPooledObject;
import com.rjil.rms.ha.EventDumpTask;
import com.rjil.rms.logger.LoggerWriter;
import com.rjil.rms.logger.RMSLoggerTypeEnum;

/**
 * 
 * @author Kiran.Jangid
 *
 */

public class EventDumpTaskFactory implements PooledObjectFactory<EventDumpTask> {

	private LoggerWriter loggerWriter = LoggerWriter.getInstance();
	private static final String OBJECT_NAME = "EventDumpTask";
	private static final String CLASS_NAME = EventDumpTaskFactory.class.getSimpleName();

	@Override
	public void activateObject(PooledObject<EventDumpTask> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "activateObject",
				"Activating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public void destroyObject(PooledObject<EventDumpTask> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "destroyObject",
				"Destroying object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public PooledObject<EventDumpTask> makeObject() throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "makeObject",
				"Creating object from the object pool of " + OBJECT_NAME);
		return new DefaultPooledObject<>(new EventDumpTask());
	}

	@Override
	public void passivateObject(PooledObject<EventDumpTask> arg0) throws Exception {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "passivateObject",
				"Passivating object from the object pool of " + OBJECT_NAME);
	}

	@Override
	public boolean validateObject(PooledObject<EventDumpTask> arg0) {
		loggerWriter.writeClassLevelLog(RMSLoggerTypeEnum.INFO.getValue(), CLASS_NAME, "validateObject",
				"Validating object from the object pool of " + OBJECT_NAME);
		return false;
	}
}
