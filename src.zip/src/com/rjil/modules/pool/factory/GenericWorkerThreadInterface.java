package com.rjil.modules.pool.factory;

/**
 *
 * This interface declares a method to reset WorkerThread objects to their initial state
 *
 */
public interface GenericWorkerThreadInterface {
	
	public void reset();
	

}
