
package com.rjil.modules.pool;

/**
 * A factory interface for creating {@link ObjectPool}s.
 *
 * @see ObjectPool
 * 
 * @author aayush.bhatnagar
 */
public interface ObjectPoolFactory {
    /**
     * Create and return a new {@link ObjectPool}.
     * @return a new {@link ObjectPool}
     * @throws IllegalStateException when this pool factory is not configured properly
     */
    ObjectPool createPool() throws IllegalStateException;
}
