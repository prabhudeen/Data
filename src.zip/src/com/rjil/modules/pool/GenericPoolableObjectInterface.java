package com.rjil.modules.pool;

/**
 * @author akarshita.saxena
 * This interface declares a method to reset all Poolable objects to their initial state
 *
 */
public interface GenericPoolableObjectInterface {
	
	public void reset();

}
