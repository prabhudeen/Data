
package com.rjil.modules.pool;

/**
 * A factory for creating {@link KeyedObjectPool}s.
 *
 * @see KeyedObjectPool
 * 
 * @author aayush.bhatnagar
 *
 */
public interface KeyedObjectPoolFactory {
    /**
     * Create a new {@link KeyedObjectPool}.
     * @return a new {@link KeyedObjectPool}
     * @throws IllegalStateException when this pool factory is not configured properly
     */
    KeyedObjectPool createPool() throws IllegalStateException;
}
