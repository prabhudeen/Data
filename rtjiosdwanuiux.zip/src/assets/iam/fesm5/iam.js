import { Injectable, Component, NgModule, APP_INITIALIZER, HostListener, defineInjectable, inject } from '@angular/core';
import { HttpClient, HttpResponse, HTTP_INTERCEPTORS, HttpHeaders } from '@angular/common/http';
import { utils, padding, ModeOfOperation } from 'aes-js';
import { Router, NavigationEnd } from '@angular/router';
import { __values } from 'tslib';
import { CookieService } from 'ngx-cookie-service';
import * as Fingerprint2 from 'fingerprintjs2sync';
import { CookieService as CookieService$1 } from 'ngx-cookie-service/cookie-service/cookie.service';
import { Subject, throwError, Observable } from 'rxjs';
import { retry, catchError, delay, filter, tap } from 'rxjs/operators';
import { Location } from '@angular/common';
import { util } from 'node-forge';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var CONSTANTS = /** @class */ (function () {
    function CONSTANTS() {
    }
    /**
     * @return {?}
     */
    CONSTANTS.prototype.getProtocol = /**
     * @return {?}
     */
    function () {
        return location.protocol;
    };
    CONSTANTS.PROTOCOL = location.protocol + "//";
    CONSTANTS.WEBSOCKET_PROTOCOL = location.protocol.localeCompare('https:') === 0 ? 'wss://' : 'ws://';
    CONSTANTS.IDENTITY_CONTEXT = '/IAM/identity/';
    CONSTANTS.ACCESS_CONTEXT = '/IAM/access/';
    CONSTANTS.TRACE_CONTEXT = '/IAM/trace/';
    return CONSTANTS;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var AppConfigurationService = /** @class */ (function () {
    function AppConfigurationService(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * @param {?} filePath
     * @return {?}
     */
    AppConfigurationService.prototype.loadConfiguration = /**
     * @param {?} filePath
     * @return {?}
     */
    function (filePath) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(filePath).toPromise().then(function (response) {
                _this.appConfiguration = response;
                resolve();
            }).catch(function (response) {
                console.log(response);
                console.log("could not load configuration file error: \n " + JSON.stringify(response));
                reject("could not load configuration file error: \n " + JSON.stringify(response));
            });
        });
    };
    /**
     * @return {?}
     */
    AppConfigurationService.prototype.getConfiguration = /**
     * @return {?}
     */
    function () {
        return this.appConfiguration;
    };
    AppConfigurationService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    AppConfigurationService.ctorParameters = function () { return [
        { type: HttpClient }
    ]; };
    /** @nocollapse */ AppConfigurationService.ngInjectableDef = defineInjectable({ factory: function AppConfigurationService_Factory() { return new AppConfigurationService(inject(HttpClient)); }, token: AppConfigurationService, providedIn: "root" });
    return AppConfigurationService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
var forge = require('node-forge');
var RsaUtils = /** @class */ (function () {
    function RsaUtils() {
    }
    /**
     * @param {?} pem_file_content
     * @return {?}
     */
    RsaUtils.privateKeyFromPEM = /**
     * @param {?} pem_file_content
     * @return {?}
     */
    function (pem_file_content) {
        RsaUtils.privateKey = forge.pki.privateKeyFromPem(pem_file_content);
    };
    /**
     * @return {?}
     */
    RsaUtils.publicKeyToPEM = /**
     * @return {?}
     */
    function () {
        return forge.pki.publicKeyToPem(RsaUtils.publicKey);
    };
    /**
     * @param {?} pem_file_content
     * @return {?}
     */
    RsaUtils.publicKeyFromPEM = /**
     * @param {?} pem_file_content
     * @return {?}
     */
    function (pem_file_content) {
        RsaUtils.publicKey = forge.pki.publicKeyFromPem(pem_file_content);
    };
    /**
     * @param {?} message
     * @param {?=} pemPublicKey
     * @return {?}
     */
    RsaUtils.encrypt = /**
     * @param {?} message
     * @param {?=} pemPublicKey
     * @return {?}
     */
    function (message, pemPublicKey) {
        if (pemPublicKey) {
            return forge.util.encode64(forge.pki.privateKeyFromPem(pemPublicKey).encrypt(message, 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            }));
        }
        else if (RsaUtils.publicKey) {
            return forge.util.encode64(RsaUtils.publicKey.encrypt(message, 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            }));
        }
        else {
            console.log('public key is not defined');
            return null;
        }
    };
    /**
     * @param {?} cipherText
     * @param {?=} pemPrivateKey
     * @return {?}
     */
    RsaUtils.decrypt = /**
     * @param {?} cipherText
     * @param {?=} pemPrivateKey
     * @return {?}
     */
    function (cipherText, pemPrivateKey) {
        if (pemPrivateKey) {
            return forge.pki.privateKeyFromPem(pemPrivateKey).decrypt(forge.util.decode64(cipherText), 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            });
        }
        else if (RsaUtils.privateKey) {
            return RsaUtils.privateKey.decrypt(forge.util.decode64(cipherText), 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            });
        }
        else {
            console.log('private key is not defined');
            return null;
        }
    };
    /**
     * @return {?}
     */
    RsaUtils.prototype.privateKeyToPEM = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var rsaPrivateKey = forge.pki.privateKeyToAsn1(RsaUtils.privateKey);
        /** @type {?} */
        var privateKeyInfo = forge.pki.wrapRsaPrivateKey(rsaPrivateKey);
        return forge.pki.privateKeyInfoToPem(privateKeyInfo);
    };
    RsaUtils.publicKey = null;
    RsaUtils.privateKey = null;
    return RsaUtils;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var AesUtils = /** @class */ (function () {
    function AesUtils() {
    }
    /**
     * @param {?} aesKey
     * @return {?}
     */
    AesUtils.setAesEncryptionKey = /**
     * @param {?} aesKey
     * @return {?}
     */
    function (aesKey) {
        AesUtils.aesKey = aesKey;
    };
    /**
     * @param {?} message
     * @param {?=} aesKey
     * @return {?}
     */
    AesUtils.encrypt = /**
     * @param {?} message
     * @param {?=} aesKey
     * @return {?}
     */
    function (message, aesKey) {
        if (!aesKey) {
            aesKey = AesUtils.aesKey;
        }
        /** @type {?} */
        var key = utils.utf8.toBytes(aesKey);
        /** @type {?} */
        var textBytes = utils.utf8.toBytes(message);
        textBytes = new padding.pkcs7.pad(textBytes);
        /** @type {?} */
        var aesEcb = new ModeOfOperation.ecb(key);
        /** @type {?} */
        var encryptedBytes = aesEcb.encrypt(textBytes);
        return utils.hex.fromBytes(encryptedBytes);
    };
    /**
     * @param {?} cipher
     * @param {?=} aesKey
     * @return {?}
     */
    AesUtils.decrypt = /**
     * @param {?} cipher
     * @param {?=} aesKey
     * @return {?}
     */
    function (cipher, aesKey) {
        if (!aesKey) {
            aesKey = AesUtils.aesKey;
        }
        /** @type {?} */
        var key = utils.utf8.toBytes(aesKey);
        /** @type {?} */
        var aesEcb = new ModeOfOperation.ecb(key);
        /** @type {?} */
        var encryptedBytes = utils.hex.toBytes(cipher);
        /** @type {?} */
        var decryptedBytes = aesEcb.decrypt(encryptedBytes);
        decryptedBytes = padding.pkcs7.strip(decryptedBytes);
        return utils.utf8.fromBytes(decryptedBytes);
    };
    /**
     * @param {?=} length
     * @return {?}
     */
    AesUtils.generateRandomAesKey = /**
     * @param {?=} length
     * @return {?}
     */
    function (length) {
        if (length === void 0) { length = 16; }
        /** @type {?} */
        var map = new Map();
        map.set(0, 'a').set(1, 'b').set(2, 'c').set(3, 'd').set(4, 'e').set(5, 'f').
            set(6, 'g').set(7, 'h').set(8, 'i').set(9, 'j').set(10, 'k').set(11, 'l').set(12, 'm').
            set(13, 'n').set(14, 'o').set(15, 'p').set(16, 'q').set(17, 'r').
            set(18, 's').set(19, 't').set(20, 'u').set(21, 'v').set(22, 'w').set(23, 'x').set(24, 'y').
            set(25, 'z').set(26, 'A').set(27, 'B').set(28, 'C').set(29, 'D').set(30, 'E').set(31, 'F').
            set(32, 'G').set(33, 'H').set(34, 'I').set(35, 'J').set(36, 'K').set(37, 'L').set(38, 'M').
            set(39, 'N').set(40, 'O').set(41, 'P').set(42, 'Q').set(43, 'R').set(44, 'S').set(45, 'T').
            set(46, 'U').set(47, 'V').set(48, 'W').set(49, 'X').set(50, 'Y').set(51, 'Z');
        /** @type {?} */
        var key = '';
        for (var i = 0; i < length; i++) {
            key = key.concat(map.get(Math.floor(Math.random() * 52)));
        }
        return key;
    };
    /**
     * @return {?}
     */
    AesUtils.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    AesUtils.aesKey = null;
    return AesUtils;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var NavigateService = /** @class */ (function () {
    function NavigateService(router) {
        this.router = router;
    }
    /**
     * @param {?} path
     * @return {?}
     */
    NavigateService.prototype.navigate = /**
     * @param {?} path
     * @return {?}
     */
    function (path) {
        this.router.navigate(path);
    };
    NavigateService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    NavigateService.ctorParameters = function () { return [
        { type: Router }
    ]; };
    /** @nocollapse */ NavigateService.ngInjectableDef = defineInjectable({ factory: function NavigateService_Factory() { return new NavigateService(inject(Router)); }, token: NavigateService, providedIn: "root" });
    return NavigateService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var SessionService = /** @class */ (function () {
    function SessionService(cookieService, appSetting, navigateService) {
        this.cookieService = cookieService;
        this.appSetting = appSetting;
        this.navigateService = navigateService;
        this.hashKey = new Fingerprint2({ excludeAdBlock: true }).getSync().fprint.substr(0, 16);
    }
    /*
    *This function is used to fetch stored session data
    */
    /**
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.getSessionData = /**
     * @param {?=} key
     * @return {?}
     */
    function (key) {
        if (key === void 0) { key = 'globals'; }
        /** @type {?} */
        var data;
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            data = JSON.parse(this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : '{}');
        }
        else {
            console.log('into clearing session');
            this.clearSessionDataAndGotoSessionExpirePage();
            data = /** @type {?} */ ({});
        }
        return /** @type {?} */ (data);
    };
    /*
    *
    */
    /**
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.getAesKey = /**
     * @param {?=} key
     * @return {?}
     */
    function (key) {
        if (key === void 0) { key = 'aesKey'; }
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : null;
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return null;
    };
    /*
    *
    */
    /**
     * @param {?} sessionData
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.setSessionData = /**
     * @param {?} sessionData
     * @param {?=} key
     * @return {?}
     */
    function (sessionData, key) {
        if (key === void 0) { key = 'globals'; }
        /** @type {?} */
        var data = {};
        /** @type {?} */
        var userInformation = {
            currentUser: {
                userName: sessionData.userName,
                appData: sessionData.appData,
                nodeNameCircle: sessionData.nodeNameCircle
            }
        };
        if (sessionData.neNameCircleName) {
            userInformation.currentUser['neNameCircleName'] = sessionData.neNameCircleName;
        }
        if (sessionData.aesKey) {
            data['aesKey'] = sessionData.aesKey;
        }
        data[key] = userInformation;
        this.cookieService.set(key, AesUtils.encrypt(JSON.stringify(data), this.hashKey));
    };
    /*
    *
    */
    /**
     * @param {...?} args
     * @return {?}
     */
    SessionService.prototype.clearSessionData = /**
     * @param {...?} args
     * @return {?}
     */
    function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (args.length > 0) {
            try {
                for (var args_1 = __values(args), args_1_1 = args_1.next(); !args_1_1.done; args_1_1 = args_1.next()) {
                    var arg = args_1_1.value;
                    this.cookieService.delete(arg);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (args_1_1 && !args_1_1.done && (_a = args_1.return)) _a.call(args_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        else {
            this.cookieService.deleteAll();
            localStorage.clear();
        }
        var e_1, _a;
    };
    /*
    *
    */
    /**
     * @param {?=} timeStamp
     * @return {?}
     */
    SessionService.prototype.putDateForCookieExpiry = /**
     * @param {?=} timeStamp
     * @return {?}
     */
    function (timeStamp) {
        /** @type {?} */
        var sessionTime = 600000;
        if (this.appSetting.getConfiguration()) {
            sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
        }
        if (!timeStamp) {
            this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
        }
        else {
            this.cookieService.set('expiryTime', timeStamp);
        }
    };
    /*
    *
    */
    /**
     * @return {?}
     */
    SessionService.prototype.getDateForCookieExpiry = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var sessionTime = 600000;
        if (this.appSetting.getConfiguration()) {
            sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
        }
        if (this.cookieService.check('expiryTime')) {
            return Number.parseInt(this.cookieService.get('expiryTime'));
        }
        this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
        return (new Date().getTime() + sessionTime);
    };
    /*
    *
    */
    /**
     * @param {?} userToken
     * @return {?}
     */
    SessionService.prototype.setUserTokenData = /**
     * @param {?} userToken
     * @return {?}
     */
    function (userToken) {
        this.cookieService.set('userToken', AesUtils.encrypt(userToken, this.hashKey));
    };
    /*
    *
    */
    /**
     * @return {?}
     */
    SessionService.prototype.getUserTokenData = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return this.cookieService.check('userToken') ? AesUtils.decrypt(this.cookieService.get('userToken'), this.hashKey) : null;
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return null;
    };
    /*
    *
    */
    /**
     * @param {?} moduleRestriction
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.setSessionDataForModuleRestriction = /**
     * @param {?} moduleRestriction
     * @param {?=} key
     * @return {?}
     */
    function (moduleRestriction, key) {
        if (key === void 0) { key = 'moduleRestriction'; }
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(moduleRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    };
    /*
    *
    */
    /**
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.getSessionDataForModuleRestriction = /**
     * @param {?=} key
     * @return {?}
     */
    function (key) {
        if (key === void 0) { key = 'moduleRestriction'; }
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    };
    /*
    *
    */
    /**
     * @param {?} structuredRestriction
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.setSessionDataForStructuredRestriction = /**
     * @param {?} structuredRestriction
     * @param {?=} key
     * @return {?}
     */
    function (structuredRestriction, key) {
        if (key === void 0) { key = 'structuredRestriction'; }
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(structuredRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    };
    /*
    *
    */
    /**
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.getSessionDataForStructuredRestriction = /**
     * @param {?=} key
     * @return {?}
     */
    function (key) {
        if (key === void 0) { key = 'structuredRestriction'; }
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    };
    /*
    *
    */
    /**
     * @param {?} nodeCircleRestriction
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.setSessionDataForNodeCircleRestriction = /**
     * @param {?} nodeCircleRestriction
     * @param {?=} key
     * @return {?}
     */
    function (nodeCircleRestriction, key) {
        if (key === void 0) { key = 'nodeCircleRestriction'; }
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(nodeCircleRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    };
    /*
    *
    */
    /**
     * @param {?=} key
     * @return {?}
     */
    SessionService.prototype.getSessionDataForNodeCircleRestriction = /**
     * @param {?=} key
     * @return {?}
     */
    function (key) {
        if (key === void 0) { key = 'nodeCircleRestriction'; }
        /** @type {?} */
        var expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    };
    /*
    *
    */
    /**
     * @return {?}
     */
    SessionService.prototype.clearSessionDataAndGotoSessionExpirePage = /**
     * @return {?}
     */
    function () {
        this.resetVariables();
        this.clearSessionData();
        if (this.appSetting.getConfiguration()) {
            console.log(this.appSetting.getConfiguration().sessionExpiredPage);
            this.navigateService.navigate([this.appSetting.getConfiguration().sessionExpiredPage]);
        }
    };
    /*
    *
    */
    /**
     * @return {?}
     */
    SessionService.prototype.clearSessionDataAndGotoLogoutPage = /**
     * @return {?}
     */
    function () {
        this.resetVariables();
        this.clearSessionData();
        if (this.appSetting.getConfiguration()) {
            this.navigateService.navigate([this.appSetting.getConfiguration().logoutPath]);
        }
    };
    /**
     * @return {?}
     */
    SessionService.prototype.resetVariables = /**
     * @return {?}
     */
    function () {
        this.globals = null;
        this.selectedCircleName = null;
        this.selectedNeName = null;
        this.selectedNeShortName = null;
        this.parsedNodeCircleJson = null;
        this.nodeNameCircle = null;
        this.structuredRestriction = null;
        this.moduleRestriction = null;
        this.mapNeNameCircleName = null;
        this.nodeNameList = [];
    };
    SessionService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    SessionService.ctorParameters = function () { return [
        { type: CookieService },
        { type: AppConfigurationService },
        { type: NavigateService }
    ]; };
    /** @nocollapse */ SessionService.ngInjectableDef = defineInjectable({ factory: function SessionService_Factory() { return new SessionService(inject(CookieService$1), inject(AppConfigurationService), inject(NavigateService)); }, token: SessionService, providedIn: "root" });
    return SessionService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var WebSocketCallbackClass = /** @class */ (function () {
    function WebSocketCallbackClass() {
    }
    /**
     * @return {?}
     */
    WebSocketCallbackClass.getOnMessageObservable = /**
     * @return {?}
     */
    function () {
        return WebSocketCallbackClass.onMessageSubject.asObservable();
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.getOnOpenObservable = /**
     * @return {?}
     */
    function () {
        return WebSocketCallbackClass.onOpenSubject.asObservable();
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.getOnCloseObservable = /**
     * @return {?}
     */
    function () {
        return WebSocketCallbackClass.onCloseSubject.asObservable();
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.getOnErrorObservable = /**
     * @return {?}
     */
    function () {
        return WebSocketCallbackClass.onErrorSubject.asObservable();
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.getOnWebsocketReconnectObservable = /**
     * @return {?}
     */
    function () {
        return WebSocketCallbackClass.onWebsocketReconnectSubject.asObservable();
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.reInitializeObservables = /**
     * @return {?}
     */
    function () {
        WebSocketCallbackClass.onMessageSubject = new Subject();
        WebSocketCallbackClass.onOpenSubject = new Subject();
        WebSocketCallbackClass.onCloseSubject = new Subject();
        WebSocketCallbackClass.onErrorSubject = new Subject();
    };
    /**
     * @param {?} event
     * @return {?}
     */
    WebSocketCallbackClass.prototype.onMessage = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        WebSocketCallbackClass.onMessageSubject.next(event);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    WebSocketCallbackClass.prototype.onClose = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        console.log('websocket closed');
        WebSocketCallbackClass.onCloseSubject.next(event);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    WebSocketCallbackClass.prototype.onError = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        console.log(event);
        WebSocketCallbackClass.onErrorSubject.next(event);
    };
    /**
     * @param {?} event
     * @param {?} websocket
     * @return {?}
     */
    WebSocketCallbackClass.prototype.onOpen = /**
     * @param {?} event
     * @param {?} websocket
     * @return {?}
     */
    function (event, websocket) {
        console.log('websocket opened');
        WebSocketCallbackClass.onOpenSubject.next(event);
    };
    /**
     * @return {?}
     */
    WebSocketCallbackClass.prototype.onReconnect = /**
     * @return {?}
     */
    function () {
        console.log('websocket re-connected');
        WebSocketCallbackClass.onWebsocketReconnectSubject.next();
    };
    WebSocketCallbackClass.onMessageSubject = new Subject();
    WebSocketCallbackClass.onOpenSubject = new Subject();
    WebSocketCallbackClass.onCloseSubject = new Subject();
    WebSocketCallbackClass.onErrorSubject = new Subject();
    WebSocketCallbackClass.onWebsocketReconnectSubject = new Subject();
    return WebSocketCallbackClass;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var MessageMapping = /** @class */ (function () {
    function MessageMapping(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * @param {?} code
     * @return {?}
     */
    MessageMapping.getMessage = /**
     * @param {?} code
     * @return {?}
     */
    function (code) {
        return MessageMapping.messageMap.has(code) ? MessageMapping.messageMap.get(code) : 'unknown error code received';
    };
    /**
     * @param {?} filePath
     * @return {?}
     */
    MessageMapping.prototype.loadMesageMap = /**
     * @param {?} filePath
     * @return {?}
     */
    function (filePath) {
        this.httpClient.get(filePath).toPromise().then(function (response) {
            new Map(Object.entries(response)).forEach(function (value, key) {
                MessageMapping.messageMap.set(Number.parseInt(key), value);
            });
        }).catch(function (response) {
            console.log(response);
            console.log("could not load configuration file error: \n " + JSON.stringify(response));
        });
    };
    MessageMapping.messageMap = new Map();
    MessageMapping.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    MessageMapping.ctorParameters = function () { return [
        { type: HttpClient }
    ]; };
    /** @nocollapse */ MessageMapping.ngInjectableDef = defineInjectable({ factory: function MessageMapping_Factory() { return new MessageMapping(inject(HttpClient)); }, token: MessageMapping, providedIn: "root" });
    return MessageMapping;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var CacheManagerService = /** @class */ (function () {
    function CacheManagerService(appConfiguration, httpClient, sessionService, location, messageMapping) {
        var _this = this;
        this.appConfiguration = appConfiguration;
        this.httpClient = httpClient;
        this.sessionService = sessionService;
        this.location = location;
        this.messageMapping = messageMapping;
        this.websocketOpenPromise = new Promise(function (resolve, reject) {
            _this.resolveFn = resolve;
            _this.rejectFn = reject;
        });
    }
    /**
     * @return {?}
     */
    CacheManagerService.prototype.ngOnInit = /**
     * @return {?}
     */
    function () { };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        if (this.websocket) {
            this.websocket.close();
        }
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getAuthKey = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getauthkey');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project, 'operation': 'getauthkey' }),
            observe: /** @type {?} */ ('response')
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions)
                .pipe(retry(2), catchError(_this.handleError)).subscribe(function (resp) {
                if (resp.body.statusCode.type) {
                    RsaUtils.publicKeyFromPEM(resp.body.statusCode.AppData.pemFile);
                    _this.encryptionKey = resp.body.statusCode.AppData;
                    /** @type {?} */
                    var serverTime = resp.headers.has('Date') ? new Date(resp.headers.get('Date')).getTime() : new Date().getTime();
                    /** @type {?} */
                    var clientTime = new Date().getTime();
                    _this.timeAdjustment = serverTime - clientTime;
                    //this.sessionService.putDateForCookieExpiry();
                    resolve();
                }
                else {
                    reject();
                }
            }, function (error) {
                console.log('fetching rsa key failed');
                console.log(error);
                reject();
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getNodeShortNameFullNameJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeShortNameFullName');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getNodeShortNameFullName'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.neShortNameFullNameJson = {
                        'NodeName': resp.statusCode.AppData
                    };
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getCircleShortNameFullNameJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleShortNameFullName');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getCircleShortNameFullName'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.circleFullNameJsonResponse = {
                        CircleName: resp.statusCode.AppData
                    };
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getModuleToIdJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getShortCodeToIdMap');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getShortCodeToIdMap'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.shortCodeToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getNodeToIdJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeToIdMap');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getNodeToIdMap'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.nodeToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getCircleToIdJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleToIdMap');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getCircleToIdMap'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.circleToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getOperationToModuleNodeCircleJson = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getOperationToModuleNodeCircle');
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getOperationToModuleNodeCircle'
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                if (resp.statusCode.type) {
                    _this.OperationToAccessMapping = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, function (error) {
                console.log(error);
                reject(error);
            });
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getPathName = /**
     * @return {?}
     */
    function () {
        return window.location && window.location.hash && window.location.hash.substr(1);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    CacheManagerService.prototype.onStartupRouteChange = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.sessionService.globals = _this.sessionService.getSessionData().globals;
            if (!_this.sessionService.globals) {
                _this.sessionService.globals = {};
            }
            if (_this.appConfiguration.getConfiguration().loginPage && _this.appConfiguration.getConfiguration().nonRestrictedPages
                && _this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
                /** @type {?} */
                var pathName = _this.location.path();
                if (pathName.includes("?")) {
                    pathName = pathName.split("?")[0];
                }
                /** @type {?} */
                var restrictedPage = _this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
                /** @type {?} */
                var loggedIn = _this.sessionService.globals.currentUser;
                if (restrictedPage && !loggedIn) {
                    _this.location.go(_this.appConfiguration.getConfiguration().loginPage);
                    resolve();
                }
                else if (loggedIn) {
                    try {
                        if (!_this.sessionService.moduleRestriction) {
                            _this.sessionService.moduleRestriction = _this.sessionService.getSessionDataForModuleRestriction();
                        }
                        if (!_this.sessionService.structuredRestriction) {
                            _this.sessionService.structuredRestriction = _this.sessionService.getSessionDataForStructuredRestriction();
                        }
                        if (!_this.sessionService.parsedNodeCircleJson) {
                            _this.sessionService.parsedNodeCircleJson = _this.sessionService.getSessionDataForNodeCircleRestriction();
                        }
                        /** @type {?} */
                        var loginPage = _this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) != -1;
                        if (loginPage) {
                            _this.location.go(_this.appConfiguration.getConfiguration().defaultPageAfterLogin);
                        }
                        _this.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(function (resp) {
                            resolve();
                        }, function (error) {
                            console.log(error);
                            resolve();
                        });
                    }
                    catch (e) {
                        console.log(e);
                    }
                }
                else {
                    resolve();
                }
            }
        });
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.callWhenConfigLoads = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var userDetails = this.sessionService.globals;
        /** @type {?} */
        var aesKey = this.sessionService.getSessionData().aesKey;
        this.messageMapping.loadMesageMap('assets/configuration/messagemapping.json');
        if (aesKey) {
            AesUtils.setAesEncryptionKey(aesKey);
        }
        if (userDetails && userDetails.currentUser && userDetails.currentUser.username && !this.loginUserImage) {
            this.getUserImage(userDetails.currentUser.username).then(function (response) {
                if (response.success) {
                    this.loginUserImage = response.AppData.userInfo.userImage ? response.AppData.userInfo.userImage : 'noImage';
                }
            }, function (err) {
                console.log(err);
            });
        }
    };
    /**
     * @template T
     * @param {?} userName
     * @return {?}
     */
    CacheManagerService.prototype.getUserImage = /**
     * @template T
     * @param {?} userName
     * @return {?}
     */
    function (userName) {
        var _this = this;
        /** @type {?} */
        var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getUserImage&userName=').concat(userName);
        /** @type {?} */
        var httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getUserImage',
                'userToken': userName + "-" + this.sessionService.getUserTokenData()
            })
        };
        return new Promise(function (resolve, reject) {
            _this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(_this.handleError))
                .subscribe(function (resp) {
                resolve(resp);
            }, function (error) {
                reject(error);
            });
        });
    };
    /**
     * @param {?} websocketCallbacks
     * @return {?}
     */
    CacheManagerService.prototype.openWebSocketChannel = /**
     * @param {?} websocketCallbacks
     * @return {?}
     */
    function (websocketCallbacks) {
        var _this = this;
        /** @type {?} */
        var responseSessionData = this.sessionService.getSessionData();
        /** @type {?} */
        var protocol = CONSTANTS.WEBSOCKET_PROTOCOL;
        /** @type {?} */
        var ip = this.appConfiguration.getConfiguration().ip;
        /** @type {?} */
        var port = this.appConfiguration.getConfiguration().port;
        /** @type {?} */
        var websocketPort = this.appConfiguration.getConfiguration().websocketPort;
        /** @type {?} */
        var project = this.appConfiguration.getConfiguration().project;
        /** @type {?} */
        var userName = responseSessionData.globals.currentUser.userName;
        /** @type {?} */
        var base64token = util.encode64(userName + "-" + this.sessionService.getUserTokenData());
        /** @type {?} */
        var queryString = "?operation=authenticateWebSocket&project=" + project + "&userToken=" + base64token + "&projectUrl=" + ip + ":" + port;
        /** @type {?} */
        var webSocketURL = "" + protocol + ip + ":" + websocketPort + "/websocket" + queryString;
        return new Observable(function (observe) {
            /** @type {?} */
            var flag = false;
            try {
                _this.websocket = new WebSocket(webSocketURL);
                if (websocketCallbacks.onOpen) {
                    _this.websocket.onopen = function () {
                        websocketCallbacks.onOpen();
                        /** @type {?} */
                        var map = _this.getCookies();
                        _this.X_SOCKET_ADDRESS = map.has('X-SOCKET-ADDRESS') ? map.get('X-SOCKET-ADDRESS') : null;
                        _this.X_USERNAME = map.has('X-USERNAME') ? map.get('X-USERNAME') : null;
                        _this.SOCKET_IP = map.has('socketIp') ? map.get('socketIp') : null;
                        _this.resolveFn();
                        observe.next();
                        flag = true;
                    };
                }
                if (websocketCallbacks.onClose) {
                    _this.websocket.onclose = function () {
                        websocketCallbacks.onClose();
                        WebSocketCallbackClass.reInitializeObservables();
                        _this.reInitializeWebsocketOpenPromise();
                        /** @type {?} */
                        var map = _this.getCookies();
                        responseSessionData = _this.sessionService.getSessionData();
                        if (map.has('X-USERNAME') && flag && responseSessionData.globals && responseSessionData.globals.currentUser) {
                            /** @type {?} */
                            var callback_1 = new WebSocketCallbackClass();
                            _this.openWebSocketChannel(callback_1).subscribe(function (resp) {
                                callback_1.onReconnect();
                            });
                        }
                    };
                }
                /** @type {?} */
                var resolveFn_1 = _this.resolveFn;
                _this.websocket.onerror = function (error) {
                    if (websocketCallbacks.onError) {
                        websocketCallbacks.onError(error);
                    }
                    console.log('re-connecting to websocket server...');
                    resolveFn_1();
                    observe.error();
                };
                if (websocketCallbacks.onMessage) {
                    _this.websocket.onmessage = websocketCallbacks.onMessage;
                }
            }
            catch (error) {
                _this.resolveFn();
                console.log(error);
                observe.error(error);
            }
        }).pipe(delay(2000)).pipe(retry(15));
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.getCookies = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var cookieStr = document.cookie;
        /** @type {?} */
        var cookies = cookieStr.split(';');
        /** @type {?} */
        var map = new Map();
        cookies.forEach(function (cookie) {
            if (cookie) {
                /** @type {?} */
                var keyVal = cookie.trim().split('=');
                map.set(keyVal[0].trim(), keyVal[1].trim());
            }
        });
        return map;
    };
    /**
     * @param {?} error
     * @return {?}
     */
    CacheManagerService.prototype.handleError = /**
     * @param {?} error
     * @return {?}
     */
    function (error) {
        if (error instanceof ErrorEvent) {
            return throwError("Could not connect to server.\n:" + error);
        }
        else {
            return throwError("Server returned code " + error.status + ", body was: " + error.error);
        }
    };
    /**
     * @return {?}
     */
    CacheManagerService.prototype.reInitializeWebsocketOpenPromise = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.websocketOpenPromise = new Promise(function (resolve, reject) {
            _this.resolveFn = resolve;
            _this.rejectFn = reject;
        });
    };
    /**
     * @param {?} event
     * @return {?}
     */
    CacheManagerService.prototype.onbeforeunloadHandler = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        /** @type {?} */
        var loginPage = this.appConfiguration.getConfiguration()
            .nonRestrictedPages.includes(this.location.path());
        if (loginPage) {
            this.websocket.close();
        }
    };
    CacheManagerService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    CacheManagerService.ctorParameters = function () { return [
        { type: AppConfigurationService },
        { type: HttpClient },
        { type: SessionService },
        { type: Location },
        { type: MessageMapping }
    ]; };
    CacheManagerService.propDecorators = {
        onbeforeunloadHandler: [{ type: HostListener, args: ['window:onbeforeunload', ['$event'],] }]
    };
    /** @nocollapse */ CacheManagerService.ngInjectableDef = defineInjectable({ factory: function CacheManagerService_Factory() { return new CacheManagerService(inject(AppConfigurationService), inject(HttpClient), inject(SessionService), inject(Location), inject(MessageMapping)); }, token: CacheManagerService, providedIn: "root" });
    return CacheManagerService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var HttpService = /** @class */ (function () {
    function HttpService(httpClient, appConfiguration, cache, sessionService) {
        this.httpClient = httpClient;
        this.appConfiguration = appConfiguration;
        this.cache = cache;
        this.sessionService = sessionService;
    }
    /**
     * @param {?} queryString
     * @param {?} key
     * @return {?}
     */
    HttpService.prototype.parseQueryString = /**
     * @param {?} queryString
     * @param {?} key
     * @return {?}
     */
    function (queryString, key) {
        /** @type {?} */
        var tokens;
        if (queryString) {
            tokens = queryString.split('&');
        }
        else {
            return null;
        }
        /** @type {?} */
        var map = new Map();
        try {
            for (var tokens_1 = __values(tokens), tokens_1_1 = tokens_1.next(); !tokens_1_1.done; tokens_1_1 = tokens_1.next()) {
                var token = tokens_1_1.value;
                /** @type {?} */
                var keyValue = token.split('=');
                map.set(keyValue[0], keyValue[1]);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (tokens_1_1 && !tokens_1_1.done && (_a = tokens_1.return)) _a.call(tokens_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return map.has(key) ? map.get(key) : null;
        var e_1, _a;
    };
    /**
     * @param {?} url
     * @return {?}
     */
    HttpService.prototype.parseUrl = /**
     * @param {?} url
     * @return {?}
     */
    function (url) {
        /** @type {?} */
        var parsedParameters = new Map();
        /** @type {?} */
        var queryString = url.split('?')[1];
        /** @type {?} */
        var parameterPairList = queryString.split('&');
        parameterPairList.forEach(function (parameterPair) {
            /** @type {?} */
            var keyValue = parameterPair.split('=');
            parsedParameters[keyValue[0]] = keyValue[1];
        });
        return parsedParameters;
    };
    /**
     * @param {?} url
     * @return {?}
     */
    HttpService.prototype.checkAuthorization = /**
     * @param {?} url
     * @return {?}
     */
    function (url) {
        if (!this.appConfiguration.getConfiguration().clientSideRequestBarring) {
            return true;
        }
        /** @type {?} */
        var parsedParameters = this.parseUrl(url);
        /** @type {?} */
        var operation = parsedParameters['operation'];
        /** @type {?} */
        var accessGrantedModule = false;
        /** @type {?} */
        var accessGrantedNode = false;
        /** @type {?} */
        var accessGrantedCircle = false;
        switch (operation) {
            case 'doLogin':
            case 'logoutUser':
                accessGrantedModule = true;
                break;
            default:
                if (this.cache.OperationToAccessMapping[operation] &&
                    this.cache.OperationToAccessMapping[operation].module !== 'freeAllow') {
                    /** @type {?} */
                    var accessRequired = this.cache.OperationToAccessMapping[operation].access;
                    if (this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module]) {
                        accessGrantedModule =
                            this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module][accessRequired] ? true : false;
                    }
                    else {
                        accessGrantedModule = false;
                    }
                }
                else if (this.cache.OperationToAccessMapping[operation] &&
                    this.cache.OperationToAccessMapping[operation].module === 'freeAllow') {
                    accessGrantedModule = true;
                }
                else {
                    accessGrantedModule = false;
                }
                break;
        }
        if (!accessGrantedModule) {
            return false;
        }
        if (this.cache.OperationToAccessMapping[operation] && this.cache.OperationToAccessMapping[operation].circle) {
            if (this.cache.OperationToAccessMapping[operation].node) {
                /** @type {?} */
                var circleAccessRequired = parsedParameters['circleName'];
                /** @type {?} */
                var nodeAccessRequired = parsedParameters['nodeName'];
                if (circleAccessRequired && nodeAccessRequired) {
                    if (nodeAccessRequired.parsedNodeCircleJson[nodeAccessRequired] &&
                        this.sessionService.parsedNodeCircleJson[nodeAccessRequired][circleAccessRequired]) {
                        accessGrantedCircle = true;
                    }
                    else {
                        accessGrantedCircle = false;
                    }
                }
                else {
                    accessGrantedCircle = false;
                }
            }
            else {
                accessGrantedCircle = false;
            }
        }
        else if (this.cache.OperationToAccessMapping[operation] &&
            !this.cache.OperationToAccessMapping[operation].circle) {
            accessGrantedCircle = true;
        }
        else {
            accessGrantedCircle = false;
        }
        if (!accessGrantedCircle) {
            return false;
        }
        if (this.cache.OperationToAccessMapping[operation] &&
            this.cache.OperationToAccessMapping[operation].node) {
            /** @type {?} */
            var nodeAccessRequired = parsedParameters['nodeName'];
            if (nodeAccessRequired) {
                if (this.sessionService.parsedNodeCircleJson[nodeAccessRequired]) {
                    accessGrantedNode = true;
                }
                else {
                    accessGrantedNode = false;
                }
            }
            else {
                accessGrantedNode = false;
            }
        }
        else if (this.cache.OperationToAccessMapping[operation] &&
            !this.cache.OperationToAccessMapping[operation].node) {
            accessGrantedNode = true;
        }
        else {
            accessGrantedNode = false;
        }
        return accessGrantedNode;
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.getData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            console.log(url);
            if (this.checkAuthorization(url)) {
                if (request.responseType) {
                    request.headers.set('responseType', request.responseType);
                }
                /** @type {?} */
                var httpOptions_1 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_1.headers['operation'] = operation;
                if (request.responseType) {
                    httpOptions_1['responseType'] = request.responseType;
                }
                return new Observable(function (observe) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.get(url, httpOptions_1).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) {
                                console.log(response);
                                if (request.callbackfunction) {
                                    request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                                }
                                else {
                                    observe.next(response);
                                }
                            }, function (error) {
                                observe.error(error);
                            });
                        });
                    }
                    else {
                        _this.httpClient.get(url, httpOptions_1).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) {
                            if (request.callbackfunction) {
                                request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                            }
                            else {
                                observe.next(response);
                            }
                        }, function (error) {
                            observe.error(error);
                        });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.postData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            console.log(url);
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                var httpOptions_2 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_2.headers['operation'] = operation;
                return new Observable(function (subscriber) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.post(url, request.data, httpOptions_2).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                        });
                    }
                    else {
                        _this.httpClient.post(url, request.data, httpOptions_2).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.putData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                var httpOptions_3 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_3.headers['operation'] = operation;
                return new Observable(function (subscriber) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.put(url, request.data, httpOptions_3).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                        });
                    }
                    else {
                        _this.httpClient.put(url, request.data, httpOptions_3).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.deleteData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                var httpOptions_4 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_4.headers['operation'] = operation;
                return new Observable(function (subscriber) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.delete(url, httpOptions_4).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                        });
                    }
                    else {
                        _this.httpClient.delete(url, httpOptions_4).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.headData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                var httpOptions_5 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_5.headers['operation'] = operation;
                return new Observable(function (subscriber) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.head(url, httpOptions_5).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                        });
                    }
                    else {
                        _this.httpClient.head(url, httpOptions_5).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    HttpService.prototype.patchData = /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        /** @type {?} */
        var operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        var url;
        /** @type {?} */
        var config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = "?" + request.queryString;
            }
            url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                var httpOptions_6 = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions_6.headers['operation'] = operation;
                return new Observable(function (subscriber) {
                    if (_this.sessionService.getSessionData().globals &&
                        _this.sessionService.getSessionData().globals.currentUser) {
                        _this.cache.websocketOpenPromise.then(function () {
                            _this.httpClient.patch(url, request.data, httpOptions_6).pipe(retry(2), catchError(_this.handleError))
                                .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                        });
                    }
                    else {
                        _this.httpClient.patch(url, request.data, httpOptions_6).pipe(retry(2), catchError(_this.handleError))
                            .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                    }
                });
            }
            else {
                return throwError("Not authorized for accessing " + url + ": 401");
            }
        }
    };
    /**
     * @param {?} error
     * @return {?}
     */
    HttpService.prototype.handleError = /**
     * @param {?} error
     * @return {?}
     */
    function (error) {
        if (error instanceof ErrorEvent) {
            return throwError("Could not connect to server.\n:" + error);
        }
        else {
            return throwError(error);
        }
    };
    HttpService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    HttpService.ctorParameters = function () { return [
        { type: HttpClient },
        { type: AppConfigurationService },
        { type: CacheManagerService },
        { type: SessionService }
    ]; };
    /** @nocollapse */ HttpService.ngInjectableDef = defineInjectable({ factory: function HttpService_Factory() { return new HttpService(inject(HttpClient), inject(AppConfigurationService), inject(CacheManagerService), inject(SessionService)); }, token: HttpService, providedIn: "root" });
    return HttpService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var IamService = /** @class */ (function () {
    function IamService(httpService, appConfiguration, sessionService, cache, router, location) {
        this.httpService = httpService;
        this.appConfiguration = appConfiguration;
        this.sessionService = sessionService;
        this.cache = cache;
        this.router = router;
        this.location = location;
        this.startListeningToRouteChange().subscribe(function () {
            console.log('started listening for route change');
        });
    }
    /**
     * @return {?}
     */
    IamService.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    IamService.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        this.websocket.close();
    };
    /**
     * @template T
     * @param {?} payload
     * @param {?} project
     * @return {?}
     */
    IamService.prototype.doLogin = /**
     * @template T
     * @param {?} payload
     * @param {?} project
     * @return {?}
     */
    function (payload, project) {
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders().set('project', this.appConfiguration.getConfiguration().project);
        }
        else {
            headers = new HttpHeaders().set('project', project);
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=doLogin',
            headers: headers,
            data: payload
        };
        return this.httpService.postData(request);
    };
    /**
     * @return {?}
     */
    IamService.prototype.startListeningToRouteChange = /**
     * @return {?}
     */
    function () {
        var _this = this;
        return new Observable(function (observe) {
            _this.router.events.pipe(filter(function (event) { return event instanceof NavigationEnd; })).subscribe(function (event) {
                if (event instanceof NavigationEnd) {
                    _this.onRouteChange(event);
                }
            });
            observe.next();
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} password
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.authenticateUser = /**
     * @template T
     * @param {?} userName
     * @param {?} password
     * @param {?=} project
     * @return {?}
     */
    function (userName, password, project) {
        var _this = this;
        return new Observable(function (observe) {
            /** @type {?} */
            var responseSessionData = _this.sessionService.getSessionData();
            if (responseSessionData && responseSessionData.globals &&
                responseSessionData.globals.currentUser && responseSessionData.globals.currentUser.userName) {
                console.log('user already logged in');
                _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                observe.next();
            }
            else {
                /** @type {?} */
                var randomAesKey_1 = AesUtils.generateRandomAesKey();
                /** @type {?} */
                var credentials = {
                    userName: userName,
                    userPassword: RsaUtils.encrypt(password),
                };
                /** @type {?} */
                var payload = {
                    AppData: {
                        userInfo: credentials,
                        encryptionKey: RsaUtils.encrypt(randomAesKey_1)
                    }
                };
                _this.doLogin(payload, project).subscribe(function (response) {
                    if (response.body && response.body.statusCode && response.body.statusCode.AppData && response.body.statusCode.AppData.userToken) {
                        /** @type {?} */
                        var subTokens = response.body.statusCode.AppData.userToken.split('@');
                        /** @type {?} */
                        var moduleRestriction = null;
                        /** @type {?} */
                        var structuredRestriction = null;
                        /** @type {?} */
                        var nodeNameCircle = null;
                        if (subTokens[1] && subTokens[1].length > 0) {
                            moduleRestriction = _this.parseToken(AesUtils.decrypt(subTokens[1], randomAesKey_1));
                        }
                        else {
                            moduleRestriction = {};
                        }
                        structuredRestriction = _this.restructureAccessJson(moduleRestriction, {});
                        _this.sessionService.setSessionDataForModuleRestriction(moduleRestriction);
                        _this.sessionService.setSessionDataForStructuredRestriction(structuredRestriction);
                        _this.sessionService.setUserTokenData(subTokens[0]);
                        if (subTokens[2] && subTokens[2].length > 0) {
                            nodeNameCircle = AesUtils.decrypt(subTokens[2], randomAesKey_1);
                        }
                        else {
                            nodeNameCircle = '';
                        }
                        /** @type {?} */
                        var parsedNodeCircleJson = _this.parseNodeCircleToken(nodeNameCircle);
                        _this.sessionService.setSessionDataForNodeCircleRestriction(/** @type {?} */ (parsedNodeCircleJson));
                        /** @type {?} */
                        var neNamesCircleList = nodeNameCircle.split('#');
                        if (!_this.sessionService.nodeNameList) {
                            _this.sessionService.nodeNameList = [];
                        }
                        if (!_this.sessionService.mapNeNameCircleName) {
                            _this.sessionService.mapNeNameCircleName = {};
                        }
                        for (var itr = 0; itr < neNamesCircleList.length; itr++) {
                            /** @type {?} */
                            var cirleNamesForNE = neNamesCircleList[itr].split(':');
                            _this.sessionService.nodeNameList.push(cirleNamesForNE[0]);
                            _this.sessionService.mapNeNameCircleName[cirleNamesForNE[0]] = cirleNamesForNE[1];
                        }
                        _this.sessionService.selectedNeShortName = _this.sessionService.nodeNameList[0];
                        _this.neShortNameFullNameMapping();
                        _this.neCircleShortNameFullNameMapping();
                        /** @type {?} */
                        var neNameCircleName = JSON.parse(JSON.stringify({
                            selectedNeName: _this.sessionService.selectedNeName,
                            selectedCircleName: _this.sessionService.selectedCircleName
                        }));
                        /** @type {?} */
                        var requestData = {
                            userName: userName,
                            appData: response.body.statusCode.AppData,
                            nodeNameCircle: nodeNameCircle,
                            aesKey: AesUtils.decrypt(subTokens[3], randomAesKey_1),
                            neNameCircleName: neNameCircleName
                        };
                        _this.sessionService.putDateForCookieExpiry();
                        _this.sessionService.setSessionData(requestData);
                        AesUtils.setAesEncryptionKey(AesUtils.decrypt(subTokens[3], randomAesKey_1));
                        _this.cache.getUserImage(userName).then(function (resp) {
                            if (resp.success) {
                                this.cache.loginUserImage = resp.AppData.userInfo.userImage ? resp.AppData.userInfo.userImage : 'noImage';
                            }
                        }, function (err) {
                            console.log(err);
                        });
                        _this.cache.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(function () {
                            _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                            observe.next(response);
                        }, function () {
                            _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                            observe.next(response);
                        });
                    }
                    else {
                        observe.next(response);
                    }
                }, function (error) {
                    observe.error(error);
                });
            }
        });
    };
    /**
     * @param {?} userName
     * @return {?}
     */
    IamService.prototype.doLogout = /**
     * @param {?} userName
     * @return {?}
     */
    function (userName) {
        var _this = this;
        if (!userName) {
            throwError('userName is undefined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: "operation=logoutUser&userName=" + userName,
        };
        return new Observable(function (observe) {
            _this.httpService.deleteData(request).subscribe(function (response) {
                observe.next();
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @return {?}
     */
    IamService.prototype.logoutUser = /**
     * @return {?}
     */
    function () {
        var _this = this;
        return new Observable(function (observe) {
            /** @type {?} */
            var globals = _this.sessionService.getSessionData().globals;
            if (globals && globals.currentUser && globals.currentUser.userName) {
                /** @type {?} */
                var inUserName = globals.currentUser.userName;
                _this.doLogout(inUserName).subscribe(function () {
                    _this.resetVariables();
                    _this.sessionService.clearSessionDataAndGotoLogoutPage();
                    if (_this.cache.websocket && _this.cache.websocket.close) {
                        _this.cache.websocket.close();
                        _this.cache.websocket = null;
                    }
                    observe.next();
                }, function (error) {
                    _this.resetVariables();
                    _this.sessionService.clearSessionDataAndGotoLogoutPage();
                    if (_this.cache.websocket && _this.cache.websocket.close) {
                        _this.cache.websocket.close();
                        _this.cache.websocket = null;
                    }
                    observe.error();
                });
            }
            else {
                _this.resetVariables();
                _this.sessionService.clearSessionDataAndGotoLogoutPage();
                if (_this.cache.websocket && _this.cache.websocket.close) {
                    _this.cache.websocket.close();
                    _this.cache.websocket = null;
                }
                observe.next();
                console.log('no user to logout');
            }
        });
    };
    /**
     * @return {?}
     */
    IamService.prototype.getPathName = /**
     * @return {?}
     */
    function () {
        return window.location && window.location.hash && window.location.hash.substr(1);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    IamService.prototype.onRouteChange = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.sessionService.globals = this.sessionService.getSessionData().globals;
        if (!this.sessionService.globals) {
            this.sessionService.globals = {};
        }
        if (this.router.url == this.appConfiguration.getConfiguration().sessionExpiredPage) {
            try {
                if (this.cache.websocket) {
                    this.cache.websocket.close();
                    this.cache.websocket = null;
                }
            }
            catch (ErrorEvent) {
                console.log(ErrorEvent);
            }
        }
        if (this.appConfiguration.getConfiguration().loginPage &&
            this.appConfiguration.getConfiguration().nonRestrictedPages &&
            this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
            /** @type {?} */
            var pathName = this.location.path();
            if (pathName.includes("?")) {
                pathName = pathName.split("?")[0];
            }
            /** @type {?} */
            var restrictedPage = this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
            /** @type {?} */
            var loggedIn = this.sessionService.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                this.router.navigate([this.appConfiguration.getConfiguration().loginPage]);
            }
            else if (loggedIn) {
                /** @type {?} */
                var loginPage = this.appConfiguration.getConfiguration()
                    .nonRestrictedPages.indexOf(pathName) != -1;
                if (loginPage) {
                    this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                }
            }
        }
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getAllroleid = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getAllRoleSelectedFiled',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createSingleUser = /**
     * @template T
     * @param {?} creatingUser
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    function (creatingUser, AppData, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: "operation=createSingleUser&creatingUser=" + creatingUser,
            data: { AppData: AppData },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createAccount = /**
     * @template T
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    function (AppData, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=createAccount',
            data: { AppData: AppData },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createBulkUser = /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    function (creatingUser, file, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: "operation=createBulkUser&creatingUser=" + creatingUser,
            data: file,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createBulkRolesandUsers = /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    function (creatingUser, file, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: "operation=createBulkRolesandUsers&creatingUser=" + creatingUser,
            data: file,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.downloadBulkUsers = /**
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getBulkUser',
            responseType: 'arraybuffer',
            headers: headers,
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                /** @type {?} */
                var blob = new Blob([resp.body], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel'
                });
                /** @type {?} */
                var a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "UserList.xlsx";
                a.click();
                observe.next();
            }, function (error) {
                console.log(error);
                observe.error();
            });
        });
    };
    /**
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.downloadUserTemplate = /**
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getTemplate',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                /** @type {?} */
                var data1 = resp.body;
                /** @type {?} */
                var data = resp.body['statusCode']['AppData']['Base64Stream'];
                /** @type {?} */
                var bindata = window.atob(data);
                /** @type {?} */
                var len = bindata.length;
                /** @type {?} */
                var bytes = new Uint8Array(len);
                for (var i = 0; i < len; i++) {
                    bytes[i] = bindata.charCodeAt(i);
                }
                /** @type {?} */
                var file = new Blob([bytes.buffer], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
                });
                window.saveAs(file, "usertemplate" + ".xlsx");
                observe.next();
            }, function (error) {
                observe.error();
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.deleteUser = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=deleteUser&userName=' + userName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.deleteData(request).subscribe(function (resp) {
                console.log(resp);
                console.log(resp.body);
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} userInfo
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.modifyUser = /**
     * @template T
     * @param {?} userName
     * @param {?} userInfo
     * @param {?=} project
     * @return {?}
     */
    function (userName, userInfo, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyUser&userName=' + userName,
            headers: headers,
            data: { 'AppData': userInfo }
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewUser = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getUser&userName=' + userName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewUserListAccordingtoRole = /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    function (roleId, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!roleId) {
            throwError('roleId is not defined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getUsersList&roleId=' + roleId,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.blockUser = /**
     * @template T
     * @param {?} userId
     * @param {?=} project
     * @return {?}
     */
    function (userId, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userId) {
            throwError('userId is not defined');
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=blockUser&userId=' + userId,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.checkUserExistence = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=checkUser&userName=' + userName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} index
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getAllUser = /**
     * @template T
     * @param {?} index
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    function (index, size, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getAllUser&from=' + index + '&size=' + size,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getRestrictedUser = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getAllUserSelectedField',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createRole = /**
     * @template T
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    function (roleData, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var currentDate = new Date();
        roleData.roleInfo.role['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['createdBy'] = this.cache.X_USERNAME;
        roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=createRole',
            data: { 'AppData': roleData },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @return {?}
     */
    IamService.prototype.resetVariables = /**
     * @return {?}
     */
    function () {
        this.sessionService.globals = null;
        this.sessionService.selectedCircleName = null;
        this.sessionService.selectedNeName = null;
        this.sessionService.selectedNeShortName = null;
        this.sessionService.parsedNodeCircleJson = null;
        this.sessionService.nodeNameCircle = null;
        this.sessionService.structuredRestriction = null;
        this.sessionService.moduleRestriction = null;
        this.sessionService.mapNeNameCircleName = null;
        this.sessionService.nodeNameList = [];
    };
    /**
     * @param {?} key
     * @return {?}
     */
    IamService.prototype.getCookie = /**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        /** @type {?} */
        var cookieStr = document.cookie;
        /** @type {?} */
        var cookies = cookieStr.split(';');
        /** @type {?} */
        var map = {};
        cookies.forEach(function (cookie) {
            if (cookie) {
                /** @type {?} */
                var keyval = cookie.trim().split('=');
                map[keyval[0].trim()] = keyval[1].trim();
            }
        });
        return map[key];
    };
    /**
     * @param {?} module
     * @param {?} structuredJson
     * @return {?}
     */
    IamService.prototype.restructureAccessJson = /**
     * @param {?} module
     * @param {?} structuredJson
     * @return {?}
     */
    function (module, structuredJson) {
        for (var key in module) {
            if (module.hasOwnProperty(key)) {
                /** @type {?} */
                var value = module[key];
                if (value.access) {
                    /** @type {?} */
                    var access = {};
                    for (var ky in value.access) {
                        if (value.access.hasOwnProperty(key)) {
                            /** @type {?} */
                            var element = value.access[ky];
                            switch (ky) {
                                case 'R':
                                    access['Read'] = true;
                                    break;
                                case 'W':
                                    access['Write'] = true;
                                    break;
                                case 'D':
                                    access['Delete'] = true;
                                    break;
                            }
                        }
                    }
                    structuredJson[key] = access;
                }
                else {
                    this.restructureAccessJson(value, structuredJson);
                }
            }
        }
        return structuredJson;
    };
    // var authToken="SC1.1:RD#SC1.2:RWD#SC1.3:RD#SC5.1:RD#SC2.1:RWD#SC3.2.1:RD";
    /**
     * @param {?} authToken
     * @return {?}
     */
    IamService.prototype.parseToken = /**
     * @param {?} authToken
     * @return {?}
     */
    function (authToken) {
        /** @type {?} */
        var json = {};
        if (!authToken) {
            return json;
        }
        /** @type {?} */
        var tokens = authToken.split('#');
        for (var i = 0; i < tokens.length; i++) {
            /** @type {?} */
            var token = tokens[i];
            /** @type {?} */
            var shortCodes = token.split('.');
            /** @type {?} */
            var tempName = '';
            /** @type {?} */
            var temp = json;
            for (var j = 0; j < shortCodes.length - 1; j++) {
                /** @type {?} */
                var shortCode = shortCodes[j];
                if (tempName === '') {
                    tempName = shortCode;
                }
                else {
                    tempName = tempName + "." + shortCode;
                }
                if (!temp.hasOwnProperty(tempName)) {
                    temp[tempName] = {};
                }
                temp = temp[tempName];
            }
            if (tempName === '') {
                tempName = shortCodes[shortCodes.length - 1].split(':')[0];
            }
            else {
                tempName = tempName + "." + shortCodes[shortCodes.length - 1].split(':')[0];
            }
            if (!temp.hasOwnProperty(tempName)) {
                /** @type {?} */
                var restrictJson = {};
                /** @type {?} */
                var restriction = shortCodes[shortCodes.length - 1].split(':')[1].split('');
                for (var k = 0; k < restriction.length; k++) {
                    restrictJson[restriction[k]] = true;
                }
                temp[tempName] = { access: restrictJson };
            }
        }
        return json;
    };
    /**
     * @param {?} token
     * @return {?}
     */
    IamService.prototype.parseNodeCircleToken = /**
     * @param {?} token
     * @return {?}
     */
    function (token) {
        /** @type {?} */
        var parsedJson = {};
        if (!token || token === '') {
            return parsedJson;
        }
        /** @type {?} */
        var singleNodeCircleList = token.split('#');
        for (var i = 0; i < singleNodeCircleList.length; i++) {
            /** @type {?} */
            var singleNodeCircle = singleNodeCircleList[i];
            /** @type {?} */
            var node = singleNodeCircle.split(':')[0];
            /** @type {?} */
            var circlesList = singleNodeCircle.split(':')[1].split(',');
            /** @type {?} */
            var circleJson = {};
            for (var j = 0; j < circlesList.length; j++) {
                circleJson[this.cache.circleFullNameJsonResponse['CircleName'][circlesList[j]]] = true;
            }
            parsedJson[node] = circleJson;
        }
        return parsedJson;
    };
    /**
     * @return {?}
     */
    IamService.prototype.neShortNameFullNameMapping = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var response = this.cache.neShortNameFullNameJson;
        /** @type {?} */
        var neShortName = this.sessionService.nodeNameList[0];
        if (response.NodeName) {
            /** @type {?} */
            var nodeFullName = response.NodeName[neShortName];
            this.sessionService.selectedNeName = nodeFullName;
        }
        if (!this.cache.mapNeShortNameFullName) {
            this.cache.mapNeShortNameFullName = {};
        }
        for (var itr = 0; itr < response.NodeName && this.sessionService.nodeNameList.length; itr++) {
            this.cache.mapNeShortNameFullName[response.NodeName[this.sessionService.nodeNameList[itr]]] = this.sessionService.nodeNameList[itr];
        }
    };
    /**
     * @return {?}
     */
    IamService.prototype.neCircleShortNameFullNameMapping = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var response = this.cache.circleFullNameJsonResponse;
        /** @type {?} */
        var circleShortNamesList = this.sessionService.mapNeNameCircleName[this.sessionService.nodeNameList[0]];
        if (circleShortNamesList) {
            /** @type {?} */
            var circle = circleShortNamesList.split(',');
            this.sessionService.selectedCircleName = response.CircleName[circle[0]];
        }
    };
    /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getAccessJson = /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    function (productId, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getModuleSubModuleData&productId=' + productId,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getNodeCircleJson = /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    function (productId, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeCircleData&productId=' + productId,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getModuleToIdJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getShortCodeToIdMap',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getNodeToIdJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeToIdMap',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getCircleToIdJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getCircleToIdMap',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getCircleShortNameFullNameJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getCircleShortNameFullName',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getNodeShortNameFullNameJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeShortNameFullName',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getOperationToModuleNodeCircleJson = /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    function (project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getOperationToModuleNodeCircle',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.deleteRole = /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    function (roleId, project) {
        var _this = this;
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=deleteRole&roleId=' + roleId,
            headers: headers,
        };
        return new Observable(function (observe) {
            _this.httpService.deleteData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleId
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.modifyRole = /**
     * @template T
     * @param {?} roleId
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    function (roleId, roleData, project) {
        var _this = this;
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var currentDate = new Date();
        roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=updateRole&roleId=' + roleId,
            data: { "AppData": roleData },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewRole = /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    function (roleId, project) {
        var _this = this;
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=viewRole&roleId=' + roleId,
            headers: headers,
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getAllRole = /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    function (from, size, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getAllRole&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} rolename
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.checkRoleExistence = /**
     * @template T
     * @param {?} rolename
     * @param {?=} project
     * @return {?}
     */
    function (rolename, project) {
        var _this = this;
        if (!rolename)
            throw "rolename is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=checkRole&roleName=' + rolename,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.createUserGroup = /**
     * @template T
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    function (groupData, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var currentDate = new Date();
        groupData.groupInfo['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['createdBy'] = this.cache.X_USERNAME;
        groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=createGroup',
            headers: headers,
            data: { 'AppData': groupData }
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewUserGroup = /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    function (groupId, project) {
        var _this = this;
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            headers: headers,
            queryString: 'operation=viewGroup&groupId=' + groupId,
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewUserGroupList = /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    function (from, size, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=viewGroupList&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.viewAllGroup = /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    function (from, size, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=viewAllGroup&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.deleteUserGroup = /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    function (groupId, project) {
        var _this = this;
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=deleteGroup&groupId=' + groupId,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.deleteData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupId
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.modifyUserGroup = /**
     * @template T
     * @param {?} groupId
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    function (groupId, groupData, project) {
        var _this = this;
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var currentDate = new Date();
        groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyGroup&groupId=' + groupId,
            headers: headers,
            data: { 'AppData': groupData }
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.lockUser = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=lockUser&userName=' + userName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.unlockUser = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=unlockUser&userName=' + userName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.lockGroup = /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    function (groupName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=lockGroup&groupName=' + groupName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.unlockGroup = /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    function (groupName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=unlockGroup&groupName=' + groupName,
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} roleIdJson
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getCountUsers = /**
     * @template T
     * @param {?} roleIdJson
     * @param {?=} project
     * @return {?}
     */
    function (roleIdJson, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getCountUsers',
            headers: headers,
            data: roleIdJson
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} oldPassword
     * @param {?} newPassword
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.changePassword = /**
     * @template T
     * @param {?} userName
     * @param {?} oldPassword
     * @param {?} newPassword
     * @param {?=} project
     * @return {?}
     */
    function (userName, oldPassword, newPassword, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=changePassword&userName=' + userName,
            data: {
                "userInfo": {
                    "userName": userName,
                    "oldUserPassword": AesUtils.encrypt(oldPassword),
                    "newUserPassword": AesUtils.encrypt(newPassword)
                }
            },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.forgotPassword = /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    function (userName, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=forgotPassoword',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} requestParameters
     * @param {?} requestHeaders
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.insertTraceData = /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} requestParameters
     * @param {?} requestHeaders
     * @param {?=} project
     * @return {?}
     */
    function (userName, operation, requestParameters, requestHeaders, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var currentDate = new Date();
        headers = headers.append("userName", userName).append("operation", operation).append("timestamp", currentDate.getTime().toString());
        /** @type {?} */
        var request = {
            context: CONSTANTS.TRACE_CONTEXT,
            queryString: 'operation=insertTraceData',
            data: {
                "requestParameters": { requestParameters: requestParameters },
                "requestHeaders": { requestHeaders: requestHeaders },
            },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} traceLevel
     * @param {?} fromTimeStamp
     * @param {?} toTimeStamp
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.getTraceData = /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} traceLevel
     * @param {?} fromTimeStamp
     * @param {?} toTimeStamp
     * @param {?=} project
     * @return {?}
     */
    function (userName, operation, traceLevel, fromTimeStamp, toTimeStamp, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName).append("operation", operation).append("traceLevel", traceLevel).append("fromTimeStamp", fromTimeStamp).append("toTimeStamp", toTimeStamp);
        /** @type {?} */
        var request = {
            context: CONSTANTS.TRACE_CONTEXT,
            queryString: 'operation=getTraceData',
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.getData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.resetPassword = /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    function (userName, otp, newPassword, confirmPassword, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        var password = RsaUtils.encrypt(newPassword);
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=resetPassword',
            data: {
                "userInfo": {
                    "userName": userName,
                    "newPassword": password,
                    "confirmPassword": password,
                    "otp": otp
                }
            },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.generatePassword = /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    function (userName, otp, newPassword, confirmPassword, project) {
        var _this = this;
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        var password = RsaUtils.encrypt(newPassword);
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=generatePassword',
            data: {
                "userInfo": {
                    "userName": userName,
                    "newPassword": password,
                    "confirmPassword": password,
                    "otp": otp
                }
            },
            headers: headers
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    /**
     * @template T
     * @param {?} userName
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    IamService.prototype.modifyUserImage = /**
     * @template T
     * @param {?} userName
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    function (userName, AppData, project) {
        var _this = this;
        if (!userName)
            throw "userName is undefined";
        /** @type {?} */
        var headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        var request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyUserImage&userName=' + userName,
            headers: headers,
            data: {
                'AppData': AppData
            }
        };
        return new Observable(function (observe) {
            _this.httpService.postData(request).subscribe(function (resp) {
                observe.next(resp.body);
            }, function (error) {
                observe.error(error);
            });
        });
    };
    IamService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    IamService.ctorParameters = function () { return [
        { type: HttpService },
        { type: AppConfigurationService },
        { type: SessionService },
        { type: CacheManagerService },
        { type: Router },
        { type: Location }
    ]; };
    /** @nocollapse */ IamService.ngInjectableDef = defineInjectable({ factory: function IamService_Factory() { return new IamService(inject(HttpService), inject(AppConfigurationService), inject(SessionService), inject(CacheManagerService), inject(Router), inject(Location)); }, token: IamService, providedIn: "root" });
    return IamService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var HttpResponseInterceptor = /** @class */ (function () {
    function HttpResponseInterceptor(sessionService, appConfiguration, cache) {
        this.sessionService = sessionService;
        this.appConfiguration = appConfiguration;
        this.cache = cache;
    }
    /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    HttpResponseInterceptor.prototype.intercept = /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    function (req, next) {
        var _this = this;
        if (this.cache.X_SOCKET_ADDRESS) {
            req = req.clone({
                setHeaders: {
                    'X-SOCKET-ADDRESS': this.cache.X_SOCKET_ADDRESS
                }
            });
        }
        if (this.cache.X_USERNAME) {
            req = req.clone({
                setHeaders: {
                    'X-USERNAME': this.cache.X_USERNAME
                }
            });
        }
        if (this.cache.SOCKET_IP) {
            req = req.clone({
                setHeaders: {
                    'socketIp': this.cache.SOCKET_IP
                }
            });
        }
        if (req.headers.has('X-Event-Name')) {
            req = req.clone({
                setHeaders: {
                    operation: req.headers.get('X-Event-Name')
                }
            });
        }
        else if (req.headers.has('Event-Key')) {
            req = req.clone({
                setHeaders: {
                    operation: req.headers.get('Event-Key')
                }
            });
        }
        else if (req.params.has('operation')) {
            req = req.clone({
                setHeaders: {
                    operation: req.params.get('operation')
                }
            });
        }
        if (this.sessionService.getSessionData().globals && this.sessionService.getSessionData().globals.currentUser &&
            this.sessionService.getSessionData().globals.currentUser.userName &&
            this.appConfiguration.getConfiguration() && this.appConfiguration.getConfiguration().project) {
            /** @type {?} */
            var userToken = this.sessionService.getUserTokenData();
            /** @type {?} */
            var userName = this.sessionService.getSessionData().globals.currentUser.userName;
            /** @type {?} */
            var product = void 0;
            product = req.headers.get("project");
            if (!product) {
                product = this.appConfiguration.getConfiguration().project;
            }
            req = req.clone({
                setHeaders: {
                    userToken: userName + "-" + userToken,
                    project: product
                }
            });
        }
        return next.handle(req).pipe(tap(function (response) {
            if (response instanceof HttpResponse) {
                /** @type {?} */
                var resp = /** @type {?} */ (response);
                if (resp.headers.has('userToken')) {
                    _this.sessionService.setUserTokenData(resp.headers.get('userToken'));
                    _this.sessionService.putDateForCookieExpiry();
                }
                if (response.body && response.body['statusCode'] &&
                    response.body['statusCode']['httpstatuscode']) {
                    if (response.body['statusCode']['httpstatuscode'] === 401 && (response.body['statusCode']['opStatusCode']
                        === 903 || response.body['statusCode']['opStatusCode'] === 4030)) {
                        _this.sessionService.clearSessionDataAndGotoSessionExpirePage();
                    }
                }
            }
        }));
    };
    HttpResponseInterceptor.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    HttpResponseInterceptor.ctorParameters = function () { return [
        { type: SessionService },
        { type: AppConfigurationService },
        { type: CacheManagerService }
    ]; };
    return HttpResponseInterceptor;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var IamComponent = /** @class */ (function () {
    function IamComponent() {
    }
    /**
     * @return {?}
     */
    IamComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    IamComponent.decorators = [
        { type: Component, args: [{
                    selector: 'lib-iam',
                    template: "\n    <p>\n      iam works!\n    </p>\n  ",
                    styles: []
                },] },
    ];
    /** @nocollapse */
    IamComponent.ctorParameters = function () { return []; };
    return IamComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/**
 * @param {?} appConfigurationService
 * @param {?} cache
 * @return {?}
 */
function initializeApp(appConfigurationService, cache) {
    return function () { return new Promise(function (resolve, reject) {
        appConfigurationService.loadConfiguration('assets/configuration/config.json').then(function () {
            /** @type {?} */
            var getRsaKeyPromise = cache.getAuthKey();
            /** @type {?} */
            var startUpRouteChangePromise = cache.onStartupRouteChange(event);
            Promise.all([getRsaKeyPromise, startUpRouteChangePromise]).then(function () {
                /** @type {?} */
                var nodeShortFullPromise = cache.getNodeShortNameFullNameJson();
                /** @type {?} */
                var circleShortFullPromise = cache.getCircleShortNameFullNameJson();
                /** @type {?} */
                var moduleToIdPromise = cache.getModuleToIdJson();
                /** @type {?} */
                var nodeToIdPromise = cache.getNodeToIdJson();
                /** @type {?} */
                var circleToIdPromise = cache.getCircleToIdJson();
                /** @type {?} */
                var operationToModuleNodeCirclePromise = cache.getOperationToModuleNodeCircleJson();
                Promise.all([nodeShortFullPromise, circleShortFullPromise, moduleToIdPromise,
                    nodeToIdPromise, circleToIdPromise, operationToModuleNodeCirclePromise]).then(function () {
                    cache.callWhenConfigLoads();
                    resolve();
                }, function (error) {
                    console.log(error);
                    reject();
                });
            }, function (error) {
                console.log(error);
                reject();
            });
        }, function (error) {
            console.log(error);
            reject();
        });
    }); };
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
var ɵ0 = initializeApp;
var IamModule = /** @class */ (function () {
    function IamModule() {
    }
    /**
     * @return {?}
     */
    IamModule.forRoot = /**
     * @return {?}
     */
    function () {
        return {
            ngModule: IamModule,
            providers: []
        };
    };
    IamModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    declarations: [IamComponent],
                    exports: [IamComponent],
                    providers: [IamService, CookieService, SessionService, AppConfigurationService, CacheManagerService, {
                            provide: APP_INITIALIZER,
                            useFactory: ɵ0,
                            deps: [AppConfigurationService, CacheManagerService],
                            multi: true
                        }, {
                            provide: HTTP_INTERCEPTORS,
                            useClass: HttpResponseInterceptor,
                            multi: true
                        }]
                },] },
    ];
    return IamModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

export { IamService, AppConfigurationService, CacheManagerService, CONSTANTS, HttpResponseInterceptor, HttpService, MessageMapping, NavigateService, SessionService, WebSocketCallbackClass, IamComponent, IamModule, initializeApp as ɵa };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWFtLmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9pYW0vbGliL2NvbnN0YW50LnRzIiwibmc6Ly9pYW0vbGliL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UudHMiLCJuZzovL2lhbS9saWIvcnNhLXV0aWxzLnRzIiwibmc6Ly9pYW0vbGliL2Flcy11dGlscy50cyIsIm5nOi8vaWFtL2xpYi9uYXZpZ2F0ZS5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL3Nlc3Npb24uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi93ZWItc29ja2V0LWNhbGxiYWNrcy1jbGFzcy50cyIsIm5nOi8vaWFtL2xpYi9tZXNzYWdlLW1hcHBpbmcudHMiLCJuZzovL2lhbS9saWIvY2FjaGUtbWFuYWdlci5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL2h0dHAuc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9pYW0uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9odHRwLXJlc3BvbnNlLWludGVyY2VwdG9yLnRzIiwibmc6Ly9pYW0vbGliL2lhbS5jb21wb25lbnQudHMiLCJuZzovL2lhbS9saWIvY29uZmlndXJhdGlvbi1mYWN0b3J5LnRzIiwibmc6Ly9pYW0vbGliL2lhbS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIENPTlNUQU5UUyB7XHJcbiAgICAvL3B1YmxpYyBzdGF0aWMgcmVhZG9ubHkgU0VTU0lPTl9USU1FT1VUOiBudW1iZXIgPSAxICogNjAgKiA2MCAqIDEwMDA7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1RPQ09MOiBzdHJpbmcgPSBgJHtsb2NhdGlvbi5wcm90b2NvbH0vL2A7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFdFQlNPQ0tFVF9QUk9UT0NPTDogc3RyaW5nID0gbG9jYXRpb24ucHJvdG9jb2wubG9jYWxlQ29tcGFyZSgnaHR0cHM6JykgPT09IDAgPyAnd3NzOi8vJyA6ICd3czovLyc7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IElERU5USVRZX0NPTlRFWFQ6IHN0cmluZyA9ICcvSUFNL2lkZW50aXR5Lyc7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFDQ0VTU19DT05URVhUOiBzdHJpbmcgPSAnL0lBTS9hY2Nlc3MvJztcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVFJBQ0VfQ09OVEVYVDogc3RyaW5nID0gJy9JQU0vdHJhY2UvJztcclxuICAgIGdldFByb3RvY29sKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIGxvY2F0aW9uLnByb3RvY29sO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIHtcclxuICBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb247XHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7IH1cclxuICBsb2FkQ29uZmlndXJhdGlvbihmaWxlUGF0aDogc3RyaW5nKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4gKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxBcHBDb25maWd1cmF0aW9uPihmaWxlUGF0aCkudG9Qcm9taXNlKCkudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24gPSByZXNwb25zZTtcclxuICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgIH0pLmNhdGNoKChyZXNwb25zZTogYW55KSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhgY291bGQgbm90IGxvYWQgY29uZmlndXJhdGlvbiBmaWxlIGVycm9yOiBcXG4gJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YCk7XHJcbiAgICAgICAgICByZWplY3QoYGNvdWxkIG5vdCBsb2FkIGNvbmZpZ3VyYXRpb24gZmlsZSBlcnJvcjogXFxuICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpfWApO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBwdWJsaWMgZ2V0Q29uZmlndXJhdGlvbigpOiBBcHBDb25maWd1cmF0aW9uIHtcclxuICAgIHJldHVybiB0aGlzLmFwcENvbmZpZ3VyYXRpb247XHJcbiAgfVxyXG4gIFxyXG59XHJcbmV4cG9ydCBpbnRlcmZhY2UgQXBwQ29uZmlndXJhdGlvbiB7XHJcbiAgaXA6IHN0cmluZztcclxuICBwb3J0OiBudW1iZXI7XHJcbiAgd2Vic29ja2V0UG9ydDogbnVtYmVyO1xyXG4gIHByb2plY3Q6IHN0cmluZztcclxuICBub25SZXN0cmljdGVkUGFnZXM6IEFycmF5PHN0cmluZz47XHJcbiAgZGVmYXVsdFBhZ2VBZnRlckxvZ2luOiBzdHJpbmc7XHJcbiAgbG9naW5QYWdlOiBzdHJpbmc7XHJcbiAgc2Vzc2lvbkV4cGlyZWRQYWdlOiBzdHJpbmc7XHJcbiAgbG9nb3V0UGF0aDogc3RyaW5nO1xyXG4gIGNsaWVudFNpZGVSZXF1ZXN0QmFycmluZzogYm9vbGVhbjtcclxuICBzZXNzaW9uVGltZU91dDogbnVtYmVyO1xyXG59XHJcbiIsImNvbnN0ICBmb3JnZSA9IHJlcXVpcmUoJ25vZGUtZm9yZ2UnKTtcclxuZXhwb3J0IGNsYXNzIFJzYVV0aWxzIHtcclxuICAgIHByaXZhdGUgc3RhdGljIHB1YmxpY0tleSA9IG51bGw7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBwcml2YXRlS2V5ID0gbnVsbDtcclxuICAgIGNvbnN0cnVjdG9yKCkge31cclxuICAgIHB1YmxpYyBzdGF0aWMgcHJpdmF0ZUtleUZyb21QRU0ocGVtX2ZpbGVfY29udGVudDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgUnNhVXRpbHMucHJpdmF0ZUtleSA9IGZvcmdlLnBraS5wcml2YXRlS2V5RnJvbVBlbShwZW1fZmlsZV9jb250ZW50KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgcHVibGljS2V5VG9QRU0oKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gZm9yZ2UucGtpLnB1YmxpY0tleVRvUGVtKFJzYVV0aWxzLnB1YmxpY0tleSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIHB1YmxpY0tleUZyb21QRU0ocGVtX2ZpbGVfY29udGVudDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgUnNhVXRpbHMucHVibGljS2V5ID0gZm9yZ2UucGtpLnB1YmxpY0tleUZyb21QZW0ocGVtX2ZpbGVfY29udGVudCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVuY3J5cHQobWVzc2FnZTogc3RyaW5nLCBwZW1QdWJsaWNLZXk/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChwZW1QdWJsaWNLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZvcmdlLnV0aWwuZW5jb2RlNjQoZm9yZ2UucGtpLnByaXZhdGVLZXlGcm9tUGVtKHBlbVB1YmxpY0tleSkuZW5jcnlwdChtZXNzYWdlLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2UgaWYgKFJzYVV0aWxzLnB1YmxpY0tleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9yZ2UudXRpbC5lbmNvZGU2NChSc2FVdGlscy5wdWJsaWNLZXkuZW5jcnlwdChtZXNzYWdlLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncHVibGljIGtleSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGRlY3J5cHQoY2lwaGVyVGV4dDogc3RyaW5nLCBwZW1Qcml2YXRlS2V5Pzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAocGVtUHJpdmF0ZUtleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9yZ2UucGtpLnByaXZhdGVLZXlGcm9tUGVtKHBlbVByaXZhdGVLZXkpLmRlY3J5cHQoZm9yZ2UudXRpbC5kZWNvZGU2NChjaXBoZXJUZXh0KSwgJ1JTQS1PQUVQJywge1xyXG4gICAgICAgICAgICAgICAgbWQ6IGZvcmdlLm1kLnNoYTI1Ni5jcmVhdGUoKSxcclxuICAgICAgICAgICAgICAgIG1nZjE6IHtcclxuICAgICAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMS5jcmVhdGUoKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKFJzYVV0aWxzLnByaXZhdGVLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFJzYVV0aWxzLnByaXZhdGVLZXkuZGVjcnlwdChmb3JnZS51dGlsLmRlY29kZTY0KGNpcGhlclRleHQpLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdwcml2YXRlIGtleSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcml2YXRlS2V5VG9QRU0oKTogc3RyaW5nIHtcclxuICAgICAgICBjb25zdCByc2FQcml2YXRlS2V5ID0gZm9yZ2UucGtpLnByaXZhdGVLZXlUb0FzbjEoUnNhVXRpbHMucHJpdmF0ZUtleSk7XHJcbiAgICAgICAgY29uc3QgcHJpdmF0ZUtleUluZm8gPSBmb3JnZS5wa2kud3JhcFJzYVByaXZhdGVLZXkocnNhUHJpdmF0ZUtleSk7XHJcbiAgICAgICAgcmV0dXJuIGZvcmdlLnBraS5wcml2YXRlS2V5SW5mb1RvUGVtKHByaXZhdGVLZXlJbmZvKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgKiBhcyBhZXNqcyBmcm9tICdhZXMtanMnO1xyXG5pbXBvcnQgeyBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmV4cG9ydCBjbGFzcyBBZXNVdGlscyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBhZXNLZXk6IHN0cmluZyA9IG51bGw7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHt9XHJcbiAgICBwdWJsaWMgc3RhdGljIHNldEFlc0VuY3J5cHRpb25LZXkoYWVzS2V5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBBZXNVdGlscy5hZXNLZXkgPSBhZXNLZXk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVuY3J5cHQobWVzc2FnZTogc3RyaW5nLCBhZXNLZXk/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghYWVzS2V5KSB7XHJcbiAgICAgICAgICAgIGFlc0tleSA9IEFlc1V0aWxzLmFlc0tleTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3Qga2V5ID0gYWVzanMudXRpbHMudXRmOC50b0J5dGVzKGFlc0tleSk7XHJcbiAgICAgICAgbGV0IHRleHRCeXRlcyA9IGFlc2pzLnV0aWxzLnV0ZjgudG9CeXRlcyhtZXNzYWdlKTtcclxuICAgICAgICB0ZXh0Qnl0ZXMgPSBuZXcgYWVzanMucGFkZGluZy5wa2NzNy5wYWQodGV4dEJ5dGVzKTtcclxuICAgICAgICBjb25zdCBhZXNFY2IgPSBuZXcgYWVzanMuTW9kZU9mT3BlcmF0aW9uLmVjYihrZXkpO1xyXG4gICAgICAgIGNvbnN0IGVuY3J5cHRlZEJ5dGVzID0gYWVzRWNiLmVuY3J5cHQodGV4dEJ5dGVzKTtcclxuICAgICAgICByZXR1cm4gYWVzanMudXRpbHMuaGV4LmZyb21CeXRlcyhlbmNyeXB0ZWRCeXRlcyk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGRlY3J5cHQoY2lwaGVyOiBzdHJpbmcsIGFlc0tleT86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFhZXNLZXkpIHtcclxuICAgICAgICAgICAgYWVzS2V5ID0gQWVzVXRpbHMuYWVzS2V5O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBrZXkgPSBhZXNqcy51dGlscy51dGY4LnRvQnl0ZXMoYWVzS2V5KTtcclxuICAgICAgICBjb25zdCBhZXNFY2IgPSBuZXcgYWVzanMuTW9kZU9mT3BlcmF0aW9uLmVjYihrZXkpO1xyXG4gICAgICAgIGNvbnN0IGVuY3J5cHRlZEJ5dGVzID0gYWVzanMudXRpbHMuaGV4LnRvQnl0ZXMoY2lwaGVyKTtcclxuICAgICAgICBsZXQgZGVjcnlwdGVkQnl0ZXMgPSBhZXNFY2IuZGVjcnlwdChlbmNyeXB0ZWRCeXRlcyk7XHJcbiAgICAgICAgZGVjcnlwdGVkQnl0ZXMgPSBhZXNqcy5wYWRkaW5nLnBrY3M3LnN0cmlwKGRlY3J5cHRlZEJ5dGVzKTtcclxuICAgICAgICByZXR1cm4gIGFlc2pzLnV0aWxzLnV0ZjguZnJvbUJ5dGVzKGRlY3J5cHRlZEJ5dGVzKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVSYW5kb21BZXNLZXkobGVuZ3RoOiBudW1iZXI9IDE2KTogc3RyaW5nIHtcclxuICAgICAgICBjb25zdCBtYXA6IE1hcDxudW1iZXIsIHN0cmluZz4gPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xyXG4gICAgICAgIG1hcC5zZXQoMCwgJ2EnKS5zZXQoMSwgJ2InKS5zZXQoMiwgJ2MnKS5zZXQoMywgJ2QnKS5zZXQoNCwgJ2UnKS5zZXQoNSwgJ2YnKS5cclxuICAgICAgICBzZXQoNiwgJ2cnKS5zZXQoNywgJ2gnKS5zZXQoOCwgJ2knKS5zZXQoOSwgJ2onKS5zZXQoMTAsICdrJykuc2V0KDExLCAnbCcpLnNldCgxMiwgJ20nKS5cclxuICAgICAgICBzZXQoMTMsICduJykuc2V0KDE0LCAnbycpLnNldCgxNSwgJ3AnKS5zZXQoMTYsICdxJykuc2V0KDE3LCAncicpLlxyXG4gICAgICAgIHNldCgxOCwgJ3MnKS5zZXQoMTksICd0Jykuc2V0KDIwLCAndScpLnNldCgyMSwgJ3YnKS5zZXQoMjIsICd3Jykuc2V0KDIzLCAneCcpLnNldCgyNCwgJ3knKS5cclxuICAgICAgICBzZXQoMjUsICd6Jykuc2V0KDI2LCAnQScpLnNldCgyNywgJ0InKS5zZXQoMjgsICdDJykuc2V0KDI5LCAnRCcpLnNldCgzMCwgJ0UnKS5zZXQoMzEsICdGJykuXHJcbiAgICAgICAgc2V0KDMyLCAnRycpLnNldCgzMywgJ0gnKS5zZXQoMzQsICdJJykuc2V0KDM1LCAnSicpLnNldCgzNiwgJ0snKS5zZXQoMzcsICdMJykuc2V0KDM4LCAnTScpLlxyXG4gICAgICAgIHNldCgzOSwgJ04nKS5zZXQoNDAsICdPJykuc2V0KDQxLCAnUCcpLnNldCg0MiwgJ1EnKS5zZXQoNDMsICdSJykuc2V0KDQ0LCAnUycpLnNldCg0NSwgJ1QnKS5cclxuICAgICAgICBzZXQoNDYsICdVJykuc2V0KDQ3LCAnVicpLnNldCg0OCwgJ1cnKS5zZXQoNDksICdYJykuc2V0KDUwLCAnWScpLnNldCg1MSwgJ1onKTtcclxuICAgICAgICBsZXQga2V5ID0gJyc7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBrZXkgPSBrZXkuY29uY2F0KG1hcC5nZXQoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNTIpKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBrZXk7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0ZVNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyKSB7IH1cclxuICBuYXZpZ2F0ZShwYXRoOiBzdHJpbmdbXSk6IHZvaWQge1xyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUocGF0aCk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb29raWVTZXJ2aWNlIH0gZnJvbSAnbmd4LWNvb2tpZS1zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09OU1RBTlRTIH0gZnJvbSAnLi9jb25zdGFudCc7XHJcbmltcG9ydCB7IEFlc1V0aWxzIH0gZnJvbSAnLi9hZXMtdXRpbHMnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSBhcyBBcHBTZXR0aW5nIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0ICogYXMgRmluZ2VycHJpbnQyIGZyb20gJ2ZpbmdlcnByaW50anMyc3luYyc7XHJcbmltcG9ydCB7IE5hdmlnYXRlU2VydmljZSB9IGZyb20gJy4vbmF2aWdhdGUuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgU2Vzc2lvblNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGhhc2hLZXk6IHN0cmluZyA9IG5ldyBGaW5nZXJwcmludDIoe2V4Y2x1ZGVBZEJsb2NrIDogdHJ1ZX0pLmdldFN5bmMoKS5mcHJpbnQuc3Vic3RyKDAsIDE2KTtcclxuICBwdWJsaWMgZ2xvYmFsczogYW55O1xyXG4gIHB1YmxpYyBzZWxlY3RlZENpcmNsZU5hbWU6IHN0cmluZztcclxuICBwdWJsaWMgc2VsZWN0ZWROZU5hbWU6IHN0cmluZztcclxuICBwdWJsaWMgc2VsZWN0ZWROZVNob3J0TmFtZTogc3RyaW5nO1xyXG4gIHB1YmxpYyBwYXJzZWROb2RlQ2lyY2xlSnNvbjogYW55O1xyXG4gIHB1YmxpYyBub2RlTmFtZUNpcmNsZTogYW55O1xyXG4gIHB1YmxpYyBzdHJ1Y3R1cmVkUmVzdHJpY3Rpb246IGFueTtcclxuICBwdWJsaWMgbW9kdWxlUmVzdHJpY3Rpb246IGFueTtcclxuICBwdWJsaWMgbWFwTmVOYW1lQ2lyY2xlTmFtZTogYW55O1xyXG4gIHB1YmxpYyBub2RlTmFtZUxpc3Q6IGFueTtcclxuICBwdWJsaWMgY29uc3RydWN0b3IocHJpdmF0ZSBjb29raWVTZXJ2aWNlOiBDb29raWVTZXJ2aWNlLCBwcml2YXRlIGFwcFNldHRpbmc6IEFwcFNldHRpbmcsIHByaXZhdGUgbmF2aWdhdGVTZXJ2aWNlOiBOYXZpZ2F0ZVNlcnZpY2UpIHt9XHJcbiAgLypcclxuICAqVGhpcyBmdW5jdGlvbiBpcyB1c2VkIHRvIGZldGNoIHN0b3JlZCBzZXNzaW9uIGRhdGFcclxuICAqL1xyXG4gIGdldFNlc3Npb25EYXRhKGtleTogc3RyaW5nID0gJ2dsb2JhbHMnKTogUmVzcG9uc2VTZXNzaW9uRGF0YSB7XHJcbiAgICBjb25zdCBjb29raWU6IFJlc3BvbnNlU2Vzc2lvbkRhdGEgPSB7fTtcclxuICAgIGxldCBkYXRhOiBKU09OO1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgICAgZGF0YSA9IEpTT04ucGFyc2UodGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKGtleSkgPyBBZXNVdGlscy5kZWNyeXB0KHRoaXMuY29va2llU2VydmljZS5nZXQoa2V5KSwgdGhpcy5oYXNoS2V5KSA6ICd7fScpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coJ2ludG8gY2xlYXJpbmcgc2Vzc2lvbicpO1xyXG4gICAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgICAgZGF0YSA9IHt9IGFzIEpTT047XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZGF0YSBhcyBSZXNwb25zZVNlc3Npb25EYXRhO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGdldEFlc0tleShrZXk6IHN0cmluZyA9ICdhZXNLZXknKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGV4cGlyeVRpbWU6IG51bWJlciA9IHRoaXMuZ2V0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgaWYgKGV4cGlyeVRpbWUgPiBuZXcgRGF0ZSgpLmdldFRpbWUoKSkge1xyXG4gICAgICByZXR1cm4gdGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKGtleSkgPyBBZXNVdGlscy5kZWNyeXB0KHRoaXMuY29va2llU2VydmljZS5nZXQoa2V5KSwgdGhpcy5oYXNoS2V5KSA6IG51bGw7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFNlc3Npb25EYXRhKHNlc3Npb25EYXRhOiBSZXF1ZXN0U2Vzc2lvbkRhdGEsIGtleSA9ICdnbG9iYWxzJyApOiB2b2lkIHtcclxuICAgIGNvbnN0IGRhdGEgPSB7fTtcclxuICAgIGNvbnN0IHVzZXJJbmZvcm1hdGlvbiA9IHtcclxuICAgICAgICBjdXJyZW50VXNlcjoge1xyXG4gICAgICAgICAgdXNlck5hbWU6IHNlc3Npb25EYXRhLnVzZXJOYW1lLFxyXG4gICAgICAgICAgYXBwRGF0YTogc2Vzc2lvbkRhdGEuYXBwRGF0YSxcclxuICAgICAgICAgIG5vZGVOYW1lQ2lyY2xlOiBzZXNzaW9uRGF0YS5ub2RlTmFtZUNpcmNsZVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBpZiAoc2Vzc2lvbkRhdGEubmVOYW1lQ2lyY2xlTmFtZSkge1xyXG4gICAgICB1c2VySW5mb3JtYXRpb24uY3VycmVudFVzZXJbJ25lTmFtZUNpcmNsZU5hbWUnXSA9IHNlc3Npb25EYXRhLm5lTmFtZUNpcmNsZU5hbWU7XHJcbiAgICB9XHJcbiAgICBpZiAoc2Vzc2lvbkRhdGEuYWVzS2V5KSB7XHJcbiAgICAgIGRhdGFbJ2Flc0tleSddID0gc2Vzc2lvbkRhdGEuYWVzS2V5O1xyXG4gICAgfVxyXG4gICAgZGF0YVtrZXldID0gdXNlckluZm9ybWF0aW9uO1xyXG4gICAgdGhpcy5jb29raWVTZXJ2aWNlLnNldChrZXksIEFlc1V0aWxzLmVuY3J5cHQoSlNPTi5zdHJpbmdpZnkoZGF0YSksIHRoaXMuaGFzaEtleSkpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGNsZWFyU2Vzc2lvbkRhdGEoLi4uYXJnczogc3RyaW5nW10pOiB2b2lkIHtcclxuICAgIGlmICggYXJncy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGZvciAoY29uc3QgYXJnIG9mIGFyZ3MpIHtcclxuICAgICAgICB0aGlzLmNvb2tpZVNlcnZpY2UuZGVsZXRlKGFyZyk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuY29va2llU2VydmljZS5kZWxldGVBbGwoKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgcHV0RGF0ZUZvckNvb2tpZUV4cGlyeSh0aW1lU3RhbXA/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIGxldCBzZXNzaW9uVGltZTpudW1iZXI9NjAwMDAwO1xyXG4gICAgaWYodGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKSlcclxuICAgIHtcclxuICAgICAgc2Vzc2lvblRpbWU9dGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uVGltZU91dDtcclxuICAgIH1cclxuICAgIGlmICghdGltZVN0YW1wKSB7XHJcbiAgICAgIHRoaXMuY29va2llU2VydmljZS5zZXQoJ2V4cGlyeVRpbWUnLCAobmV3IERhdGUoKS5nZXRUaW1lKCkgKyBzZXNzaW9uVGltZSkudG9TdHJpbmcoKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCdleHBpcnlUaW1lJywgdGltZVN0YW1wKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXREYXRlRm9yQ29va2llRXhwaXJ5KCk6IG51bWJlciB7XHJcbiAgICBsZXQgc2Vzc2lvblRpbWU6bnVtYmVyPTYwMDAwMDtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpXHJcbiAgICB7XHJcbiAgICAgIHNlc3Npb25UaW1lPXRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkuc2Vzc2lvblRpbWVPdXQ7XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKCdleHBpcnlUaW1lJykpIHtcclxuICAgICByZXR1cm4gTnVtYmVyLnBhcnNlSW50KHRoaXMuY29va2llU2VydmljZS5nZXQoJ2V4cGlyeVRpbWUnKSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCdleHBpcnlUaW1lJywgKG5ldyBEYXRlKCkuZ2V0VGltZSgpICsgc2Vzc2lvblRpbWUpLnRvU3RyaW5nKCkpO1xyXG4gICAgcmV0dXJuIChuZXcgRGF0ZSgpLmdldFRpbWUoKSArIHNlc3Npb25UaW1lKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBzZXRVc2VyVG9rZW5EYXRhKHVzZXJUb2tlbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCd1c2VyVG9rZW4nLCBBZXNVdGlscy5lbmNyeXB0KHVzZXJUb2tlbiwgdGhpcy5oYXNoS2V5KSk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0VXNlclRva2VuRGF0YSgpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLmNvb2tpZVNlcnZpY2UuY2hlY2soJ3VzZXJUb2tlbicpID8gQWVzVXRpbHMuZGVjcnlwdCh0aGlzLmNvb2tpZVNlcnZpY2UuZ2V0KCd1c2VyVG9rZW4nKSwgdGhpcy5oYXNoS2V5KSA6IG51bGw7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFNlc3Npb25EYXRhRm9yTW9kdWxlUmVzdHJpY3Rpb24obW9kdWxlUmVzdHJpY3Rpb246IEpTT04sIGtleTogc3RyaW5nID0gJ21vZHVsZVJlc3RyaWN0aW9uJyk6IHZvaWQge1xyXG4gICAgaWYgKHR5cGVvZihTdG9yYWdlKSkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KG1vZHVsZVJlc3RyaWN0aW9uKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZygnTG9jYWwgU3RvcmdhZSBub3QgYXZhaWxhYmxlJyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0U2Vzc2lvbkRhdGFGb3JNb2R1bGVSZXN0cmljdGlvbihrZXk6IHN0cmluZyA9ICdtb2R1bGVSZXN0cmljdGlvbicpOiBKU09OIHtcclxuICAgIGNvbnN0IGV4cGlyeVRpbWU6IG51bWJlciA9IHRoaXMuZ2V0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgaWYgKGV4cGlyeVRpbWUgPiBuZXcgRGF0ZSgpLmdldFRpbWUoKSkge1xyXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA6ICd7fScpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5jbGVhclNlc3Npb25EYXRhQW5kR290b1Nlc3Npb25FeHBpcmVQYWdlKCk7XHJcbiAgICByZXR1cm4gSlNPTi5wYXJzZSgne30nKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBzZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihzdHJ1Y3R1cmVkUmVzdHJpY3Rpb246IEpTT04sIGtleTogc3RyaW5nID0gJ3N0cnVjdHVyZWRSZXN0cmljdGlvbicpOiB2b2lkIHtcclxuICAgIGlmICh0eXBlb2YoU3RvcmFnZSkpIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeShzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdMb2NhbCBTdG9yZ2FlIG5vdCBhdmFpbGFibGUnKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihrZXk6IHN0cmluZyA9ICdzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24nKTogSlNPTiB7XHJcbiAgICBjb25zdCBleHBpcnlUaW1lOiBudW1iZXIgPSB0aGlzLmdldERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgIGlmIChleHBpcnlUaW1lID4gbmV3IERhdGUoKS5nZXRUaW1lKCkpIHtcclxuICAgICAgcmV0dXJuIEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA/IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgOiAne30nKTtcclxuICAgIH1cclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgcmV0dXJuIEpTT04ucGFyc2UoJ3t9Jyk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgc2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24obm9kZUNpcmNsZVJlc3RyaWN0aW9uOiBKU09OLCBrZXk6IHN0cmluZyA9ICdub2RlQ2lyY2xlUmVzdHJpY3Rpb24nKTogdm9pZCB7XHJcbiAgICBpZiAodHlwZW9mKFN0b3JhZ2UpKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkobm9kZUNpcmNsZVJlc3RyaWN0aW9uKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZygnTG9jYWwgU3RvcmdhZSBub3QgYXZhaWxhYmxlJyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24oa2V5OiBzdHJpbmcgPSAnbm9kZUNpcmNsZVJlc3RyaWN0aW9uJyk6IEpTT04ge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpIDogJ3t9Jyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBKU09OLnBhcnNlKCd7fScpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGEoKTtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpIHtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2UpO1xyXG4gICAgICB0aGlzLm5hdmlnYXRlU2VydmljZS5uYXZpZ2F0ZShbdGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2VdKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBjbGVhclNlc3Npb25EYXRhQW5kR290b0xvZ291dFBhZ2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGEoKTtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpIHtcclxuICAgICAgdGhpcy5uYXZpZ2F0ZVNlcnZpY2UubmF2aWdhdGUoW3RoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkubG9nb3V0UGF0aF0pO1xyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIHJlc2V0VmFyaWFibGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5nbG9iYWxzID0gbnVsbDtcclxuICAgIHRoaXMuc2VsZWN0ZWRDaXJjbGVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2VsZWN0ZWROZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZWxlY3RlZE5lU2hvcnROYW1lID0gbnVsbDtcclxuICAgIHRoaXMucGFyc2VkTm9kZUNpcmNsZUpzb24gPSBudWxsO1xyXG4gICAgdGhpcy5ub2RlTmFtZUNpcmNsZSA9IG51bGw7XHJcbiAgICB0aGlzLnN0cnVjdHVyZWRSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICB0aGlzLm1vZHVsZVJlc3RyaWN0aW9uID0gbnVsbDtcclxuICAgIHRoaXMubWFwTmVOYW1lQ2lyY2xlTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLm5vZGVOYW1lTGlzdCA9IFtdO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0U2Vzc2lvbkRhdGEge1xyXG4gIHVzZXJOYW1lOiBzdHJpbmc7XHJcbiAgYXBwRGF0YTogSlNPTjtcclxuICBub2RlTmFtZUNpcmNsZTogc3RyaW5nO1xyXG4gIGFlc0tleT86IHN0cmluZztcclxuICBuZU5hbWVDaXJjbGVOYW1lPzogSlNPTjtcclxufVxyXG5leHBvcnQgaW50ZXJmYWNlIFJlc3BvbnNlU2Vzc2lvbkRhdGEge1xyXG4gIGdsb2JhbHM/OiB7XHJcbiAgICBjdXJyZW50VXNlcjoge1xyXG4gICAgICB1c2VyTmFtZT86IHN0cmluZztcclxuICAgICAgYXBwRGF0YT86IEpTT047XHJcbiAgICAgIG5vZGVOYW1lQ2lyY2xlPzogc3RyaW5nO1xyXG4gICAgICBuZU5hbWVDaXJjbGVOYW1lPzogSlNPTjtcclxuICAgIH07XHJcbiAgfTtcclxuICBhZXNLZXk/OiBzdHJpbmc7XHJcbn1cclxuIiwiaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tzIH0gZnJvbSAnLi9pYW0uc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuZXhwb3J0IGNsYXNzIFdlYlNvY2tldENhbGxiYWNrQ2xhc3MgaW1wbGVtZW50cyBXZWJTb2NrZXRDYWxsYmFja3Mge1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25NZXNzYWdlU3ViamVjdDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25PcGVuU3ViamVjdDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25DbG9zZVN1YmplY3Q6IFN1YmplY3Q8YW55PiA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgIHByaXZhdGUgc3RhdGljIG9uRXJyb3JTdWJqZWN0OiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBvbldlYnNvY2tldFJlY29ubmVjdFN1YmplY3Q6IFN1YmplY3Q8dm9pZD4gPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0T25NZXNzYWdlT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE9uT3Blbk9ic2VydmFibGUoKTogT2JzZXJ2YWJsZTxNZXNzYWdlRXZlbnQ+IHtcclxuICAgICAgICByZXR1cm4gV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbkNsb3NlT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uQ2xvc2VTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbkVycm9yT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uRXJyb3JTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbldlYnNvY2tldFJlY29ubmVjdE9ic2VydmFibGUoKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICAgICAgcmV0dXJuIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25XZWJzb2NrZXRSZWNvbm5lY3RTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyByZUluaXRpYWxpemVPYnNlcnZhYmxlcygpOiB2b2lkIHtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QgPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0ICA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uQ2xvc2VTdWJqZWN0ICA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uRXJyb3JTdWJqZWN0ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgfVxyXG4gICAgb25NZXNzYWdlKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QubmV4dChldmVudCk7XHJcbiAgICB9XHJcbiAgICBvbkNsb3NlKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnd2Vic29ja2V0IGNsb3NlZCcpO1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25DbG9zZVN1YmplY3QubmV4dChldmVudCk7XHJcbiAgICB9XHJcbiAgICBvbkVycm9yKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbkVycm9yU3ViamVjdC5uZXh0KGV2ZW50KTtcclxuICAgIH1cclxuICAgIG9uT3BlbihldmVudDogTWVzc2FnZUV2ZW50LCB3ZWJzb2NrZXQ6IFdlYlNvY2tldCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd3ZWJzb2NrZXQgb3BlbmVkJyk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0Lm5leHQoZXZlbnQpO1xyXG4gICAgfVxyXG4gICAgb25SZWNvbm5lY3QoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3dlYnNvY2tldCByZS1jb25uZWN0ZWQnKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uV2Vic29ja2V0UmVjb25uZWN0U3ViamVjdC5uZXh0KCk7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gXCJAYW5ndWxhci9jb21tb24vaHR0cFwiO1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCdcbn0pXG5leHBvcnQgY2xhc3MgTWVzc2FnZU1hcHBpbmcge1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cENsaWVudDogSHR0cENsaWVudCkgeyB9XG4gIHByaXZhdGUgc3RhdGljIG1lc3NhZ2VNYXA6IE1hcDxudW1iZXIsIHN0cmluZz4gPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xuICBwdWJsaWMgc3RhdGljIGdldE1lc3NhZ2UoY29kZTogbnVtYmVyKTogYW55IHtcbiAgICAgIHJldHVybiBNZXNzYWdlTWFwcGluZy5tZXNzYWdlTWFwLmhhcyhjb2RlKSA/IE1lc3NhZ2VNYXBwaW5nLm1lc3NhZ2VNYXAuZ2V0KGNvZGUpIDogJ3Vua25vd24gZXJyb3IgY29kZSByZWNlaXZlZCc7XG4gIH1cbiAgcHVibGljIGxvYWRNZXNhZ2VNYXAoZmlsZVBhdGg6c3RyaW5nKTogdm9pZCB7XG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEpTT04+KGZpbGVQYXRoKS50b1Byb21pc2UoKS50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgIG5ldyBNYXA8c3RyaW5nLHN0cmluZz4oT2JqZWN0LmVudHJpZXMocmVzcG9uc2UpKS5mb3JFYWNoKCh2YWx1ZTogc3RyaW5nLCBrZXk6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgTWVzc2FnZU1hcHBpbmcubWVzc2FnZU1hcC5zZXQoTnVtYmVyLnBhcnNlSW50KGtleSksdmFsdWUpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KS5jYXRjaCgocmVzcG9uc2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYGNvdWxkIG5vdCBsb2FkIGNvbmZpZ3VyYXRpb24gZmlsZSBlcnJvcjogXFxuICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpfWApO1xuICAgICAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25Jbml0LCBPbkRlc3Ryb3ksIEhvc3RMaXN0ZW5lciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IENPTlNUQU5UUyB9IGZyb20gJy4vY29uc3RhbnQnO1xyXG5pbXBvcnQgeyBIdHRwSGVhZGVycywgSHR0cENsaWVudCwgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgcmV0cnksIGNhdGNoRXJyb3IsIGRlbGF5IH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyB0aHJvd0Vycm9yLCBPYnNlcnZhYmxlLCBTdWJzY3JpYmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJzYVV0aWxzIH0gZnJvbSAnLi9yc2EtdXRpbHMnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSwgUmVzcG9uc2VTZXNzaW9uRGF0YSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgKiBhcyBmb3JnZSBmcm9tICdub2RlLWZvcmdlJztcclxuaW1wb3J0IHsgQWVzVXRpbHMgfSBmcm9tICcuL2Flcy11dGlscyc7XHJcbmltcG9ydCB7IFdlYlNvY2tldENhbGxiYWNrQ2xhc3MgfSBmcm9tICcuL3dlYi1zb2NrZXQtY2FsbGJhY2tzLWNsYXNzJztcclxuaW1wb3J0IHsgTWVzc2FnZU1hcHBpbmcgfSBmcm9tICcuL21lc3NhZ2UtbWFwcGluZyc7XHJcbmltcG9ydCB7IFdlYlNvY2tldENhbGxiYWNrcyB9IGZyb20gJy4vaWFtLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQ2FjaGVNYW5hZ2VyU2VydmljZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICBwdWJsaWMgZW5jcnlwdGlvbktleTogYW55O1xyXG4gIHB1YmxpYyB0aW1lQWRqdXN0bWVudDogbnVtYmVyO1xyXG4gIHB1YmxpYyBjaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZTogYW55O1xyXG4gIHB1YmxpYyBuZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjogYW55O1xyXG4gIHB1YmxpYyBtYXBOZVNob3J0TmFtZUZ1bGxOYW1lOiBhbnk7XHJcbiAgcHVibGljIHNob3J0Q29kZVRvSWRNYXA6IGFueTtcclxuICBwdWJsaWMgbm9kZVRvSWRNYXA6IGFueTtcclxuICBwdWJsaWMgY2lyY2xlVG9JZE1hcDogYW55O1xyXG4gIHB1YmxpYyBPcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmc6IGFueTtcclxuICBwdWJsaWMgbG9naW5Vc2VySW1hZ2U6IGFueTtcclxuICBwdWJsaWMgd2Vic29ja2V0OiBXZWJTb2NrZXQ7XHJcbiAgcHVibGljIFhfU09DS0VUX0FERFJFU1M6IHN0cmluZztcclxuICBwdWJsaWMgWF9VU0VSTkFNRTogc3RyaW5nO1xyXG4gIHB1YmxpYyBTT0NLRVRfSVA6IHN0cmluZztcclxuICBwdWJsaWMgcmVzb2x2ZUZuOiAoKSA9PiB2b2lkO1xyXG4gIHB1YmxpYyByZWplY3RGbjogKCkgPT4gdm9pZDtcclxuICBwdWJsaWMgd2Vic29ja2V0T3BlblByb21pc2U6IFByb21pc2U8dm9pZD4gPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICB0aGlzLnJlc29sdmVGbiA9IHJlc29sdmU7XHJcbiAgICB0aGlzLnJlamVjdEZuID0gcmVqZWN0O1xyXG4gIH0pO1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgYXBwQ29uZmlndXJhdGlvbjogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIHByaXZhdGUgaHR0cENsaWVudDogSHR0cENsaWVudCxcclxuICAgIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLCBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixwcml2YXRlIG1lc3NhZ2VNYXBwaW5nOk1lc3NhZ2VNYXBwaW5nKSB7IH1cclxuICBuZ09uSW5pdCgpIHsgfVxyXG4gIG5nT25EZXN0cm95KCkge1xyXG4gICAgaWYgKHRoaXMud2Vic29ja2V0KSB7XHJcbiAgICAgIHRoaXMud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGdldEF1dGhLZXkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRhdXRoa2V5Jyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHsgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsICdvcGVyYXRpb24nOiAnZ2V0YXV0aGtleScgfSksXHJcbiAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IHtcclxuICAgICAgICAgIHBlbUZpbGU6IHN0cmluZ1xyXG4gICAgICAgIH1cclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxIdHRwUmVzcG9uc2U8UmVzcG9uc2U+Pih1cmwsIGh0dHBPcHRpb25zKVxyXG4gICAgICAgIC5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5ib2R5LnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICBSc2FVdGlscy5wdWJsaWNLZXlGcm9tUEVNKHJlc3AuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEucGVtRmlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZW5jcnlwdGlvbktleSA9IHJlc3AuYm9keS5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIGNvbnN0IHNlcnZlclRpbWUgPSByZXNwLmhlYWRlcnMuaGFzKCdEYXRlJykgPyBuZXcgRGF0ZShyZXNwLmhlYWRlcnMuZ2V0KCdEYXRlJykpLmdldFRpbWUoKSA6IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xyXG4gICAgICAgICAgICBjb25zdCBjbGllbnRUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgIHRoaXMudGltZUFkanVzdG1lbnQgPSBzZXJ2ZXJUaW1lIC0gY2xpZW50VGltZTtcclxuICAgICAgICAgICAgLy90aGlzLnNlc3Npb25TZXJ2aWNlLnB1dERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coJ2ZldGNoaW5nIHJzYSBrZXkgZmFpbGVkJyk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXROb2RlU2hvcnROYW1lRnVsbE5hbWVKc29uKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCkuY29uY2F0KCc/b3BlcmF0aW9uPWdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZScpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXROb2RlU2hvcnROYW1lRnVsbE5hbWUnXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IEpTT04sXHJcbiAgICAgICAgdHlwZTogc3RyaW5nLFxyXG4gICAgICAgIGh0dHBzdGF0dXNjb2RlOiBzdHJpbmcsXHJcbiAgICAgICAgb3BTdGF0dXNDb2RlOiBzdHJpbmdcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8UmVzcG9uc2U+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIGlmIChyZXNwLnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICB0aGlzLm5lU2hvcnROYW1lRnVsbE5hbWVKc29uID0ge1xyXG4gICAgICAgICAgICAgICdOb2RlTmFtZSc6IHJlc3Auc3RhdHVzQ29kZS5BcHBEYXRhXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZScpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZSdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2lyY2xlRnVsbE5hbWVKc29uUmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgICAgQ2lyY2xlTmFtZTogcmVzcC5zdGF0dXNDb2RlLkFwcERhdGFcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0TW9kdWxlVG9JZEpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0U2hvcnRDb2RlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRTaG9ydENvZGVUb0lkTWFwJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG9ydENvZGVUb0lkTWFwID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVUb0lkSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXROb2RlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXROb2RlVG9JZE1hcCdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZVRvSWRNYXAgPSByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Q2lyY2xlVG9JZEpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0Q2lyY2xlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRDaXJjbGVUb0lkTWFwJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5jaXJjbGVUb0lkTWFwID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZUpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZSdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldFBhdGhOYW1lKCkge1xyXG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbiAmJiB3aW5kb3cubG9jYXRpb24uaGFzaCAmJiB3aW5kb3cubG9jYXRpb24uaGFzaC5zdWJzdHIoMSk7XHJcbn1cclxuICBvblN0YXJ0dXBSb3V0ZUNoYW5nZShldmVudCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscztcclxuICAgICAgaWYgKCF0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMpIHtcclxuICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB7fTtcclxuICAgICAgfVxyXG4gICAgICBpZiAodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5sb2dpblBhZ2UgJiYgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5ub25SZXN0cmljdGVkUGFnZXNcclxuICAgICAgICAmJiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbikge1xyXG4gICAgICAgIGxldCBwYXRoTmFtZSA9IHRoaXMubG9jYXRpb24ucGF0aCgpO1xyXG4gICAgICAgIGlmKHBhdGhOYW1lLmluY2x1ZGVzKFwiP1wiKSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXRoTmFtZT1wYXRoTmFtZS5zcGxpdChcIj9cIilbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlc3RyaWN0ZWRQYWdlOiBib29sZWFuID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5ub25SZXN0cmljdGVkUGFnZXMuaW5kZXhPZihwYXRoTmFtZSk9PT0tMTtcclxuICAgICAgICBjb25zdCBsb2dnZWRJbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscy5jdXJyZW50VXNlcjtcclxuICAgICAgIGlmIChyZXN0cmljdGVkUGFnZSAmJiAhbG9nZ2VkSW4pIHtcclxuICAgICAgICAgIHRoaXMubG9jYXRpb24uZ28odGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5sb2dpblBhZ2UpO1xyXG4gICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobG9nZ2VkSW4pIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5tb2R1bGVSZXN0cmljdGlvbikge1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubW9kdWxlUmVzdHJpY3Rpb24gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhRm9yTW9kdWxlUmVzdHJpY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2Uuc3RydWN0dXJlZFJlc3RyaWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhRm9yU3RydWN0dXJlZFJlc3RyaWN0aW9uKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKCF0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5wYXJzZWROb2RlQ2lyY2xlSnNvbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBsb2dpblBhZ2UgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlcy5pbmRleE9mKHBhdGhOYW1lKSE9LTE7XHJcbiAgICAgICAgICAgIGlmIChsb2dpblBhZ2UpIHtcclxuICAgICAgICAgICAgICB0aGlzLmxvY2F0aW9uLmdvKHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm9wZW5XZWJTb2NrZXRDaGFubmVsKG5ldyBXZWJTb2NrZXRDYWxsYmFja0NsYXNzKCkpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBjYWxsV2hlbkNvbmZpZ0xvYWRzKCkge1xyXG4gICAgY29uc3QgdXNlckRldGFpbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHM7XHJcbiAgICBjb25zdCBhZXNLZXkgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuYWVzS2V5O1xyXG4gICAgdGhpcy5tZXNzYWdlTWFwcGluZy5sb2FkTWVzYWdlTWFwKCdhc3NldHMvY29uZmlndXJhdGlvbi9tZXNzYWdlbWFwcGluZy5qc29uJyk7XHJcbiAgICBpZiAoYWVzS2V5KSB7XHJcbiAgICAgIEFlc1V0aWxzLnNldEFlc0VuY3J5cHRpb25LZXkoYWVzS2V5KTtcclxuICAgIH1cclxuICAgIGlmICh1c2VyRGV0YWlscyAmJiB1c2VyRGV0YWlscy5jdXJyZW50VXNlciAmJiB1c2VyRGV0YWlscy5jdXJyZW50VXNlci51c2VybmFtZSAmJiAhdGhpcy5sb2dpblVzZXJJbWFnZSkge1xyXG4gICAgICBpbnRlcmZhY2UgVXNlckltYWdlUmVzcG9uc2Uge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGJvb2xlYW47XHJcbiAgICAgICAgQXBwRGF0YToge1xyXG4gICAgICAgICAgdXNlckluZm86IHtcclxuICAgICAgICAgICAgdXNlckltYWdlOiBzdHJpbmc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmdldFVzZXJJbWFnZTxVc2VySW1hZ2VSZXNwb25zZT4odXNlckRldGFpbHMuY3VycmVudFVzZXIudXNlcm5hbWUpLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgIHRoaXMubG9naW5Vc2VySW1hZ2UgPSByZXNwb25zZS5BcHBEYXRhLnVzZXJJbmZvLnVzZXJJbWFnZSA/IHJlc3BvbnNlLkFwcERhdGEudXNlckluZm8udXNlckltYWdlIDogJ25vSW1hZ2UnO1xyXG4gICAgICAgIH1cclxuICAgICAgfSwgZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuICBnZXRVc2VySW1hZ2U8VD4odXNlck5hbWU6IHN0cmluZyk6IFByb21pc2U8VD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5JREVOVElUWV9DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0VXNlckltYWdlJnVzZXJOYW1lPScpLmNvbmNhdCh1c2VyTmFtZSk7XHJcbiAgICBjb25zdCB1c2VyVG9rZW4gPSBgJHt1c2VyTmFtZX0tdGhpcy5zZXNzaW9uU2VydmljZS5nZXRVc2VyVG9rZW5EYXRhKClgO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRVc2VySW1hZ2UnLFxyXG4gICAgICAgICd1c2VyVG9rZW4nOiBgJHt1c2VyTmFtZX0tJHt0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFVzZXJUb2tlbkRhdGEoKX1gXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxUPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICByZXNvbHZlKHJlc3ApO1xyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgb3BlbldlYlNvY2tldENoYW5uZWwod2Vic29ja2V0Q2FsbGJhY2tzOiBXZWJTb2NrZXRDYWxsYmFja3MpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcclxuICAgIGxldCByZXNwb25zZVNlc3Npb25EYXRhOiBSZXNwb25zZVNlc3Npb25EYXRhID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpO1xyXG4gICAgY29uc3QgcHJvdG9jb2wgPSBDT05TVEFOVFMuV0VCU09DS0VUX1BST1RPQ09MO1xyXG4gICAgY29uc3QgaXAgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwO1xyXG4gICAgY29uc3QgcG9ydCA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydDtcclxuICAgIGNvbnN0IHdlYnNvY2tldFBvcnQgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLndlYnNvY2tldFBvcnQ7XHJcbiAgICBjb25zdCBwcm9qZWN0ID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0O1xyXG4gICAgY29uc3QgdXNlck5hbWUgPSByZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWU7XHJcbiAgICBjb25zdCBiYXNlNjR0b2tlbiA9IGZvcmdlLnV0aWwuZW5jb2RlNjQoYCR7dXNlck5hbWV9LSR7dGhpcy5zZXNzaW9uU2VydmljZS5nZXRVc2VyVG9rZW5EYXRhKCl9YCk7XHJcbiAgICBjb25zdCBxdWVyeVN0cmluZyA9IGA/b3BlcmF0aW9uPWF1dGhlbnRpY2F0ZVdlYlNvY2tldCZwcm9qZWN0PSR7cHJvamVjdH0mdXNlclRva2VuPSR7YmFzZTY0dG9rZW59JnByb2plY3RVcmw9JHtpcH06JHtwb3J0fWA7XHJcbiAgICBjb25zdCB3ZWJTb2NrZXRVUkwgPSBgJHtwcm90b2NvbH0ke2lwfToke3dlYnNvY2tldFBvcnR9L3dlYnNvY2tldCR7cXVlcnlTdHJpbmd9YDtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTx2b2lkPihvYnNlcnZlID0+IHtcclxuICAgICAgbGV0IGZsYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB0aGlzLndlYnNvY2tldCA9IG5ldyBXZWJTb2NrZXQod2ViU29ja2V0VVJMKTtcclxuICAgICAgICBpZiAod2Vic29ja2V0Q2FsbGJhY2tzLm9uT3Blbikge1xyXG4gICAgICAgICAgdGhpcy53ZWJzb2NrZXQub25vcGVuID0gKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZWJzb2NrZXRDYWxsYmFja3Mub25PcGVuKCk7XHJcbiAgICAgICAgICAgIGNvbnN0IG1hcDogTWFwPHN0cmluZywgc3RyaW5nPiA9IHRoaXMuZ2V0Q29va2llcygpO1xyXG4gICAgICAgICAgICB0aGlzLlhfU09DS0VUX0FERFJFU1MgPSBtYXAuaGFzKCdYLVNPQ0tFVC1BRERSRVNTJykgPyBtYXAuZ2V0KCdYLVNPQ0tFVC1BRERSRVNTJykgOiBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLlhfVVNFUk5BTUUgPSBtYXAuaGFzKCdYLVVTRVJOQU1FJykgPyBtYXAuZ2V0KCdYLVVTRVJOQU1FJykgOiBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLlNPQ0tFVF9JUCA9IG1hcC5oYXMoJ3NvY2tldElwJykgPyBtYXAuZ2V0KCdzb2NrZXRJcCcpIDogbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5yZXNvbHZlRm4oKTtcclxuICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgICAgICAgIGZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAod2Vic29ja2V0Q2FsbGJhY2tzLm9uQ2xvc2UpIHtcclxuICAgICAgICAgIHRoaXMud2Vic29ja2V0Lm9uY2xvc2UgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHdlYnNvY2tldENhbGxiYWNrcy5vbkNsb3NlKCk7XHJcbiAgICAgICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3MucmVJbml0aWFsaXplT2JzZXJ2YWJsZXMoKTtcclxuICAgICAgICAgICAgdGhpcy5yZUluaXRpYWxpemVXZWJzb2NrZXRPcGVuUHJvbWlzZSgpO1xyXG4gICAgICAgICAgICBjb25zdMOCwqBtYXA6w4LCoE1hcDxzdHJpbmcsw4LCoHN0cmluZz7DgsKgPcOCwqB0aGlzLmdldENvb2tpZXMoKTtcclxuICAgICAgICAgICAgIHJlc3BvbnNlU2Vzc2lvbkRhdGE9dGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpO1xyXG4gICAgICAgICAgICBpZihtYXAuaGFzKCdYLVVTRVJOQU1FJykgJiYgZmxhZyYmcmVzcG9uc2VTZXNzaW9uRGF0YS5nbG9iYWxzJiZyZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIpw4LCoHtcclxuICAgICAgICAgICAgICBjb25zdCBjYWxsYmFjayA9IG5ld8OCwqBXZWJTb2NrZXRDYWxsYmFja0NsYXNzKCk7XHJcbiAgICAgICAgICAgIMOCwqDDgsKgdGhpcy5vcGVuV2ViU29ja2V0Q2hhbm5lbChjYWxsYmFjaykuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sub25SZWNvbm5lY3QoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXNvbHZlRm4gPSB0aGlzLnJlc29sdmVGbjtcclxuICAgICAgICB0aGlzLndlYnNvY2tldC5vbmVycm9yID0gZnVuY3Rpb24oZXJyb3IpIHtcclxuICAgICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25FcnJvcikge1xyXG4gICAgICAgICAgICB3ZWJzb2NrZXRDYWxsYmFja3Mub25FcnJvcihlcnJvcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygncmUtY29ubmVjdGluZyB0byB3ZWJzb2NrZXQgc2VydmVyLi4uJyk7XHJcbiAgICAgICAgICByZXNvbHZlRm4oKTtcclxuICAgICAgICAgIG9ic2VydmUuZXJyb3IoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25NZXNzYWdlKSB7XHJcbiAgICAgICAgICB0aGlzLndlYnNvY2tldC5vbm1lc3NhZ2UgPSB3ZWJzb2NrZXRDYWxsYmFja3Mub25NZXNzYWdlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICB0aGlzLnJlc29sdmVGbigpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfSkucGlwZShkZWxheSgyMDAwKSkucGlwZShyZXRyeSgxNSkpO1xyXG4gIH1cclxuICBwcml2YXRlIGdldENvb2tpZXMoKTogTWFwPHN0cmluZywgc3RyaW5nPiB7XHJcbiAgICBjb25zdCBjb29raWVTdHI6IHN0cmluZyA9IGRvY3VtZW50LmNvb2tpZTtcclxuICAgIGNvbnN0IGNvb2tpZXM6IHN0cmluZ1tdID0gY29va2llU3RyLnNwbGl0KCc7Jyk7XHJcbiAgICBjb25zdCBtYXA6IE1hcDxzdHJpbmcsIHN0cmluZz4gPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xyXG4gICAgY29va2llcy5mb3JFYWNoKGNvb2tpZSA9PiB7XHJcbiAgICAgIGlmIChjb29raWUpIHtcclxuICAgICAgICBjb25zdCBrZXlWYWwgPSBjb29raWUudHJpbSgpLnNwbGl0KCc9Jyk7XHJcbiAgICAgICAgbWFwLnNldChrZXlWYWxbMF0udHJpbSgpLCBrZXlWYWxbMV0udHJpbSgpKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gbWFwO1xyXG4gIH1cclxuICBwcml2YXRlIGhhbmRsZUVycm9yKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xyXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3JFdmVudCkge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihgQ291bGQgbm90IGNvbm5lY3QgdG8gc2VydmVyLlxcbjoke2Vycm9yfWApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRocm93RXJyb3IoYFNlcnZlciByZXR1cm5lZCBjb2RlICR7ZXJyb3Iuc3RhdHVzfSwgYm9keSB3YXM6ICR7ZXJyb3IuZXJyb3J9YCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHByaXZhdGUgcmVJbml0aWFsaXplV2Vic29ja2V0T3BlblByb21pc2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLndlYnNvY2tldE9wZW5Qcm9taXNlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLnJlc29sdmVGbiA9IHJlc29sdmU7XHJcbiAgICAgIHRoaXMucmVqZWN0Rm4gPSByZWplY3Q7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgQEhvc3RMaXN0ZW5lcignd2luZG93Om9uYmVmb3JldW5sb2FkJyxbJyRldmVudCddKVxyXG4gIG9uYmVmb3JldW5sb2FkSGFuZGxlcihldmVudDogRXZlbnQpIHtcclxuICAgIGNvbnN0IGxvZ2luUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKClcclxuICAgICAgICAgIC5ub25SZXN0cmljdGVkUGFnZXMuaW5jbHVkZXModGhpcy5sb2NhdGlvbi5wYXRoKCkpO1xyXG4gICAgaWYobG9naW5QYWdlKVxyXG4gICAge1xyXG4gICAgICB0aGlzLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwSGVhZGVycywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBDT05TVEFOVFMgfSBmcm9tICcuL2NvbnN0YW50JztcclxuaW1wb3J0IHsgQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIEFwcENvbmZpZ3VyYXRpb24gfSBmcm9tICcuL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyB0aHJvd0Vycm9yLCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IHJldHJ5LCBjYXRjaEVycm9yIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEh0dHBTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50LCBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLFxyXG4gIHByaXZhdGUgY2FjaGU6IENhY2hlTWFuYWdlclNlcnZpY2UsIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlKSB7IH1cclxuICBwcml2YXRlIHBhcnNlUXVlcnlTdHJpbmcocXVlcnlTdHJpbmc6IHN0cmluZywga2V5OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgbGV0IHRva2Vuczogc3RyaW5nW107XHJcbiAgICBpZiAocXVlcnlTdHJpbmcpIHtcclxuICAgICAgdG9rZW5zID0gcXVlcnlTdHJpbmcuc3BsaXQoJyYnKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgY29uc3QgbWFwOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuICAgIGZvciAoY29uc3QgdG9rZW4gb2YgdG9rZW5zKSB7XHJcbiAgICAgIGNvbnN0IGtleVZhbHVlOiBzdHJpbmdbXSA9IHRva2VuLnNwbGl0KCc9Jyk7XHJcbiAgICAgIG1hcC5zZXQoa2V5VmFsdWVbMF0sIGtleVZhbHVlWzFdKTtcclxuICAgIH1cclxuICAgIHJldHVybiBtYXAuaGFzKGtleSkgPyBtYXAuZ2V0KGtleSkgOiBudWxsO1xyXG4gIH1cclxuICBwYXJzZVVybCh1cmw6IHN0cmluZyk6IE1hcDxzdHJpbmcsIHN0cmluZz4ge1xyXG4gICAgY29uc3QgcGFyc2VkUGFyYW1ldGVyczogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcbiAgICBjb25zdCBxdWVyeVN0cmluZzogc3RyaW5nID0gdXJsLnNwbGl0KCc/JylbMV07XHJcbiAgICBjb25zdCBwYXJhbWV0ZXJQYWlyTGlzdDogc3RyaW5nW10gPSBxdWVyeVN0cmluZy5zcGxpdCgnJicpO1xyXG4gICAgcGFyYW1ldGVyUGFpckxpc3QuZm9yRWFjaChwYXJhbWV0ZXJQYWlyID0+IHtcclxuICAgICAgY29uc3Qga2V5VmFsdWU6IHN0cmluZ1tdID0gcGFyYW1ldGVyUGFpci5zcGxpdCgnPScpO1xyXG4gICAgICBwYXJzZWRQYXJhbWV0ZXJzW2tleVZhbHVlWzBdXSA9IGtleVZhbHVlWzFdO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gcGFyc2VkUGFyYW1ldGVycztcclxuICB9XHJcbiAgcHJpdmF0ZSBjaGVja0F1dGhvcml6YXRpb24odXJsOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgIGlmICghdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5jbGllbnRTaWRlUmVxdWVzdEJhcnJpbmcpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbiAgICBjb25zdCAgcGFyc2VkUGFyYW1ldGVyczogTWFwPHN0cmluZywgc3RyaW5nPiA9IHRoaXMucGFyc2VVcmwodXJsKTtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHBhcnNlZFBhcmFtZXRlcnNbJ29wZXJhdGlvbiddO1xyXG4gICAgbGV0IGFjY2Vzc0dyYW50ZWRNb2R1bGUgPSBmYWxzZTtcclxuICAgIGxldCBhY2Nlc3NHcmFudGVkTm9kZSA9IGZhbHNlO1xyXG4gICAgbGV0IGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSBmYWxzZTtcclxuICAgIHN3aXRjaCAob3BlcmF0aW9uKSB7XHJcbiAgICBjYXNlICdkb0xvZ2luJzpcclxuICAgIGNhc2UgJ2xvZ291dFVzZXInOlxyXG4gICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gdHJ1ZTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBpZiAodGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXSAmJlxyXG4gICAgICAgICAgICB0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZSAhPT0gJ2ZyZWVBbGxvdycpIHtcclxuICAgICAgICBjb25zdCBhY2Nlc3NSZXF1aXJlZCA9IHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uYWNjZXNzO1xyXG4gICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLnN0cnVjdHVyZWRSZXN0cmljdGlvblt0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZV0pIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWRNb2R1bGUgPVxyXG4gICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb25bdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5tb2R1bGVdW2FjY2Vzc1JlcXVpcmVkXSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgYWNjZXNzR3JhbnRlZE1vZHVsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgICB0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZSA9PT0gJ2ZyZWVBbGxvdycpIHtcclxuICAgICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gdHJ1ZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gICAgaWYgKCFhY2Nlc3NHcmFudGVkTW9kdWxlKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmIHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uY2lyY2xlKSB7XHJcbiAgICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm5vZGUpIHtcclxuICAgICAgICBjb25zdCBjaXJjbGVBY2Nlc3NSZXF1aXJlZCA9IHBhcnNlZFBhcmFtZXRlcnNbJ2NpcmNsZU5hbWUnXTtcclxuICAgICAgICBjb25zdCBub2RlQWNjZXNzUmVxdWlyZWQgPSBwYXJzZWRQYXJhbWV0ZXJzWydub2RlTmFtZSddO1xyXG4gICAgICAgIGlmIChjaXJjbGVBY2Nlc3NSZXF1aXJlZCAmJiBub2RlQWNjZXNzUmVxdWlyZWQpIHtcclxuICAgICAgICAgIGlmIChub2RlQWNjZXNzUmVxdWlyZWQucGFyc2VkTm9kZUNpcmNsZUpzb25bbm9kZUFjY2Vzc1JlcXVpcmVkXSAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uW25vZGVBY2Nlc3NSZXF1aXJlZF1bY2lyY2xlQWNjZXNzUmVxdWlyZWRdKSB7XHJcbiAgICAgICAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSB0cnVlO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBhY2Nlc3NHcmFudGVkQ2lyY2xlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgIXRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uY2lyY2xlKSB7XHJcbiAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgaWYgKCFhY2Nlc3NHcmFudGVkQ2lyY2xlKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5ub2RlKSB7XHJcbiAgICAgIGNvbnN0IG5vZGVBY2Nlc3NSZXF1aXJlZCA9IHBhcnNlZFBhcmFtZXRlcnNbJ25vZGVOYW1lJ107XHJcbiAgICAgIGlmIChub2RlQWNjZXNzUmVxdWlyZWQpIHtcclxuICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5wYXJzZWROb2RlQ2lyY2xlSnNvbltub2RlQWNjZXNzUmVxdWlyZWRdKSB7XHJcbiAgICAgICAgICBhY2Nlc3NHcmFudGVkTm9kZSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWROb2RlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWROb2RlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXSAmJlxyXG4gICAgICAgICF0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm5vZGUpIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiBhY2Nlc3NHcmFudGVkTm9kZTtcclxuICB9XHJcbiAgZ2V0RGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgY29uc29sZS5sb2codXJsKTtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBpZiAocmVxdWVzdC5yZXNwb25zZVR5cGUpIHtcclxuICAgICAgICAgIHJlcXVlc3QuaGVhZGVycy5zZXQoJ3Jlc3BvbnNlVHlwZScsIHJlcXVlc3QucmVzcG9uc2VUeXBlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIGlmKHJlcXVlc3QucmVzcG9uc2VUeXBlKSB7XHJcbiAgICAgICAgICBodHRwT3B0aW9uc1sncmVzcG9uc2VUeXBlJ10gPSByZXF1ZXN0LnJlc3BvbnNlVHlwZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcclxuICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0LmNhbGxiYWNrZnVuY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0LmNhbGxiYWNrZnVuY3Rpb24oe2JvZHk6IHJlc3BvbnNlLmJvZHksIGhlYWRlcnM6IHJlc3BvbnNlLmhlYWRlcnMsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzfSk7XHJcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHJlcXVlc3QuY2FsbGJhY2tmdW5jdGlvbikge1xyXG4gICAgICAgICAgICAgICAgcmVxdWVzdC5jYWxsYmFja2Z1bmN0aW9uKHtib2R5OiByZXNwb25zZS5ib2R5LCBoZWFkZXJzOiByZXNwb25zZS5oZWFkZXJzLCBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1c30pO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBOb3QgYXV0aG9yaXplZCBmb3IgYWNjZXNzaW5nICR7dXJsfTogNDAxYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcG9zdERhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGNvbnNvbGUubG9nKHVybCk7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wb3N0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucG9zdDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgcmVxdWVzdC5kYXRhLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwdXREYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzP3JlcXVlc3QuaGVhZGVyczp7fSBhcyBIdHRwSGVhZGVycyxcclxuICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICAgICAgfTtcclxuICAgICAgICBodHRwT3B0aW9ucy5oZWFkZXJzWydvcGVyYXRpb24nXSA9IG9wZXJhdGlvbjtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihzdWJzY3JpYmVyID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucHV0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucHV0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihgTm90IGF1dGhvcml6ZWQgZm9yIGFjY2Vzc2luZyAke3VybH06IDQwMWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGRlbGV0ZURhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5kZWxldGU8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuZGVsZXRlPEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBoZWFkRGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVycz9yZXF1ZXN0LmhlYWRlcnM6e30gYXMgSHR0cEhlYWRlcnMsXHJcbiAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnIGFzICdib2R5J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaHR0cE9wdGlvbnMuaGVhZGVyc1snb3BlcmF0aW9uJ10gPSBvcGVyYXRpb247XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4oc3Vic2NyaWJlciA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LmhlYWQ8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuaGVhZDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uc2UgPT4gc3Vic2NyaWJlci5uZXh0KHJlc3BvbnNlKSwgZXJyb3IgPT4gc3Vic2NyaWJlci5lcnJvcihlcnJvcikpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBOb3QgYXV0aG9yaXplZCBmb3IgYWNjZXNzaW5nICR7dXJsfTogNDAxYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcGF0Y2hEYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzP3JlcXVlc3QuaGVhZGVyczp7fSBhcyBIdHRwSGVhZGVycyxcclxuICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICAgICAgfTtcclxuICAgICAgICBodHRwT3B0aW9ucy5oZWFkZXJzWydvcGVyYXRpb24nXSA9IG9wZXJhdGlvbjtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihzdWJzY3JpYmVyID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucGF0Y2g8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIHJlcXVlc3QuZGF0YSwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wYXRjaDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgcmVxdWVzdC5kYXRhLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIGhhbmRsZUVycm9yKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xyXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3JFdmVudCkge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihgQ291bGQgbm90IGNvbm5lY3QgdG8gc2VydmVyLlxcbjoke2Vycm9yfWApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVlc3Qge1xyXG4gIGNvbnRleHQ6IHN0cmluZztcclxuICBkYXRhPzogYW55O1xyXG4gIGhlYWRlcnM/OiBIdHRwSGVhZGVycztcclxuICBxdWVyeVN0cmluZz86IHN0cmluZztcclxuICByZXNwb25zZVR5cGU/OiBzdHJpbmc7XHJcbiAgcmVxVXJsPzogc3RyaW5nO1xyXG4gIGNhbGxiYWNrZnVuY3Rpb24/KC4uLmFyZ3MpOiBhbnk7XHJcbn1cclxuZXhwb3J0IGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgYm9keT86IGFueTtcclxuICBoZWFkZXJzPzogYW55O1xyXG4gIHN0YXR1cz86IGFueTtcclxuICBxdWVyeVN0cmluZz86IGFueTtcclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkRlc3Ryb3ksIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwU2VydmljZSwgUmVxdWVzdCB9IGZyb20gJy4vaHR0cC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBmaWx0ZXIgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09OU1RBTlRTIH0gZnJvbSAnLi9jb25zdGFudCc7XHJcbmltcG9ydCB7IFNlc3Npb25TZXJ2aWNlLCBSZXNwb25zZVNlc3Npb25EYXRhLCBSZXF1ZXN0U2Vzc2lvbkRhdGEgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IFJzYVV0aWxzIH0gZnJvbSAnLi9yc2EtdXRpbHMnO1xyXG5pbXBvcnQgeyBBZXNVdGlscyB9IGZyb20gJy4vYWVzLXV0aWxzJztcclxuaW1wb3J0IHsgSHR0cEhlYWRlcnMsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgQ2FjaGVNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4vY2FjaGUtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBzYXZlQXMgfSBmcm9tICdmaWxlLXNhdmVyJztcclxuaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcyB9IGZyb20gJy4vd2ViLXNvY2tldC1jYWxsYmFja3MtY2xhc3MnO1xyXG5pbXBvcnQgeyBoZWFkZXJzVG9TdHJpbmcgfSBmcm9tICdzZWxlbml1bS13ZWJkcml2ZXIvaHR0cCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJYW1TZXJ2aWNlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gIHByaXZhdGUgd2Vic29ja2V0OiBXZWJTb2NrZXQ7XHJcbiAgZXZlbnQ6IGFueTtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHBTZXJ2aWNlOiBIdHRwU2VydmljZSwgcHJpdmF0ZSBhcHBDb25maWd1cmF0aW9uOiBBcHBDb25maWd1cmF0aW9uU2VydmljZSxcclxuICAgIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSwgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24pIHtcclxuICAgIHRoaXMuc3RhcnRMaXN0ZW5pbmdUb1JvdXRlQ2hhbmdlKCkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3N0YXJ0ZWQgbGlzdGVuaW5nIGZvciByb3V0ZSBjaGFuZ2UnKTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICB9XHJcbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICB0aGlzLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gIH1cclxuICBwcml2YXRlIGRvTG9naW48VD4ocGF5bG9hZCwgcHJvamVjdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycygpLnNldCgncHJvamVjdCcsXHJcbiAgICAgICAgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKCkuc2V0KCdwcm9qZWN0JyxcclxuICAgICAgICBwcm9qZWN0KTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1kb0xvZ2luJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogcGF5bG9hZFxyXG4gICAgfTtcclxuICAgIHJldHVybiB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpO1xyXG4gIH1cclxuICBzdGFydExpc3RlbmluZ1RvUm91dGVDaGFuZ2UoKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMucm91dGVyLmV2ZW50cy5waXBlKFxyXG4gICAgICAgIGZpbHRlcihldmVudCA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpXHJcbiAgICAgICkuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICB0aGlzLm9uUm91dGVDaGFuZ2UoZXZlbnQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBhdXRoZW50aWNhdGVVc2VyPFQ+KHVzZXJOYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcsIHByb2plY3Q/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlU2Vzc2lvbkRhdGE6IFJlc3BvbnNlU2Vzc2lvbkRhdGEgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCk7XHJcbiAgICAgIGlmIChyZXNwb25zZVNlc3Npb25EYXRhICYmIHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscyAmJlxyXG4gICAgICAgIHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscy5jdXJyZW50VXNlciAmJiByZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWUpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygndXNlciBhbHJlYWR5IGxvZ2dlZCBpbicpO1xyXG4gICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHJhbmRvbUFlc0tleSA9IEFlc1V0aWxzLmdlbmVyYXRlUmFuZG9tQWVzS2V5KCk7XHJcbiAgICAgICAgY29uc3QgY3JlZGVudGlhbHMgPSB7XHJcbiAgICAgICAgICB1c2VyTmFtZTogdXNlck5hbWUsXHJcbiAgICAgICAgICB1c2VyUGFzc3dvcmQ6IFJzYVV0aWxzLmVuY3J5cHQocGFzc3dvcmQpLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIEFwcERhdGE6IHtcclxuICAgICAgICAgICAgdXNlckluZm86IGNyZWRlbnRpYWxzLFxyXG4gICAgICAgICAgICBlbmNyeXB0aW9uS2V5OiBSc2FVdGlscy5lbmNyeXB0KHJhbmRvbUFlc0tleSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuZG9Mb2dpbjxUPihwYXlsb2FkLCBwcm9qZWN0KS5zdWJzY3JpYmUocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHkgJiYgcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlICYmIHJlc3BvbnNlLmJvZHkuc3RhdHVzQ29kZS5BcHBEYXRhICYmIHJlc3BvbnNlLmJvZHkuc3RhdHVzQ29kZS5BcHBEYXRhLnVzZXJUb2tlbikge1xyXG4gICAgICAgICAgICBjb25zdCBzdWJUb2tlbnM6IHN0cmluZ1tdID0gcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEudXNlclRva2VuLnNwbGl0KCdAJyk7XHJcbiAgICAgICAgICAgIGxldCBtb2R1bGVSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICAgICAgICAgIGxldCBzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSBudWxsO1xyXG4gICAgICAgICAgICBsZXQgbm9kZU5hbWVDaXJjbGUgPSBudWxsO1xyXG4gICAgICAgICAgICBpZiAoc3ViVG9rZW5zWzFdICYmIHN1YlRva2Vuc1sxXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgbW9kdWxlUmVzdHJpY3Rpb24gPSB0aGlzLnBhcnNlVG9rZW4oQWVzVXRpbHMuZGVjcnlwdChzdWJUb2tlbnNbMV0sIHJhbmRvbUFlc0tleSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIG1vZHVsZVJlc3RyaWN0aW9uID0ge307XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3RydWN0dXJlZFJlc3RyaWN0aW9uID0gdGhpcy5yZXN0cnVjdHVyZUFjY2Vzc0pzb24obW9kdWxlUmVzdHJpY3Rpb24sIHt9KTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRTZXNzaW9uRGF0YUZvck1vZHVsZVJlc3RyaWN0aW9uKG1vZHVsZVJlc3RyaWN0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFVzZXJUb2tlbkRhdGEoc3ViVG9rZW5zWzBdKTtcclxuICAgICAgICAgICAgaWYgKHN1YlRva2Vuc1syXSAmJiBzdWJUb2tlbnNbMl0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgIG5vZGVOYW1lQ2lyY2xlID0gQWVzVXRpbHMuZGVjcnlwdChzdWJUb2tlbnNbMl0sIHJhbmRvbUFlc0tleSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgbm9kZU5hbWVDaXJjbGUgPSAnJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBwYXJzZWROb2RlQ2lyY2xlSnNvbiA9IHRoaXMucGFyc2VOb2RlQ2lyY2xlVG9rZW4obm9kZU5hbWVDaXJjbGUpO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhRm9yTm9kZUNpcmNsZVJlc3RyaWN0aW9uKHBhcnNlZE5vZGVDaXJjbGVKc29uIGFzIEpTT04pO1xyXG4gICAgICAgICAgICBjb25zdCBuZU5hbWVzQ2lyY2xlTGlzdDogc3RyaW5nW10gPSBub2RlTmFtZUNpcmNsZS5zcGxpdCgnIycpO1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0KSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZSkge1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZSA9IHt9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAobGV0IGl0ciA9IDA7IGl0ciA8IG5lTmFtZXNDaXJjbGVMaXN0Lmxlbmd0aDsgaXRyKyspIHtcclxuICAgICAgICAgICAgICBjb25zdCBjaXJsZU5hbWVzRm9yTkUgPSBuZU5hbWVzQ2lyY2xlTGlzdFtpdHJdLnNwbGl0KCc6Jyk7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QucHVzaChjaXJsZU5hbWVzRm9yTkVbMF0pO1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZVtjaXJsZU5hbWVzRm9yTkVbMF1dID0gY2lybGVOYW1lc0Zvck5FWzFdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZVNob3J0TmFtZSA9IHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0WzBdO1xyXG4gICAgICAgICAgICB0aGlzLm5lU2hvcnROYW1lRnVsbE5hbWVNYXBwaW5nKCk7XHJcbiAgICAgICAgICAgIHRoaXMubmVDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZU1hcHBpbmcoKTtcclxuICAgICAgICAgICAgY29uc3QgbmVOYW1lQ2lyY2xlTmFtZTogSlNPTiA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgIHNlbGVjdGVkTmVOYW1lOiB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lLFxyXG4gICAgICAgICAgICAgIHNlbGVjdGVkQ2lyY2xlTmFtZTogdGhpcy5zZXNzaW9uU2VydmljZS5zZWxlY3RlZENpcmNsZU5hbWVcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0RGF0YTogUmVxdWVzdFNlc3Npb25EYXRhID0ge1xyXG4gICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyTmFtZSxcclxuICAgICAgICAgICAgICBhcHBEYXRhOiByZXNwb25zZS5ib2R5LnN0YXR1c0NvZGUuQXBwRGF0YSxcclxuICAgICAgICAgICAgICBub2RlTmFtZUNpcmNsZTogbm9kZU5hbWVDaXJjbGUsXHJcbiAgICAgICAgICAgICAgYWVzS2V5OiBBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1szXSwgcmFuZG9tQWVzS2V5KSxcclxuICAgICAgICAgICAgICBuZU5hbWVDaXJjbGVOYW1lOiBuZU5hbWVDaXJjbGVOYW1lXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UucHV0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhKHJlcXVlc3REYXRhKTtcclxuICAgICAgICAgICAgQWVzVXRpbHMuc2V0QWVzRW5jcnlwdGlvbktleShBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1szXSwgcmFuZG9tQWVzS2V5KSk7XHJcbiAgICAgICAgICAgIGludGVyZmFjZSBVc2VySW1hZ2VSZXNwb25zZSB7XHJcbiAgICAgICAgICAgICAgc3VjY2VzczogYm9vbGVhbjtcclxuICAgICAgICAgICAgICBBcHBEYXRhOiB7XHJcbiAgICAgICAgICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICB1c2VySW1hZ2U6IHN0cmluZztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUuZ2V0VXNlckltYWdlPFVzZXJJbWFnZVJlc3BvbnNlPih1c2VyTmFtZSkudGhlbihmdW5jdGlvbiAocmVzcCkge1xyXG4gICAgICAgICAgICAgIGlmIChyZXNwLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FjaGUubG9naW5Vc2VySW1hZ2UgPSByZXNwLkFwcERhdGEudXNlckluZm8udXNlckltYWdlID8gcmVzcC5BcHBEYXRhLnVzZXJJbmZvLnVzZXJJbWFnZSA6ICdub0ltYWdlJztcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS5vcGVuV2ViU29ja2V0Q2hhbm5lbChuZXcgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcygpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5kZWZhdWx0UGFnZUFmdGVyTG9naW5dKTtcclxuICAgICAgICAgICAgICBvYnNlcnZlLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBkb0xvZ291dCh1c2VyTmFtZSk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgaWYgKCF1c2VyTmFtZSkge1xyXG4gICAgICB0aHJvd0Vycm9yKCd1c2VyTmFtZSBpcyB1bmRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogYG9wZXJhdGlvbj1sb2dvdXRVc2VyJnVzZXJOYW1lPSR7dXNlck5hbWV9YCxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTx7IHN1Y2Nlc3M6IGJvb2xlYW4gfT4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBsb2dvdXRVc2VyKCk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHZvaWQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICBjb25zdCBnbG9iYWxzID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHM7XHJcbiAgICAgIGlmIChnbG9iYWxzICYmIGdsb2JhbHMuY3VycmVudFVzZXIgJiYgZ2xvYmFscy5jdXJyZW50VXNlci51c2VyTmFtZSkge1xyXG4gICAgICAgIGNvbnN0IGluVXNlck5hbWUgPSBnbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lO1xyXG4gICAgICAgIHRoaXMuZG9Mb2dvdXQoaW5Vc2VyTmFtZSkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9Mb2dvdXRQYWdlKCk7XHJcbiAgICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQgJiYgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UoKTtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQgPSBudWxsO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgICAgfSwgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvTG9nb3V0UGFnZSgpO1xyXG4gICAgICAgICAgaWYgKHRoaXMuY2FjaGUud2Vic29ja2V0ICYmIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0ID0gbnVsbDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9ic2VydmUuZXJyb3IoKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5jbGVhclNlc3Npb25EYXRhQW5kR290b0xvZ291dFBhZ2UoKTtcclxuICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQgJiYgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UpIHtcclxuICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdubyB1c2VyIHRvIGxvZ291dCcpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0UGF0aE5hbWUoKSB7XHJcbiAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoLnN1YnN0cigxKTtcclxufVxyXG4gIG9uUm91dGVDaGFuZ2UoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHM7XHJcbiAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscykge1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB7fTtcclxuICAgIH1cclxuICAgIGlmKCB0aGlzLnJvdXRlci51cmwgPT0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2UpXHJcbiAgICB7XHJcbiAgICAgIHRyeVxyXG4gICAgICB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUud2Vic29ja2V0KSB7XHJcbiAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjYXRjaChFcnJvckV2ZW50KVxyXG4gICAgICB7XHJcbiAgICAgICAgY29uc29sZS5sb2coRXJyb3JFdmVudCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmxvZ2luUGFnZSAmJlxyXG4gICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlcyAmJlxyXG4gICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbikge1xyXG4gICAgICAgIGxldCBwYXRoTmFtZSA9IHRoaXMubG9jYXRpb24ucGF0aCgpO1xyXG4gICAgICAgIGlmKHBhdGhOYW1lLmluY2x1ZGVzKFwiP1wiKSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXRoTmFtZT1wYXRoTmFtZS5zcGxpdChcIj9cIilbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICBjb25zdCByZXN0cmljdGVkUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubm9uUmVzdHJpY3RlZFBhZ2VzLmluZGV4T2YocGF0aE5hbWUpPT09LTE7XHJcbiAgICAgIGNvbnN0IGxvZ2dlZEluID0gdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzLmN1cnJlbnRVc2VyO1xyXG4gICAgICBpZiAocmVzdHJpY3RlZFBhZ2UgJiYgIWxvZ2dlZEluKSB7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW3RoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubG9naW5QYWdlXSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobG9nZ2VkSW4pIHtcclxuICAgICAgICBjb25zdCBsb2dpblBhZ2UgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpXHJcbiAgICAgICAgICAubm9uUmVzdHJpY3RlZFBhZ2VzLmluZGV4T2YocGF0aE5hbWUpIT0tMTtcclxuICAgICAgICBpZiAobG9naW5QYWdlKSB7XHJcbiAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5kZWZhdWx0UGFnZUFmdGVyTG9naW5dKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgZ2V0QWxscm9sZWlkPFQ+KHByb2plY3Q/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxSb2xlU2VsZWN0ZWRGaWxlZCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlU2luZ2xlVXNlcjxUPihjcmVhdGluZ1VzZXI6IHN0cmluZywgQXBwRGF0YTogYW55LHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBBcHBEYXRhLnVzZXJJbmZvLnVzZXJQYXNzd29yZCA9IEFlc1V0aWxzLmVuY3J5cHQoQXBwRGF0YS51c2VySW5mby51c2VyUGFzc3dvcmQpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiBgb3BlcmF0aW9uPWNyZWF0ZVNpbmdsZVVzZXImY3JlYXRpbmdVc2VyPSR7Y3JlYXRpbmdVc2VyfWAsXHJcbiAgICAgIGRhdGE6IHsgQXBwRGF0YSB9LFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNyZWF0ZUFjY291bnQ8VD4oIEFwcERhdGE6IGFueSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgQXBwRGF0YS51c2VySW5mby51c2VyUGFzc3dvcmQgPSBBZXNVdGlscy5lbmNyeXB0KEFwcERhdGEudXNlckluZm8udXNlclBhc3N3b3JkKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1jcmVhdGVBY2NvdW50JyxcclxuICAgICAgZGF0YToge0FwcERhdGF9LFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNyZWF0ZUJ1bGtVc2VyPFQ+KGNyZWF0aW5nVXNlcjogc3RyaW5nLCBmaWxlOiBhbnkscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogYG9wZXJhdGlvbj1jcmVhdGVCdWxrVXNlciZjcmVhdGluZ1VzZXI9JHtjcmVhdGluZ1VzZXJ9YCxcclxuICAgICAgZGF0YTogZmlsZSxcclxuICAgICAgaGVhZGVyczpoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjcmVhdGVCdWxrUm9sZXNhbmRVc2VyczxUPihjcmVhdGluZ1VzZXI6IHN0cmluZywgZmlsZTogYW55LHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6IGBvcGVyYXRpb249Y3JlYXRlQnVsa1JvbGVzYW5kVXNlcnMmY3JlYXRpbmdVc2VyPSR7Y3JlYXRpbmdVc2VyfWAsXHJcbiAgICAgIGRhdGE6IGZpbGUsXHJcbiAgICAgIGhlYWRlcnM6aGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZG93bmxvYWRCdWxrVXNlcnMocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QXJyYXlCdWZmZXI+PiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRCdWxrVXNlcicsXHJcbiAgICAgIHJlc3BvbnNlVHlwZTogJ2FycmF5YnVmZmVyJyxcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QXJyYXlCdWZmZXI+PihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPEFycmF5QnVmZmVyPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCAgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcmVzcC5ib2R5XSwge1xyXG4gICAgICAgICAgdHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0LGFwcGxpY2F0aW9uL3ZuZC5tcy1leGNlbCdcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gICAgICBhLmhyZWYgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICBhLmRvd25sb2FkID0gXCJVc2VyTGlzdC54bHN4XCI7XHJcbiAgICAgIGEuY2xpY2soKTtcclxuICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRvd25sb2FkVXNlclRlbXBsYXRlKHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VGVtcGxhdGUnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHZvaWQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGEocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIGxldCBkYXRhMSA9IHJlc3AuYm9keTtcclxuICAgICAgICBsZXQgZGF0YSA9IHJlc3AuYm9keVsnc3RhdHVzQ29kZSddWydBcHBEYXRhJ11bJ0Jhc2U2NFN0cmVhbSddO1xyXG4gICAgICAgIHZhciBiaW5kYXRhID0gd2luZG93LmF0b2IoZGF0YSk7XHJcbiAgICAgICAgdmFyIGxlbiA9IGJpbmRhdGEubGVuZ3RoO1xyXG4gICAgICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGxlbik7XHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICAgICAgYnl0ZXNbaV0gPSBiaW5kYXRhLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBmaWxlID0gbmV3IEJsb2IoW2J5dGVzLmJ1ZmZlcl0sIHtcclxuICAgICAgICAgIHR5cGU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldDsnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgd2luZG93LnNhdmVBcyhmaWxlLCBcInVzZXJ0ZW1wbGF0ZVwiICsgXCIueGxzeFwiKVxyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcigpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBkZWxldGVVc2VyPFQ+KHVzZXJOYW1lOiBzdHJpbmcscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1kZWxldGVVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5kZWxldGVEYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwLmJvZHkpO1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIG1vZGlmeVVzZXI8VD4odXNlck5hbWU6IHN0cmluZywgdXNlckluZm8scHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1tb2RpZnlVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogeyAnQXBwRGF0YSc6IHVzZXJJbmZvIH1cclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHZpZXdVc2VyPFQ+KHVzZXJOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBpZiAoIXVzZXJOYW1lKSB7XHJcbiAgICAgIHRocm93RXJyb3IoJ3VzZXJOYW1lIGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1VzZXJMaXN0QWNjb3JkaW5ndG9Sb2xlPFQ+KHJvbGVJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaWYgKCFyb2xlSWQpIHtcclxuICAgICAgdGhyb3dFcnJvcigncm9sZUlkIGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VXNlcnNMaXN0JnJvbGVJZD0nICsgcm9sZUlkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGJsb2NrVXNlcjxUPih1c2VySWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlcklkKSB7XHJcbiAgICAgIHRocm93RXJyb3IoJ3VzZXJJZCBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWJsb2NrVXNlciZ1c2VySWQ9JyArIHVzZXJJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjaGVja1VzZXJFeGlzdGVuY2U8VD4odXNlck5hbWU6IHN0cmluZyxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoZWNrVXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0QWxsVXNlcjxUPihpbmRleDogbnVtYmVyLCBzaXplOiBudW1iZXIscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxVc2VyJmZyb209JyArIGluZGV4ICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0UmVzdHJpY3RlZFVzZXI8VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxVc2VyU2VsZWN0ZWRGaWVsZCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlUm9sZTxUPihyb2xlRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsnY3JlYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsnY3JlYXRlZEJ5J10gPSB0aGlzLmNhY2hlLlhfVVNFUk5BTUU7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Y3JlYXRlUm9sZScsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiByb2xlRGF0YSB9LFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICByZXNldFZhcmlhYmxlcygpOiB2b2lkIHtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscyA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkQ2lyY2xlTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZVNob3J0TmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVDaXJjbGUgPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5tb2R1bGVSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm1hcE5lTmFtZUNpcmNsZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QgPSBbXTtcclxuICB9XHJcbiAgZ2V0Q29va2llKGtleSk6IGFueSB7XHJcbiAgICBjb25zdCBjb29raWVTdHIgPSBkb2N1bWVudC5jb29raWU7XHJcbiAgICBjb25zdCBjb29raWVzOiBzdHJpbmdbXSA9IGNvb2tpZVN0ci5zcGxpdCgnOycpO1xyXG4gICAgY29uc3QgbWFwID0ge307XHJcbiAgICBjb29raWVzLmZvckVhY2goY29va2llID0+IHtcclxuICAgICAgaWYgKGNvb2tpZSkge1xyXG4gICAgICAgIGNvbnN0IGtleXZhbCA9IGNvb2tpZS50cmltKCkuc3BsaXQoJz0nKTtcclxuICAgICAgICBtYXBba2V5dmFsWzBdLnRyaW0oKV0gPSBrZXl2YWxbMV0udHJpbSgpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBtYXBba2V5XTtcclxuICB9XHJcbiAgcmVzdHJ1Y3R1cmVBY2Nlc3NKc29uKG1vZHVsZSwgc3RydWN0dXJlZEpzb24pIHtcclxuICAgIGZvciAoY29uc3Qga2V5IGluIG1vZHVsZSkge1xyXG4gICAgICBpZiAobW9kdWxlLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IG1vZHVsZVtrZXldO1xyXG4gICAgICAgIGlmICh2YWx1ZS5hY2Nlc3MpIHtcclxuICAgICAgICAgIGNvbnN0IGFjY2VzcyA9IHt9O1xyXG4gICAgICAgICAgZm9yIChjb25zdCBreSBpbiB2YWx1ZS5hY2Nlc3MpIHtcclxuICAgICAgICAgICAgaWYgKHZhbHVlLmFjY2Vzcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZWxlbWVudCA9IHZhbHVlLmFjY2Vzc1treV07XHJcbiAgICAgICAgICAgICAgc3dpdGNoIChreSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnUic6XHJcbiAgICAgICAgICAgICAgICAgIGFjY2Vzc1snUmVhZCddID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdXJzpcclxuICAgICAgICAgICAgICAgICAgYWNjZXNzWydXcml0ZSddID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdEJzpcclxuICAgICAgICAgICAgICAgICAgYWNjZXNzWydEZWxldGUnXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3RydWN0dXJlZEpzb25ba2V5XSA9IGFjY2VzcztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5yZXN0cnVjdHVyZUFjY2Vzc0pzb24odmFsdWUsIHN0cnVjdHVyZWRKc29uKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBzdHJ1Y3R1cmVkSnNvbjtcclxuICB9XHJcbiAgLy8gdmFyIGF1dGhUb2tlbj1cIlNDMS4xOlJEI1NDMS4yOlJXRCNTQzEuMzpSRCNTQzUuMTpSRCNTQzIuMTpSV0QjU0MzLjIuMTpSRFwiO1xyXG4gIHBhcnNlVG9rZW4oYXV0aFRva2VuOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGpzb24gPSB7fTtcclxuICAgIGlmICghYXV0aFRva2VuKSB7XHJcbiAgICAgIHJldHVybiBqc29uO1xyXG4gICAgfVxyXG4gICAgY29uc3QgdG9rZW5zOiBzdHJpbmdbXSA9IGF1dGhUb2tlbi5zcGxpdCgnIycpO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0b2tlbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgdG9rZW4gPSB0b2tlbnNbaV07XHJcbiAgICAgIGNvbnN0IHNob3J0Q29kZXMgPSB0b2tlbi5zcGxpdCgnLicpO1xyXG4gICAgICBsZXQgdGVtcE5hbWUgPSAnJztcclxuICAgICAgbGV0IHRlbXAgPSBqc29uO1xyXG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNob3J0Q29kZXMubGVuZ3RoIC0gMTsgaisrKSB7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRDb2RlID0gc2hvcnRDb2Rlc1tqXTtcclxuICAgICAgICBpZiAodGVtcE5hbWUgPT09ICcnKSB7XHJcbiAgICAgICAgICB0ZW1wTmFtZSA9IHNob3J0Q29kZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGVtcE5hbWUgPSBgJHt0ZW1wTmFtZX0uJHtzaG9ydENvZGV9YDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0ZW1wLmhhc093blByb3BlcnR5KHRlbXBOYW1lKSkge1xyXG4gICAgICAgICAgdGVtcFt0ZW1wTmFtZV0gPSB7fTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcCA9IHRlbXBbdGVtcE5hbWVdO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICh0ZW1wTmFtZSA9PT0gJycpIHtcclxuICAgICAgICB0ZW1wTmFtZSA9IHNob3J0Q29kZXNbc2hvcnRDb2Rlcy5sZW5ndGggLSAxXS5zcGxpdCgnOicpWzBdO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRlbXBOYW1lID0gYCR7dGVtcE5hbWV9LiR7c2hvcnRDb2Rlc1tzaG9ydENvZGVzLmxlbmd0aCAtIDFdLnNwbGl0KCc6JylbMF19YDtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIXRlbXAuaGFzT3duUHJvcGVydHkodGVtcE5hbWUpKSB7XHJcbiAgICAgICAgY29uc3QgcmVzdHJpY3RKc29uID0ge307XHJcbiAgICAgICAgY29uc3QgcmVzdHJpY3Rpb24gPSBzaG9ydENvZGVzW3Nob3J0Q29kZXMubGVuZ3RoIC0gMV0uc3BsaXQoJzonKVsxXS5zcGxpdCgnJyk7XHJcbiAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCByZXN0cmljdGlvbi5sZW5ndGg7IGsrKykge1xyXG4gICAgICAgICAgcmVzdHJpY3RKc29uW3Jlc3RyaWN0aW9uW2tdXSA9IHRydWU7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wW3RlbXBOYW1lXSA9IHsgYWNjZXNzOiByZXN0cmljdEpzb24gfTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGpzb247XHJcbiAgfVxyXG4gIHByaXZhdGUgcGFyc2VOb2RlQ2lyY2xlVG9rZW4odG9rZW4pIHtcclxuICAgIGNvbnN0IHBhcnNlZEpzb24gPSB7fTtcclxuICAgIGlmICghdG9rZW4gfHwgdG9rZW4gPT09ICcnKSB7XHJcbiAgICAgIHJldHVybiBwYXJzZWRKc29uO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgc2luZ2xlTm9kZUNpcmNsZUxpc3Q6IHN0cmluZ1tdID0gdG9rZW4uc3BsaXQoJyMnKTtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2luZ2xlTm9kZUNpcmNsZUxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3Qgc2luZ2xlTm9kZUNpcmNsZSA9IHNpbmdsZU5vZGVDaXJjbGVMaXN0W2ldO1xyXG4gICAgICBjb25zdCBub2RlID0gc2luZ2xlTm9kZUNpcmNsZS5zcGxpdCgnOicpWzBdO1xyXG4gICAgICBjb25zdCBjaXJjbGVzTGlzdCA9IHNpbmdsZU5vZGVDaXJjbGUuc3BsaXQoJzonKVsxXS5zcGxpdCgnLCcpO1xyXG4gICAgICBjb25zdCBjaXJjbGVKc29uID0ge307XHJcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgY2lyY2xlc0xpc3QubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICBjaXJjbGVKc29uW3RoaXMuY2FjaGUuY2lyY2xlRnVsbE5hbWVKc29uUmVzcG9uc2VbJ0NpcmNsZU5hbWUnXVtjaXJjbGVzTGlzdFtqXV1dID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBwYXJzZWRKc29uW25vZGVdID0gY2lyY2xlSnNvbjtcclxuICAgIH1cclxuICAgIHJldHVybiBwYXJzZWRKc29uO1xyXG4gIH1cclxuICBuZVNob3J0TmFtZUZ1bGxOYW1lTWFwcGluZygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5jYWNoZS5uZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjtcclxuICAgIGNvbnN0IG5lU2hvcnROYW1lID0gdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3RbMF07XHJcbiAgICBpZiAocmVzcG9uc2UuTm9kZU5hbWUpIHtcclxuICAgICAgY29uc3Qgbm9kZUZ1bGxOYW1lID0gcmVzcG9uc2UuTm9kZU5hbWVbbmVTaG9ydE5hbWVdO1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lID0gbm9kZUZ1bGxOYW1lO1xyXG4gICAgfVxyXG4gICAgaWYgKCF0aGlzLmNhY2hlLm1hcE5lU2hvcnROYW1lRnVsbE5hbWUpIHtcclxuICAgICAgdGhpcy5jYWNoZS5tYXBOZVNob3J0TmFtZUZ1bGxOYW1lID0ge307XHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBpdHIgPSAwOyBpdHIgPCByZXNwb25zZS5Ob2RlTmFtZSAmJiB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdC5sZW5ndGg7IGl0cisrKSB7XHJcbiAgICAgIHRoaXMuY2FjaGUubWFwTmVTaG9ydE5hbWVGdWxsTmFtZVtyZXNwb25zZS5Ob2RlTmFtZVt0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdFtpdHJdXV0gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdFtpdHJdO1xyXG4gICAgfVxyXG4gIH1cclxuICBuZUNpcmNsZVNob3J0TmFtZUZ1bGxOYW1lTWFwcGluZygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5jYWNoZS5jaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZTtcclxuICAgIGNvbnN0IGNpcmNsZVNob3J0TmFtZXNMaXN0ID0gdGhpcy5zZXNzaW9uU2VydmljZS5tYXBOZU5hbWVDaXJjbGVOYW1lW3RoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0WzBdXTtcclxuICAgIGlmIChjaXJjbGVTaG9ydE5hbWVzTGlzdCkge1xyXG4gICAgICBjb25zdCBjaXJjbGUgPSBjaXJjbGVTaG9ydE5hbWVzTGlzdC5zcGxpdCgnLCcpO1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkQ2lyY2xlTmFtZSA9IHJlc3BvbnNlLkNpcmNsZU5hbWVbY2lyY2xlWzBdXTtcclxuICAgIH1cclxuICB9XHJcbiAgZ2V0QWNjZXNzSnNvbjxUPihwcm9kdWN0SWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0TW9kdWxlU3ViTW9kdWxlRGF0YSZwcm9kdWN0SWQ9JyArIHByb2R1Y3RJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXROb2RlQ2lyY2xlSnNvbjxUPihwcm9kdWN0SWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Tm9kZUNpcmNsZURhdGEmcHJvZHVjdElkPScgKyBwcm9kdWN0SWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0TW9kdWxlVG9JZEpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0U2hvcnRDb2RlVG9JZE1hcCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Tm9kZVRvSWRKc29uPFQ+KHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldE5vZGVUb0lkTWFwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDaXJjbGVUb0lkSnNvbjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRDaXJjbGVUb0lkTWFwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZUpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Q2lyY2xlU2hvcnROYW1lRnVsbE5hbWUnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZUpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Tm9kZVNob3J0TmFtZUZ1bGxOYW1lJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRPcGVyYXRpb25Ub01vZHVsZU5vZGVDaXJjbGVKc29uPFQ+KHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZScsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZGVsZXRlUm9sZTxUPihyb2xlSWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIXJvbGVJZClcclxuICAgICAgdGhyb3cgXCJSb2xlIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249ZGVsZXRlUm9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5Um9sZTxUPihyb2xlSWQsIHJvbGVEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlSWQpXHJcbiAgICAgIHRocm93IFwiUm9sZSBpZCBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICAgIH1cclxuICAgICAgZWxzZSB7XHJcbiAgICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsndXBkYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dXBkYXRlUm9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgZGF0YTogeyBcIkFwcERhdGFcIjogcm9sZURhdGEgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1JvbGU8VD4ocm9sZUlkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlSWQpXHJcbiAgICAgIHRocm93IFwiUm9sZSBpZCBpcyB1bmRlZmluZWRcIjtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj12aWV3Um9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0QWxsUm9sZTxUPihmcm9tLCBzaXplLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEFsbFJvbGUmZnJvbT0nICsgZnJvbSArICcmc2l6ZT0nICsgc2l6ZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY2hlY2tSb2xlRXhpc3RlbmNlPFQ+KHJvbGVuYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlbmFtZSlcclxuICAgICAgdGhyb3cgXCJyb2xlbmFtZSBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoZWNrUm9sZSZyb2xlTmFtZT0nICsgcm9sZW5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlVXNlckdyb3VwPFQ+KGdyb3VwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1snY3JlYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1snY3JlYXRlZEJ5J10gPSB0aGlzLmNhY2hlLlhfVVNFUk5BTUU7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWyd1cGRhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1jcmVhdGVHcm91cCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiBncm91cERhdGEgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHZpZXdVc2VyR3JvdXA8VD4oZ3JvdXBJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghZ3JvdXBJZClcclxuICAgICAgdGhyb3cgXCJncm91cElkIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj12aWV3R3JvdXAmZ3JvdXBJZD0nICsgZ3JvdXBJZCxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1VzZXJHcm91cExpc3Q8VD4oZnJvbSwgc2l6ZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdHcm91cExpc3QmZnJvbT0nICsgZnJvbSArICcmc2l6ZT0nICsgc2l6ZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB2aWV3QWxsR3JvdXA8VD4oZnJvbSwgc2l6ZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdBbGxHcm91cCZmcm9tPScgKyBmcm9tICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRlbGV0ZVVzZXJHcm91cDxUPihncm91cElkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFncm91cElkKVxyXG4gICAgICB0aHJvdyBcImdyb3VwSWQgaWQgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWRlbGV0ZUdyb3VwJmdyb3VwSWQ9JyArIGdyb3VwSWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5VXNlckdyb3VwPFQ+KGdyb3VwSWQsIGdyb3VwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghZ3JvdXBJZClcclxuICAgICAgdGhyb3cgXCJncm91cElkIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRPbiddID0gbmV3IERhdGUoY3VycmVudERhdGUuZ2V0VGltZSgpICsgdGhpcy5jYWNoZS50aW1lQWRqdXN0bWVudCArIDE5ODAwMDAwKTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRCeSddID0gdGhpcy5jYWNoZS5YX1VTRVJOQU1FO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPW1vZGlmeUdyb3VwJmdyb3VwSWQ9JyArIGdyb3VwSWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiBncm91cERhdGEgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbG9ja1VzZXI8VD4odXNlck5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1sb2NrVXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdW5sb2NrVXNlcjxUPih1c2VyTmFtZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXVubG9ja1VzZXImdXNlck5hbWU9JyArIHVzZXJOYW1lLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGxvY2tHcm91cDxUPihncm91cE5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1sb2NrR3JvdXAmZ3JvdXBOYW1lPScgKyBncm91cE5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdW5sb2NrR3JvdXA8VD4oZ3JvdXBOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dW5sb2NrR3JvdXAmZ3JvdXBOYW1lPScgKyBncm91cE5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Q291bnRVc2VyczxUPihyb2xlSWRKc29uLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Q291bnRVc2VycycsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6cm9sZUlkSnNvblxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY2hhbmdlUGFzc3dvcmQ8VD4odXNlck5hbWUsIG9sZFBhc3N3b3JkLCBuZXdQYXNzd29yZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoYW5nZVBhc3N3b3JkJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIFwidXNlckluZm9cIjoge1xyXG4gICAgICAgICAgXCJ1c2VyTmFtZVwiOiB1c2VyTmFtZSxcclxuICAgICAgICAgIFwib2xkVXNlclBhc3N3b3JkXCI6IEFlc1V0aWxzLmVuY3J5cHQob2xkUGFzc3dvcmQpLFxyXG4gICAgICAgICAgXCJuZXdVc2VyUGFzc3dvcmRcIjogQWVzVXRpbHMuZW5jcnlwdChuZXdQYXNzd29yZClcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGZvcmdvdFBhc3N3b3JkPFQ+KHVzZXJOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBoZWFkZXJzPWhlYWRlcnMuYXBwZW5kKFwidXNlck5hbWVcIix1c2VyTmFtZSk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Zm9yZ290UGFzc293b3JkJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBpbnNlcnRUcmFjZURhdGE8VD4odXNlck5hbWUsb3BlcmF0aW9uOnN0cmluZyxyZXF1ZXN0UGFyYW1ldGVyczpzdHJpbmcscmVxdWVzdEhlYWRlcnM6c3RyaW5nLHByb2plY3Q/OnN0cmluZywpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgbGV0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKS5hcHBlbmQoXCJvcGVyYXRpb25cIixvcGVyYXRpb24pLmFwcGVuZChcInRpbWVzdGFtcFwiLGN1cnJlbnREYXRlLmdldFRpbWUoKS50b1N0cmluZygpKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5UUkFDRV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1pbnNlcnRUcmFjZURhdGEnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgICBcInJlcXVlc3RQYXJhbWV0ZXJzXCI6IHtyZXF1ZXN0UGFyYW1ldGVyc30sXHJcbiAgICAgICAgICBcInJlcXVlc3RIZWFkZXJzXCI6IHtyZXF1ZXN0SGVhZGVyc30sXHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldFRyYWNlRGF0YTxUPih1c2VyTmFtZSxvcGVyYXRpb246c3RyaW5nLHRyYWNlTGV2ZWw6c3RyaW5nLGZyb21UaW1lU3RhbXA6c3RyaW5nLHRvVGltZVN0YW1wOnN0cmluZyxwcm9qZWN0PzpzdHJpbmcsKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKS5hcHBlbmQoXCJvcGVyYXRpb25cIixvcGVyYXRpb24pLmFwcGVuZChcInRyYWNlTGV2ZWxcIix0cmFjZUxldmVsKS5hcHBlbmQoXCJmcm9tVGltZVN0YW1wXCIsZnJvbVRpbWVTdGFtcCkuYXBwZW5kKFwidG9UaW1lU3RhbXBcIix0b1RpbWVTdGFtcCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuVFJBQ0VfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VHJhY2VEYXRhJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICByZXNldFBhc3N3b3JkPFQ+KHVzZXJOYW1lOiBzdHJpbmcsIG90cDogU3RyaW5nLCBuZXdQYXNzd29yZDogc3RyaW5nLGNvbmZpcm1QYXNzd29yZDogc3RyaW5nLCBwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaGVhZGVycz1oZWFkZXJzLmFwcGVuZChcInVzZXJOYW1lXCIsdXNlck5hbWUpO1xyXG4gICAgbGV0IHBhc3N3b3JkOnN0cmluZyA9UnNhVXRpbHMuZW5jcnlwdChuZXdQYXNzd29yZCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249cmVzZXRQYXNzd29yZCcsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBcInVzZXJJbmZvXCI6IHtcclxuICAgICAgICAgIFwidXNlck5hbWVcIjogdXNlck5hbWUsXHJcbiAgICAgICAgICBcIm5ld1Bhc3N3b3JkXCI6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgXCJjb25maXJtUGFzc3dvcmRcIjogcGFzc3dvcmQsXHJcbiAgICAgICAgICBcIm90cFwiOm90cFxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2VuZXJhdGVQYXNzd29yZDxUPih1c2VyTmFtZTogc3RyaW5nLCBvdHA6IFN0cmluZywgbmV3UGFzc3dvcmQ6IHN0cmluZyxjb25maXJtUGFzc3dvcmQ6IHN0cmluZywgcHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKTtcclxuICAgIGxldCBwYXNzd29yZDpzdHJpbmcgPVJzYVV0aWxzLmVuY3J5cHQobmV3UGFzc3dvcmQpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdlbmVyYXRlUGFzc3dvcmQnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgXCJ1c2VySW5mb1wiOiB7XHJcbiAgICAgICAgICBcInVzZXJOYW1lXCI6IHVzZXJOYW1lLFxyXG4gICAgICAgICAgXCJuZXdQYXNzd29yZFwiOiBwYXNzd29yZCxcclxuICAgICAgICAgIFwiY29uZmlybVBhc3N3b3JkXCI6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgXCJvdHBcIjpvdHBcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIG1vZGlmeVVzZXJJbWFnZTxUPih1c2VyTmFtZSwgQXBwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghdXNlck5hbWUpXHJcbiAgICAgIHRocm93IFwidXNlck5hbWUgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPW1vZGlmeVVzZXJJbWFnZSZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICAnQXBwRGF0YSc6IEFwcERhdGFcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgV2ViU29ja2V0Q2FsbGJhY2tzIHtcclxuICBvbk9wZW4/OiAoZXZlbnQ/OiBhbnksd2Vic29ja2V0PzogV2ViU29ja2V0KSA9PiB2b2lkO1xyXG4gIG9uQ2xvc2U/OiAoZXZlbnQ/OiBhbnkpID0+IHZvaWQ7XHJcbiAgb25FcnJvcj86IChldmVudD86IGFueSkgPT4gdm9pZDtcclxuICBvbk1lc3NhZ2U6IChldmVudD86IGFueSkgPT4gdm9pZDtcclxufVxyXG4iLCJpbXBvcnQgeyBIdHRwSW50ZXJjZXB0b3IsIEh0dHBSZXF1ZXN0LCBIdHRwSGFuZGxlciwgSHR0cFJlc3BvbnNlLCBIdHRwRXZlbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgU2Vzc2lvblNlcnZpY2UgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IENhY2hlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuL2NhY2hlLW1hbmFnZXIuc2VydmljZSc7XHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEh0dHBSZXNwb25zZUludGVyY2VwdG9yIGltcGxlbWVudHMgSHR0cEludGVyY2VwdG9yIHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLCBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgY2FjaGU6IENhY2hlTWFuYWdlclNlcnZpY2UpIHsgfVxyXG4gICAgaW50ZXJjZXB0KHJlcTogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUuWF9TT0NLRVRfQUREUkVTUykge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdYLVNPQ0tFVC1BRERSRVNTJzogdGhpcy5jYWNoZS5YX1NPQ0tFVF9BRERSRVNTXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jYWNoZS5YX1VTRVJOQU1FKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ1gtVVNFUk5BTUUnOiB0aGlzLmNhY2hlLlhfVVNFUk5BTUVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNhY2hlLlNPQ0tFVF9JUCkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdzb2NrZXRJcCc6IHRoaXMuY2FjaGUuU09DS0VUX0lQXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVxLmhlYWRlcnMuaGFzKCdYLUV2ZW50LU5hbWUnKSkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogcmVxLmhlYWRlcnMuZ2V0KCdYLUV2ZW50LU5hbWUnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAocmVxLmhlYWRlcnMuaGFzKCdFdmVudC1LZXknKSkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogcmVxLmhlYWRlcnMuZ2V0KCdFdmVudC1LZXknKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9ICBlbHNlIGlmIChyZXEucGFyYW1zLmhhcygnb3BlcmF0aW9uJykpIHtcclxuICAgICAgICAgICAgcmVxID0gcmVxLmNsb25lKHtcclxuICAgICAgICAgICAgICAgIHNldEhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvcGVyYXRpb246IHJlcS5wYXJhbXMuZ2V0KCdvcGVyYXRpb24nKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lICYmXHJcbiAgICAgICAgICAgIHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkgJiYgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0KSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJUb2tlbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0VXNlclRva2VuRGF0YSgpO1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lO1xyXG4gICAgICAgICAgICBsZXQgcHJvZHVjdDogc3RyaW5nO1xyXG4gICAgICAgICAgICBwcm9kdWN0ID0gcmVxLmhlYWRlcnMuZ2V0KFwicHJvamVjdFwiKTtcclxuICAgICAgICAgICAgaWYgKCFwcm9kdWN0KSB7XHJcbiAgICAgICAgICAgICAgICBwcm9kdWN0ID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclRva2VuOiBgJHt1c2VyTmFtZX0tJHt1c2VyVG9rZW59YCxcclxuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0OiBwcm9kdWN0XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV4dC5oYW5kbGUocmVxKS5waXBlKHRhcChyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcCA9IHJlc3BvbnNlIGFzIEh0dHBSZXNwb25zZTxhbnk+O1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3AuaGVhZGVycy5oYXMoJ3VzZXJUb2tlbicpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRVc2VyVG9rZW5EYXRhKHJlc3AuaGVhZGVycy5nZXQoJ3VzZXJUb2tlbicpKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnB1dERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5ib2R5ICYmIHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXVsnaHR0cHN0YXR1c2NvZGUnXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5ib2R5WydzdGF0dXNDb2RlJ11bJ2h0dHBzdGF0dXNjb2RlJ10gPT09IDQwMSAmJiAocmVzcG9uc2UuYm9keVsnc3RhdHVzQ29kZSddWydvcFN0YXR1c0NvZGUnXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA9PT0gOTAzIHx8IHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXVsnb3BTdGF0dXNDb2RlJ10gPT09IDQwMzApKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItaWFtJyxcclxuICB0ZW1wbGF0ZTogYFxyXG4gICAgPHA+XHJcbiAgICAgIGlhbSB3b3JrcyFcclxuICAgIDwvcD5cclxuICBgLFxyXG4gIHN0eWxlczogW11cclxufSlcclxuZXhwb3J0IGNsYXNzIElhbUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUFwcChhcHBDb25maWd1cmF0aW9uU2VydmljZTogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsXHJcbiAgICBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSkge1xyXG4gICAgcmV0dXJuICgpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgYXBwQ29uZmlndXJhdGlvblNlcnZpY2UubG9hZENvbmZpZ3VyYXRpb24oJ2Fzc2V0cy9jb25maWd1cmF0aW9uL2NvbmZpZy5qc29uJykudGhlbigoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZ2V0UnNhS2V5UHJvbWlzZSA9IGNhY2hlLmdldEF1dGhLZXkoKTtcclxuICAgICAgICBjb25zdCBzdGFydFVwUm91dGVDaGFuZ2VQcm9taXNlID0gY2FjaGUub25TdGFydHVwUm91dGVDaGFuZ2UoZXZlbnQpO1xyXG4gICAgICAgIFByb21pc2UuYWxsKFtnZXRSc2FLZXlQcm9taXNlLCBzdGFydFVwUm91dGVDaGFuZ2VQcm9taXNlXSkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBub2RlU2hvcnRGdWxsUHJvbWlzZSA9IGNhY2hlLmdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZUpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IGNpcmNsZVNob3J0RnVsbFByb21pc2UgPSBjYWNoZS5nZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZUpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IG1vZHVsZVRvSWRQcm9taXNlID0gY2FjaGUuZ2V0TW9kdWxlVG9JZEpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IG5vZGVUb0lkUHJvbWlzZSA9IGNhY2hlLmdldE5vZGVUb0lkSnNvbigpO1xyXG4gICAgICAgICAgY29uc3QgY2lyY2xlVG9JZFByb21pc2UgPSBjYWNoZS5nZXRDaXJjbGVUb0lkSnNvbigpO1xyXG4gICAgICAgICAgY29uc3Qgb3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlUHJvbWlzZSA9IGNhY2hlLmdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZUpzb24oKTtcclxuICAgICAgICAgIFByb21pc2UuYWxsKFtub2RlU2hvcnRGdWxsUHJvbWlzZSwgY2lyY2xlU2hvcnRGdWxsUHJvbWlzZSwgbW9kdWxlVG9JZFByb21pc2UsXHJcbiAgICAgICAgICAgIG5vZGVUb0lkUHJvbWlzZSwgY2lyY2xlVG9JZFByb21pc2UsIG9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZVByb21pc2VdKS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgIGNhY2hlLmNhbGxXaGVuQ29uZmlnTG9hZHMoKTtcclxuICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0sIChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4iLCJpbXBvcnQgeyBOZ01vZHVsZSwgQVBQX0lOSVRJQUxJWkVSLCBNb2R1bGVXaXRoUHJvdmlkZXJzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElhbUNvbXBvbmVudCB9IGZyb20gJy4vaWFtLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ2FjaGVNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4vY2FjaGUtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU2Vzc2lvblNlcnZpY2UgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IElhbVNlcnZpY2UgfSBmcm9tICcuL2lhbS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29va2llU2VydmljZSB9IGZyb20gJ25neC1jb29raWUtc2VydmljZSc7XHJcbmltcG9ydCB7IEhUVFBfSU5URVJDRVBUT1JTIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBIdHRwUmVzcG9uc2VJbnRlcmNlcHRvciB9IGZyb20gJy4vaHR0cC1yZXNwb25zZS1pbnRlcmNlcHRvcic7XHJcbmltcG9ydCB7IGluaXRpYWxpemVBcHAgfSBmcm9tICcuL2NvbmZpZ3VyYXRpb24tZmFjdG9yeSc7XHJcblxyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtJYW1Db21wb25lbnRdLFxyXG4gIGV4cG9ydHM6IFtJYW1Db21wb25lbnRdLFxyXG4gIHByb3ZpZGVyczogWyBJYW1TZXJ2aWNlLCBDb29raWVTZXJ2aWNlICwgU2Vzc2lvblNlcnZpY2UsIEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLCBDYWNoZU1hbmFnZXJTZXJ2aWNlLCB7XHJcbiAgICBwcm92aWRlOiBBUFBfSU5JVElBTElaRVIsXHJcbiAgICB1c2VGYWN0b3J5OiBpbml0aWFsaXplQXBwLFxyXG4gICAgZGVwczogW0FwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLCBDYWNoZU1hbmFnZXJTZXJ2aWNlXSxcclxuICAgIG11bHRpOiB0cnVlXHJcbiAgfSwge1xyXG4gICAgcHJvdmlkZTogSFRUUF9JTlRFUkNFUFRPUlMsXHJcbiAgICB1c2VDbGFzczogSHR0cFJlc3BvbnNlSW50ZXJjZXB0b3IsXHJcbiAgICBtdWx0aTogdHJ1ZVxyXG4gIH1dXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJYW1Nb2R1bGUge1xyXG4gIHB1YmxpYyBzdGF0aWMgZm9yUm9vdCgpOiBNb2R1bGVXaXRoUHJvdmlkZXJzIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIG5nTW9kdWxlOiBJYW1Nb2R1bGUsXHJcbiAgICAgIHByb3ZpZGVyczogW11cclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJhZXNqcy51dGlscyIsImFlc2pzLnBhZGRpbmciLCJhZXNqcy5Nb2RlT2ZPcGVyYXRpb24iLCJ0c2xpYl8xLl9fdmFsdWVzIiwiQXBwU2V0dGluZyIsImZvcmdlLnV0aWwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBT0ksK0JBQVc7OztJQUFYO1FBQ0ksT0FBTyxRQUFRLENBQUMsUUFBUSxDQUFDO0tBQzVCO3lCQVA0QyxRQUFRLENBQUMsUUFBUSxPQUFJO21DQUNkLFFBQVEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxRQUFRLEdBQUcsT0FBTztpQ0FDdEUsZ0JBQWdCOytCQUNsQixjQUFjOzhCQUNmLGFBQWE7b0JBTmhFOzs7Ozs7O0FDQUE7SUFRRSxpQ0FBb0IsVUFBc0I7UUFBdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtLQUFLOzs7OztJQUMvQyxtREFBaUI7Ozs7SUFBakIsVUFBa0IsUUFBZ0I7UUFBbEMsaUJBV0M7UUFWQyxPQUFPLElBQUksT0FBTyxDQUFRLFVBQUMsT0FBTyxFQUFFLE1BQU07WUFDeEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQW1CLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLFFBQVE7Z0JBQ3hFLEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7Z0JBQ2pDLE9BQU8sRUFBRSxDQUFDO2FBQ1gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLFFBQWE7Z0JBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaURBQStDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFHLENBQUMsQ0FBQztnQkFDdkYsTUFBTSxDQUFDLGlEQUErQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBRyxDQUFDLENBQUM7YUFDckYsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDTSxrREFBZ0I7Ozs7UUFDckIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7OztnQkFuQmhDLFVBQVUsU0FBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7Ozs7Z0JBSlEsVUFBVTs7O2tDQURuQjs7Ozs7Ozs7QUNBQSxJQUFPLEtBQUssR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7O0lBSWpDO0tBQWdCOzs7OztJQUNGLDBCQUFpQjs7OztjQUFDLGdCQUF3QjtRQUNwRCxRQUFRLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzs7Ozs7SUFFMUQsdUJBQWM7Ozs7UUFDeEIsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7Ozs7OztJQUUxQyx5QkFBZ0I7Ozs7Y0FBQyxnQkFBd0I7UUFDbkQsUUFBUSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLENBQUM7Ozs7Ozs7SUFFeEQsZ0JBQU87Ozs7O2NBQUMsT0FBZSxFQUFFLFlBQXFCO1FBQ3hELElBQUksWUFBWSxFQUFFO1lBQ2QsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFO2dCQUM5RixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUM1QixJQUFJLEVBQUU7b0JBQ0YsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtpQkFDN0I7YUFDSixDQUFDLENBQUMsQ0FBQztTQUNQO2FBQU0sSUFBSSxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQzNCLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRTtnQkFDdkUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDNUIsSUFBSSxFQUFFO29CQUNGLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7aUJBQzdCO2FBQ0osQ0FBQyxDQUFDLENBQUM7U0FDUDthQUFNO1lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7Ozs7Ozs7SUFFUyxnQkFBTzs7Ozs7Y0FBQyxVQUFrQixFQUFFLGFBQXNCO1FBQzVELElBQUksYUFBYSxFQUFFO1lBQ2YsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRSxVQUFVLEVBQUU7Z0JBQ25HLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQzVCLElBQUksRUFBRTtvQkFDRixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2lCQUM3QjthQUNKLENBQUMsQ0FBQztTQUNOO2FBQU0sSUFBSSxRQUFRLENBQUMsVUFBVSxFQUFFO1lBQzVCLE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUUsVUFBVSxFQUFFO2dCQUM1RSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUM1QixJQUFJLEVBQUU7b0JBQ0YsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtpQkFDN0I7YUFDSixDQUFDLENBQUM7U0FDTjthQUFNO1lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO1lBQzFDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7Ozs7O0lBRUwsa0NBQWU7OztJQUFmOztRQUNJLElBQU0sYUFBYSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDOztRQUN0RSxJQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUN4RDt5QkF4RDBCLElBQUk7MEJBQ0gsSUFBSTttQkFIcEM7Ozs7Ozs7QUNBQTtJQUtJO0tBQWdCOzs7OztJQUNGLDRCQUFtQjs7OztjQUFDLE1BQWM7UUFDNUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7Ozs7Ozs7SUFFZixnQkFBTzs7Ozs7Y0FBQyxPQUFlLEVBQUUsTUFBZTtRQUNsRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1QsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7U0FDNUI7O1FBQ0QsSUFBTSxHQUFHLEdBQUdBLEtBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUM3QyxJQUFJLFNBQVMsR0FBR0EsS0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbEQsU0FBUyxHQUFHLElBQUlDLE9BQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDOztRQUNuRCxJQUFNLE1BQU0sR0FBRyxJQUFJQyxlQUFxQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7UUFDbEQsSUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRCxPQUFPRixLQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQzs7Ozs7OztJQUV2QyxnQkFBTzs7Ozs7Y0FBQyxNQUFjLEVBQUUsTUFBZTtRQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1QsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7U0FDNUI7O1FBQ0QsSUFBTSxHQUFHLEdBQUdBLEtBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUM3QyxJQUFNLE1BQU0sR0FBRyxJQUFJRSxlQUFxQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7UUFDbEQsSUFBTSxjQUFjLEdBQUdGLEtBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUN2RCxJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3BELGNBQWMsR0FBR0MsT0FBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDM0QsT0FBUUQsS0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7OztJQUV6Qyw2QkFBb0I7Ozs7Y0FBQyxNQUFrQjtRQUFsQix1QkFBQSxFQUFBLFdBQWtCOztRQUNqRCxJQUFNLEdBQUcsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7UUFDM0QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztZQUMzRSxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQztZQUN0RixHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQ2hFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQzFGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQzFGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQzFGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQzFGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDOztRQUM5RSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdCLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzdEO1FBQ0QsT0FBTyxHQUFHLENBQUM7Ozs7O0lBRWYsMkJBQVE7OztJQUFSO0tBQ0M7c0JBNUMrQixJQUFJO21CQUp4Qzs7Ozs7OztBQ0FBO0lBUUUseUJBQW9CLE1BQWM7UUFBZCxXQUFNLEdBQU4sTUFBTSxDQUFRO0tBQUs7Ozs7O0lBQ3ZDLGtDQUFROzs7O0lBQVIsVUFBUyxJQUFjO1FBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzVCOztnQkFSRixVQUFVLFNBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25COzs7O2dCQUpRLE1BQU07OzswQkFEZjs7Ozs7Ozs7NEJDeUI2QixhQUE0QixFQUFVLFVBQXNCLEVBQVUsZUFBZ0M7UUFBdEcsa0JBQWEsR0FBYixhQUFhLENBQWU7UUFBVSxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQVUsb0JBQWUsR0FBZixlQUFlLENBQWlCO3VCQVh2RyxJQUFJLFlBQVksQ0FBQyxFQUFDLGNBQWMsRUFBRyxJQUFJLEVBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7Ozs7Ozs7O0lBZWxHLHVDQUFjOzs7O0lBQWQsVUFBZSxHQUF1QjtRQUF2QixvQkFBQSxFQUFBLGVBQXVCOztRQUVwQyxJQUFJLElBQUksQ0FBTzs7UUFDZixJQUFNLFVBQVUsR0FBVyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUN6RCxJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQ25DLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQ3pIO2FBQU07WUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLENBQUM7WUFDaEQsSUFBSSxxQkFBRyxFQUFVLENBQUEsQ0FBQztTQUNuQjtRQUNELHlCQUFPLElBQTJCLEVBQUM7S0FDcEM7Ozs7Ozs7O0lBSUQsa0NBQVM7Ozs7SUFBVCxVQUFVLEdBQXNCO1FBQXRCLG9CQUFBLEVBQUEsY0FBc0I7O1FBQzlCLElBQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDM0c7UUFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7Ozs7Ozs7SUFJRCx1Q0FBYzs7Ozs7SUFBZCxVQUFlLFdBQStCLEVBQUUsR0FBZTtRQUFmLG9CQUFBLEVBQUEsZUFBZTs7UUFDN0QsSUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDOztRQUNoQixJQUFNLGVBQWUsR0FBRztZQUNwQixXQUFXLEVBQUU7Z0JBQ1gsUUFBUSxFQUFFLFdBQVcsQ0FBQyxRQUFRO2dCQUM5QixPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU87Z0JBQzVCLGNBQWMsRUFBRSxXQUFXLENBQUMsY0FBYzthQUMzQztTQUNKLENBQUM7UUFDRixJQUFJLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRTtZQUNoQyxlQUFlLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsV0FBVyxDQUFDLGdCQUFnQixDQUFDO1NBQ2hGO1FBQ0QsSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFO1lBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO1NBQ3JDO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGVBQWUsQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQ25GOzs7Ozs7OztJQUlELHlDQUFnQjs7OztJQUFoQjtRQUFpQixjQUFpQjthQUFqQixVQUFpQixFQUFqQixxQkFBaUIsRUFBakIsSUFBaUI7WUFBakIseUJBQWlCOztRQUNoQyxJQUFLLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOztnQkFDcEIsS0FBa0IsSUFBQSxTQUFBRyxTQUFBLElBQUksQ0FBQSwwQkFBQTtvQkFBakIsSUFBTSxHQUFHLGlCQUFBO29CQUNaLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNoQzs7Ozs7Ozs7O1NBQ0Y7YUFBTTtZQUNMLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDL0IsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3RCOztLQUNGOzs7Ozs7OztJQUlELCtDQUFzQjs7OztJQUF0QixVQUF1QixTQUFrQjs7UUFDdkMsSUFBSSxXQUFXLEdBQVEsTUFBTSxDQUFDO1FBQzlCLElBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUNyQztZQUNFLFdBQVcsR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUMsY0FBYyxDQUFDO1NBQy9EO1FBQ0QsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNkLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7U0FDdkY7YUFBTTtZQUNMLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztTQUNqRDtLQUNGOzs7Ozs7O0lBSUQsK0NBQXNCOzs7SUFBdEI7O1FBQ0UsSUFBSSxXQUFXLEdBQVEsTUFBTSxDQUFDO1FBQzlCLElBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUNyQztZQUNFLFdBQVcsR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUMsY0FBYyxDQUFDO1NBQy9EO1FBQ0QsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUMzQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztTQUM3RDtRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsV0FBVyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDdEYsUUFBUSxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLFdBQVcsRUFBRTtLQUM3Qzs7Ozs7Ozs7SUFJRCx5Q0FBZ0I7Ozs7SUFBaEIsVUFBaUIsU0FBaUI7UUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQ2hGOzs7Ozs7O0lBSUQseUNBQWdCOzs7SUFBaEI7O1FBQ0UsSUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQztTQUMzSDtRQUNELElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO1FBQ2hELE9BQU8sSUFBSSxDQUFDO0tBQ2I7Ozs7Ozs7OztJQUlELDJEQUFrQzs7Ozs7SUFBbEMsVUFBbUMsaUJBQXVCLEVBQUUsR0FBaUM7UUFBakMsb0JBQUEsRUFBQSx5QkFBaUM7UUFDM0YsSUFBSSxRQUFPLE9BQU8sQ0FBQyxFQUFFO1lBQ25CLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO1NBQzlEO2FBQU07WUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDNUM7S0FDRjs7Ozs7Ozs7SUFJRCwyREFBa0M7Ozs7SUFBbEMsVUFBbUMsR0FBaUM7UUFBakMsb0JBQUEsRUFBQSx5QkFBaUM7O1FBQ2xFLElBQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNqRjtRQUNELElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO1FBQ2hELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN6Qjs7Ozs7Ozs7O0lBSUQsK0RBQXNDOzs7OztJQUF0QyxVQUF1QyxxQkFBMkIsRUFBRSxHQUFxQztRQUFyQyxvQkFBQSxFQUFBLDZCQUFxQztRQUN2RyxJQUFJLFFBQU8sT0FBTyxDQUFDLEVBQUU7WUFDbkIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7U0FDbEU7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUM1QztLQUNGOzs7Ozs7OztJQUlELCtEQUFzQzs7OztJQUF0QyxVQUF1QyxHQUFxQztRQUFyQyxvQkFBQSxFQUFBLDZCQUFxQzs7UUFDMUUsSUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQ2pGO1FBQ0QsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLENBQUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3pCOzs7Ozs7Ozs7SUFJRCwrREFBc0M7Ozs7O0lBQXRDLFVBQXVDLHFCQUEyQixFQUFFLEdBQXFDO1FBQXJDLG9CQUFBLEVBQUEsNkJBQXFDO1FBQ3ZHLElBQUksUUFBTyxPQUFPLENBQUMsRUFBRTtZQUNuQixZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztTQUNsRTthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1NBQzVDO0tBQ0Y7Ozs7Ozs7O0lBSUQsK0RBQXNDOzs7O0lBQXRDLFVBQXVDLEdBQXFDO1FBQXJDLG9CQUFBLEVBQUEsNkJBQXFDOztRQUMxRSxJQUFNLFVBQVUsR0FBVyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUN6RCxJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDakY7UUFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDekI7Ozs7Ozs7SUFJRCxpRUFBd0M7OztJQUF4QztRQUNFLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFBRTtZQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztTQUN4RjtLQUNGOzs7Ozs7O0lBSUQsMERBQWlDOzs7SUFBakM7UUFDRSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEVBQUU7WUFDckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztTQUNoRjtLQUNGOzs7O0lBQ08sdUNBQWM7Ozs7UUFDcEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUMvQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUM7UUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDM0IsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQztRQUNsQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1FBQzlCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7OztnQkE1TjFCLFVBQVUsU0FBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7Ozs7Z0JBVFEsYUFBYTtnQkFHY0MsdUJBQVU7Z0JBRXJDLGVBQWU7Ozt5QkFOeEI7Ozs7Ozs7QUNDQTs7Ozs7O0lBUWtCLDZDQUFzQjs7OztRQUNoQyxPQUFPLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDOzs7OztJQUVwRCwwQ0FBbUI7Ozs7UUFDN0IsT0FBTyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLENBQUM7Ozs7O0lBRWpELDJDQUFvQjs7OztRQUM5QixPQUFPLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7SUFFbEQsMkNBQW9COzs7O1FBQzlCLE9BQU8sc0JBQXNCLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxDQUFDOzs7OztJQUVsRCx3REFBaUM7Ozs7UUFDM0MsT0FBTyxzQkFBc0IsQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7SUFFL0QsOENBQXVCOzs7O1FBQ2pDLHNCQUFzQixDQUFDLGdCQUFnQixHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDO1FBQ3RFLHNCQUFzQixDQUFDLGFBQWEsR0FBSSxJQUFJLE9BQU8sRUFBZ0IsQ0FBQztRQUNwRSxzQkFBc0IsQ0FBQyxjQUFjLEdBQUksSUFBSSxPQUFPLEVBQWdCLENBQUM7UUFDckUsc0JBQXNCLENBQUMsY0FBYyxHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDOzs7Ozs7SUFFeEUsMENBQVM7Ozs7SUFBVCxVQUFVLEtBQW1CO1FBQ3pCLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUN2RDs7Ozs7SUFDRCx3Q0FBTzs7OztJQUFQLFVBQVEsS0FBbUI7UUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2hDLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDckQ7Ozs7O0lBQ0Qsd0NBQU87Ozs7SUFBUCxVQUFRLEtBQW1CO1FBQ3ZCLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkIsc0JBQXNCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUNyRDs7Ozs7O0lBQ0QsdUNBQU07Ozs7O0lBQU4sVUFBTyxLQUFtQixFQUFFLFNBQW9CO1FBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNoQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3BEOzs7O0lBQ0QsNENBQVc7OztJQUFYO1FBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3RDLHNCQUFzQixDQUFDLDJCQUEyQixDQUFDLElBQUksRUFBRSxDQUFDO0tBQzdEOzhDQTdDK0MsSUFBSSxPQUFPLEVBQWdCOzJDQUM5QixJQUFJLE9BQU8sRUFBZ0I7NENBQzFCLElBQUksT0FBTyxFQUFnQjs0Q0FDM0IsSUFBSSxPQUFPLEVBQWdCO3lEQUNiLElBQUksT0FBTyxFQUFRO2lDQVBuRjs7Ozs7OztBQ0FBO0lBT0Usd0JBQW9CLFVBQXNCO1FBQXRCLGVBQVUsR0FBVixVQUFVLENBQVk7S0FBSzs7Ozs7SUFFakMseUJBQVU7Ozs7Y0FBQyxJQUFZO1FBQ2pDLE9BQU8sY0FBYyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsY0FBYyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsNkJBQTZCLENBQUM7Ozs7OztJQUU5RyxzQ0FBYTs7OztjQUFDLFFBQWU7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQU8sUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQUMsUUFBUTtZQUMxRCxJQUFJLEdBQUcsQ0FBZ0IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEtBQWEsRUFBRSxHQUFXO2dCQUNsRixjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzNELENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxRQUFhO1lBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpREFBK0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUcsQ0FBQyxDQUFDO1NBQzFGLENBQUMsQ0FBQzs7Z0NBWndDLElBQUksR0FBRyxFQUFrQjs7Z0JBTjNFLFVBQVUsU0FBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7Ozs7Z0JBSFEsVUFBVTs7O3lCQURuQjs7Ozs7OztBQ0FBO0lBdUNFLDZCQUFvQixnQkFBeUMsRUFBVSxVQUFzQixFQUNuRixnQkFBd0MsUUFBa0IsRUFBUyxjQUE2QjtRQUQxRyxpQkFDK0c7UUFEM0YscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtRQUFVLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDbkYsbUJBQWMsR0FBZCxjQUFjO1FBQTBCLGFBQVEsR0FBUixRQUFRLENBQVU7UUFBUyxtQkFBYyxHQUFkLGNBQWMsQ0FBZTtvQ0FMN0QsSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtZQUM3RSxLQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztZQUN6QixLQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQztTQUN4QixDQUFDO0tBRTZHOzs7O0lBQy9HLHNDQUFROzs7SUFBUixlQUFjOzs7O0lBQ2QseUNBQVc7OztJQUFYO1FBQ0UsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDeEI7S0FDRjs7OztJQUNELHdDQUFVOzs7SUFBVjtRQUFBLGlCQXNDQzs7UUFyQ0MsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO2FBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs7UUFDdEUsSUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLENBQUM7WUFDcEgsT0FBTyxvQkFBRSxVQUFvQixDQUFBO1NBQzlCLENBQUM7UUFXRixPQUFPLElBQUksT0FBTyxDQUFPLFVBQUMsT0FBTyxFQUFFLE1BQU07WUFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQXlCLEdBQUcsRUFBRSxXQUFXLENBQUM7aUJBQzFELElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQzFELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUM3QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUNoRSxLQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzs7b0JBQ2xELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7b0JBQ2xILElBQU0sVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ3hDLEtBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQzs7b0JBRTlDLE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNO29CQUNMLE1BQU0sRUFBRSxDQUFDO2lCQUNWO2FBQ0YsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLEVBQUUsQ0FBQzthQUNWLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsMERBQTRCOzs7SUFBNUI7UUFBQSxpQkFrQ0M7O1FBakNDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDOztRQUNsRixJQUFNLFdBQVcsR0FBRztZQUNsQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUM7Z0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO2dCQUMzRCxXQUFXLEVBQUUsMEJBQTBCO2FBQ3hDLENBQUM7U0FDSCxDQUFDO1FBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDeEIsS0FBSSxDQUFDLHVCQUF1QixHQUFHO3dCQUM3QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPO3FCQUNwQyxDQUFDO29CQUNGLE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNO29CQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDZDthQUNGLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsNERBQThCOzs7SUFBOUI7UUFBQSxpQkFrQ0M7O1FBakNDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDOztRQUNwRixJQUFNLFdBQVcsR0FBRztZQUNsQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUM7Z0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO2dCQUMzRCxXQUFXLEVBQUUsNEJBQTRCO2FBQzFDLENBQUM7U0FDSCxDQUFDO1FBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDeEIsS0FBSSxDQUFDLDBCQUEwQixHQUFHO3dCQUNoQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPO3FCQUNwQyxDQUFDO29CQUNGLE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNO29CQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDZDthQUNGLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsK0NBQWlCOzs7SUFBakI7UUFBQSxpQkFnQ0M7O1FBL0JDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDOztRQUM3RSxJQUFNLFdBQVcsR0FBRztZQUNsQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUM7Z0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO2dCQUMzRCxXQUFXLEVBQUUscUJBQXFCO2FBQ25DLENBQUM7U0FDSCxDQUFDO1FBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDeEIsS0FBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUNoRCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Q7YUFDRixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7OztJQUNELDZDQUFlOzs7SUFBZjtRQUFBLGlCQWdDQzs7UUEvQkMsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO2FBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7O1FBQ3hFLElBQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQztnQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87Z0JBQzNELFdBQVcsRUFBRSxnQkFBZ0I7YUFDOUIsQ0FBQztTQUNILENBQUM7UUFTRixPQUFPLElBQUksT0FBTyxDQUFPLFVBQUMsT0FBTyxFQUFFLE1BQU07WUFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQVcsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDekYsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUN4QixLQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUMzQyxPQUFPLEVBQUUsQ0FBQztpQkFDWDtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Q7YUFDRixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7OztJQUNELCtDQUFpQjs7O0lBQWpCO1FBQUEsaUJBZ0NDOztRQS9CQyxJQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQzs7UUFDMUUsSUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTztnQkFDM0QsV0FBVyxFQUFFLGtCQUFrQjthQUNoQyxDQUFDO1NBQ0gsQ0FBQztRQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxLQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN6RixTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNiLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7b0JBQ3hCLEtBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQzdDLE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNO29CQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDZDthQUNGLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsZ0VBQWtDOzs7SUFBbEM7UUFBQSxpQkFnQ0M7O1FBL0JDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDOztRQUN4RixJQUFNLFdBQVcsR0FBRztZQUNsQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUM7Z0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO2dCQUMzRCxXQUFXLEVBQUUsZ0NBQWdDO2FBQzlDLENBQUM7U0FDSCxDQUFDO1FBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDeEIsS0FBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUN4RCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Q7YUFDRixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7OztJQUNELHlDQUFXOzs7SUFBWDtRQUNFLE9BQU8sTUFBTSxDQUFDLFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDcEY7Ozs7O0lBQ0Msa0RBQW9COzs7O0lBQXBCLFVBQXFCLEtBQUs7UUFBMUIsaUJBZ0RDO1FBOUNDLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQztZQUMzRSxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7Z0JBQ2hDLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQzthQUNsQztZQUNELElBQUksS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxJQUFJLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQjttQkFDaEgsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMscUJBQXFCLEVBQUU7O2dCQUNuRSxJQUFJLFFBQVEsR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNwQyxJQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQ3pCO29CQUNFLFFBQVEsR0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqQzs7Z0JBQ0QsSUFBTSxjQUFjLEdBQVksS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDOztnQkFDbkgsSUFBTSxRQUFRLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO2dCQUMxRCxJQUFJLGNBQWMsSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDOUIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ3JFLE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNLElBQUksUUFBUSxFQUFFO29CQUNuQixJQUFJO3dCQUNGLElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixFQUFFOzRCQUMxQyxLQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsa0NBQWtDLEVBQUUsQ0FBQzt5QkFDbEc7d0JBQ0QsSUFBSSxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLEVBQUU7NEJBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxzQ0FBc0MsRUFBRSxDQUFDO3lCQUMxRzt3QkFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsRUFBRTs0QkFDN0MsS0FBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLHNDQUFzQyxFQUFFLENBQUM7eUJBQ3pHOzt3QkFDRCxJQUFNLFNBQVMsR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3BHLElBQUksU0FBUyxFQUFFOzRCQUNiLEtBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQ2xGO3dCQUNELEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLHNCQUFzQixFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJOzRCQUNwRSxPQUFPLEVBQUUsQ0FBQzt5QkFDWCxFQUFFLFVBQUEsS0FBSzs0QkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUNuQixPQUFPLEVBQUUsQ0FBQzt5QkFDWCxDQUFDLENBQUM7cUJBQ0o7b0JBQUMsT0FBTyxDQUFDLEVBQUU7d0JBQ1YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDaEI7aUJBQ0Y7cUJBQU07b0JBQ0wsT0FBTyxFQUFFLENBQUM7aUJBQ1g7YUFDRjtTQUNGLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsaURBQW1COzs7SUFBbkI7O1FBQ0UsSUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7O1FBQ2hELElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsTUFBTSxDQUFDO1FBQzNELElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDOUUsSUFBSSxNQUFNLEVBQUU7WUFDVixRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEM7UUFDRCxJQUFJLFdBQVcsSUFBSSxXQUFXLENBQUMsV0FBVyxJQUFJLFdBQVcsQ0FBQyxXQUFXLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQVN0RyxJQUFJLENBQUMsWUFBWSxDQUFvQixXQUFXLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLFFBQVE7Z0JBQzVGLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtvQkFDcEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztpQkFDN0c7YUFDRixFQUFFLFVBQVUsR0FBRztnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCLENBQUMsQ0FBQztTQUNKO0tBQ0Y7Ozs7OztJQUNELDBDQUFZOzs7OztJQUFaLFVBQWdCLFFBQWdCO1FBQWhDLGlCQW9CQzs7UUFuQkMsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO2FBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7O1FBRW5HLElBQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQztnQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87Z0JBQzNELFdBQVcsRUFBRSxjQUFjO2dCQUMzQixXQUFXLEVBQUssUUFBUSxTQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUk7YUFDckUsQ0FBQztTQUNILENBQUM7UUFDRixPQUFPLElBQUksT0FBTyxDQUFJLFVBQUMsT0FBTyxFQUFFLE1BQU07WUFDcEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUksR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDbEYsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDYixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDZixFQUFFLFVBQUEsS0FBSztnQkFDTixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7Ozs7SUFDRCxrREFBb0I7Ozs7SUFBcEIsVUFBcUIsa0JBQXNDO1FBQTNELGlCQTREQzs7UUEzREMsSUFBSSxtQkFBbUIsR0FBd0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQzs7UUFDcEYsSUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLGtCQUFrQixDQUFDOztRQUM5QyxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7O1FBQ3ZELElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQzs7UUFDM0QsSUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsYUFBYSxDQUFDOztRQUM3RSxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLENBQUM7O1FBQ2pFLElBQU0sUUFBUSxHQUFHLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDOztRQUNsRSxJQUFNLFdBQVcsR0FBR0MsSUFBVSxDQUFDLFFBQVEsQ0FBSSxRQUFRLFNBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBSSxDQUFDLENBQUM7O1FBQ2pHLElBQU0sV0FBVyxHQUFHLDhDQUE0QyxPQUFPLG1CQUFjLFdBQVcsb0JBQWUsRUFBRSxTQUFJLElBQU0sQ0FBQzs7UUFDNUgsSUFBTSxZQUFZLEdBQUcsS0FBRyxRQUFRLEdBQUcsRUFBRSxTQUFJLGFBQWEsa0JBQWEsV0FBYSxDQUFDO1FBQ2pGLE9BQU8sSUFBSSxVQUFVLENBQU8sVUFBQSxPQUFPOztZQUNqQyxJQUFJLElBQUksR0FBWSxLQUFLLENBQUM7WUFDMUIsSUFBSTtnQkFDRixLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUM3QyxJQUFJLGtCQUFrQixDQUFDLE1BQU0sRUFBRTtvQkFDN0IsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUc7d0JBQ3RCLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxDQUFDOzt3QkFDNUIsSUFBTSxHQUFHLEdBQXdCLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDbkQsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUN6RixLQUFJLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUM7d0JBQ3ZFLEtBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQzt3QkFDbEUsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO3dCQUNqQixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2YsSUFBSSxHQUFHLElBQUksQ0FBQztxQkFDYixDQUFBO2lCQUNGO2dCQUNELElBQUksa0JBQWtCLENBQUMsT0FBTyxFQUFFO29CQUM5QixLQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRzt3QkFDdkIsa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUM7d0JBQzdCLHNCQUFzQixDQUFDLHVCQUF1QixFQUFFLENBQUM7d0JBQ2pELEtBQUksQ0FBQyxnQ0FBZ0MsRUFBRSxDQUFDOzt3QkFDeEMsSUFBTSxHQUFHLEdBQXdCLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDbEQsbUJBQW1CLEdBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQzt3QkFDMUQsSUFBRyxHQUFHLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksSUFBRSxtQkFBbUIsQ0FBQyxPQUFPLElBQUUsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTs7NEJBQ3RHLElBQU0sVUFBUSxHQUFHLElBQUksc0JBQXNCLEVBQUUsQ0FBQzs0QkFDOUMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFVBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0NBQ2hELFVBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQzs2QkFDMUIsQ0FBQyxDQUFDO3lCQUNGO3FCQUNGLENBQUM7aUJBQ0g7O2dCQUNELElBQU0sV0FBUyxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ2pDLEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSztvQkFDckMsSUFBSSxrQkFBa0IsQ0FBQyxPQUFPLEVBQUU7d0JBQzlCLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDbkM7b0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO29CQUNwRCxXQUFTLEVBQUUsQ0FBQztvQkFDWixPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7aUJBQ2pCLENBQUM7Z0JBQ0YsSUFBSSxrQkFBa0IsQ0FBQyxTQUFTLEVBQUU7b0JBQ2hDLEtBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLGtCQUFrQixDQUFDLFNBQVMsQ0FBQztpQkFDekQ7YUFDRjtZQUFDLE9BQU8sS0FBSyxFQUFFO2dCQUNkLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkIsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QjtTQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0tBQ3RDOzs7O0lBQ08sd0NBQVU7Ozs7O1FBQ2hCLElBQU0sU0FBUyxHQUFXLFFBQVEsQ0FBQyxNQUFNLENBQUM7O1FBQzFDLElBQU0sT0FBTyxHQUFhLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O1FBQy9DLElBQU0sR0FBRyxHQUF3QixJQUFJLEdBQUcsRUFBa0IsQ0FBQztRQUMzRCxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUEsTUFBTTtZQUNwQixJQUFJLE1BQU0sRUFBRTs7Z0JBQ1YsSUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDeEMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7YUFDN0M7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQzs7Ozs7O0lBRUwseUNBQVc7Ozs7Y0FBQyxLQUF3QjtRQUMxQyxJQUFJLEtBQUssWUFBWSxVQUFVLEVBQUU7WUFDL0IsT0FBTyxVQUFVLENBQUMsb0NBQWtDLEtBQU8sQ0FBQyxDQUFDO1NBQzlEO2FBQU07WUFDTCxPQUFPLFVBQVUsQ0FBQywwQkFBd0IsS0FBSyxDQUFDLE1BQU0sb0JBQWUsS0FBSyxDQUFDLEtBQU8sQ0FBQyxDQUFDO1NBQ3JGOzs7OztJQUVLLDhEQUFnQzs7Ozs7UUFDdEMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksT0FBTyxDQUFPLFVBQUMsT0FBTyxFQUFFLE1BQU07WUFDNUQsS0FBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7WUFDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7U0FDeEIsQ0FBQyxDQUFDOzs7Ozs7SUFHTCxtREFBcUI7Ozs7SUFEckIsVUFDc0IsS0FBWTs7UUFDaEMsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFO2FBQ25ELGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFDekQsSUFBRyxTQUFTLEVBQ1o7WUFDRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3hCO0tBQ0Y7O2dCQWpkRixVQUFVLFNBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25COzs7O2dCQWhCUSx1QkFBdUI7Z0JBRVYsVUFBVTtnQkFJdkIsY0FBYztnQkFDZCxRQUFRO2dCQUlSLGNBQWM7Ozt3Q0E0Y3BCLFlBQVksU0FBQyx1QkFBdUIsRUFBQyxDQUFDLFFBQVEsQ0FBQzs7OzhCQXhkbEQ7Ozs7Ozs7O0lDY0UscUJBQW9CLFVBQXNCLEVBQVUsZ0JBQXlDLEVBQ3JGLE9BQW9DLGNBQThCO1FBRHRELGVBQVUsR0FBVixVQUFVLENBQVk7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQXlCO1FBQ3JGLFVBQUssR0FBTCxLQUFLO1FBQStCLG1CQUFjLEdBQWQsY0FBYyxDQUFnQjtLQUFLOzs7Ozs7SUFDdkUsc0NBQWdCOzs7OztjQUFDLFdBQW1CLEVBQUUsR0FBVzs7UUFDdkQsSUFBSSxNQUFNLENBQVc7UUFDckIsSUFBSSxXQUFXLEVBQUU7WUFDZixNQUFNLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNqQzthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUM7U0FDYjs7UUFDRCxJQUFNLEdBQUcsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7O1lBQzNELEtBQW9CLElBQUEsV0FBQUYsU0FBQSxNQUFNLENBQUEsOEJBQUE7Z0JBQXJCLElBQU0sS0FBSyxtQkFBQTs7Z0JBQ2QsSUFBTSxRQUFRLEdBQWEsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDNUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbkM7Ozs7Ozs7OztRQUNELE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQzs7Ozs7OztJQUU1Qyw4QkFBUTs7OztJQUFSLFVBQVMsR0FBVzs7UUFDbEIsSUFBTSxnQkFBZ0IsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7O1FBQ3hFLElBQU0sV0FBVyxHQUFXLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O1FBQzlDLElBQU0saUJBQWlCLEdBQWEsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzRCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxhQUFhOztZQUNyQyxJQUFNLFFBQVEsR0FBYSxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3QyxDQUFDLENBQUM7UUFDSCxPQUFPLGdCQUFnQixDQUFDO0tBQ3pCOzs7OztJQUNPLHdDQUFrQjs7OztjQUFDLEdBQVc7UUFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHdCQUF3QixFQUFFO1lBQ3RFLE9BQU8sSUFBSSxDQUFDO1NBQ2I7O1FBQ0QsSUFBTyxnQkFBZ0IsR0FBd0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7UUFDbEUsSUFBTSxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7O1FBQ2hELElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDOztRQUNoQyxJQUFJLGlCQUFpQixHQUFHLEtBQUssQ0FBQzs7UUFDOUIsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7UUFDaEMsUUFBUSxTQUFTO1lBQ2pCLEtBQUssU0FBUyxDQUFDO1lBQ2YsS0FBSyxZQUFZO2dCQUNmLG1CQUFtQixHQUFHLElBQUksQ0FBQztnQkFDM0IsTUFBTTtZQUNSO2dCQUNFLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUM7b0JBQzVDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTs7b0JBQzNFLElBQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDO29CQUM3RSxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDcEcsbUJBQW1COzRCQUNuQixJQUFJLENBQUMsY0FBYyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQztxQkFDakk7eUJBQU07d0JBQ0wsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO3FCQUM3QjtpQkFDRjtxQkFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDO29CQUNyRCxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQ3pFLG1CQUFtQixHQUFHLElBQUksQ0FBQztpQkFDNUI7cUJBQU07b0JBQ0wsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO2lCQUM3QjtnQkFDSCxNQUFNO1NBQ0w7UUFDRCxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDeEIsT0FBTyxLQUFLLENBQUM7U0FDZDtRQUNELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtZQUMzRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFOztnQkFDdkQsSUFBTSxvQkFBb0IsR0FBRyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7Z0JBQzVELElBQU0sa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3hELElBQUksb0JBQW9CLElBQUksa0JBQWtCLEVBQUU7b0JBQzlDLElBQUksa0JBQWtCLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUM7d0JBQzdELElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO3dCQUNwRixtQkFBbUIsR0FBRyxJQUFJLENBQUM7cUJBQzVCO3lCQUFNO3dCQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztxQkFDN0I7aUJBQ0Y7cUJBQU07b0JBQ0wsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO2lCQUM3QjthQUNGO2lCQUFNO2dCQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQzthQUM3QjtTQUNGO2FBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztZQUNyRCxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFO1lBQzFELG1CQUFtQixHQUFHLElBQUksQ0FBQztTQUM1QjthQUFNO1lBQ0wsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3hCLE9BQU8sS0FBSyxDQUFDO1NBQ2Q7UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDO1lBQzlDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFOztZQUN2RCxJQUFNLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3hELElBQUksa0JBQWtCLEVBQUU7Z0JBQ3RCLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUNoRSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7aUJBQzFCO3FCQUFNO29CQUNMLGlCQUFpQixHQUFHLEtBQUssQ0FBQztpQkFDM0I7YUFDRjtpQkFBTTtnQkFDTCxpQkFBaUIsR0FBRyxLQUFLLENBQUM7YUFDM0I7U0FDRjthQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUM7WUFDckQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRTtZQUN4RCxpQkFBaUIsR0FBRyxJQUFJLENBQUM7U0FDMUI7YUFBTTtZQUNMLGlCQUFpQixHQUFHLEtBQUssQ0FBQztTQUMzQjtRQUNELE9BQU8saUJBQWlCLENBQUM7Ozs7Ozs7SUFFM0IsNkJBQU87Ozs7O0lBQVAsVUFBVyxPQUFnQjtRQUEzQixpQkEyREM7O1FBMURDLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztRQUMxRSxJQUFJLEdBQUcsQ0FBUzs7UUFDaEIsSUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUN0QjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzFCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsTUFBSSxPQUFPLENBQUMsV0FBYSxDQUFDO2FBQ2pEO1lBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO1lBQ2pHLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2hDLElBQUksT0FBTyxDQUFDLFlBQVksRUFBRTtvQkFDeEIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDM0Q7O2dCQUNELElBQU0sYUFBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsYUFBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLElBQUcsT0FBTyxDQUFDLFlBQVksRUFBRTtvQkFDdkIsYUFBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7aUJBQ3BEO2dCQUNELE9BQU8sSUFBSSxVQUFVLENBQWtCLFVBQUEsT0FBTztvQkFDNUMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87d0JBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7NEJBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lDQUNsRyxTQUFTLENBQUMsVUFBQSxRQUFRO2dDQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUNyQixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtvQ0FDNUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDO2lDQUNyRztxQ0FBTTtvQ0FDTCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lDQUN4Qjs2QkFDRixFQUFFLFVBQUEsS0FBSztnQ0FDSixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDOzZCQUN4QixDQUFDLENBQUM7eUJBQ0osQ0FBQyxDQUFDO3FCQUNOO3lCQUFNO3dCQUNMLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNsRyxTQUFTLENBQUMsVUFBQSxRQUFROzRCQUNqQixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtnQ0FDNUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDOzZCQUNyRztpQ0FBTTtnQ0FDTCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzZCQUN4Qjt5QkFDRixFQUFFLFVBQUEsS0FBSzs0QkFDSixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3lCQUN4QixDQUFDLENBQUM7cUJBQ0o7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxVQUFVLENBQUMsa0NBQWdDLEdBQUcsVUFBTyxDQUFDLENBQUM7YUFDL0Q7U0FDRjtLQUNGOzs7Ozs7SUFDRCw4QkFBUTs7Ozs7SUFBUixVQUFZLE9BQWdCO1FBQTVCLGlCQW9DQzs7UUFuQ0MsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O1FBQzFFLElBQUksR0FBRyxDQUFTOztRQUNoQixJQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQ3RCO2FBQU07WUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDMUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxNQUFJLE9BQU8sQ0FBQyxXQUFhLENBQUM7YUFDakQ7WUFDRCxHQUFHLEdBQUcsS0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLFNBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFhLENBQUM7WUFDakcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7Z0JBQ2hDLElBQU0sYUFBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsYUFBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLE9BQU8sSUFBSSxVQUFVLENBQWtCLFVBQUEsVUFBVTtvQkFDL0MsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87d0JBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7NEJBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUNBQ2pILFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO3lCQUNyRixDQUFDLENBQUM7cUJBQ047eUJBQU07d0JBQ0wsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDakgsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7cUJBQ3JGO2lCQUNGLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE9BQU8sVUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7S0FDRjs7Ozs7O0lBQ0QsNkJBQU87Ozs7O0lBQVAsVUFBVyxPQUFnQjtRQUEzQixpQkFtQ0M7O1FBbENDLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztRQUMxRSxJQUFJLEdBQUcsQ0FBUzs7UUFDaEIsSUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUN0QjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzFCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsTUFBSSxPQUFPLENBQUMsV0FBYSxDQUFDO2FBQ2pEO1lBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO1lBQ2pHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQkFDaEMsSUFBTSxhQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7b0JBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTtpQkFDOUIsQ0FBQztnQkFDRixhQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQztnQkFDN0MsT0FBTyxJQUFJLFVBQVUsQ0FBa0IsVUFBQSxVQUFVO29CQUMvQyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTzt3QkFDOUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO3dCQUN4RCxLQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQzs0QkFDbkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDaEgsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7eUJBQ3JGLENBQUMsQ0FBQztxQkFDTjt5QkFBTTt3QkFDTCxLQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNoSCxTQUFTLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFBLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQztxQkFDckY7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxVQUFVLENBQUMsa0NBQWdDLEdBQUcsVUFBTyxDQUFDLENBQUM7YUFDL0Q7U0FDRjtLQUNGOzs7Ozs7SUFDRCxnQ0FBVTs7Ozs7SUFBVixVQUFjLE9BQWdCO1FBQTlCLGlCQW1DQzs7UUFsQ0MsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O1FBQzFFLElBQUksR0FBRyxDQUFTOztRQUNoQixJQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQ3RCO2FBQU07WUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDMUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxNQUFJLE9BQU8sQ0FBQyxXQUFhLENBQUM7YUFDakQ7WUFDRCxHQUFHLEdBQUcsS0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLFNBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFhLENBQUM7WUFDakcsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7O2dCQUNoQyxJQUFNLGFBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUMsT0FBTyxDQUFDLE9BQU8scUJBQUMsRUFBaUIsQ0FBQTtvQkFDMUQsT0FBTyxvQkFBRSxVQUFvQixDQUFBO2lCQUM5QixDQUFDO2dCQUNGLGFBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUM3QyxPQUFPLElBQUksVUFBVSxDQUFrQixVQUFBLFVBQVU7b0JBQy9DLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO3dCQUM5QyxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hELEtBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDOzRCQUNuQyxLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBa0IsR0FBRyxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDckcsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7eUJBQ3JGLENBQUMsQ0FBQztxQkFDTjt5QkFBTTt3QkFDTCxLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBa0IsR0FBRyxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDckcsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7cUJBQ3JGO2lCQUNGLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE9BQU8sVUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7S0FDRjs7Ozs7O0lBQ0QsOEJBQVE7Ozs7O0lBQVIsVUFBWSxPQUFnQjtRQUE1QixpQkFtQ0M7O1FBbENDLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztRQUMxRSxJQUFJLEdBQUcsQ0FBUzs7UUFDaEIsSUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUN0QjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzFCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsTUFBSSxPQUFPLENBQUMsV0FBYSxDQUFDO2FBQ2pEO1lBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO1lBQ2pHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQkFDaEMsSUFBTSxhQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7b0JBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTtpQkFDOUIsQ0FBQztnQkFDRixhQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQztnQkFDN0MsT0FBTyxJQUFJLFVBQVUsQ0FBa0IsVUFBQSxVQUFVO29CQUMvQyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTzt3QkFDOUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO3dCQUN4RCxLQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQzs0QkFDbkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQWtCLEdBQUcsRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUNBQ25HLFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO3lCQUNyRixDQUFDLENBQUM7cUJBQ047eUJBQU07d0JBQ0wsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQWtCLEdBQUcsRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NkJBQ25HLFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO3FCQUNyRjtpQkFDRixDQUFDLENBQUM7YUFDSjtpQkFBTTtnQkFDTCxPQUFPLFVBQVUsQ0FBQyxrQ0FBZ0MsR0FBRyxVQUFPLENBQUMsQ0FBQzthQUMvRDtTQUNGO0tBQ0Y7Ozs7OztJQUNELCtCQUFTOzs7OztJQUFULFVBQWEsT0FBZ0I7UUFBN0IsaUJBbUNDOztRQWxDQyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7UUFDMUUsSUFBSSxHQUFHLENBQVM7O1FBQ2hCLElBQU0sTUFBTSxHQUFxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUMxRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDbEIsR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7U0FDdEI7YUFBTTtZQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO2dCQUN4QixPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzthQUMxQjtpQkFBTTtnQkFDTCxPQUFPLENBQUMsV0FBVyxHQUFHLE1BQUksT0FBTyxDQUFDLFdBQWEsQ0FBQzthQUNqRDtZQUNELEdBQUcsR0FBRyxLQUFHLFNBQVMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsU0FBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQWEsQ0FBQztZQUNqRyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7Z0JBQ2hDLElBQU0sYUFBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsYUFBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLE9BQU8sSUFBSSxVQUFVLENBQWtCLFVBQUEsVUFBVTtvQkFDL0MsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87d0JBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7NEJBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUNBQ2xILFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO3lCQUNyRixDQUFDLENBQUM7cUJBQ047eUJBQU07d0JBQ0wsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDbEgsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7cUJBQ3JGO2lCQUNGLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE9BQU8sVUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7S0FDRjs7Ozs7SUFDTyxpQ0FBVzs7OztjQUFDLEtBQXdCO1FBQzFDLElBQUksS0FBSyxZQUFZLFVBQVUsRUFBRTtZQUMvQixPQUFPLFVBQVUsQ0FBQyxvQ0FBa0MsS0FBTyxDQUFDLENBQUM7U0FDOUQ7YUFBTTtZQUNMLE9BQU8sVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFCOzs7Z0JBdFdKLFVBQVUsU0FBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7Ozs7Z0JBVlEsVUFBVTtnQkFFVix1QkFBdUI7Z0JBR3ZCLG1CQUFtQjtnQkFDbkIsY0FBYzs7O3NCQVB2Qjs7Ozs7OztBQ0FBO0lBdUJFLG9CQUFvQixXQUF3QixFQUFVLGdCQUF5QyxFQUNyRixnQkFDQSxPQUFvQyxNQUFjLEVBQVUsUUFBa0I7UUFGcEUsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQXlCO1FBQ3JGLG1CQUFjLEdBQWQsY0FBYztRQUNkLFVBQUssR0FBTCxLQUFLO1FBQStCLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBVSxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ3RGLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUMzQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7U0FDbkQsQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDRCw2QkFBUTs7O0lBQVI7S0FDQzs7OztJQUNELGdDQUFXOzs7SUFBWDtRQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7S0FDeEI7Ozs7Ozs7SUFDTyw0QkFBTzs7Ozs7O2NBQUksT0FBTyxFQUFFLE9BQU87O1FBQ2pDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUN2QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNyRDthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFDdkMsT0FBTyxDQUFDLENBQUM7U0FDWjs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBRSxPQUFPO1NBQ2QsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUM7Ozs7O0lBRS9DLGdEQUEyQjs7O0lBQTNCO1FBQUEsaUJBV0M7UUFWQyxPQUFPLElBQUksVUFBVSxDQUFPLFVBQUEsT0FBTztZQUNqQyxLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQ3JCLE1BQU0sQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUssWUFBWSxhQUFhLEdBQUEsQ0FBQyxDQUNoRCxDQUFDLFNBQVMsQ0FBQyxVQUFBLEtBQUs7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO29CQUNsQyxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMzQjthQUNGLENBQUMsQ0FBQztZQUNILE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUNoQixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFFRCxxQ0FBZ0I7Ozs7Ozs7SUFBaEIsVUFBb0IsUUFBZ0IsRUFBRSxRQUFnQixFQUFFLE9BQWdCO1FBQXhFLGlCQXFHQztRQXBHQyxPQUFPLElBQUksVUFBVSxDQUFrQixVQUFBLE9BQU87O1lBQzVDLElBQU0sbUJBQW1CLEdBQXdCLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEYsSUFBSSxtQkFBbUIsSUFBSSxtQkFBbUIsQ0FBQyxPQUFPO2dCQUNwRCxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFO2dCQUM3RixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7Z0JBQ3RDLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO2dCQUN2RixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDaEI7aUJBQU07O2dCQUNMLElBQU0sY0FBWSxHQUFHLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOztnQkFDckQsSUFBTSxXQUFXLEdBQUc7b0JBQ2xCLFFBQVEsRUFBRSxRQUFRO29CQUNsQixZQUFZLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7aUJBQ3pDLENBQUM7O2dCQUNGLElBQU0sT0FBTyxHQUFHO29CQUNkLE9BQU8sRUFBRTt3QkFDUCxRQUFRLEVBQUUsV0FBVzt3QkFDckIsYUFBYSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBWSxDQUFDO3FCQUM5QztpQkFDRixDQUFDO2dCQUNGLEtBQUksQ0FBQyxPQUFPLENBQUksT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7b0JBQ2xELElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTs7d0JBQy9ILElBQU0sU0FBUyxHQUFhLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzt3QkFDbEYsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7O3dCQUM3QixJQUFJLHFCQUFxQixHQUFHLElBQUksQ0FBQzs7d0JBQ2pDLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQzt3QkFDMUIsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7NEJBQzNDLGlCQUFpQixHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsY0FBWSxDQUFDLENBQUMsQ0FBQzt5QkFDbkY7NkJBQU07NEJBQ0wsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO3lCQUN4Qjt3QkFDRCxxQkFBcUIsR0FBRyxLQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQzFFLEtBQUksQ0FBQyxjQUFjLENBQUMsa0NBQWtDLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDMUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxzQ0FBc0MsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3dCQUNsRixLQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNuRCxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs0QkFDM0MsY0FBYyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLGNBQVksQ0FBQyxDQUFDO3lCQUMvRDs2QkFBTTs0QkFDTCxjQUFjLEdBQUcsRUFBRSxDQUFDO3lCQUNyQjs7d0JBQ0QsSUFBTSxvQkFBb0IsR0FBRyxLQUFJLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBQ3ZFLEtBQUksQ0FBQyxjQUFjLENBQUMsc0NBQXNDLG1CQUFDLG9CQUE0QixFQUFDLENBQUM7O3dCQUN6RixJQUFNLGlCQUFpQixHQUFhLGNBQWMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzlELElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRTs0QkFDckMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO3lCQUN2Qzt3QkFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsRUFBRTs0QkFDNUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUM7eUJBQzlDO3dCQUNELEtBQUssSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLEVBQUU7OzRCQUN2RCxJQUFNLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzFELEtBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDMUQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ2xGO3dCQUNELEtBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzlFLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO3dCQUNsQyxLQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQzs7d0JBQ3hDLElBQU0sZ0JBQWdCLEdBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUN2RCxjQUFjLEVBQUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjOzRCQUNsRCxrQkFBa0IsRUFBRSxLQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQjt5QkFDM0QsQ0FBQyxDQUFDLENBQUM7O3dCQUNKLElBQU0sV0FBVyxHQUF1Qjs0QkFDdEMsUUFBUSxFQUFFLFFBQVE7NEJBQ2xCLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPOzRCQUN6QyxjQUFjLEVBQUUsY0FBYzs0QkFDOUIsTUFBTSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLGNBQVksQ0FBQzs0QkFDcEQsZ0JBQWdCLEVBQUUsZ0JBQWdCO3lCQUNuQyxDQUFDO3dCQUNGLEtBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLEVBQUUsQ0FBQzt3QkFDN0MsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQ2hELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFZLENBQUMsQ0FBQyxDQUFDO3dCQVMzRSxLQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBb0IsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSTs0QkFDdEUsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO2dDQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQzs2QkFDM0c7eUJBQ0YsRUFBRSxVQUFVLEdBQUc7NEJBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDbEIsQ0FBQyxDQUFDO3dCQUNILEtBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxzQkFBc0IsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDOzRCQUN0RSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQzs0QkFDdkYsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDeEIsRUFBRTs0QkFDRCxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQzs0QkFDdkYsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDeEIsQ0FBQyxDQUFDO3FCQUNKO3lCQUFNO3dCQUNMLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ3hCO2lCQUNGLEVBQUUsVUFBQSxLQUFLO29CQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3RCLENBQUMsQ0FBQzthQUNKO1NBQ0YsQ0FBQyxDQUFDO0tBQ0o7Ozs7O0lBQ0QsNkJBQVE7Ozs7SUFBUixVQUFTLFFBQVE7UUFBakIsaUJBZUM7UUFkQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDckM7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLG1DQUFpQyxRQUFVO1NBQ3pELENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFPLFVBQUEsT0FBTztZQUNqQyxLQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBdUIsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsUUFBUTtnQkFDM0UsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDRCwrQkFBVTs7O0lBQVY7UUFBQSxpQkFpQ0M7UUFoQ0MsT0FBTyxJQUFJLFVBQVUsQ0FBTyxVQUFBLE9BQU87O1lBQ2pDLElBQU0sT0FBTyxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQzdELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7O2dCQUNsRSxJQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsS0FBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUM7b0JBQ2xDLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdEIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxpQ0FBaUMsRUFBRSxDQUFDO29CQUN4RCxJQUFJLEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRTt3QkFDdEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQzdCLEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztxQkFDN0I7b0JBQ0QsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2lCQUNoQixFQUFFLFVBQUMsS0FBSztvQkFDUCxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3RCLEtBQUksQ0FBQyxjQUFjLENBQUMsaUNBQWlDLEVBQUUsQ0FBQztvQkFDeEQsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUU7d0JBQ3RELEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUM3QixLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7cUJBQzdCO29CQUNELE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDakIsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixLQUFJLENBQUMsY0FBYyxDQUFDLGlDQUFpQyxFQUFFLENBQUM7Z0JBQ3hELElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFO29CQUN0RCxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDN0IsS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjtnQkFDRCxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2FBQ2xDO1NBQ0YsQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDRCxnQ0FBVzs7O0lBQVg7UUFDRSxPQUFPLE1BQU0sQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3BGOzs7OztJQUNDLGtDQUFhOzs7O0lBQWIsVUFBYyxLQUFVO1FBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO1FBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRTtZQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDbEM7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixFQUNsRjtZQUNFLElBQ0E7Z0JBQ0UsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRTtvQkFDeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztpQkFDN0I7YUFDRjtZQUNELE9BQU0sVUFBVSxFQUNoQjtnQkFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pCO1NBQ0Y7UUFDRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVM7WUFDcEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsa0JBQWtCO1lBQzNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixFQUFFOztZQUM5RCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3BDLElBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFDekI7Z0JBQ0UsUUFBUSxHQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDakM7O1lBQ0gsSUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDOztZQUMxRyxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7WUFDekQsSUFBSSxjQUFjLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzthQUM1RTtpQkFBTSxJQUFJLFFBQVEsRUFBRTs7Z0JBQ25CLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRTtxQkFDdkQsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLFNBQVMsRUFBRTtvQkFDYixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztpQkFDeEY7YUFDRjtTQUNGO0tBQ0Y7Ozs7OztJQUNELGlDQUFZOzs7OztJQUFaLFVBQWdCLE9BQWdCO1FBQWhDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLG1DQUFtQztZQUNoRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxxQ0FBZ0I7Ozs7Ozs7SUFBaEIsVUFBb0IsWUFBb0IsRUFBRSxPQUFZLEVBQUMsT0FBZTtRQUF0RSxpQkFzQkM7O1FBckJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7O1FBQ2hGLElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw2Q0FBMkMsWUFBYztZQUN0RSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQUEsRUFBRTtZQUNqQixPQUFPLEVBQUMsT0FBTztTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGtDQUFhOzs7Ozs7SUFBYixVQUFrQixPQUFZLEVBQUMsT0FBZTtRQUE5QyxpQkFzQkM7O1FBckJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7O1FBQ2hGLElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSx5QkFBeUI7WUFDdEMsSUFBSSxFQUFFLEVBQUMsT0FBTyxTQUFBLEVBQUM7WUFDZixPQUFPLEVBQUMsT0FBTztTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxtQ0FBYzs7Ozs7OztJQUFkLFVBQWtCLFlBQW9CLEVBQUUsSUFBUyxFQUFDLE9BQWU7UUFBakUsaUJBcUJDOztRQXBCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSwyQ0FBeUMsWUFBYztZQUNwRSxJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUNELDRDQUF1Qjs7Ozs7OztJQUF2QixVQUEyQixZQUFvQixFQUFFLElBQVMsRUFBQyxPQUFlO1FBQTFFLGlCQXFCQzs7UUFwQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsb0RBQWtELFlBQWM7WUFDN0UsSUFBSSxFQUFFLElBQUk7WUFDVixPQUFPLEVBQUMsT0FBTztTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7SUFDRCxzQ0FBaUI7Ozs7SUFBakIsVUFBa0IsT0FBZTtRQUFqQyxpQkE2QkM7O1FBNUJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHVCQUF1QjtZQUNwQyxZQUFZLEVBQUUsYUFBYTtZQUMzQixPQUFPLEVBQUMsT0FBTztTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBNEIsVUFBQSxPQUFPO1lBQ3RELEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFjLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7O2dCQUMzRCxJQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDakMsSUFBSSxFQUFFLDRGQUE0RjtpQkFDbkcsQ0FBQyxDQUFDOztnQkFDSCxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN0QyxDQUFDLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ25DLENBQUMsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUM3QixDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ1IsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNqQixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7SUFDRCx5Q0FBb0I7Ozs7SUFBcEIsVUFBcUIsT0FBZTtRQUFwQyxpQkFnQ0M7O1FBL0JDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHVCQUF1QjtZQUNwQyxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBTyxVQUFBLE9BQU87WUFDakMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTs7Z0JBQzlDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7O2dCQUN0QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDOztnQkFDOUQsSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs7Z0JBQ2hDLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7O2dCQUN6QixJQUFJLEtBQUssR0FBRyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDNUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2xDOztnQkFDRCxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDbEMsSUFBSSxFQUFFLG9FQUFvRTtpQkFDM0UsQ0FBQyxDQUFDO2dCQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsR0FBRyxPQUFPLENBQUMsQ0FBQTtnQkFDN0MsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNqQixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELCtCQUFVOzs7Ozs7SUFBVixVQUFjLFFBQWdCLEVBQUMsT0FBZTtRQUE5QyxpQkF5QkM7O1FBeEJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsVUFBVSxDQUFDLHlCQUF5QixDQUFDLENBQUM7U0FDdkM7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLFFBQVE7WUFDeEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUNELCtCQUFVOzs7Ozs7O0lBQVYsVUFBYyxRQUFnQixFQUFFLFFBQVEsRUFBQyxPQUFlO1FBQXhELGlCQXdCQzs7UUF2QkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDYixVQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQztTQUN2Qzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsUUFBUTtZQUN4RCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO1NBQzlCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsNkJBQVE7Ozs7OztJQUFSLFVBQVksUUFBUSxFQUFDLE9BQWU7UUFBcEMsaUJBdUJDOztRQXRCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQ3ZDOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw2QkFBNkIsR0FBRyxRQUFRO1lBQ3JELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsZ0RBQTJCOzs7Ozs7SUFBM0IsVUFBK0IsTUFBTSxFQUFDLE9BQWU7UUFBckQsaUJBdUJDOztRQXRCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQ3JDOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxNQUFNO1lBQ3RELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsOEJBQVM7Ozs7OztJQUFULFVBQWEsTUFBTSxFQUFDLE9BQWU7UUFBbkMsaUJBdUJDOztRQXRCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQ3JDOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw2QkFBNkIsR0FBRyxNQUFNO1lBQ25ELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsdUNBQWtCOzs7Ozs7SUFBbEIsVUFBc0IsUUFBZ0IsRUFBQyxPQUFlO1FBQXRELGlCQXVCQztRQXRCQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsVUFBVSxDQUFDLHlCQUF5QixDQUFDLENBQUM7U0FDdkM7O1FBQ0QsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsK0JBQStCLEdBQUcsUUFBUTtZQUN2RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCwrQkFBVTs7Ozs7OztJQUFWLFVBQWMsS0FBYSxFQUFFLElBQVksRUFBQyxPQUFlO1FBQXpELGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsS0FBSyxHQUFHLFFBQVEsR0FBRyxJQUFJO1lBQ25FLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7SUFDRCxzQ0FBaUI7Ozs7O0lBQWpCLFVBQXFCLE9BQWU7UUFBcEMsaUJBb0JDOztRQW5CQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSxtQ0FBbUM7WUFDaEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCwrQkFBVTs7Ozs7O0lBQVYsVUFBYyxRQUFRLEVBQUMsT0FBZTtRQUF0QyxpQkEwQkM7O1FBekJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUMvQixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDN0csUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDNUQsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBQzdHLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDOztRQUM1RCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLHNCQUFzQjtZQUNuQyxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO1lBQzdCLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsbUNBQWM7OztJQUFkO1FBQ0UsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBQzlDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztRQUMxQyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztRQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQztRQUNoRCxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDMUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFDakQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFDN0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFDL0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO0tBQ3ZDOzs7OztJQUNELDhCQUFTOzs7O0lBQVQsVUFBVSxHQUFHOztRQUNYLElBQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7O1FBQ2xDLElBQU0sT0FBTyxHQUFhLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O1FBQy9DLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBQSxNQUFNO1lBQ3BCLElBQUksTUFBTSxFQUFFOztnQkFDVixJQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4QyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQzFDO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDakI7Ozs7OztJQUNELDBDQUFxQjs7Ozs7SUFBckIsVUFBc0IsTUFBTSxFQUFFLGNBQWM7UUFDMUMsS0FBSyxJQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUU7WUFDeEIsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQkFDOUIsSUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMxQixJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7O29CQUNoQixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7b0JBQ2xCLEtBQUssSUFBTSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTt3QkFDN0IsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTs7NEJBQ3BDLElBQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7NEJBQ2pDLFFBQVEsRUFBRTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDdEIsTUFBTTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDdkIsTUFBTTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDeEIsTUFBTTs2QkFDVDt5QkFDRjtxQkFDRjtvQkFDRCxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUNuRDthQUNGO1NBQ0Y7UUFDRCxPQUFPLGNBQWMsQ0FBQztLQUN2Qjs7Ozs7O0lBRUQsK0JBQVU7Ozs7SUFBVixVQUFXLFNBQWlCOztRQUMxQixJQUFNLElBQUksR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNkLE9BQU8sSUFBSSxDQUFDO1NBQ2I7O1FBQ0QsSUFBTSxNQUFNLEdBQWEsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs7WUFDdEMsSUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDOztZQUN4QixJQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztZQUNwQyxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUM7O1lBQ2xCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztZQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O2dCQUM5QyxJQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hDLElBQUksUUFBUSxLQUFLLEVBQUUsRUFBRTtvQkFDbkIsUUFBUSxHQUFHLFNBQVMsQ0FBQztpQkFDdEI7cUJBQU07b0JBQ0wsUUFBUSxHQUFNLFFBQVEsU0FBSSxTQUFXLENBQUM7aUJBQ3ZDO2dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUNyQjtnQkFDRCxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3ZCO1lBQ0QsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFO2dCQUNuQixRQUFRLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVEO2lCQUFNO2dCQUNMLFFBQVEsR0FBTSxRQUFRLFNBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBRyxDQUFDO2FBQzdFO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7O2dCQUNsQyxJQUFNLFlBQVksR0FBRyxFQUFFLENBQUM7O2dCQUN4QixJQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUM5RSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDM0MsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFFckM7Z0JBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxDQUFDO2FBQzNDO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7OztJQUNPLHlDQUFvQjs7OztjQUFDLEtBQUs7O1FBQ2hDLElBQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSyxFQUFFLEVBQUU7WUFDMUIsT0FBTyxVQUFVLENBQUM7U0FDbkI7O1FBQ0QsSUFBTSxvQkFBb0IsR0FBYSxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3hELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O1lBQ3BELElBQU0sZ0JBQWdCLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7O1lBQ2pELElBQU0sSUFBSSxHQUFHLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7WUFDNUMsSUFBTSxXQUFXLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzs7WUFDOUQsSUFBTSxVQUFVLEdBQUcsRUFBRSxDQUFDO1lBQ3RCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMzQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQzthQUN4RjtZQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxVQUFVLENBQUM7U0FDL0I7UUFDRCxPQUFPLFVBQVUsQ0FBQzs7Ozs7SUFFcEIsK0NBQTBCOzs7SUFBMUI7O1FBQ0UsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQzs7UUFDcEQsSUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEQsSUFBSSxRQUFRLENBQUMsUUFBUSxFQUFFOztZQUNyQixJQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQztTQUNuRDtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHNCQUFzQixFQUFFO1lBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMsc0JBQXNCLEdBQUcsRUFBRSxDQUFDO1NBQ3hDO1FBQ0QsS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLFFBQVEsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQzNGLElBQUksQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDckk7S0FDRjs7OztJQUNELHFEQUFnQzs7O0lBQWhDOztRQUNFLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUM7O1FBQ3ZELElBQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFHLElBQUksb0JBQW9CLEVBQUU7O1lBQ3hCLElBQU0sTUFBTSxHQUFHLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDekU7S0FDRjs7Ozs7OztJQUNELGtDQUFhOzs7Ozs7SUFBYixVQUFpQixTQUFTLEVBQUMsT0FBZTtRQUExQyxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSw2Q0FBNkMsR0FBRyxTQUFTO1lBQ3RFLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0Qsc0NBQWlCOzs7Ozs7SUFBakIsVUFBcUIsU0FBUyxFQUFDLE9BQWU7UUFBOUMsaUJBb0JDOztRQW5CQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsd0NBQXdDLEdBQUcsU0FBUztZQUNqRSxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7O0lBQ0Qsc0NBQWlCOzs7OztJQUFqQixVQUFxQixPQUFlO1FBQXBDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLCtCQUErQjtZQUM1QyxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7O0lBQ0Qsb0NBQWU7Ozs7O0lBQWYsVUFBbUIsT0FBZTtRQUFsQyxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSwwQkFBMEI7WUFDdkMsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELHNDQUFpQjs7Ozs7SUFBakIsVUFBcUIsT0FBZTtRQUFwQyxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSw0QkFBNEI7WUFDekMsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELG1EQUE4Qjs7Ozs7SUFBOUIsVUFBa0MsT0FBZTtRQUFqRCxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSxzQ0FBc0M7WUFDbkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELGlEQUE0Qjs7Ozs7SUFBNUIsVUFBZ0MsT0FBZTtRQUEvQyxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSxvQ0FBb0M7WUFDakQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELHVEQUFrQzs7Ozs7SUFBbEMsVUFBc0MsT0FBZTtRQUFyRCxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSwwQ0FBMEM7WUFDdkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCwrQkFBVTs7Ozs7O0lBQVYsVUFBYyxNQUFNLEVBQUMsT0FBZTtRQUFwQyxpQkFzQkM7UUFyQkMsSUFBSSxDQUFDLE1BQU07WUFDVCxNQUFNLHNCQUFzQixDQUFDOztRQUM3QixJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsTUFBTTtZQUNwRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDcEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCwrQkFBVTs7Ozs7OztJQUFWLFVBQWMsTUFBTSxFQUFFLFFBQVEsRUFBQyxPQUFlO1FBQTlDLGlCQTBCQztRQXpCQyxJQUFJLENBQUMsTUFBTTtZQUNULE1BQU0sc0JBQXNCLENBQUM7O1FBQzdCLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUMvQixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDN0csUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7O1FBQzlELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsTUFBTTtZQUNwRCxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO1lBQzdCLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsNkJBQVE7Ozs7OztJQUFSLFVBQVksTUFBTSxFQUFDLE9BQWU7UUFBbEMsaUJBc0JDO1FBckJDLElBQUksQ0FBQyxNQUFNO1lBQ1QsTUFBTSxzQkFBc0IsQ0FBQzs7UUFDL0IsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLDRCQUE0QixHQUFHLE1BQU07WUFDbEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0QsK0JBQVU7Ozs7Ozs7SUFBVixVQUFjLElBQUksRUFBRSxJQUFJLEVBQUMsT0FBZTtRQUF4QyxpQkFvQkM7O1FBbkJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSw0QkFBNEIsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7WUFDbEUsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFFRCx1Q0FBa0I7Ozs7OztJQUFsQixVQUFzQixRQUFRLEVBQUMsT0FBZTtRQUE5QyxpQkFzQkM7UUFyQkMsSUFBSSxDQUFDLFFBQVE7WUFDWCxNQUFNLHVCQUF1QixDQUFDOztRQUM5QixJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsK0JBQStCLEdBQUcsUUFBUTtZQUN2RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELG9DQUFlOzs7Ozs7SUFBZixVQUFtQixTQUFTLEVBQUMsT0FBZTtRQUE1QyxpQkEwQkM7O1FBekJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUMvQixTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQztRQUMxRyxTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO1FBQ3pELFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBQzFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7O1FBQ3pELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSx1QkFBdUI7WUFDcEMsT0FBTyxFQUFFLE9BQU87WUFDaEIsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtTQUMvQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUVELGtDQUFhOzs7Ozs7SUFBYixVQUFpQixPQUFPLEVBQUMsT0FBZTtRQUF4QyxpQkFzQkM7UUFyQkMsSUFBSSxDQUFDLE9BQU87WUFDVixNQUFNLHlCQUF5QixDQUFDOztRQUNoQyxJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxPQUFPO1NBQ3RELENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUNELHNDQUFpQjs7Ozs7OztJQUFqQixVQUFxQixJQUFJLEVBQUUsSUFBSSxFQUFDLE9BQWU7UUFBL0MsaUJBb0JDOztRQW5CQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSwrQkFBK0IsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7WUFDckUsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0QsaUNBQVk7Ozs7Ozs7SUFBWixVQUFnQixJQUFJLEVBQUUsSUFBSSxFQUFDLE9BQWU7UUFBMUMsaUJBb0JDOztRQW5CQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7WUFDcEUsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxvQ0FBZTs7Ozs7O0lBQWYsVUFBbUIsT0FBTyxFQUFDLE9BQWU7UUFBMUMsaUJBc0JDO1FBckJDLElBQUksQ0FBQyxPQUFPO1lBQ1YsTUFBTSx5QkFBeUIsQ0FBQzs7UUFDaEMsSUFBSSxPQUFPLENBQWM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsT0FBTztZQUN2RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDcEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxvQ0FBZTs7Ozs7OztJQUFmLFVBQW1CLE9BQU8sRUFBRSxTQUFTLEVBQUMsT0FBZTtRQUFyRCxpQkEwQkM7UUF6QkMsSUFBSSxDQUFDLE9BQU87WUFDVixNQUFNLHlCQUF5QixDQUFDOztRQUNoQyxJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELElBQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDL0IsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDMUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQzs7UUFDekQsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLE9BQU87WUFDdkQsT0FBTyxFQUFFLE9BQU87WUFDaEIsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtTQUMvQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELDZCQUFROzs7Ozs7SUFBUixVQUFZLFFBQVEsRUFBQyxPQUFlO1FBQXBDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsUUFBUTtZQUN0RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELCtCQUFVOzs7Ozs7SUFBVixVQUFjLFFBQVEsRUFBQyxPQUFlO1FBQXRDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsUUFBUTtZQUN4RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELDhCQUFTOzs7Ozs7SUFBVCxVQUFhLFNBQVMsRUFBQyxPQUFlO1FBQXRDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsU0FBUztZQUN6RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGdDQUFXOzs7Ozs7SUFBWCxVQUFlLFNBQVMsRUFBQyxPQUFlO1FBQXhDLGlCQW9CQzs7UUFuQkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsa0NBQWtDLEdBQUcsU0FBUztZQUMzRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGtDQUFhOzs7Ozs7SUFBYixVQUFpQixVQUFVLEVBQUMsT0FBZTtRQUEzQyxpQkFxQkM7O1FBcEJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUMsVUFBVTtTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7O0lBQ0QsbUNBQWM7Ozs7Ozs7O0lBQWQsVUFBa0IsUUFBUSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUMsT0FBZTtRQUFwRSxpQkEyQkM7O1FBMUJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLG9DQUFvQyxHQUFHLFFBQVE7WUFDNUQsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRTtvQkFDVixVQUFVLEVBQUUsUUFBUTtvQkFDcEIsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7b0JBQ2hELGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO2lCQUNqRDthQUNGO1lBQ0QsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxtQ0FBYzs7Ozs7O0lBQWQsVUFBa0IsUUFBUSxFQUFDLE9BQWU7UUFBMUMsaUJBcUJDOztRQXBCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsT0FBTyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDOztRQUM1QyxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsMkJBQTJCO1lBQ3hDLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7Ozs7O0lBQ0Qsb0NBQWU7Ozs7Ozs7OztJQUFmLFVBQW1CLFFBQVEsRUFBQyxTQUFnQixFQUFDLGlCQUF3QixFQUFDLGNBQXFCLEVBQUMsT0FBZTtRQUEzRyxpQkEwQkM7O1FBekJDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBSSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUM3QixPQUFPLEdBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDOztRQUMvSCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGFBQWE7WUFDaEMsV0FBVyxFQUFFLDJCQUEyQjtZQUN4QyxJQUFJLEVBQUU7Z0JBQ0YsbUJBQW1CLEVBQUUsRUFBQyxpQkFBaUIsbUJBQUEsRUFBQztnQkFDeEMsZ0JBQWdCLEVBQUUsRUFBQyxjQUFjLGdCQUFBLEVBQUM7YUFDckM7WUFDRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7Ozs7SUFDRCxpQ0FBWTs7Ozs7Ozs7OztJQUFaLFVBQWdCLFFBQVEsRUFBQyxTQUFnQixFQUFDLFVBQWlCLEVBQUMsYUFBb0IsRUFBQyxXQUFrQixFQUFDLE9BQWU7UUFBbkgsaUJBcUJDOztRQXBCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsT0FBTyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUMsV0FBVyxDQUFDLENBQUM7O1FBQ2xMLElBQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsYUFBYTtZQUNoQyxXQUFXLEVBQUUsd0JBQXdCO1lBQ3JDLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7Ozs7O0lBQ0Qsa0NBQWE7Ozs7Ozs7OztJQUFiLFVBQWlCLFFBQWdCLEVBQUUsR0FBVyxFQUFFLFdBQW1CLEVBQUMsZUFBdUIsRUFBRSxPQUFlO1FBQTVHLGlCQThCQzs7UUE3QkMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQzs7UUFDNUMsSUFBSSxRQUFRLEdBQVMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQzs7UUFDbkQsSUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFO29CQUNWLFVBQVUsRUFBRSxRQUFRO29CQUNwQixhQUFhLEVBQUUsUUFBUTtvQkFDdkIsaUJBQWlCLEVBQUUsUUFBUTtvQkFDM0IsS0FBSyxFQUFDLEdBQUc7aUJBQ1Y7YUFDRjtZQUNELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLFVBQUEsT0FBTztZQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLFVBQUEsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7Ozs7O0lBQ0QscUNBQWdCOzs7Ozs7Ozs7SUFBaEIsVUFBb0IsUUFBZ0IsRUFBRSxHQUFXLEVBQUUsV0FBbUIsRUFBQyxlQUF1QixFQUFFLE9BQWU7UUFBL0csaUJBOEJDOztRQTdCQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsT0FBTyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDOztRQUM1QyxJQUFJLFFBQVEsR0FBUyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDOztRQUNuRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsNEJBQTRCO1lBQ3pDLElBQUksRUFBRTtnQkFDSixVQUFVLEVBQUU7b0JBQ1YsVUFBVSxFQUFFLFFBQVE7b0JBQ3BCLGFBQWEsRUFBRSxRQUFRO29CQUN2QixpQkFBaUIsRUFBRSxRQUFRO29CQUMzQixLQUFLLEVBQUMsR0FBRztpQkFDVjthQUNGO1lBQ0QsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksVUFBQSxPQUFPO1lBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsVUFBQSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0Qsb0NBQWU7Ozs7Ozs7SUFBZixVQUFtQixRQUFRLEVBQUUsT0FBTyxFQUFDLE9BQWU7UUFBcEQsaUJBeUJDO1FBeEJDLElBQUksQ0FBQyxRQUFRO1lBQ1gsTUFBTSx1QkFBdUIsQ0FBQzs7UUFDOUIsSUFBSSxPQUFPLENBQWM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxJQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUscUNBQXFDLEdBQUcsUUFBUTtZQUM3RCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUU7Z0JBQ0osU0FBUyxFQUFFLE9BQU87YUFDbkI7U0FDRixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxVQUFBLE9BQU87WUFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxVQUFBLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Z0JBbDlDRixVQUFVLFNBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25COzs7O2dCQWxCUSxXQUFXO2dCQUdYLHVCQUF1QjtnQkFFdkIsY0FBYztnQkFJZCxtQkFBbUI7Z0JBQ25CLE1BQU07Z0JBQ04sUUFBUTs7O3FCQVpqQjs7Ozs7OztBQ0FBO0lBU0ksaUNBQW9CLGNBQThCLEVBQVUsZ0JBQXlDLEVBQ3pGO1FBRFEsbUJBQWMsR0FBZCxjQUFjLENBQWdCO1FBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtRQUN6RixVQUFLLEdBQUwsS0FBSztLQUEwQjs7Ozs7O0lBQzNDLDJDQUFTOzs7OztJQUFULFVBQVUsR0FBcUIsRUFBRSxJQUFpQjtRQUFsRCxpQkEyRUM7UUExRUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFO1lBQzdCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixrQkFBa0IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQjtpQkFDbEQ7YUFDSixDQUFDLENBQUM7U0FDTjtRQUNELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7WUFDdkIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVU7aUJBQ3RDO2FBQ0osQ0FBQyxDQUFDO1NBQ047UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ3RCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTO2lCQUNuQzthQUNKLENBQUMsQ0FBQztTQUNOO1FBQ0QsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNqQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQztnQkFDWixVQUFVLEVBQUU7b0JBQ1IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQztpQkFDN0M7YUFDSixDQUFDLENBQUM7U0FDTjthQUNJLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbkMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7aUJBQzFDO2FBQ0osQ0FBQyxDQUFDO1NBQ047YUFBTyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixTQUFTLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2lCQUN6QzthQUNKLENBQUMsQ0FBQztTQUNOO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3hHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRO1lBQ2pFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBRTs7WUFDOUYsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDOztZQUN6RCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDOztZQUNuRixJQUFJLE9BQU8sVUFBUztZQUNwQixPQUFPLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDVixPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxDQUFDO2FBQzlEO1lBQ0QsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFNBQVMsRUFBSyxRQUFRLFNBQUksU0FBVztvQkFDckMsT0FBTyxFQUFFLE9BQU87aUJBQ25CO2FBQ0osQ0FBQyxDQUFDO1NBQ047UUFDRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFBLFFBQVE7WUFDckMsSUFBSSxRQUFRLFlBQVksWUFBWSxFQUFFOztnQkFDbEMsSUFBTSxJQUFJLHFCQUFHLFFBQTZCLEVBQUM7Z0JBQzNDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQy9CLEtBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztvQkFDcEUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2lCQUNoRDtnQkFDRCxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQzVDLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtvQkFDL0MsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssR0FBRyxLQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsY0FBYyxDQUFDOzRCQUNqRyxHQUFHLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxjQUFjLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRTt3QkFDbEUsS0FBSSxDQUFDLGNBQWMsQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO3FCQUNsRTtpQkFDSjthQUNKO1NBQ0osQ0FBQyxDQUFDLENBQUM7S0FDUDs7Z0JBL0VKLFVBQVU7Ozs7Z0JBTEYsY0FBYztnQkFHZCx1QkFBdUI7Z0JBQ3ZCLG1CQUFtQjs7a0NBTjVCOzs7Ozs7O0FDQUE7SUFhRTtLQUFpQjs7OztJQUVqQiwrQkFBUTs7O0lBQVI7S0FDQzs7Z0JBZEYsU0FBUyxTQUFDO29CQUNULFFBQVEsRUFBRSxTQUFTO29CQUNuQixRQUFRLEVBQUUsMkNBSVQ7b0JBQ0QsTUFBTSxFQUFFLEVBQUU7aUJBQ1g7Ozs7dUJBVkQ7Ozs7Ozs7Ozs7OztBQ0dBLHVCQUE4Qix1QkFBZ0QsRUFDMUUsS0FBMEI7SUFDMUIsT0FBTyxjQUFNLE9BQUEsSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtRQUM3Qyx1QkFBdUIsQ0FBQyxpQkFBaUIsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLElBQUksQ0FBQzs7WUFDakYsSUFBTSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7O1lBQzVDLElBQU0seUJBQXlCLEdBQUcsS0FBSyxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDOztnQkFDOUQsSUFBTSxvQkFBb0IsR0FBRyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsQ0FBQzs7Z0JBQ2xFLElBQU0sc0JBQXNCLEdBQUcsS0FBSyxDQUFDLDhCQUE4QixFQUFFLENBQUM7O2dCQUN0RSxJQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOztnQkFDcEQsSUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDOztnQkFDaEQsSUFBTSxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs7Z0JBQ3BELElBQU0sa0NBQWtDLEdBQUcsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLENBQUM7Z0JBQ3RGLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxvQkFBb0IsRUFBRSxzQkFBc0IsRUFBRSxpQkFBaUI7b0JBQzFFLGVBQWUsRUFBRSxpQkFBaUIsRUFBRSxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUM3RSxLQUFLLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztvQkFDNUIsT0FBTyxFQUFFLENBQUM7aUJBQ1osRUFBRSxVQUFDLEtBQUs7b0JBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbkIsTUFBTSxFQUFFLENBQUM7aUJBQ2QsQ0FBQyxDQUFDO2FBQ0osRUFBRSxVQUFDLEtBQUs7Z0JBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkIsTUFBTSxFQUFFLENBQUM7YUFDVixDQUFDLENBQUM7U0FDSixFQUFFLFVBQUMsS0FBSztZQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkIsTUFBTSxFQUFFLENBQUM7U0FDVixDQUFDLENBQUM7S0FDSixDQUFDLEdBQUEsQ0FBQztDQUNKOzs7Ozs7QUNqQ0gsU0FtQmdCLGFBQWE7Ozs7Ozs7SUFVYixpQkFBTzs7OztRQUNuQixPQUFPO1lBQ0wsUUFBUSxFQUFFLFNBQVM7WUFDbkIsU0FBUyxFQUFFLEVBQUU7U0FDZCxDQUFDOzs7Z0JBckJMLFFBQVEsU0FBQztvQkFDUixPQUFPLEVBQUUsRUFDUjtvQkFDRCxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQzVCLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQztvQkFDdkIsU0FBUyxFQUFFLENBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRyxjQUFjLEVBQUUsdUJBQXVCLEVBQUUsbUJBQW1CLEVBQUU7NEJBQ3JHLE9BQU8sRUFBRSxlQUFlOzRCQUN4QixVQUFVLElBQWU7NEJBQ3pCLElBQUksRUFBRSxDQUFDLHVCQUF1QixFQUFFLG1CQUFtQixDQUFDOzRCQUNwRCxLQUFLLEVBQUUsSUFBSTt5QkFDWixFQUFFOzRCQUNELE9BQU8sRUFBRSxpQkFBaUI7NEJBQzFCLFFBQVEsRUFBRSx1QkFBdUI7NEJBQ2pDLEtBQUssRUFBRSxJQUFJO3lCQUNaLENBQUM7aUJBQ0g7O29CQTNCRDs7Ozs7Ozs7Ozs7Ozs7OyJ9