export declare class RsaUtils {
    private static publicKey;
    private static privateKey;
    constructor();
    static privateKeyFromPEM(pem_file_content: string): void;
    static publicKeyToPEM(): string;
    static publicKeyFromPEM(pem_file_content: string): void;
    static encrypt(message: string, pemPublicKey?: string): string;
    static decrypt(cipherText: string, pemPrivateKey?: string): string;
    privateKeyToPEM(): string;
}
