import { Router } from '@angular/router';
export declare class NavigateService {
    private router;
    constructor(router: Router);
    navigate(path: string[]): void;
}
