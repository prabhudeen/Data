export declare class CONSTANTS {
    static readonly PROTOCOL: string;
    static readonly WEBSOCKET_PROTOCOL: string;
    static readonly IDENTITY_CONTEXT: string;
    static readonly ACCESS_CONTEXT: string;
    static readonly TRACE_CONTEXT: string;
    getProtocol(): string;
}
