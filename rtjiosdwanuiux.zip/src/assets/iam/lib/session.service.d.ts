import { CookieService } from 'ngx-cookie-service';
import { AppConfigurationService as AppSetting } from './app-configuration.service';
import { NavigateService } from './navigate.service';
export declare class SessionService {
    private cookieService;
    private appSetting;
    private navigateService;
    private hashKey;
    globals: any;
    selectedCircleName: string;
    selectedNeName: string;
    selectedNeShortName: string;
    parsedNodeCircleJson: any;
    nodeNameCircle: any;
    structuredRestriction: any;
    moduleRestriction: any;
    mapNeNameCircleName: any;
    nodeNameList: any;
    constructor(cookieService: CookieService, appSetting: AppSetting, navigateService: NavigateService);
    getSessionData(key?: string): ResponseSessionData;
    getAesKey(key?: string): string;
    setSessionData(sessionData: RequestSessionData, key?: string): void;
    clearSessionData(...args: string[]): void;
    putDateForCookieExpiry(timeStamp?: string): void;
    getDateForCookieExpiry(): number;
    setUserTokenData(userToken: string): void;
    getUserTokenData(): string;
    setSessionDataForModuleRestriction(moduleRestriction: JSON, key?: string): void;
    getSessionDataForModuleRestriction(key?: string): JSON;
    setSessionDataForStructuredRestriction(structuredRestriction: JSON, key?: string): void;
    getSessionDataForStructuredRestriction(key?: string): JSON;
    setSessionDataForNodeCircleRestriction(nodeCircleRestriction: JSON, key?: string): void;
    getSessionDataForNodeCircleRestriction(key?: string): JSON;
    clearSessionDataAndGotoSessionExpirePage(): void;
    clearSessionDataAndGotoLogoutPage(): void;
    private resetVariables();
}
export interface RequestSessionData {
    userName: string;
    appData: JSON;
    nodeNameCircle: string;
    aesKey?: string;
    neNameCircleName?: JSON;
}
export interface ResponseSessionData {
    globals?: {
        currentUser: {
            userName?: string;
            appData?: JSON;
            nodeNameCircle?: string;
            neNameCircleName?: JSON;
        };
    };
    aesKey?: string;
}
