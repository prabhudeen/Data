import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { SessionService } from './session.service';
import { Observable } from 'rxjs';
import { AppConfigurationService } from './app-configuration.service';
import { CacheManagerService } from './cache-manager.service';
export declare class HttpResponseInterceptor implements HttpInterceptor {
    private sessionService;
    private appConfiguration;
    private cache;
    constructor(sessionService: SessionService, appConfiguration: AppConfigurationService, cache: CacheManagerService);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
}
