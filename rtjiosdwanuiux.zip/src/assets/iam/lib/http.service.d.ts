import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { AppConfigurationService } from './app-configuration.service';
import { Observable } from 'rxjs';
import { CacheManagerService } from './cache-manager.service';
import { SessionService } from './session.service';
export declare class HttpService {
    private httpClient;
    private appConfiguration;
    private cache;
    private sessionService;
    constructor(httpClient: HttpClient, appConfiguration: AppConfigurationService, cache: CacheManagerService, sessionService: SessionService);
    private parseQueryString(queryString, key);
    parseUrl(url: string): Map<string, string>;
    private checkAuthorization(url);
    getData<T>(request: Request): Observable<HttpResponse<T>>;
    postData<T>(request: Request): Observable<HttpResponse<T>>;
    putData<T>(request: Request): Observable<HttpResponse<T>>;
    deleteData<T>(request: Request): Observable<HttpResponse<T>>;
    headData<T>(request: Request): Observable<HttpResponse<T>>;
    patchData<T>(request: Request): Observable<HttpResponse<T>>;
    private handleError(error);
}
export interface Request {
    context: string;
    data?: any;
    headers?: HttpHeaders;
    queryString?: string;
    responseType?: string;
    reqUrl?: string;
    callbackfunction?(...args: any[]): any;
}
export interface Response {
    body?: any;
    headers?: any;
    status?: any;
    queryString?: any;
}
