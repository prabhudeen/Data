import { HttpClient } from '@angular/common/http';
export declare class AppConfigurationService {
    private httpClient;
    private appConfiguration;
    constructor(httpClient: HttpClient);
    loadConfiguration(filePath: string): Promise<void>;
    getConfiguration(): AppConfiguration;
}
export interface AppConfiguration {
    ip: string;
    port: number;
    websocketPort: number;
    project: string;
    nonRestrictedPages: Array<string>;
    defaultPageAfterLogin: string;
    loginPage: string;
    sessionExpiredPage: string;
    logoutPath: string;
    clientSideRequestBarring: boolean;
    sessionTimeOut: number;
}
