import { OnInit } from '@angular/core';
export declare class IamComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
