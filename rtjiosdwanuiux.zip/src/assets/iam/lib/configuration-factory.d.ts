import { CacheManagerService } from './cache-manager.service';
import { AppConfigurationService } from './app-configuration.service';
export declare function initializeApp(appConfigurationService: AppConfigurationService, cache: CacheManagerService): () => Promise<void>;
