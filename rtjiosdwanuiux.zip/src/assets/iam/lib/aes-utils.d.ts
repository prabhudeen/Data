import { OnInit } from '@angular/core';
export declare class AesUtils implements OnInit {
    private static aesKey;
    constructor();
    static setAesEncryptionKey(aesKey: string): void;
    static encrypt(message: string, aesKey?: string): string;
    static decrypt(cipher: string, aesKey?: string): string;
    static generateRandomAesKey(length?: number): string;
    ngOnInit(): void;
}
