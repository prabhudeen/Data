import { WebSocketCallbacks } from './iam.service';
import { Observable } from 'rxjs';
export declare class WebSocketCallbackClass implements WebSocketCallbacks {
    private static onMessageSubject;
    private static onOpenSubject;
    private static onCloseSubject;
    private static onErrorSubject;
    private static onWebsocketReconnectSubject;
    static getOnMessageObservable(): Observable<MessageEvent>;
    static getOnOpenObservable(): Observable<MessageEvent>;
    static getOnCloseObservable(): Observable<MessageEvent>;
    static getOnErrorObservable(): Observable<MessageEvent>;
    static getOnWebsocketReconnectObservable(): Observable<void>;
    static reInitializeObservables(): void;
    onMessage(event: MessageEvent): void;
    onClose(event: MessageEvent): void;
    onError(event: MessageEvent): void;
    onOpen(event: MessageEvent, websocket: WebSocket): void;
    onReconnect(): void;
}
