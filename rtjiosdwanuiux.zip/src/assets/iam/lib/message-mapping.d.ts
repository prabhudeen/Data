import { HttpClient } from "@angular/common/http";
export declare class MessageMapping {
    private httpClient;
    constructor(httpClient: HttpClient);
    private static messageMap;
    static getMessage(code: number): any;
    loadMesageMap(filePath: string): void;
}
