(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('aes-js'), require('@angular/router'), require('ngx-cookie-service'), require('fingerprintjs2sync'), require('ngx-cookie-service/cookie-service/cookie.service'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('node-forge')) :
    typeof define === 'function' && define.amd ? define('iam', ['exports', '@angular/core', '@angular/common/http', 'aes-js', '@angular/router', 'ngx-cookie-service', 'fingerprintjs2sync', 'ngx-cookie-service/cookie-service/cookie.service', 'rxjs', 'rxjs/operators', '@angular/common', 'node-forge'], factory) :
    (factory((global.iam = {}),global.ng.core,global.ng.common.http,null,global.ng.router,null,null,null,global.rxjs,global.rxjs.operators,global.ng.common,null));
}(this, (function (exports,i0,i1,aesjs,i1$1,ngxCookieService,Fingerprint2,i1$2,rxjs,operators,i4,forge) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m)
            return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length)
                    o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CONSTANTS = (function () {
        function CONSTANTS() {
        }
        /**
         * @return {?}
         */
        CONSTANTS.prototype.getProtocol = /**
         * @return {?}
         */
            function () {
                return location.protocol;
            };
        CONSTANTS.PROTOCOL = location.protocol + "//";
        CONSTANTS.WEBSOCKET_PROTOCOL = location.protocol.localeCompare('https:') === 0 ? 'wss://' : 'ws://';
        CONSTANTS.IDENTITY_CONTEXT = '/IAM/identity/';
        CONSTANTS.ACCESS_CONTEXT = '/IAM/access/';
        CONSTANTS.TRACE_CONTEXT = '/IAM/trace/';
        return CONSTANTS;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var AppConfigurationService = (function () {
        function AppConfigurationService(httpClient) {
            this.httpClient = httpClient;
        }
        /**
         * @param {?} filePath
         * @return {?}
         */
        AppConfigurationService.prototype.loadConfiguration = /**
         * @param {?} filePath
         * @return {?}
         */
            function (filePath) {
                var _this = this;
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(filePath).toPromise().then(function (response) {
                        _this.appConfiguration = response;
                        resolve();
                    }).catch(function (response) {
                        console.log(response);
                        console.log("could not load configuration file error: \n " + JSON.stringify(response));
                        reject("could not load configuration file error: \n " + JSON.stringify(response));
                    });
                });
            };
        /**
         * @return {?}
         */
        AppConfigurationService.prototype.getConfiguration = /**
         * @return {?}
         */
            function () {
                return this.appConfiguration;
            };
        AppConfigurationService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        AppConfigurationService.ctorParameters = function () {
            return [
                { type: i1.HttpClient }
            ];
        };
        /** @nocollapse */ AppConfigurationService.ngInjectableDef = i0.defineInjectable({ factory: function AppConfigurationService_Factory() { return new AppConfigurationService(i0.inject(i1.HttpClient)); }, token: AppConfigurationService, providedIn: "root" });
        return AppConfigurationService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @type {?} */
    var forge$1 = require('node-forge');
    var RsaUtils = (function () {
        function RsaUtils() {
        }
        /**
         * @param {?} pem_file_content
         * @return {?}
         */
        RsaUtils.privateKeyFromPEM = /**
         * @param {?} pem_file_content
         * @return {?}
         */
            function (pem_file_content) {
                RsaUtils.privateKey = forge$1.pki.privateKeyFromPem(pem_file_content);
            };
        /**
         * @return {?}
         */
        RsaUtils.publicKeyToPEM = /**
         * @return {?}
         */
            function () {
                return forge$1.pki.publicKeyToPem(RsaUtils.publicKey);
            };
        /**
         * @param {?} pem_file_content
         * @return {?}
         */
        RsaUtils.publicKeyFromPEM = /**
         * @param {?} pem_file_content
         * @return {?}
         */
            function (pem_file_content) {
                RsaUtils.publicKey = forge$1.pki.publicKeyFromPem(pem_file_content);
            };
        /**
         * @param {?} message
         * @param {?=} pemPublicKey
         * @return {?}
         */
        RsaUtils.encrypt = /**
         * @param {?} message
         * @param {?=} pemPublicKey
         * @return {?}
         */
            function (message, pemPublicKey) {
                if (pemPublicKey) {
                    return forge$1.util.encode64(forge$1.pki.privateKeyFromPem(pemPublicKey).encrypt(message, 'RSA-OAEP', {
                        md: forge$1.md.sha256.create(),
                        mgf1: {
                            md: forge$1.md.sha1.create()
                        }
                    }));
                }
                else if (RsaUtils.publicKey) {
                    return forge$1.util.encode64(RsaUtils.publicKey.encrypt(message, 'RSA-OAEP', {
                        md: forge$1.md.sha256.create(),
                        mgf1: {
                            md: forge$1.md.sha1.create()
                        }
                    }));
                }
                else {
                    console.log('public key is not defined');
                    return null;
                }
            };
        /**
         * @param {?} cipherText
         * @param {?=} pemPrivateKey
         * @return {?}
         */
        RsaUtils.decrypt = /**
         * @param {?} cipherText
         * @param {?=} pemPrivateKey
         * @return {?}
         */
            function (cipherText, pemPrivateKey) {
                if (pemPrivateKey) {
                    return forge$1.pki.privateKeyFromPem(pemPrivateKey).decrypt(forge$1.util.decode64(cipherText), 'RSA-OAEP', {
                        md: forge$1.md.sha256.create(),
                        mgf1: {
                            md: forge$1.md.sha1.create()
                        }
                    });
                }
                else if (RsaUtils.privateKey) {
                    return RsaUtils.privateKey.decrypt(forge$1.util.decode64(cipherText), 'RSA-OAEP', {
                        md: forge$1.md.sha256.create(),
                        mgf1: {
                            md: forge$1.md.sha1.create()
                        }
                    });
                }
                else {
                    console.log('private key is not defined');
                    return null;
                }
            };
        /**
         * @return {?}
         */
        RsaUtils.prototype.privateKeyToPEM = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var rsaPrivateKey = forge$1.pki.privateKeyToAsn1(RsaUtils.privateKey);
                /** @type {?} */
                var privateKeyInfo = forge$1.pki.wrapRsaPrivateKey(rsaPrivateKey);
                return forge$1.pki.privateKeyInfoToPem(privateKeyInfo);
            };
        RsaUtils.publicKey = null;
        RsaUtils.privateKey = null;
        return RsaUtils;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var AesUtils = (function () {
        function AesUtils() {
        }
        /**
         * @param {?} aesKey
         * @return {?}
         */
        AesUtils.setAesEncryptionKey = /**
         * @param {?} aesKey
         * @return {?}
         */
            function (aesKey) {
                AesUtils.aesKey = aesKey;
            };
        /**
         * @param {?} message
         * @param {?=} aesKey
         * @return {?}
         */
        AesUtils.encrypt = /**
         * @param {?} message
         * @param {?=} aesKey
         * @return {?}
         */
            function (message, aesKey) {
                if (!aesKey) {
                    aesKey = AesUtils.aesKey;
                }
                /** @type {?} */
                var key = aesjs.utils.utf8.toBytes(aesKey);
                /** @type {?} */
                var textBytes = aesjs.utils.utf8.toBytes(message);
                textBytes = new aesjs.padding.pkcs7.pad(textBytes);
                /** @type {?} */
                var aesEcb = new aesjs.ModeOfOperation.ecb(key);
                /** @type {?} */
                var encryptedBytes = aesEcb.encrypt(textBytes);
                return aesjs.utils.hex.fromBytes(encryptedBytes);
            };
        /**
         * @param {?} cipher
         * @param {?=} aesKey
         * @return {?}
         */
        AesUtils.decrypt = /**
         * @param {?} cipher
         * @param {?=} aesKey
         * @return {?}
         */
            function (cipher, aesKey) {
                if (!aesKey) {
                    aesKey = AesUtils.aesKey;
                }
                /** @type {?} */
                var key = aesjs.utils.utf8.toBytes(aesKey);
                /** @type {?} */
                var aesEcb = new aesjs.ModeOfOperation.ecb(key);
                /** @type {?} */
                var encryptedBytes = aesjs.utils.hex.toBytes(cipher);
                /** @type {?} */
                var decryptedBytes = aesEcb.decrypt(encryptedBytes);
                decryptedBytes = aesjs.padding.pkcs7.strip(decryptedBytes);
                return aesjs.utils.utf8.fromBytes(decryptedBytes);
            };
        /**
         * @param {?=} length
         * @return {?}
         */
        AesUtils.generateRandomAesKey = /**
         * @param {?=} length
         * @return {?}
         */
            function (length) {
                if (length === void 0) {
                    length = 16;
                }
                /** @type {?} */
                var map = new Map();
                map.set(0, 'a').set(1, 'b').set(2, 'c').set(3, 'd').set(4, 'e').set(5, 'f').
                    set(6, 'g').set(7, 'h').set(8, 'i').set(9, 'j').set(10, 'k').set(11, 'l').set(12, 'm').
                    set(13, 'n').set(14, 'o').set(15, 'p').set(16, 'q').set(17, 'r').
                    set(18, 's').set(19, 't').set(20, 'u').set(21, 'v').set(22, 'w').set(23, 'x').set(24, 'y').
                    set(25, 'z').set(26, 'A').set(27, 'B').set(28, 'C').set(29, 'D').set(30, 'E').set(31, 'F').
                    set(32, 'G').set(33, 'H').set(34, 'I').set(35, 'J').set(36, 'K').set(37, 'L').set(38, 'M').
                    set(39, 'N').set(40, 'O').set(41, 'P').set(42, 'Q').set(43, 'R').set(44, 'S').set(45, 'T').
                    set(46, 'U').set(47, 'V').set(48, 'W').set(49, 'X').set(50, 'Y').set(51, 'Z');
                /** @type {?} */
                var key = '';
                for (var i = 0; i < length; i++) {
                    key = key.concat(map.get(Math.floor(Math.random() * 52)));
                }
                return key;
            };
        /**
         * @return {?}
         */
        AesUtils.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        AesUtils.aesKey = null;
        return AesUtils;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var NavigateService = (function () {
        function NavigateService(router) {
            this.router = router;
        }
        /**
         * @param {?} path
         * @return {?}
         */
        NavigateService.prototype.navigate = /**
         * @param {?} path
         * @return {?}
         */
            function (path) {
                this.router.navigate(path);
            };
        NavigateService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        NavigateService.ctorParameters = function () {
            return [
                { type: i1$1.Router }
            ];
        };
        /** @nocollapse */ NavigateService.ngInjectableDef = i0.defineInjectable({ factory: function NavigateService_Factory() { return new NavigateService(i0.inject(i1$1.Router)); }, token: NavigateService, providedIn: "root" });
        return NavigateService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var SessionService = (function () {
        function SessionService(cookieService, appSetting, navigateService) {
            this.cookieService = cookieService;
            this.appSetting = appSetting;
            this.navigateService = navigateService;
            this.hashKey = new Fingerprint2({ excludeAdBlock: true }).getSync().fprint.substr(0, 16);
        }
        /*
        *This function is used to fetch stored session data
        */
        /**
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.getSessionData = /**
         * @param {?=} key
         * @return {?}
         */
            function (key) {
                if (key === void 0) {
                    key = 'globals';
                }
                /** @type {?} */
                var data;
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    data = JSON.parse(this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : '{}');
                }
                else {
                    console.log('into clearing session');
                    this.clearSessionDataAndGotoSessionExpirePage();
                    data = /** @type {?} */ ({});
                }
                return /** @type {?} */ (data);
            };
        /*
        *
        */
        /**
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.getAesKey = /**
         * @param {?=} key
         * @return {?}
         */
            function (key) {
                if (key === void 0) {
                    key = 'aesKey';
                }
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    return this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : null;
                }
                this.clearSessionDataAndGotoSessionExpirePage();
                return null;
            };
        /*
        *
        */
        /**
         * @param {?} sessionData
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.setSessionData = /**
         * @param {?} sessionData
         * @param {?=} key
         * @return {?}
         */
            function (sessionData, key) {
                if (key === void 0) {
                    key = 'globals';
                }
                /** @type {?} */
                var data = {};
                /** @type {?} */
                var userInformation = {
                    currentUser: {
                        userName: sessionData.userName,
                        appData: sessionData.appData,
                        nodeNameCircle: sessionData.nodeNameCircle
                    }
                };
                if (sessionData.neNameCircleName) {
                    userInformation.currentUser['neNameCircleName'] = sessionData.neNameCircleName;
                }
                if (sessionData.aesKey) {
                    data['aesKey'] = sessionData.aesKey;
                }
                data[key] = userInformation;
                this.cookieService.set(key, AesUtils.encrypt(JSON.stringify(data), this.hashKey));
            };
        /*
        *
        */
        /**
         * @param {...?} args
         * @return {?}
         */
        SessionService.prototype.clearSessionData = /**
         * @param {...?} args
         * @return {?}
         */
            function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                if (args.length > 0) {
                    try {
                        for (var args_1 = __values(args), args_1_1 = args_1.next(); !args_1_1.done; args_1_1 = args_1.next()) {
                            var arg = args_1_1.value;
                            this.cookieService.delete(arg);
                        }
                    }
                    catch (e_1_1) {
                        e_1 = { error: e_1_1 };
                    }
                    finally {
                        try {
                            if (args_1_1 && !args_1_1.done && (_a = args_1.return))
                                _a.call(args_1);
                        }
                        finally {
                            if (e_1)
                                throw e_1.error;
                        }
                    }
                }
                else {
                    this.cookieService.deleteAll();
                    localStorage.clear();
                }
                var e_1, _a;
            };
        /*
        *
        */
        /**
         * @param {?=} timeStamp
         * @return {?}
         */
        SessionService.prototype.putDateForCookieExpiry = /**
         * @param {?=} timeStamp
         * @return {?}
         */
            function (timeStamp) {
                /** @type {?} */
                var sessionTime = 600000;
                if (this.appSetting.getConfiguration()) {
                    sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
                }
                if (!timeStamp) {
                    this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
                }
                else {
                    this.cookieService.set('expiryTime', timeStamp);
                }
            };
        /*
        *
        */
        /**
         * @return {?}
         */
        SessionService.prototype.getDateForCookieExpiry = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var sessionTime = 600000;
                if (this.appSetting.getConfiguration()) {
                    sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
                }
                if (this.cookieService.check('expiryTime')) {
                    return Number.parseInt(this.cookieService.get('expiryTime'));
                }
                this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
                return (new Date().getTime() + sessionTime);
            };
        /*
        *
        */
        /**
         * @param {?} userToken
         * @return {?}
         */
        SessionService.prototype.setUserTokenData = /**
         * @param {?} userToken
         * @return {?}
         */
            function (userToken) {
                this.cookieService.set('userToken', AesUtils.encrypt(userToken, this.hashKey));
            };
        /*
        *
        */
        /**
         * @return {?}
         */
        SessionService.prototype.getUserTokenData = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    return this.cookieService.check('userToken') ? AesUtils.decrypt(this.cookieService.get('userToken'), this.hashKey) : null;
                }
                this.clearSessionDataAndGotoSessionExpirePage();
                return null;
            };
        /*
        *
        */
        /**
         * @param {?} moduleRestriction
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.setSessionDataForModuleRestriction = /**
         * @param {?} moduleRestriction
         * @param {?=} key
         * @return {?}
         */
            function (moduleRestriction, key) {
                if (key === void 0) {
                    key = 'moduleRestriction';
                }
                if (typeof (Storage)) {
                    localStorage.setItem(key, JSON.stringify(moduleRestriction));
                }
                else {
                    console.log('Local Storgae not available');
                }
            };
        /*
        *
        */
        /**
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.getSessionDataForModuleRestriction = /**
         * @param {?=} key
         * @return {?}
         */
            function (key) {
                if (key === void 0) {
                    key = 'moduleRestriction';
                }
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
                }
                this.clearSessionDataAndGotoSessionExpirePage();
                return JSON.parse('{}');
            };
        /*
        *
        */
        /**
         * @param {?} structuredRestriction
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.setSessionDataForStructuredRestriction = /**
         * @param {?} structuredRestriction
         * @param {?=} key
         * @return {?}
         */
            function (structuredRestriction, key) {
                if (key === void 0) {
                    key = 'structuredRestriction';
                }
                if (typeof (Storage)) {
                    localStorage.setItem(key, JSON.stringify(structuredRestriction));
                }
                else {
                    console.log('Local Storgae not available');
                }
            };
        /*
        *
        */
        /**
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.getSessionDataForStructuredRestriction = /**
         * @param {?=} key
         * @return {?}
         */
            function (key) {
                if (key === void 0) {
                    key = 'structuredRestriction';
                }
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
                }
                this.clearSessionDataAndGotoSessionExpirePage();
                return JSON.parse('{}');
            };
        /*
        *
        */
        /**
         * @param {?} nodeCircleRestriction
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.setSessionDataForNodeCircleRestriction = /**
         * @param {?} nodeCircleRestriction
         * @param {?=} key
         * @return {?}
         */
            function (nodeCircleRestriction, key) {
                if (key === void 0) {
                    key = 'nodeCircleRestriction';
                }
                if (typeof (Storage)) {
                    localStorage.setItem(key, JSON.stringify(nodeCircleRestriction));
                }
                else {
                    console.log('Local Storgae not available');
                }
            };
        /*
        *
        */
        /**
         * @param {?=} key
         * @return {?}
         */
        SessionService.prototype.getSessionDataForNodeCircleRestriction = /**
         * @param {?=} key
         * @return {?}
         */
            function (key) {
                if (key === void 0) {
                    key = 'nodeCircleRestriction';
                }
                /** @type {?} */
                var expiryTime = this.getDateForCookieExpiry();
                if (expiryTime > new Date().getTime()) {
                    return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
                }
                this.clearSessionDataAndGotoSessionExpirePage();
                return JSON.parse('{}');
            };
        /*
        *
        */
        /**
         * @return {?}
         */
        SessionService.prototype.clearSessionDataAndGotoSessionExpirePage = /**
         * @return {?}
         */
            function () {
                this.resetVariables();
                this.clearSessionData();
                if (this.appSetting.getConfiguration()) {
                    console.log(this.appSetting.getConfiguration().sessionExpiredPage);
                    this.navigateService.navigate([this.appSetting.getConfiguration().sessionExpiredPage]);
                }
            };
        /*
        *
        */
        /**
         * @return {?}
         */
        SessionService.prototype.clearSessionDataAndGotoLogoutPage = /**
         * @return {?}
         */
            function () {
                this.resetVariables();
                this.clearSessionData();
                if (this.appSetting.getConfiguration()) {
                    this.navigateService.navigate([this.appSetting.getConfiguration().logoutPath]);
                }
            };
        /**
         * @return {?}
         */
        SessionService.prototype.resetVariables = /**
         * @return {?}
         */
            function () {
                this.globals = null;
                this.selectedCircleName = null;
                this.selectedNeName = null;
                this.selectedNeShortName = null;
                this.parsedNodeCircleJson = null;
                this.nodeNameCircle = null;
                this.structuredRestriction = null;
                this.moduleRestriction = null;
                this.mapNeNameCircleName = null;
                this.nodeNameList = [];
            };
        SessionService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        SessionService.ctorParameters = function () {
            return [
                { type: ngxCookieService.CookieService },
                { type: AppConfigurationService },
                { type: NavigateService }
            ];
        };
        /** @nocollapse */ SessionService.ngInjectableDef = i0.defineInjectable({ factory: function SessionService_Factory() { return new SessionService(i0.inject(i1$2.CookieService), i0.inject(AppConfigurationService), i0.inject(NavigateService)); }, token: SessionService, providedIn: "root" });
        return SessionService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var WebSocketCallbackClass = (function () {
        function WebSocketCallbackClass() {
        }
        /**
         * @return {?}
         */
        WebSocketCallbackClass.getOnMessageObservable = /**
         * @return {?}
         */
            function () {
                return WebSocketCallbackClass.onMessageSubject.asObservable();
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.getOnOpenObservable = /**
         * @return {?}
         */
            function () {
                return WebSocketCallbackClass.onOpenSubject.asObservable();
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.getOnCloseObservable = /**
         * @return {?}
         */
            function () {
                return WebSocketCallbackClass.onCloseSubject.asObservable();
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.getOnErrorObservable = /**
         * @return {?}
         */
            function () {
                return WebSocketCallbackClass.onErrorSubject.asObservable();
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.getOnWebsocketReconnectObservable = /**
         * @return {?}
         */
            function () {
                return WebSocketCallbackClass.onWebsocketReconnectSubject.asObservable();
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.reInitializeObservables = /**
         * @return {?}
         */
            function () {
                WebSocketCallbackClass.onMessageSubject = new rxjs.Subject();
                WebSocketCallbackClass.onOpenSubject = new rxjs.Subject();
                WebSocketCallbackClass.onCloseSubject = new rxjs.Subject();
                WebSocketCallbackClass.onErrorSubject = new rxjs.Subject();
            };
        /**
         * @param {?} event
         * @return {?}
         */
        WebSocketCallbackClass.prototype.onMessage = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                WebSocketCallbackClass.onMessageSubject.next(event);
            };
        /**
         * @param {?} event
         * @return {?}
         */
        WebSocketCallbackClass.prototype.onClose = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                console.log('websocket closed');
                WebSocketCallbackClass.onCloseSubject.next(event);
            };
        /**
         * @param {?} event
         * @return {?}
         */
        WebSocketCallbackClass.prototype.onError = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                console.log(event);
                WebSocketCallbackClass.onErrorSubject.next(event);
            };
        /**
         * @param {?} event
         * @param {?} websocket
         * @return {?}
         */
        WebSocketCallbackClass.prototype.onOpen = /**
         * @param {?} event
         * @param {?} websocket
         * @return {?}
         */
            function (event, websocket) {
                console.log('websocket opened');
                WebSocketCallbackClass.onOpenSubject.next(event);
            };
        /**
         * @return {?}
         */
        WebSocketCallbackClass.prototype.onReconnect = /**
         * @return {?}
         */
            function () {
                console.log('websocket re-connected');
                WebSocketCallbackClass.onWebsocketReconnectSubject.next();
            };
        WebSocketCallbackClass.onMessageSubject = new rxjs.Subject();
        WebSocketCallbackClass.onOpenSubject = new rxjs.Subject();
        WebSocketCallbackClass.onCloseSubject = new rxjs.Subject();
        WebSocketCallbackClass.onErrorSubject = new rxjs.Subject();
        WebSocketCallbackClass.onWebsocketReconnectSubject = new rxjs.Subject();
        return WebSocketCallbackClass;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var MessageMapping = (function () {
        function MessageMapping(httpClient) {
            this.httpClient = httpClient;
        }
        /**
         * @param {?} code
         * @return {?}
         */
        MessageMapping.getMessage = /**
         * @param {?} code
         * @return {?}
         */
            function (code) {
                return MessageMapping.messageMap.has(code) ? MessageMapping.messageMap.get(code) : 'unknown error code received';
            };
        /**
         * @param {?} filePath
         * @return {?}
         */
        MessageMapping.prototype.loadMesageMap = /**
         * @param {?} filePath
         * @return {?}
         */
            function (filePath) {
                this.httpClient.get(filePath).toPromise().then(function (response) {
                    new Map(Object.entries(response)).forEach(function (value, key) {
                        MessageMapping.messageMap.set(Number.parseInt(key), value);
                    });
                }).catch(function (response) {
                    console.log(response);
                    console.log("could not load configuration file error: \n " + JSON.stringify(response));
                });
            };
        MessageMapping.messageMap = new Map();
        MessageMapping.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        MessageMapping.ctorParameters = function () {
            return [
                { type: i1.HttpClient }
            ];
        };
        /** @nocollapse */ MessageMapping.ngInjectableDef = i0.defineInjectable({ factory: function MessageMapping_Factory() { return new MessageMapping(i0.inject(i1.HttpClient)); }, token: MessageMapping, providedIn: "root" });
        return MessageMapping;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CacheManagerService = (function () {
        function CacheManagerService(appConfiguration, httpClient, sessionService, location, messageMapping) {
            var _this = this;
            this.appConfiguration = appConfiguration;
            this.httpClient = httpClient;
            this.sessionService = sessionService;
            this.location = location;
            this.messageMapping = messageMapping;
            this.websocketOpenPromise = new Promise(function (resolve, reject) {
                _this.resolveFn = resolve;
                _this.rejectFn = reject;
            });
        }
        /**
         * @return {?}
         */
        CacheManagerService.prototype.ngOnInit = /**
         * @return {?}
         */
            function () { };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                if (this.websocket) {
                    this.websocket.close();
                }
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getAuthKey = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getauthkey');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project, 'operation': 'getauthkey' }),
                    observe: /** @type {?} */ ('response')
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions)
                        .pipe(operators.retry(2), operators.catchError(_this.handleError)).subscribe(function (resp) {
                        if (resp.body.statusCode.type) {
                            RsaUtils.publicKeyFromPEM(resp.body.statusCode.AppData.pemFile);
                            _this.encryptionKey = resp.body.statusCode.AppData;
                            /** @type {?} */
                            var serverTime = resp.headers.has('Date') ? new Date(resp.headers.get('Date')).getTime() : new Date().getTime();
                            /** @type {?} */
                            var clientTime = new Date().getTime();
                            _this.timeAdjustment = serverTime - clientTime;
                            //this.sessionService.putDateForCookieExpiry();
                            resolve();
                        }
                        else {
                            reject();
                        }
                    }, function (error) {
                        console.log('fetching rsa key failed');
                        console.log(error);
                        reject();
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getNodeShortNameFullNameJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeShortNameFullName');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getNodeShortNameFullName'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.neShortNameFullNameJson = {
                                'NodeName': resp.statusCode.AppData
                            };
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getCircleShortNameFullNameJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleShortNameFullName');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getCircleShortNameFullName'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.circleFullNameJsonResponse = {
                                CircleName: resp.statusCode.AppData
                            };
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getModuleToIdJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getShortCodeToIdMap');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getShortCodeToIdMap'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.shortCodeToIdMap = resp.statusCode.AppData;
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getNodeToIdJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeToIdMap');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getNodeToIdMap'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.nodeToIdMap = resp.statusCode.AppData;
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getCircleToIdJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleToIdMap');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getCircleToIdMap'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.circleToIdMap = resp.statusCode.AppData;
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getOperationToModuleNodeCircleJson = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getOperationToModuleNodeCircle');
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getOperationToModuleNodeCircle'
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        if (resp.statusCode.type) {
                            _this.OperationToAccessMapping = resp.statusCode.AppData;
                            resolve();
                        }
                        else {
                            reject(resp);
                        }
                    }, function (error) {
                        console.log(error);
                        reject(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getPathName = /**
         * @return {?}
         */
            function () {
                return window.location && window.location.hash && window.location.hash.substr(1);
            };
        /**
         * @param {?} event
         * @return {?}
         */
        CacheManagerService.prototype.onStartupRouteChange = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                var _this = this;
                return new Promise(function (resolve, reject) {
                    _this.sessionService.globals = _this.sessionService.getSessionData().globals;
                    if (!_this.sessionService.globals) {
                        _this.sessionService.globals = {};
                    }
                    if (_this.appConfiguration.getConfiguration().loginPage && _this.appConfiguration.getConfiguration().nonRestrictedPages
                        && _this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
                        /** @type {?} */
                        var pathName = _this.location.path();
                        if (pathName.includes("?")) {
                            pathName = pathName.split("?")[0];
                        }
                        /** @type {?} */
                        var restrictedPage = _this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
                        /** @type {?} */
                        var loggedIn = _this.sessionService.globals.currentUser;
                        if (restrictedPage && !loggedIn) {
                            _this.location.go(_this.appConfiguration.getConfiguration().loginPage);
                            resolve();
                        }
                        else if (loggedIn) {
                            try {
                                if (!_this.sessionService.moduleRestriction) {
                                    _this.sessionService.moduleRestriction = _this.sessionService.getSessionDataForModuleRestriction();
                                }
                                if (!_this.sessionService.structuredRestriction) {
                                    _this.sessionService.structuredRestriction = _this.sessionService.getSessionDataForStructuredRestriction();
                                }
                                if (!_this.sessionService.parsedNodeCircleJson) {
                                    _this.sessionService.parsedNodeCircleJson = _this.sessionService.getSessionDataForNodeCircleRestriction();
                                }
                                /** @type {?} */
                                var loginPage = _this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) != -1;
                                if (loginPage) {
                                    _this.location.go(_this.appConfiguration.getConfiguration().defaultPageAfterLogin);
                                }
                                _this.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(function (resp) {
                                    resolve();
                                }, function (error) {
                                    console.log(error);
                                    resolve();
                                });
                            }
                            catch (e) {
                                console.log(e);
                            }
                        }
                        else {
                            resolve();
                        }
                    }
                });
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.callWhenConfigLoads = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var userDetails = this.sessionService.globals;
                /** @type {?} */
                var aesKey = this.sessionService.getSessionData().aesKey;
                this.messageMapping.loadMesageMap('assets/configuration/messagemapping.json');
                if (aesKey) {
                    AesUtils.setAesEncryptionKey(aesKey);
                }
                if (userDetails && userDetails.currentUser && userDetails.currentUser.username && !this.loginUserImage) {
                    this.getUserImage(userDetails.currentUser.username).then(function (response) {
                        if (response.success) {
                            this.loginUserImage = response.AppData.userInfo.userImage ? response.AppData.userInfo.userImage : 'noImage';
                        }
                    }, function (err) {
                        console.log(err);
                    });
                }
            };
        /**
         * @template T
         * @param {?} userName
         * @return {?}
         */
        CacheManagerService.prototype.getUserImage = /**
         * @template T
         * @param {?} userName
         * @return {?}
         */
            function (userName) {
                var _this = this;
                /** @type {?} */
                var url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
                    .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
                    .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getUserImage&userName=').concat(userName);
                /** @type {?} */
                var httpOptions = {
                    headers: new i1.HttpHeaders({
                        'project': this.appConfiguration.getConfiguration().project,
                        'operation': 'getUserImage',
                        'userToken': userName + "-" + this.sessionService.getUserTokenData()
                    })
                };
                return new Promise(function (resolve, reject) {
                    _this.httpClient.get(url, httpOptions).pipe(operators.retry(2), operators.catchError(_this.handleError))
                        .subscribe(function (resp) {
                        resolve(resp);
                    }, function (error) {
                        reject(error);
                    });
                });
            };
        /**
         * @param {?} websocketCallbacks
         * @return {?}
         */
        CacheManagerService.prototype.openWebSocketChannel = /**
         * @param {?} websocketCallbacks
         * @return {?}
         */
            function (websocketCallbacks) {
                var _this = this;
                /** @type {?} */
                var responseSessionData = this.sessionService.getSessionData();
                /** @type {?} */
                var protocol = CONSTANTS.WEBSOCKET_PROTOCOL;
                /** @type {?} */
                var ip = this.appConfiguration.getConfiguration().ip;
                /** @type {?} */
                var port = this.appConfiguration.getConfiguration().port;
                /** @type {?} */
                var websocketPort = this.appConfiguration.getConfiguration().websocketPort;
                /** @type {?} */
                var project = this.appConfiguration.getConfiguration().project;
                /** @type {?} */
                var userName = responseSessionData.globals.currentUser.userName;
                /** @type {?} */
                var base64token = forge.util.encode64(userName + "-" + this.sessionService.getUserTokenData());
                /** @type {?} */
                var queryString = "?operation=authenticateWebSocket&project=" + project + "&userToken=" + base64token + "&projectUrl=" + ip + ":" + port;
                /** @type {?} */
                var webSocketURL = "" + protocol + ip + ":" + websocketPort + "/websocket" + queryString;
                return new rxjs.Observable(function (observe) {
                    /** @type {?} */
                    var flag = false;
                    try {
                        _this.websocket = new WebSocket(webSocketURL);
                        if (websocketCallbacks.onOpen) {
                            _this.websocket.onopen = function () {
                                websocketCallbacks.onOpen();
                                /** @type {?} */
                                var map = _this.getCookies();
                                _this.X_SOCKET_ADDRESS = map.has('X-SOCKET-ADDRESS') ? map.get('X-SOCKET-ADDRESS') : null;
                                _this.X_USERNAME = map.has('X-USERNAME') ? map.get('X-USERNAME') : null;
                                _this.SOCKET_IP = map.has('socketIp') ? map.get('socketIp') : null;
                                _this.resolveFn();
                                observe.next();
                                flag = true;
                            };
                        }
                        if (websocketCallbacks.onClose) {
                            _this.websocket.onclose = function () {
                                websocketCallbacks.onClose();
                                WebSocketCallbackClass.reInitializeObservables();
                                _this.reInitializeWebsocketOpenPromise();
                                /** @type {?} */
                                var map = _this.getCookies();
                                responseSessionData = _this.sessionService.getSessionData();
                                if (map.has('X-USERNAME') && flag && responseSessionData.globals && responseSessionData.globals.currentUser) {
                                    /** @type {?} */
                                    var callback_1 = new WebSocketCallbackClass();
                                    _this.openWebSocketChannel(callback_1).subscribe(function (resp) {
                                        callback_1.onReconnect();
                                    });
                                }
                            };
                        }
                        /** @type {?} */
                        var resolveFn_1 = _this.resolveFn;
                        _this.websocket.onerror = function (error) {
                            if (websocketCallbacks.onError) {
                                websocketCallbacks.onError(error);
                            }
                            console.log('re-connecting to websocket server...');
                            resolveFn_1();
                            observe.error();
                        };
                        if (websocketCallbacks.onMessage) {
                            _this.websocket.onmessage = websocketCallbacks.onMessage;
                        }
                    }
                    catch (error) {
                        _this.resolveFn();
                        console.log(error);
                        observe.error(error);
                    }
                }).pipe(operators.delay(2000)).pipe(operators.retry(15));
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.getCookies = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var cookieStr = document.cookie;
                /** @type {?} */
                var cookies = cookieStr.split(';');
                /** @type {?} */
                var map = new Map();
                cookies.forEach(function (cookie) {
                    if (cookie) {
                        /** @type {?} */
                        var keyVal = cookie.trim().split('=');
                        map.set(keyVal[0].trim(), keyVal[1].trim());
                    }
                });
                return map;
            };
        /**
         * @param {?} error
         * @return {?}
         */
        CacheManagerService.prototype.handleError = /**
         * @param {?} error
         * @return {?}
         */
            function (error) {
                if (error instanceof ErrorEvent) {
                    return rxjs.throwError("Could not connect to server.\n:" + error);
                }
                else {
                    return rxjs.throwError("Server returned code " + error.status + ", body was: " + error.error);
                }
            };
        /**
         * @return {?}
         */
        CacheManagerService.prototype.reInitializeWebsocketOpenPromise = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.websocketOpenPromise = new Promise(function (resolve, reject) {
                    _this.resolveFn = resolve;
                    _this.rejectFn = reject;
                });
            };
        /**
         * @param {?} event
         * @return {?}
         */
        CacheManagerService.prototype.onbeforeunloadHandler = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                /** @type {?} */
                var loginPage = this.appConfiguration.getConfiguration()
                    .nonRestrictedPages.includes(this.location.path());
                if (loginPage) {
                    this.websocket.close();
                }
            };
        CacheManagerService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        CacheManagerService.ctorParameters = function () {
            return [
                { type: AppConfigurationService },
                { type: i1.HttpClient },
                { type: SessionService },
                { type: i4.Location },
                { type: MessageMapping }
            ];
        };
        CacheManagerService.propDecorators = {
            onbeforeunloadHandler: [{ type: i0.HostListener, args: ['window:onbeforeunload', ['$event'],] }]
        };
        /** @nocollapse */ CacheManagerService.ngInjectableDef = i0.defineInjectable({ factory: function CacheManagerService_Factory() { return new CacheManagerService(i0.inject(AppConfigurationService), i0.inject(i1.HttpClient), i0.inject(SessionService), i0.inject(i4.Location), i0.inject(MessageMapping)); }, token: CacheManagerService, providedIn: "root" });
        return CacheManagerService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var HttpService = (function () {
        function HttpService(httpClient, appConfiguration, cache, sessionService) {
            this.httpClient = httpClient;
            this.appConfiguration = appConfiguration;
            this.cache = cache;
            this.sessionService = sessionService;
        }
        /**
         * @param {?} queryString
         * @param {?} key
         * @return {?}
         */
        HttpService.prototype.parseQueryString = /**
         * @param {?} queryString
         * @param {?} key
         * @return {?}
         */
            function (queryString, key) {
                /** @type {?} */
                var tokens;
                if (queryString) {
                    tokens = queryString.split('&');
                }
                else {
                    return null;
                }
                /** @type {?} */
                var map = new Map();
                try {
                    for (var tokens_1 = __values(tokens), tokens_1_1 = tokens_1.next(); !tokens_1_1.done; tokens_1_1 = tokens_1.next()) {
                        var token = tokens_1_1.value;
                        /** @type {?} */
                        var keyValue = token.split('=');
                        map.set(keyValue[0], keyValue[1]);
                    }
                }
                catch (e_1_1) {
                    e_1 = { error: e_1_1 };
                }
                finally {
                    try {
                        if (tokens_1_1 && !tokens_1_1.done && (_a = tokens_1.return))
                            _a.call(tokens_1);
                    }
                    finally {
                        if (e_1)
                            throw e_1.error;
                    }
                }
                return map.has(key) ? map.get(key) : null;
                var e_1, _a;
            };
        /**
         * @param {?} url
         * @return {?}
         */
        HttpService.prototype.parseUrl = /**
         * @param {?} url
         * @return {?}
         */
            function (url) {
                /** @type {?} */
                var parsedParameters = new Map();
                /** @type {?} */
                var queryString = url.split('?')[1];
                /** @type {?} */
                var parameterPairList = queryString.split('&');
                parameterPairList.forEach(function (parameterPair) {
                    /** @type {?} */
                    var keyValue = parameterPair.split('=');
                    parsedParameters[keyValue[0]] = keyValue[1];
                });
                return parsedParameters;
            };
        /**
         * @param {?} url
         * @return {?}
         */
        HttpService.prototype.checkAuthorization = /**
         * @param {?} url
         * @return {?}
         */
            function (url) {
                if (!this.appConfiguration.getConfiguration().clientSideRequestBarring) {
                    return true;
                }
                /** @type {?} */
                var parsedParameters = this.parseUrl(url);
                /** @type {?} */
                var operation = parsedParameters['operation'];
                /** @type {?} */
                var accessGrantedModule = false;
                /** @type {?} */
                var accessGrantedNode = false;
                /** @type {?} */
                var accessGrantedCircle = false;
                switch (operation) {
                    case 'doLogin':
                    case 'logoutUser':
                        accessGrantedModule = true;
                        break;
                    default:
                        if (this.cache.OperationToAccessMapping[operation] &&
                            this.cache.OperationToAccessMapping[operation].module !== 'freeAllow') {
                            /** @type {?} */
                            var accessRequired = this.cache.OperationToAccessMapping[operation].access;
                            if (this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module]) {
                                accessGrantedModule =
                                    this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module][accessRequired] ? true : false;
                            }
                            else {
                                accessGrantedModule = false;
                            }
                        }
                        else if (this.cache.OperationToAccessMapping[operation] &&
                            this.cache.OperationToAccessMapping[operation].module === 'freeAllow') {
                            accessGrantedModule = true;
                        }
                        else {
                            accessGrantedModule = false;
                        }
                        break;
                }
                if (!accessGrantedModule) {
                    return false;
                }
                if (this.cache.OperationToAccessMapping[operation] && this.cache.OperationToAccessMapping[operation].circle) {
                    if (this.cache.OperationToAccessMapping[operation].node) {
                        /** @type {?} */
                        var circleAccessRequired = parsedParameters['circleName'];
                        /** @type {?} */
                        var nodeAccessRequired = parsedParameters['nodeName'];
                        if (circleAccessRequired && nodeAccessRequired) {
                            if (nodeAccessRequired.parsedNodeCircleJson[nodeAccessRequired] &&
                                this.sessionService.parsedNodeCircleJson[nodeAccessRequired][circleAccessRequired]) {
                                accessGrantedCircle = true;
                            }
                            else {
                                accessGrantedCircle = false;
                            }
                        }
                        else {
                            accessGrantedCircle = false;
                        }
                    }
                    else {
                        accessGrantedCircle = false;
                    }
                }
                else if (this.cache.OperationToAccessMapping[operation] &&
                    !this.cache.OperationToAccessMapping[operation].circle) {
                    accessGrantedCircle = true;
                }
                else {
                    accessGrantedCircle = false;
                }
                if (!accessGrantedCircle) {
                    return false;
                }
                if (this.cache.OperationToAccessMapping[operation] &&
                    this.cache.OperationToAccessMapping[operation].node) {
                    /** @type {?} */
                    var nodeAccessRequired = parsedParameters['nodeName'];
                    if (nodeAccessRequired) {
                        if (this.sessionService.parsedNodeCircleJson[nodeAccessRequired]) {
                            accessGrantedNode = true;
                        }
                        else {
                            accessGrantedNode = false;
                        }
                    }
                    else {
                        accessGrantedNode = false;
                    }
                }
                else if (this.cache.OperationToAccessMapping[operation] &&
                    !this.cache.OperationToAccessMapping[operation].node) {
                    accessGrantedNode = true;
                }
                else {
                    accessGrantedNode = false;
                }
                return accessGrantedNode;
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.getData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    console.log(url);
                    if (this.checkAuthorization(url)) {
                        if (request.responseType) {
                            request.headers.set('responseType', request.responseType);
                        }
                        /** @type {?} */
                        var httpOptions_1 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_1.headers['operation'] = operation;
                        if (request.responseType) {
                            httpOptions_1['responseType'] = request.responseType;
                        }
                        return new rxjs.Observable(function (observe) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.get(url, httpOptions_1).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) {
                                        console.log(response);
                                        if (request.callbackfunction) {
                                            request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                                        }
                                        else {
                                            observe.next(response);
                                        }
                                    }, function (error) {
                                        observe.error(error);
                                    });
                                });
                            }
                            else {
                                _this.httpClient.get(url, httpOptions_1).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) {
                                    if (request.callbackfunction) {
                                        request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                                    }
                                    else {
                                        observe.next(response);
                                    }
                                }, function (error) {
                                    observe.error(error);
                                });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.postData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    console.log(url);
                    if (this.checkAuthorization(url)) {
                        /** @type {?} */
                        var httpOptions_2 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_2.headers['operation'] = operation;
                        return new rxjs.Observable(function (subscriber) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.post(url, request.data, httpOptions_2).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                                });
                            }
                            else {
                                _this.httpClient.post(url, request.data, httpOptions_2).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.putData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    if (this.checkAuthorization(url)) {
                        /** @type {?} */
                        var httpOptions_3 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_3.headers['operation'] = operation;
                        return new rxjs.Observable(function (subscriber) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.put(url, request.data, httpOptions_3).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                                });
                            }
                            else {
                                _this.httpClient.put(url, request.data, httpOptions_3).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.deleteData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    if (this.checkAuthorization(url)) {
                        /** @type {?} */
                        var httpOptions_4 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_4.headers['operation'] = operation;
                        return new rxjs.Observable(function (subscriber) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.delete(url, httpOptions_4).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                                });
                            }
                            else {
                                _this.httpClient.delete(url, httpOptions_4).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.headData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    if (this.checkAuthorization(url)) {
                        /** @type {?} */
                        var httpOptions_5 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_5.headers['operation'] = operation;
                        return new rxjs.Observable(function (subscriber) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.head(url, httpOptions_5).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                                });
                            }
                            else {
                                _this.httpClient.head(url, httpOptions_5).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @template T
         * @param {?} request
         * @return {?}
         */
        HttpService.prototype.patchData = /**
         * @template T
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                /** @type {?} */
                var operation = this.parseQueryString(request.queryString, 'operation');
                /** @type {?} */
                var url;
                /** @type {?} */
                var config = this.appConfiguration.getConfiguration();
                if (request.reqUrl) {
                    url = request.reqUrl;
                }
                else {
                    if (!request.queryString) {
                        request.queryString = '';
                    }
                    else {
                        request.queryString = "?" + request.queryString;
                    }
                    url = "" + CONSTANTS.PROTOCOL + config.ip + ":" + config.port + request.context + request.queryString;
                    if (this.checkAuthorization(url)) {
                        /** @type {?} */
                        var httpOptions_6 = {
                            headers: request.headers ? request.headers : /** @type {?} */ ({}),
                            observe: /** @type {?} */ ('response')
                        };
                        httpOptions_6.headers['operation'] = operation;
                        return new rxjs.Observable(function (subscriber) {
                            if (_this.sessionService.getSessionData().globals &&
                                _this.sessionService.getSessionData().globals.currentUser) {
                                _this.cache.websocketOpenPromise.then(function () {
                                    _this.httpClient.patch(url, request.data, httpOptions_6).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                        .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                                });
                            }
                            else {
                                _this.httpClient.patch(url, request.data, httpOptions_6).pipe(operators.retry(2), operators.catchError(_this.handleError))
                                    .subscribe(function (response) { return subscriber.next(response); }, function (error) { return subscriber.error(error); });
                            }
                        });
                    }
                    else {
                        return rxjs.throwError("Not authorized for accessing " + url + ": 401");
                    }
                }
            };
        /**
         * @param {?} error
         * @return {?}
         */
        HttpService.prototype.handleError = /**
         * @param {?} error
         * @return {?}
         */
            function (error) {
                if (error instanceof ErrorEvent) {
                    return rxjs.throwError("Could not connect to server.\n:" + error);
                }
                else {
                    return rxjs.throwError(error);
                }
            };
        HttpService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        HttpService.ctorParameters = function () {
            return [
                { type: i1.HttpClient },
                { type: AppConfigurationService },
                { type: CacheManagerService },
                { type: SessionService }
            ];
        };
        /** @nocollapse */ HttpService.ngInjectableDef = i0.defineInjectable({ factory: function HttpService_Factory() { return new HttpService(i0.inject(i1.HttpClient), i0.inject(AppConfigurationService), i0.inject(CacheManagerService), i0.inject(SessionService)); }, token: HttpService, providedIn: "root" });
        return HttpService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var IamService = (function () {
        function IamService(httpService, appConfiguration, sessionService, cache, router, location) {
            this.httpService = httpService;
            this.appConfiguration = appConfiguration;
            this.sessionService = sessionService;
            this.cache = cache;
            this.router = router;
            this.location = location;
            this.startListeningToRouteChange().subscribe(function () {
                console.log('started listening for route change');
            });
        }
        /**
         * @return {?}
         */
        IamService.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @return {?}
         */
        IamService.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                this.websocket.close();
            };
        /**
         * @template T
         * @param {?} payload
         * @param {?} project
         * @return {?}
         */
        IamService.prototype.doLogin = /**
         * @template T
         * @param {?} payload
         * @param {?} project
         * @return {?}
         */
            function (payload, project) {
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders().set('project', this.appConfiguration.getConfiguration().project);
                }
                else {
                    headers = new i1.HttpHeaders().set('project', project);
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=doLogin',
                    headers: headers,
                    data: payload
                };
                return this.httpService.postData(request);
            };
        /**
         * @return {?}
         */
        IamService.prototype.startListeningToRouteChange = /**
         * @return {?}
         */
            function () {
                var _this = this;
                return new rxjs.Observable(function (observe) {
                    _this.router.events.pipe(operators.filter(function (event) { return event instanceof i1$1.NavigationEnd; })).subscribe(function (event) {
                        if (event instanceof i1$1.NavigationEnd) {
                            _this.onRouteChange(event);
                        }
                    });
                    observe.next();
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} password
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.authenticateUser = /**
         * @template T
         * @param {?} userName
         * @param {?} password
         * @param {?=} project
         * @return {?}
         */
            function (userName, password, project) {
                var _this = this;
                return new rxjs.Observable(function (observe) {
                    /** @type {?} */
                    var responseSessionData = _this.sessionService.getSessionData();
                    if (responseSessionData && responseSessionData.globals &&
                        responseSessionData.globals.currentUser && responseSessionData.globals.currentUser.userName) {
                        console.log('user already logged in');
                        _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                        observe.next();
                    }
                    else {
                        /** @type {?} */
                        var randomAesKey_1 = AesUtils.generateRandomAesKey();
                        /** @type {?} */
                        var credentials = {
                            userName: userName,
                            userPassword: RsaUtils.encrypt(password),
                        };
                        /** @type {?} */
                        var payload = {
                            AppData: {
                                userInfo: credentials,
                                encryptionKey: RsaUtils.encrypt(randomAesKey_1)
                            }
                        };
                        _this.doLogin(payload, project).subscribe(function (response) {
                            if (response.body && response.body.statusCode && response.body.statusCode.AppData && response.body.statusCode.AppData.userToken) {
                                /** @type {?} */
                                var subTokens = response.body.statusCode.AppData.userToken.split('@');
                                /** @type {?} */
                                var moduleRestriction = null;
                                /** @type {?} */
                                var structuredRestriction = null;
                                /** @type {?} */
                                var nodeNameCircle = null;
                                if (subTokens[1] && subTokens[1].length > 0) {
                                    moduleRestriction = _this.parseToken(AesUtils.decrypt(subTokens[1], randomAesKey_1));
                                }
                                else {
                                    moduleRestriction = {};
                                }
                                structuredRestriction = _this.restructureAccessJson(moduleRestriction, {});
                                _this.sessionService.setSessionDataForModuleRestriction(moduleRestriction);
                                _this.sessionService.setSessionDataForStructuredRestriction(structuredRestriction);
                                _this.sessionService.setUserTokenData(subTokens[0]);
                                if (subTokens[2] && subTokens[2].length > 0) {
                                    nodeNameCircle = AesUtils.decrypt(subTokens[2], randomAesKey_1);
                                }
                                else {
                                    nodeNameCircle = '';
                                }
                                /** @type {?} */
                                var parsedNodeCircleJson = _this.parseNodeCircleToken(nodeNameCircle);
                                _this.sessionService.setSessionDataForNodeCircleRestriction(/** @type {?} */ (parsedNodeCircleJson));
                                /** @type {?} */
                                var neNamesCircleList = nodeNameCircle.split('#');
                                if (!_this.sessionService.nodeNameList) {
                                    _this.sessionService.nodeNameList = [];
                                }
                                if (!_this.sessionService.mapNeNameCircleName) {
                                    _this.sessionService.mapNeNameCircleName = {};
                                }
                                for (var itr = 0; itr < neNamesCircleList.length; itr++) {
                                    /** @type {?} */
                                    var cirleNamesForNE = neNamesCircleList[itr].split(':');
                                    _this.sessionService.nodeNameList.push(cirleNamesForNE[0]);
                                    _this.sessionService.mapNeNameCircleName[cirleNamesForNE[0]] = cirleNamesForNE[1];
                                }
                                _this.sessionService.selectedNeShortName = _this.sessionService.nodeNameList[0];
                                _this.neShortNameFullNameMapping();
                                _this.neCircleShortNameFullNameMapping();
                                /** @type {?} */
                                var neNameCircleName = JSON.parse(JSON.stringify({
                                    selectedNeName: _this.sessionService.selectedNeName,
                                    selectedCircleName: _this.sessionService.selectedCircleName
                                }));
                                /** @type {?} */
                                var requestData = {
                                    userName: userName,
                                    appData: response.body.statusCode.AppData,
                                    nodeNameCircle: nodeNameCircle,
                                    aesKey: AesUtils.decrypt(subTokens[3], randomAesKey_1),
                                    neNameCircleName: neNameCircleName
                                };
                                _this.sessionService.putDateForCookieExpiry();
                                _this.sessionService.setSessionData(requestData);
                                AesUtils.setAesEncryptionKey(AesUtils.decrypt(subTokens[3], randomAesKey_1));
                                _this.cache.getUserImage(userName).then(function (resp) {
                                    if (resp.success) {
                                        this.cache.loginUserImage = resp.AppData.userInfo.userImage ? resp.AppData.userInfo.userImage : 'noImage';
                                    }
                                }, function (err) {
                                    console.log(err);
                                });
                                _this.cache.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(function () {
                                    _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                                    observe.next(response);
                                }, function () {
                                    _this.router.navigate([_this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                                    observe.next(response);
                                });
                            }
                            else {
                                observe.next(response);
                            }
                        }, function (error) {
                            observe.error(error);
                        });
                    }
                });
            };
        /**
         * @param {?} userName
         * @return {?}
         */
        IamService.prototype.doLogout = /**
         * @param {?} userName
         * @return {?}
         */
            function (userName) {
                var _this = this;
                if (!userName) {
                    rxjs.throwError('userName is undefined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: "operation=logoutUser&userName=" + userName,
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.deleteData(request).subscribe(function (response) {
                        observe.next();
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        IamService.prototype.logoutUser = /**
         * @return {?}
         */
            function () {
                var _this = this;
                return new rxjs.Observable(function (observe) {
                    /** @type {?} */
                    var globals = _this.sessionService.getSessionData().globals;
                    if (globals && globals.currentUser && globals.currentUser.userName) {
                        /** @type {?} */
                        var inUserName = globals.currentUser.userName;
                        _this.doLogout(inUserName).subscribe(function () {
                            _this.resetVariables();
                            _this.sessionService.clearSessionDataAndGotoLogoutPage();
                            if (_this.cache.websocket && _this.cache.websocket.close) {
                                _this.cache.websocket.close();
                                _this.cache.websocket = null;
                            }
                            observe.next();
                        }, function (error) {
                            _this.resetVariables();
                            _this.sessionService.clearSessionDataAndGotoLogoutPage();
                            if (_this.cache.websocket && _this.cache.websocket.close) {
                                _this.cache.websocket.close();
                                _this.cache.websocket = null;
                            }
                            observe.error();
                        });
                    }
                    else {
                        _this.resetVariables();
                        _this.sessionService.clearSessionDataAndGotoLogoutPage();
                        if (_this.cache.websocket && _this.cache.websocket.close) {
                            _this.cache.websocket.close();
                            _this.cache.websocket = null;
                        }
                        observe.next();
                        console.log('no user to logout');
                    }
                });
            };
        /**
         * @return {?}
         */
        IamService.prototype.getPathName = /**
         * @return {?}
         */
            function () {
                return window.location && window.location.hash && window.location.hash.substr(1);
            };
        /**
         * @param {?} event
         * @return {?}
         */
        IamService.prototype.onRouteChange = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                this.sessionService.globals = this.sessionService.getSessionData().globals;
                if (!this.sessionService.globals) {
                    this.sessionService.globals = {};
                }
                if (this.router.url == this.appConfiguration.getConfiguration().sessionExpiredPage) {
                    try {
                        if (this.cache.websocket) {
                            this.cache.websocket.close();
                            this.cache.websocket = null;
                        }
                    }
                    catch (ErrorEvent) {
                        console.log(ErrorEvent);
                    }
                }
                if (this.appConfiguration.getConfiguration().loginPage &&
                    this.appConfiguration.getConfiguration().nonRestrictedPages &&
                    this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
                    /** @type {?} */
                    var pathName = this.location.path();
                    if (pathName.includes("?")) {
                        pathName = pathName.split("?")[0];
                    }
                    /** @type {?} */
                    var restrictedPage = this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
                    /** @type {?} */
                    var loggedIn = this.sessionService.globals.currentUser;
                    if (restrictedPage && !loggedIn) {
                        this.router.navigate([this.appConfiguration.getConfiguration().loginPage]);
                    }
                    else if (loggedIn) {
                        /** @type {?} */
                        var loginPage = this.appConfiguration.getConfiguration()
                            .nonRestrictedPages.indexOf(pathName) != -1;
                        if (loginPage) {
                            this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                        }
                    }
                }
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getAllroleid = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getAllRoleSelectedFiled',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} creatingUser
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createSingleUser = /**
         * @template T
         * @param {?} creatingUser
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
            function (creatingUser, AppData, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: "operation=createSingleUser&creatingUser=" + creatingUser,
                    data: { AppData: AppData },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createAccount = /**
         * @template T
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
            function (AppData, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=createAccount',
                    data: { AppData: AppData },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} creatingUser
         * @param {?} file
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createBulkUser = /**
         * @template T
         * @param {?} creatingUser
         * @param {?} file
         * @param {?=} project
         * @return {?}
         */
            function (creatingUser, file, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: "operation=createBulkUser&creatingUser=" + creatingUser,
                    data: file,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} creatingUser
         * @param {?} file
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createBulkRolesandUsers = /**
         * @template T
         * @param {?} creatingUser
         * @param {?} file
         * @param {?=} project
         * @return {?}
         */
            function (creatingUser, file, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: "operation=createBulkRolesandUsers&creatingUser=" + creatingUser,
                    data: file,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.downloadBulkUsers = /**
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getBulkUser',
                    responseType: 'arraybuffer',
                    headers: headers,
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        /** @type {?} */
                        var blob = new Blob([resp.body], {
                            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel'
                        });
                        /** @type {?} */
                        var a = document.createElement("a");
                        a.href = URL.createObjectURL(blob);
                        a.download = "UserList.xlsx";
                        a.click();
                        observe.next();
                    }, function (error) {
                        console.log(error);
                        observe.error();
                    });
                });
            };
        /**
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.downloadUserTemplate = /**
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getTemplate',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        /** @type {?} */
                        var data1 = resp.body;
                        /** @type {?} */
                        var data = resp.body['statusCode']['AppData']['Base64Stream'];
                        /** @type {?} */
                        var bindata = window.atob(data);
                        /** @type {?} */
                        var len = bindata.length;
                        /** @type {?} */
                        var bytes = new Uint8Array(len);
                        for (var i = 0; i < len; i++) {
                            bytes[i] = bindata.charCodeAt(i);
                        }
                        /** @type {?} */
                        var file = new Blob([bytes.buffer], {
                            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
                        });
                        window.saveAs(file, "usertemplate" + ".xlsx");
                        observe.next();
                    }, function (error) {
                        observe.error();
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.deleteUser = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                if (!userName) {
                    rxjs.throwError('userName is not defined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=deleteUser&userName=' + userName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.deleteData(request).subscribe(function (resp) {
                        console.log(resp);
                        console.log(resp.body);
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} userInfo
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.modifyUser = /**
         * @template T
         * @param {?} userName
         * @param {?} userInfo
         * @param {?=} project
         * @return {?}
         */
            function (userName, userInfo, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                if (!userName) {
                    rxjs.throwError('userName is not defined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=modifyUser&userName=' + userName,
                    headers: headers,
                    data: { 'AppData': userInfo }
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewUser = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                if (!userName) {
                    rxjs.throwError('userName is not defined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getUser&userName=' + userName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewUserListAccordingtoRole = /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
            function (roleId, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                if (!roleId) {
                    rxjs.throwError('roleId is not defined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getUsersList&roleId=' + roleId,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.blockUser = /**
         * @template T
         * @param {?} userId
         * @param {?=} project
         * @return {?}
         */
            function (userId, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                if (!userId) {
                    rxjs.throwError('userId is not defined');
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=blockUser&userId=' + userId,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.checkUserExistence = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                if (!userName) {
                    rxjs.throwError('userName is not defined');
                }
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=checkUser&userName=' + userName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} index
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getAllUser = /**
         * @template T
         * @param {?} index
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
            function (index, size, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getAllUser&from=' + index + '&size=' + size,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getRestrictedUser = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getAllUserSelectedField',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createRole = /**
         * @template T
         * @param {?} roleData
         * @param {?=} project
         * @return {?}
         */
            function (roleData, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var currentDate = new Date();
                roleData.roleInfo.role['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                roleData.roleInfo.role['createdBy'] = this.cache.X_USERNAME;
                roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=createRole',
                    data: { 'AppData': roleData },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @return {?}
         */
        IamService.prototype.resetVariables = /**
         * @return {?}
         */
            function () {
                this.sessionService.globals = null;
                this.sessionService.selectedCircleName = null;
                this.sessionService.selectedNeName = null;
                this.sessionService.selectedNeShortName = null;
                this.sessionService.parsedNodeCircleJson = null;
                this.sessionService.nodeNameCircle = null;
                this.sessionService.structuredRestriction = null;
                this.sessionService.moduleRestriction = null;
                this.sessionService.mapNeNameCircleName = null;
                this.sessionService.nodeNameList = [];
            };
        /**
         * @param {?} key
         * @return {?}
         */
        IamService.prototype.getCookie = /**
         * @param {?} key
         * @return {?}
         */
            function (key) {
                /** @type {?} */
                var cookieStr = document.cookie;
                /** @type {?} */
                var cookies = cookieStr.split(';');
                /** @type {?} */
                var map = {};
                cookies.forEach(function (cookie) {
                    if (cookie) {
                        /** @type {?} */
                        var keyval = cookie.trim().split('=');
                        map[keyval[0].trim()] = keyval[1].trim();
                    }
                });
                return map[key];
            };
        /**
         * @param {?} module
         * @param {?} structuredJson
         * @return {?}
         */
        IamService.prototype.restructureAccessJson = /**
         * @param {?} module
         * @param {?} structuredJson
         * @return {?}
         */
            function (module, structuredJson) {
                for (var key in module) {
                    if (module.hasOwnProperty(key)) {
                        /** @type {?} */
                        var value = module[key];
                        if (value.access) {
                            /** @type {?} */
                            var access = {};
                            for (var ky in value.access) {
                                if (value.access.hasOwnProperty(key)) {
                                    /** @type {?} */
                                    var element = value.access[ky];
                                    switch (ky) {
                                        case 'R':
                                            access['Read'] = true;
                                            break;
                                        case 'W':
                                            access['Write'] = true;
                                            break;
                                        case 'D':
                                            access['Delete'] = true;
                                            break;
                                    }
                                }
                            }
                            structuredJson[key] = access;
                        }
                        else {
                            this.restructureAccessJson(value, structuredJson);
                        }
                    }
                }
                return structuredJson;
            };
        // var authToken="SC1.1:RD#SC1.2:RWD#SC1.3:RD#SC5.1:RD#SC2.1:RWD#SC3.2.1:RD";
        /**
         * @param {?} authToken
         * @return {?}
         */
        IamService.prototype.parseToken = /**
         * @param {?} authToken
         * @return {?}
         */
            function (authToken) {
                /** @type {?} */
                var json = {};
                if (!authToken) {
                    return json;
                }
                /** @type {?} */
                var tokens = authToken.split('#');
                for (var i = 0; i < tokens.length; i++) {
                    /** @type {?} */
                    var token = tokens[i];
                    /** @type {?} */
                    var shortCodes = token.split('.');
                    /** @type {?} */
                    var tempName = '';
                    /** @type {?} */
                    var temp = json;
                    for (var j = 0; j < shortCodes.length - 1; j++) {
                        /** @type {?} */
                        var shortCode = shortCodes[j];
                        if (tempName === '') {
                            tempName = shortCode;
                        }
                        else {
                            tempName = tempName + "." + shortCode;
                        }
                        if (!temp.hasOwnProperty(tempName)) {
                            temp[tempName] = {};
                        }
                        temp = temp[tempName];
                    }
                    if (tempName === '') {
                        tempName = shortCodes[shortCodes.length - 1].split(':')[0];
                    }
                    else {
                        tempName = tempName + "." + shortCodes[shortCodes.length - 1].split(':')[0];
                    }
                    if (!temp.hasOwnProperty(tempName)) {
                        /** @type {?} */
                        var restrictJson = {};
                        /** @type {?} */
                        var restriction = shortCodes[shortCodes.length - 1].split(':')[1].split('');
                        for (var k = 0; k < restriction.length; k++) {
                            restrictJson[restriction[k]] = true;
                        }
                        temp[tempName] = { access: restrictJson };
                    }
                }
                return json;
            };
        /**
         * @param {?} token
         * @return {?}
         */
        IamService.prototype.parseNodeCircleToken = /**
         * @param {?} token
         * @return {?}
         */
            function (token) {
                /** @type {?} */
                var parsedJson = {};
                if (!token || token === '') {
                    return parsedJson;
                }
                /** @type {?} */
                var singleNodeCircleList = token.split('#');
                for (var i = 0; i < singleNodeCircleList.length; i++) {
                    /** @type {?} */
                    var singleNodeCircle = singleNodeCircleList[i];
                    /** @type {?} */
                    var node = singleNodeCircle.split(':')[0];
                    /** @type {?} */
                    var circlesList = singleNodeCircle.split(':')[1].split(',');
                    /** @type {?} */
                    var circleJson = {};
                    for (var j = 0; j < circlesList.length; j++) {
                        circleJson[this.cache.circleFullNameJsonResponse['CircleName'][circlesList[j]]] = true;
                    }
                    parsedJson[node] = circleJson;
                }
                return parsedJson;
            };
        /**
         * @return {?}
         */
        IamService.prototype.neShortNameFullNameMapping = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var response = this.cache.neShortNameFullNameJson;
                /** @type {?} */
                var neShortName = this.sessionService.nodeNameList[0];
                if (response.NodeName) {
                    /** @type {?} */
                    var nodeFullName = response.NodeName[neShortName];
                    this.sessionService.selectedNeName = nodeFullName;
                }
                if (!this.cache.mapNeShortNameFullName) {
                    this.cache.mapNeShortNameFullName = {};
                }
                for (var itr = 0; itr < response.NodeName && this.sessionService.nodeNameList.length; itr++) {
                    this.cache.mapNeShortNameFullName[response.NodeName[this.sessionService.nodeNameList[itr]]] = this.sessionService.nodeNameList[itr];
                }
            };
        /**
         * @return {?}
         */
        IamService.prototype.neCircleShortNameFullNameMapping = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var response = this.cache.circleFullNameJsonResponse;
                /** @type {?} */
                var circleShortNamesList = this.sessionService.mapNeNameCircleName[this.sessionService.nodeNameList[0]];
                if (circleShortNamesList) {
                    /** @type {?} */
                    var circle = circleShortNamesList.split(',');
                    this.sessionService.selectedCircleName = response.CircleName[circle[0]];
                }
            };
        /**
         * @template T
         * @param {?} productId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getAccessJson = /**
         * @template T
         * @param {?} productId
         * @param {?=} project
         * @return {?}
         */
            function (productId, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getModuleSubModuleData&productId=' + productId,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} productId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getNodeCircleJson = /**
         * @template T
         * @param {?} productId
         * @param {?=} project
         * @return {?}
         */
            function (productId, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getNodeCircleData&productId=' + productId,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getModuleToIdJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getShortCodeToIdMap',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getNodeToIdJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getNodeToIdMap',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getCircleToIdJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getCircleToIdMap',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getCircleShortNameFullNameJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getCircleShortNameFullName',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getNodeShortNameFullNameJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getNodeShortNameFullName',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getOperationToModuleNodeCircleJson = /**
         * @template T
         * @param {?=} project
         * @return {?}
         */
            function (project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getOperationToModuleNodeCircle',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.deleteRole = /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
            function (roleId, project) {
                var _this = this;
                if (!roleId)
                    throw "Role id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=deleteRole&roleId=' + roleId,
                    headers: headers,
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.deleteData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleId
         * @param {?} roleData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.modifyRole = /**
         * @template T
         * @param {?} roleId
         * @param {?} roleData
         * @param {?=} project
         * @return {?}
         */
            function (roleId, roleData, project) {
                var _this = this;
                if (!roleId)
                    throw "Role id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var currentDate = new Date();
                roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=updateRole&roleId=' + roleId,
                    data: { "AppData": roleData },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewRole = /**
         * @template T
         * @param {?} roleId
         * @param {?=} project
         * @return {?}
         */
            function (roleId, project) {
                var _this = this;
                if (!roleId)
                    throw "Role id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=viewRole&roleId=' + roleId,
                    headers: headers,
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getAllRole = /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
            function (from, size, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=getAllRole&from=' + from + '&size=' + size,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} rolename
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.checkRoleExistence = /**
         * @template T
         * @param {?} rolename
         * @param {?=} project
         * @return {?}
         */
            function (rolename, project) {
                var _this = this;
                if (!rolename)
                    throw "rolename is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.ACCESS_CONTEXT,
                    queryString: 'operation=checkRole&roleName=' + rolename,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.createUserGroup = /**
         * @template T
         * @param {?} groupData
         * @param {?=} project
         * @return {?}
         */
            function (groupData, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var currentDate = new Date();
                groupData.groupInfo['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                groupData.groupInfo['createdBy'] = this.cache.X_USERNAME;
                groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=createGroup',
                    headers: headers,
                    data: { 'AppData': groupData }
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewUserGroup = /**
         * @template T
         * @param {?} groupId
         * @param {?=} project
         * @return {?}
         */
            function (groupId, project) {
                var _this = this;
                if (!groupId)
                    throw "groupId id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    headers: headers,
                    queryString: 'operation=viewGroup&groupId=' + groupId,
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewUserGroupList = /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
            function (from, size, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=viewGroupList&from=' + from + '&size=' + size,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.viewAllGroup = /**
         * @template T
         * @param {?} from
         * @param {?} size
         * @param {?=} project
         * @return {?}
         */
            function (from, size, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=viewAllGroup&from=' + from + '&size=' + size,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupId
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.deleteUserGroup = /**
         * @template T
         * @param {?} groupId
         * @param {?=} project
         * @return {?}
         */
            function (groupId, project) {
                var _this = this;
                if (!groupId)
                    throw "groupId id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=deleteGroup&groupId=' + groupId,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.deleteData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupId
         * @param {?} groupData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.modifyUserGroup = /**
         * @template T
         * @param {?} groupId
         * @param {?} groupData
         * @param {?=} project
         * @return {?}
         */
            function (groupId, groupData, project) {
                var _this = this;
                if (!groupId)
                    throw "groupId id is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var currentDate = new Date();
                groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
                groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=modifyGroup&groupId=' + groupId,
                    headers: headers,
                    data: { 'AppData': groupData }
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.lockUser = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=lockUser&userName=' + userName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.unlockUser = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=unlockUser&userName=' + userName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.lockGroup = /**
         * @template T
         * @param {?} groupName
         * @param {?=} project
         * @return {?}
         */
            function (groupName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=lockGroup&groupName=' + groupName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} groupName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.unlockGroup = /**
         * @template T
         * @param {?} groupName
         * @param {?=} project
         * @return {?}
         */
            function (groupName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=unlockGroup&groupName=' + groupName,
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} roleIdJson
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getCountUsers = /**
         * @template T
         * @param {?} roleIdJson
         * @param {?=} project
         * @return {?}
         */
            function (roleIdJson, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=getCountUsers',
                    headers: headers,
                    data: roleIdJson
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} oldPassword
         * @param {?} newPassword
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.changePassword = /**
         * @template T
         * @param {?} userName
         * @param {?} oldPassword
         * @param {?} newPassword
         * @param {?=} project
         * @return {?}
         */
            function (userName, oldPassword, newPassword, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=changePassword&userName=' + userName,
                    data: {
                        "userInfo": {
                            "userName": userName,
                            "oldUserPassword": AesUtils.encrypt(oldPassword),
                            "newUserPassword": AesUtils.encrypt(newPassword)
                        }
                    },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.forgotPassword = /**
         * @template T
         * @param {?} userName
         * @param {?=} project
         * @return {?}
         */
            function (userName, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                headers = headers.append("userName", userName);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=forgotPassoword',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} operation
         * @param {?} requestParameters
         * @param {?} requestHeaders
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.insertTraceData = /**
         * @template T
         * @param {?} userName
         * @param {?} operation
         * @param {?} requestParameters
         * @param {?} requestHeaders
         * @param {?=} project
         * @return {?}
         */
            function (userName, operation, requestParameters, requestHeaders, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var currentDate = new Date();
                headers = headers.append("userName", userName).append("operation", operation).append("timestamp", currentDate.getTime().toString());
                /** @type {?} */
                var request = {
                    context: CONSTANTS.TRACE_CONTEXT,
                    queryString: 'operation=insertTraceData',
                    data: {
                        "requestParameters": { requestParameters: requestParameters },
                        "requestHeaders": { requestHeaders: requestHeaders },
                    },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} operation
         * @param {?} traceLevel
         * @param {?} fromTimeStamp
         * @param {?} toTimeStamp
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.getTraceData = /**
         * @template T
         * @param {?} userName
         * @param {?} operation
         * @param {?} traceLevel
         * @param {?} fromTimeStamp
         * @param {?} toTimeStamp
         * @param {?=} project
         * @return {?}
         */
            function (userName, operation, traceLevel, fromTimeStamp, toTimeStamp, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                headers = headers.append("userName", userName).append("operation", operation).append("traceLevel", traceLevel).append("fromTimeStamp", fromTimeStamp).append("toTimeStamp", toTimeStamp);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.TRACE_CONTEXT,
                    queryString: 'operation=getTraceData',
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.getData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} otp
         * @param {?} newPassword
         * @param {?} confirmPassword
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.resetPassword = /**
         * @template T
         * @param {?} userName
         * @param {?} otp
         * @param {?} newPassword
         * @param {?} confirmPassword
         * @param {?=} project
         * @return {?}
         */
            function (userName, otp, newPassword, confirmPassword, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                headers = headers.append("userName", userName);
                /** @type {?} */
                var password = RsaUtils.encrypt(newPassword);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=resetPassword',
                    data: {
                        "userInfo": {
                            "userName": userName,
                            "newPassword": password,
                            "confirmPassword": password,
                            "otp": otp
                        }
                    },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} otp
         * @param {?} newPassword
         * @param {?} confirmPassword
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.generatePassword = /**
         * @template T
         * @param {?} userName
         * @param {?} otp
         * @param {?} newPassword
         * @param {?} confirmPassword
         * @param {?=} project
         * @return {?}
         */
            function (userName, otp, newPassword, confirmPassword, project) {
                var _this = this;
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                headers = headers.append("userName", userName);
                /** @type {?} */
                var password = RsaUtils.encrypt(newPassword);
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=generatePassword',
                    data: {
                        "userInfo": {
                            "userName": userName,
                            "newPassword": password,
                            "confirmPassword": password,
                            "otp": otp
                        }
                    },
                    headers: headers
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        /**
         * @template T
         * @param {?} userName
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
        IamService.prototype.modifyUserImage = /**
         * @template T
         * @param {?} userName
         * @param {?} AppData
         * @param {?=} project
         * @return {?}
         */
            function (userName, AppData, project) {
                var _this = this;
                if (!userName)
                    throw "userName is undefined";
                /** @type {?} */
                var headers;
                if (!project) {
                    headers = new i1.HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
                }
                else {
                    headers = new i1.HttpHeaders({ 'project': project });
                }
                /** @type {?} */
                var request = {
                    context: CONSTANTS.IDENTITY_CONTEXT,
                    queryString: 'operation=modifyUserImage&userName=' + userName,
                    headers: headers,
                    data: {
                        'AppData': AppData
                    }
                };
                return new rxjs.Observable(function (observe) {
                    _this.httpService.postData(request).subscribe(function (resp) {
                        observe.next(resp.body);
                    }, function (error) {
                        observe.error(error);
                    });
                });
            };
        IamService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        IamService.ctorParameters = function () {
            return [
                { type: HttpService },
                { type: AppConfigurationService },
                { type: SessionService },
                { type: CacheManagerService },
                { type: i1$1.Router },
                { type: i4.Location }
            ];
        };
        /** @nocollapse */ IamService.ngInjectableDef = i0.defineInjectable({ factory: function IamService_Factory() { return new IamService(i0.inject(HttpService), i0.inject(AppConfigurationService), i0.inject(SessionService), i0.inject(CacheManagerService), i0.inject(i1$1.Router), i0.inject(i4.Location)); }, token: IamService, providedIn: "root" });
        return IamService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var HttpResponseInterceptor = (function () {
        function HttpResponseInterceptor(sessionService, appConfiguration, cache) {
            this.sessionService = sessionService;
            this.appConfiguration = appConfiguration;
            this.cache = cache;
        }
        /**
         * @param {?} req
         * @param {?} next
         * @return {?}
         */
        HttpResponseInterceptor.prototype.intercept = /**
         * @param {?} req
         * @param {?} next
         * @return {?}
         */
            function (req, next) {
                var _this = this;
                if (this.cache.X_SOCKET_ADDRESS) {
                    req = req.clone({
                        setHeaders: {
                            'X-SOCKET-ADDRESS': this.cache.X_SOCKET_ADDRESS
                        }
                    });
                }
                if (this.cache.X_USERNAME) {
                    req = req.clone({
                        setHeaders: {
                            'X-USERNAME': this.cache.X_USERNAME
                        }
                    });
                }
                if (this.cache.SOCKET_IP) {
                    req = req.clone({
                        setHeaders: {
                            'socketIp': this.cache.SOCKET_IP
                        }
                    });
                }
                if (req.headers.has('X-Event-Name')) {
                    req = req.clone({
                        setHeaders: {
                            operation: req.headers.get('X-Event-Name')
                        }
                    });
                }
                else if (req.headers.has('Event-Key')) {
                    req = req.clone({
                        setHeaders: {
                            operation: req.headers.get('Event-Key')
                        }
                    });
                }
                else if (req.params.has('operation')) {
                    req = req.clone({
                        setHeaders: {
                            operation: req.params.get('operation')
                        }
                    });
                }
                if (this.sessionService.getSessionData().globals && this.sessionService.getSessionData().globals.currentUser &&
                    this.sessionService.getSessionData().globals.currentUser.userName &&
                    this.appConfiguration.getConfiguration() && this.appConfiguration.getConfiguration().project) {
                    /** @type {?} */
                    var userToken = this.sessionService.getUserTokenData();
                    /** @type {?} */
                    var userName = this.sessionService.getSessionData().globals.currentUser.userName;
                    /** @type {?} */
                    var product = void 0;
                    product = req.headers.get("project");
                    if (!product) {
                        product = this.appConfiguration.getConfiguration().project;
                    }
                    req = req.clone({
                        setHeaders: {
                            userToken: userName + "-" + userToken,
                            project: product
                        }
                    });
                }
                return next.handle(req).pipe(operators.tap(function (response) {
                    if (response instanceof i1.HttpResponse) {
                        /** @type {?} */
                        var resp = (response);
                        if (resp.headers.has('userToken')) {
                            _this.sessionService.setUserTokenData(resp.headers.get('userToken'));
                            _this.sessionService.putDateForCookieExpiry();
                        }
                        if (response.body && response.body['statusCode'] &&
                            response.body['statusCode']['httpstatuscode']) {
                            if (response.body['statusCode']['httpstatuscode'] === 401 && (response.body['statusCode']['opStatusCode']
                                === 903 || response.body['statusCode']['opStatusCode'] === 4030)) {
                                _this.sessionService.clearSessionDataAndGotoSessionExpirePage();
                            }
                        }
                    }
                }));
            };
        HttpResponseInterceptor.decorators = [
            { type: i0.Injectable },
        ];
        /** @nocollapse */
        HttpResponseInterceptor.ctorParameters = function () {
            return [
                { type: SessionService },
                { type: AppConfigurationService },
                { type: CacheManagerService }
            ];
        };
        return HttpResponseInterceptor;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var IamComponent = (function () {
        function IamComponent() {
        }
        /**
         * @return {?}
         */
        IamComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        IamComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-iam',
                        template: "\n    <p>\n      iam works!\n    </p>\n  ",
                        styles: []
                    },] },
        ];
        /** @nocollapse */
        IamComponent.ctorParameters = function () { return []; };
        return IamComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /**
     * @param {?} appConfigurationService
     * @param {?} cache
     * @return {?}
     */
    function initializeApp(appConfigurationService, cache) {
        return function () {
            return new Promise(function (resolve, reject) {
                appConfigurationService.loadConfiguration('assets/configuration/config.json').then(function () {
                    /** @type {?} */
                    var getRsaKeyPromise = cache.getAuthKey();
                    /** @type {?} */
                    var startUpRouteChangePromise = cache.onStartupRouteChange(event);
                    Promise.all([getRsaKeyPromise, startUpRouteChangePromise]).then(function () {
                        /** @type {?} */
                        var nodeShortFullPromise = cache.getNodeShortNameFullNameJson();
                        /** @type {?} */
                        var circleShortFullPromise = cache.getCircleShortNameFullNameJson();
                        /** @type {?} */
                        var moduleToIdPromise = cache.getModuleToIdJson();
                        /** @type {?} */
                        var nodeToIdPromise = cache.getNodeToIdJson();
                        /** @type {?} */
                        var circleToIdPromise = cache.getCircleToIdJson();
                        /** @type {?} */
                        var operationToModuleNodeCirclePromise = cache.getOperationToModuleNodeCircleJson();
                        Promise.all([nodeShortFullPromise, circleShortFullPromise, moduleToIdPromise,
                            nodeToIdPromise, circleToIdPromise, operationToModuleNodeCirclePromise]).then(function () {
                            cache.callWhenConfigLoads();
                            resolve();
                        }, function (error) {
                            console.log(error);
                            reject();
                        });
                    }, function (error) {
                        console.log(error);
                        reject();
                    });
                }, function (error) {
                    console.log(error);
                    reject();
                });
            });
        };
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var ɵ0 = initializeApp;
    var IamModule = (function () {
        function IamModule() {
        }
        /**
         * @return {?}
         */
        IamModule.forRoot = /**
         * @return {?}
         */
            function () {
                return {
                    ngModule: IamModule,
                    providers: []
                };
            };
        IamModule.decorators = [
            { type: i0.NgModule, args: [{
                        imports: [],
                        declarations: [IamComponent],
                        exports: [IamComponent],
                        providers: [IamService, ngxCookieService.CookieService, SessionService, AppConfigurationService, CacheManagerService, {
                                provide: i0.APP_INITIALIZER,
                                useFactory: ɵ0,
                                deps: [AppConfigurationService, CacheManagerService],
                                multi: true
                            }, {
                                provide: i1.HTTP_INTERCEPTORS,
                                useClass: HttpResponseInterceptor,
                                multi: true
                            }]
                    },] },
        ];
        return IamModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */

    exports.IamService = IamService;
    exports.AppConfigurationService = AppConfigurationService;
    exports.CacheManagerService = CacheManagerService;
    exports.CONSTANTS = CONSTANTS;
    exports.HttpResponseInterceptor = HttpResponseInterceptor;
    exports.HttpService = HttpService;
    exports.MessageMapping = MessageMapping;
    exports.NavigateService = NavigateService;
    exports.SessionService = SessionService;
    exports.WebSocketCallbackClass = WebSocketCallbackClass;
    exports.IamComponent = IamComponent;
    exports.IamModule = IamModule;
    exports.ɵa = initializeApp;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWFtLnVtZC5qcy5tYXAiLCJzb3VyY2VzIjpbbnVsbCwibmc6Ly9pYW0vbGliL2NvbnN0YW50LnRzIiwibmc6Ly9pYW0vbGliL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UudHMiLCJuZzovL2lhbS9saWIvcnNhLXV0aWxzLnRzIiwibmc6Ly9pYW0vbGliL2Flcy11dGlscy50cyIsIm5nOi8vaWFtL2xpYi9uYXZpZ2F0ZS5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL3Nlc3Npb24uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi93ZWItc29ja2V0LWNhbGxiYWNrcy1jbGFzcy50cyIsIm5nOi8vaWFtL2xpYi9tZXNzYWdlLW1hcHBpbmcudHMiLCJuZzovL2lhbS9saWIvY2FjaGUtbWFuYWdlci5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL2h0dHAuc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9pYW0uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9odHRwLXJlc3BvbnNlLWludGVyY2VwdG9yLnRzIiwibmc6Ly9pYW0vbGliL2lhbS5jb21wb25lbnQudHMiLCJuZzovL2lhbS9saWIvY29uZmlndXJhdGlvbi1mYWN0b3J5LnRzIiwibmc6Ly9pYW0vbGliL2lhbS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UgKi9cclxuXHJcbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcclxuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XHJcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJleHBvcnQgY2xhc3MgQ09OU1RBTlRTIHtcclxuICAgIC8vcHVibGljIHN0YXRpYyByZWFkb25seSBTRVNTSU9OX1RJTUVPVVQ6IG51bWJlciA9IDEgKiA2MCAqIDYwICogMTAwMDtcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUFJPVE9DT0w6IHN0cmluZyA9IGAke2xvY2F0aW9uLnByb3RvY29sfS8vYDtcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgV0VCU09DS0VUX1BST1RPQ09MOiBzdHJpbmcgPSBsb2NhdGlvbi5wcm90b2NvbC5sb2NhbGVDb21wYXJlKCdodHRwczonKSA9PT0gMCA/ICd3c3M6Ly8nIDogJ3dzOi8vJztcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgSURFTlRJVFlfQ09OVEVYVDogc3RyaW5nID0gJy9JQU0vaWRlbnRpdHkvJztcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQUNDRVNTX0NPTlRFWFQ6IHN0cmluZyA9ICcvSUFNL2FjY2Vzcy8nO1xyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBUUkFDRV9DT05URVhUOiBzdHJpbmcgPSAnL0lBTS90cmFjZS8nO1xyXG4gICAgZ2V0UHJvdG9jb2woKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gbG9jYXRpb24ucHJvdG9jb2w7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQXBwQ29uZmlndXJhdGlvblNlcnZpY2Uge1xyXG4gIHByaXZhdGUgYXBwQ29uZmlndXJhdGlvbjogQXBwQ29uZmlndXJhdGlvbjtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHsgfVxyXG4gIGxvYWRDb25maWd1cmF0aW9uKGZpbGVQYXRoOiBzdHJpbmcpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPiAoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEFwcENvbmZpZ3VyYXRpb24+KGZpbGVQYXRoKS50b1Byb21pc2UoKS50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHRoaXMuYXBwQ29uZmlndXJhdGlvbiA9IHJlc3BvbnNlO1xyXG4gICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgfSkuY2F0Y2goKHJlc3BvbnNlOiBhbnkpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGBjb3VsZCBub3QgbG9hZCBjb25maWd1cmF0aW9uIGZpbGUgZXJyb3I6IFxcbiAke0pTT04uc3RyaW5naWZ5KHJlc3BvbnNlKX1gKTtcclxuICAgICAgICAgIHJlamVjdChgY291bGQgbm90IGxvYWQgY29uZmlndXJhdGlvbiBmaWxlIGVycm9yOiBcXG4gJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHB1YmxpYyBnZXRDb25maWd1cmF0aW9uKCk6IEFwcENvbmZpZ3VyYXRpb24ge1xyXG4gICAgcmV0dXJuIHRoaXMuYXBwQ29uZmlndXJhdGlvbjtcclxuICB9XHJcbiAgXHJcbn1cclxuZXhwb3J0IGludGVyZmFjZSBBcHBDb25maWd1cmF0aW9uIHtcclxuICBpcDogc3RyaW5nO1xyXG4gIHBvcnQ6IG51bWJlcjtcclxuICB3ZWJzb2NrZXRQb3J0OiBudW1iZXI7XHJcbiAgcHJvamVjdDogc3RyaW5nO1xyXG4gIG5vblJlc3RyaWN0ZWRQYWdlczogQXJyYXk8c3RyaW5nPjtcclxuICBkZWZhdWx0UGFnZUFmdGVyTG9naW46IHN0cmluZztcclxuICBsb2dpblBhZ2U6IHN0cmluZztcclxuICBzZXNzaW9uRXhwaXJlZFBhZ2U6IHN0cmluZztcclxuICBsb2dvdXRQYXRoOiBzdHJpbmc7XHJcbiAgY2xpZW50U2lkZVJlcXVlc3RCYXJyaW5nOiBib29sZWFuO1xyXG4gIHNlc3Npb25UaW1lT3V0OiBudW1iZXI7XHJcbn1cclxuIiwiY29uc3QgIGZvcmdlID0gcmVxdWlyZSgnbm9kZS1mb3JnZScpO1xyXG5leHBvcnQgY2xhc3MgUnNhVXRpbHMge1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgcHVibGljS2V5ID0gbnVsbDtcclxuICAgIHByaXZhdGUgc3RhdGljIHByaXZhdGVLZXkgPSBudWxsO1xyXG4gICAgY29uc3RydWN0b3IoKSB7fVxyXG4gICAgcHVibGljIHN0YXRpYyBwcml2YXRlS2V5RnJvbVBFTShwZW1fZmlsZV9jb250ZW50OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBSc2FVdGlscy5wcml2YXRlS2V5ID0gZm9yZ2UucGtpLnByaXZhdGVLZXlGcm9tUGVtKHBlbV9maWxlX2NvbnRlbnQpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBwdWJsaWNLZXlUb1BFTSgpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiBmb3JnZS5wa2kucHVibGljS2V5VG9QZW0oUnNhVXRpbHMucHVibGljS2V5KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgcHVibGljS2V5RnJvbVBFTShwZW1fZmlsZV9jb250ZW50OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBSc2FVdGlscy5wdWJsaWNLZXkgPSBmb3JnZS5wa2kucHVibGljS2V5RnJvbVBlbShwZW1fZmlsZV9jb250ZW50KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZW5jcnlwdChtZXNzYWdlOiBzdHJpbmcsIHBlbVB1YmxpY0tleT86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHBlbVB1YmxpY0tleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9yZ2UudXRpbC5lbmNvZGU2NChmb3JnZS5wa2kucHJpdmF0ZUtleUZyb21QZW0ocGVtUHVibGljS2V5KS5lbmNyeXB0KG1lc3NhZ2UsICdSU0EtT0FFUCcsIHtcclxuICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGEyNTYuY3JlYXRlKCksXHJcbiAgICAgICAgICAgICAgICBtZ2YxOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWQ6IGZvcmdlLm1kLnNoYTEuY3JlYXRlKClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoUnNhVXRpbHMucHVibGljS2V5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmb3JnZS51dGlsLmVuY29kZTY0KFJzYVV0aWxzLnB1YmxpY0tleS5lbmNyeXB0KG1lc3NhZ2UsICdSU0EtT0FFUCcsIHtcclxuICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGEyNTYuY3JlYXRlKCksXHJcbiAgICAgICAgICAgICAgICBtZ2YxOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWQ6IGZvcmdlLm1kLnNoYTEuY3JlYXRlKClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdwdWJsaWMga2V5IGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZGVjcnlwdChjaXBoZXJUZXh0OiBzdHJpbmcsIHBlbVByaXZhdGVLZXk/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChwZW1Qcml2YXRlS2V5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmb3JnZS5wa2kucHJpdmF0ZUtleUZyb21QZW0ocGVtUHJpdmF0ZUtleSkuZGVjcnlwdChmb3JnZS51dGlsLmRlY29kZTY0KGNpcGhlclRleHQpLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoUnNhVXRpbHMucHJpdmF0ZUtleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gUnNhVXRpbHMucHJpdmF0ZUtleS5kZWNyeXB0KGZvcmdlLnV0aWwuZGVjb2RlNjQoY2lwaGVyVGV4dCksICdSU0EtT0FFUCcsIHtcclxuICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGEyNTYuY3JlYXRlKCksXHJcbiAgICAgICAgICAgICAgICBtZ2YxOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWQ6IGZvcmdlLm1kLnNoYTEuY3JlYXRlKClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3ByaXZhdGUga2V5IGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHByaXZhdGVLZXlUb1BFTSgpOiBzdHJpbmcge1xyXG4gICAgICAgIGNvbnN0IHJzYVByaXZhdGVLZXkgPSBmb3JnZS5wa2kucHJpdmF0ZUtleVRvQXNuMShSc2FVdGlscy5wcml2YXRlS2V5KTtcclxuICAgICAgICBjb25zdCBwcml2YXRlS2V5SW5mbyA9IGZvcmdlLnBraS53cmFwUnNhUHJpdmF0ZUtleShyc2FQcml2YXRlS2V5KTtcclxuICAgICAgICByZXR1cm4gZm9yZ2UucGtpLnByaXZhdGVLZXlJbmZvVG9QZW0ocHJpdmF0ZUtleUluZm8pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCAqIGFzIGFlc2pzIGZyb20gJ2Flcy1qcyc7XHJcbmltcG9ydCB7IE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEFlc1V0aWxzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHByaXZhdGUgc3RhdGljIGFlc0tleTogc3RyaW5nID0gbnVsbDtcclxuICAgIGNvbnN0cnVjdG9yKCkge31cclxuICAgIHB1YmxpYyBzdGF0aWMgc2V0QWVzRW5jcnlwdGlvbktleShhZXNLZXk6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIEFlc1V0aWxzLmFlc0tleSA9IGFlc0tleTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZW5jcnlwdChtZXNzYWdlOiBzdHJpbmcsIGFlc0tleT86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFhZXNLZXkpIHtcclxuICAgICAgICAgICAgYWVzS2V5ID0gQWVzVXRpbHMuYWVzS2V5O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBrZXkgPSBhZXNqcy51dGlscy51dGY4LnRvQnl0ZXMoYWVzS2V5KTtcclxuICAgICAgICBsZXQgdGV4dEJ5dGVzID0gYWVzanMudXRpbHMudXRmOC50b0J5dGVzKG1lc3NhZ2UpO1xyXG4gICAgICAgIHRleHRCeXRlcyA9IG5ldyBhZXNqcy5wYWRkaW5nLnBrY3M3LnBhZCh0ZXh0Qnl0ZXMpO1xyXG4gICAgICAgIGNvbnN0IGFlc0VjYiA9IG5ldyBhZXNqcy5Nb2RlT2ZPcGVyYXRpb24uZWNiKGtleSk7XHJcbiAgICAgICAgY29uc3QgZW5jcnlwdGVkQnl0ZXMgPSBhZXNFY2IuZW5jcnlwdCh0ZXh0Qnl0ZXMpO1xyXG4gICAgICAgIHJldHVybiBhZXNqcy51dGlscy5oZXguZnJvbUJ5dGVzKGVuY3J5cHRlZEJ5dGVzKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZGVjcnlwdChjaXBoZXI6IHN0cmluZywgYWVzS2V5Pzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoIWFlc0tleSkge1xyXG4gICAgICAgICAgICBhZXNLZXkgPSBBZXNVdGlscy5hZXNLZXk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGtleSA9IGFlc2pzLnV0aWxzLnV0ZjgudG9CeXRlcyhhZXNLZXkpO1xyXG4gICAgICAgIGNvbnN0IGFlc0VjYiA9IG5ldyBhZXNqcy5Nb2RlT2ZPcGVyYXRpb24uZWNiKGtleSk7XHJcbiAgICAgICAgY29uc3QgZW5jcnlwdGVkQnl0ZXMgPSBhZXNqcy51dGlscy5oZXgudG9CeXRlcyhjaXBoZXIpO1xyXG4gICAgICAgIGxldCBkZWNyeXB0ZWRCeXRlcyA9IGFlc0VjYi5kZWNyeXB0KGVuY3J5cHRlZEJ5dGVzKTtcclxuICAgICAgICBkZWNyeXB0ZWRCeXRlcyA9IGFlc2pzLnBhZGRpbmcucGtjczcuc3RyaXAoZGVjcnlwdGVkQnl0ZXMpO1xyXG4gICAgICAgIHJldHVybiAgYWVzanMudXRpbHMudXRmOC5mcm9tQnl0ZXMoZGVjcnlwdGVkQnl0ZXMpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZW5lcmF0ZVJhbmRvbUFlc0tleShsZW5ndGg6IG51bWJlcj0gMTYpOiBzdHJpbmcge1xyXG4gICAgICAgIGNvbnN0IG1hcDogTWFwPG51bWJlciwgc3RyaW5nPiA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XHJcbiAgICAgICAgbWFwLnNldCgwLCAnYScpLnNldCgxLCAnYicpLnNldCgyLCAnYycpLnNldCgzLCAnZCcpLnNldCg0LCAnZScpLnNldCg1LCAnZicpLlxyXG4gICAgICAgIHNldCg2LCAnZycpLnNldCg3LCAnaCcpLnNldCg4LCAnaScpLnNldCg5LCAnaicpLnNldCgxMCwgJ2snKS5zZXQoMTEsICdsJykuc2V0KDEyLCAnbScpLlxyXG4gICAgICAgIHNldCgxMywgJ24nKS5zZXQoMTQsICdvJykuc2V0KDE1LCAncCcpLnNldCgxNiwgJ3EnKS5zZXQoMTcsICdyJykuXHJcbiAgICAgICAgc2V0KDE4LCAncycpLnNldCgxOSwgJ3QnKS5zZXQoMjAsICd1Jykuc2V0KDIxLCAndicpLnNldCgyMiwgJ3cnKS5zZXQoMjMsICd4Jykuc2V0KDI0LCAneScpLlxyXG4gICAgICAgIHNldCgyNSwgJ3onKS5zZXQoMjYsICdBJykuc2V0KDI3LCAnQicpLnNldCgyOCwgJ0MnKS5zZXQoMjksICdEJykuc2V0KDMwLCAnRScpLnNldCgzMSwgJ0YnKS5cclxuICAgICAgICBzZXQoMzIsICdHJykuc2V0KDMzLCAnSCcpLnNldCgzNCwgJ0knKS5zZXQoMzUsICdKJykuc2V0KDM2LCAnSycpLnNldCgzNywgJ0wnKS5zZXQoMzgsICdNJykuXHJcbiAgICAgICAgc2V0KDM5LCAnTicpLnNldCg0MCwgJ08nKS5zZXQoNDEsICdQJykuc2V0KDQyLCAnUScpLnNldCg0MywgJ1InKS5zZXQoNDQsICdTJykuc2V0KDQ1LCAnVCcpLlxyXG4gICAgICAgIHNldCg0NiwgJ1UnKS5zZXQoNDcsICdWJykuc2V0KDQ4LCAnVycpLnNldCg0OSwgJ1gnKS5zZXQoNTAsICdZJykuc2V0KDUxLCAnWicpO1xyXG4gICAgICAgIGxldCBrZXkgPSAnJztcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGtleSA9IGtleS5jb25jYXQobWFwLmdldChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA1MikpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGtleTtcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIE5hdmlnYXRlU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGVyOiBSb3V0ZXIpIHsgfVxyXG4gIG5hdmlnYXRlKHBhdGg6IHN0cmluZ1tdKTogdm9pZCB7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShwYXRoKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvb2tpZVNlcnZpY2UgfSBmcm9tICduZ3gtY29va2llLXNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDT05TVEFOVFMgfSBmcm9tICcuL2NvbnN0YW50JztcclxuaW1wb3J0IHsgQWVzVXRpbHMgfSBmcm9tICcuL2Flcy11dGlscyc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIGFzIEFwcFNldHRpbmcgfSBmcm9tICcuL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgKiBhcyBGaW5nZXJwcmludDIgZnJvbSAnZmluZ2VycHJpbnRqczJzeW5jJztcclxuaW1wb3J0IHsgTmF2aWdhdGVTZXJ2aWNlIH0gZnJvbSAnLi9uYXZpZ2F0ZS5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBTZXNzaW9uU2VydmljZSB7XHJcblxyXG4gIHByaXZhdGUgaGFzaEtleTogc3RyaW5nID0gbmV3IEZpbmdlcnByaW50Mih7ZXhjbHVkZUFkQmxvY2sgOiB0cnVlfSkuZ2V0U3luYygpLmZwcmludC5zdWJzdHIoMCwgMTYpO1xyXG4gIHB1YmxpYyBnbG9iYWxzOiBhbnk7XHJcbiAgcHVibGljIHNlbGVjdGVkQ2lyY2xlTmFtZTogc3RyaW5nO1xyXG4gIHB1YmxpYyBzZWxlY3RlZE5lTmFtZTogc3RyaW5nO1xyXG4gIHB1YmxpYyBzZWxlY3RlZE5lU2hvcnROYW1lOiBzdHJpbmc7XHJcbiAgcHVibGljIHBhcnNlZE5vZGVDaXJjbGVKc29uOiBhbnk7XHJcbiAgcHVibGljIG5vZGVOYW1lQ2lyY2xlOiBhbnk7XHJcbiAgcHVibGljIHN0cnVjdHVyZWRSZXN0cmljdGlvbjogYW55O1xyXG4gIHB1YmxpYyBtb2R1bGVSZXN0cmljdGlvbjogYW55O1xyXG4gIHB1YmxpYyBtYXBOZU5hbWVDaXJjbGVOYW1lOiBhbnk7XHJcbiAgcHVibGljIG5vZGVOYW1lTGlzdDogYW55O1xyXG4gIHB1YmxpYyBjb25zdHJ1Y3Rvcihwcml2YXRlIGNvb2tpZVNlcnZpY2U6IENvb2tpZVNlcnZpY2UsIHByaXZhdGUgYXBwU2V0dGluZzogQXBwU2V0dGluZywgcHJpdmF0ZSBuYXZpZ2F0ZVNlcnZpY2U6IE5hdmlnYXRlU2VydmljZSkge31cclxuICAvKlxyXG4gICpUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gZmV0Y2ggc3RvcmVkIHNlc3Npb24gZGF0YVxyXG4gICovXHJcbiAgZ2V0U2Vzc2lvbkRhdGEoa2V5OiBzdHJpbmcgPSAnZ2xvYmFscycpOiBSZXNwb25zZVNlc3Npb25EYXRhIHtcclxuICAgIGNvbnN0IGNvb2tpZTogUmVzcG9uc2VTZXNzaW9uRGF0YSA9IHt9O1xyXG4gICAgbGV0IGRhdGE6IEpTT047XHJcbiAgICBjb25zdCBleHBpcnlUaW1lOiBudW1iZXIgPSB0aGlzLmdldERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgIGlmIChleHBpcnlUaW1lID4gbmV3IERhdGUoKS5nZXRUaW1lKCkpIHtcclxuICAgICAgICBkYXRhID0gSlNPTi5wYXJzZSh0aGlzLmNvb2tpZVNlcnZpY2UuY2hlY2soa2V5KSA/IEFlc1V0aWxzLmRlY3J5cHQodGhpcy5jb29raWVTZXJ2aWNlLmdldChrZXkpLCB0aGlzLmhhc2hLZXkpIDogJ3t9Jyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZygnaW50byBjbGVhcmluZyBzZXNzaW9uJyk7XHJcbiAgICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgICBkYXRhID0ge30gYXMgSlNPTjtcclxuICAgIH1cclxuICAgIHJldHVybiBkYXRhIGFzIFJlc3BvbnNlU2Vzc2lvbkRhdGE7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0QWVzS2V5KGtleTogc3RyaW5nID0gJ2Flc0tleScpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLmNvb2tpZVNlcnZpY2UuY2hlY2soa2V5KSA/IEFlc1V0aWxzLmRlY3J5cHQodGhpcy5jb29raWVTZXJ2aWNlLmdldChrZXkpLCB0aGlzLmhhc2hLZXkpIDogbnVsbDtcclxuICAgIH1cclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgc2V0U2Vzc2lvbkRhdGEoc2Vzc2lvbkRhdGE6IFJlcXVlc3RTZXNzaW9uRGF0YSwga2V5ID0gJ2dsb2JhbHMnICk6IHZvaWQge1xyXG4gICAgY29uc3QgZGF0YSA9IHt9O1xyXG4gICAgY29uc3QgdXNlckluZm9ybWF0aW9uID0ge1xyXG4gICAgICAgIGN1cnJlbnRVc2VyOiB7XHJcbiAgICAgICAgICB1c2VyTmFtZTogc2Vzc2lvbkRhdGEudXNlck5hbWUsXHJcbiAgICAgICAgICBhcHBEYXRhOiBzZXNzaW9uRGF0YS5hcHBEYXRhLFxyXG4gICAgICAgICAgbm9kZU5hbWVDaXJjbGU6IHNlc3Npb25EYXRhLm5vZGVOYW1lQ2lyY2xlXHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIGlmIChzZXNzaW9uRGF0YS5uZU5hbWVDaXJjbGVOYW1lKSB7XHJcbiAgICAgIHVzZXJJbmZvcm1hdGlvbi5jdXJyZW50VXNlclsnbmVOYW1lQ2lyY2xlTmFtZSddID0gc2Vzc2lvbkRhdGEubmVOYW1lQ2lyY2xlTmFtZTtcclxuICAgIH1cclxuICAgIGlmIChzZXNzaW9uRGF0YS5hZXNLZXkpIHtcclxuICAgICAgZGF0YVsnYWVzS2V5J10gPSBzZXNzaW9uRGF0YS5hZXNLZXk7XHJcbiAgICB9XHJcbiAgICBkYXRhW2tleV0gPSB1c2VySW5mb3JtYXRpb247XHJcbiAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KGtleSwgQWVzVXRpbHMuZW5jcnlwdChKU09OLnN0cmluZ2lmeShkYXRhKSwgdGhpcy5oYXNoS2V5KSk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgY2xlYXJTZXNzaW9uRGF0YSguLi5hcmdzOiBzdHJpbmdbXSk6IHZvaWQge1xyXG4gICAgaWYgKCBhcmdzLmxlbmd0aCA+IDApIHtcclxuICAgICAgZm9yIChjb25zdCBhcmcgb2YgYXJncykge1xyXG4gICAgICAgIHRoaXMuY29va2llU2VydmljZS5kZWxldGUoYXJnKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5jb29raWVTZXJ2aWNlLmRlbGV0ZUFsbCgpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2UuY2xlYXIoKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBwdXREYXRlRm9yQ29va2llRXhwaXJ5KHRpbWVTdGFtcD86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgbGV0IHNlc3Npb25UaW1lOm51bWJlcj02MDAwMDA7XHJcbiAgICBpZih0aGlzLmFwcFNldHRpbmcuZ2V0Q29uZmlndXJhdGlvbigpKVxyXG4gICAge1xyXG4gICAgICBzZXNzaW9uVGltZT10aGlzLmFwcFNldHRpbmcuZ2V0Q29uZmlndXJhdGlvbigpLnNlc3Npb25UaW1lT3V0O1xyXG4gICAgfVxyXG4gICAgaWYgKCF0aW1lU3RhbXApIHtcclxuICAgICAgdGhpcy5jb29raWVTZXJ2aWNlLnNldCgnZXhwaXJ5VGltZScsIChuZXcgRGF0ZSgpLmdldFRpbWUoKSArIHNlc3Npb25UaW1lKS50b1N0cmluZygpKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuY29va2llU2VydmljZS5zZXQoJ2V4cGlyeVRpbWUnLCB0aW1lU3RhbXApO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGdldERhdGVGb3JDb29raWVFeHBpcnkoKTogbnVtYmVyIHtcclxuICAgIGxldCBzZXNzaW9uVGltZTpudW1iZXI9NjAwMDAwO1xyXG4gICAgaWYodGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKSlcclxuICAgIHtcclxuICAgICAgc2Vzc2lvblRpbWU9dGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uVGltZU91dDtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmNvb2tpZVNlcnZpY2UuY2hlY2soJ2V4cGlyeVRpbWUnKSkge1xyXG4gICAgIHJldHVybiBOdW1iZXIucGFyc2VJbnQodGhpcy5jb29raWVTZXJ2aWNlLmdldCgnZXhwaXJ5VGltZScpKTtcclxuICAgIH1cclxuICAgIHRoaXMuY29va2llU2VydmljZS5zZXQoJ2V4cGlyeVRpbWUnLCAobmV3IERhdGUoKS5nZXRUaW1lKCkgKyBzZXNzaW9uVGltZSkudG9TdHJpbmcoKSk7XHJcbiAgICByZXR1cm4gKG5ldyBEYXRlKCkuZ2V0VGltZSgpICsgc2Vzc2lvblRpbWUpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFVzZXJUb2tlbkRhdGEodXNlclRva2VuOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIHRoaXMuY29va2llU2VydmljZS5zZXQoJ3VzZXJUb2tlbicsIEFlc1V0aWxzLmVuY3J5cHQodXNlclRva2VuLCB0aGlzLmhhc2hLZXkpKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXRVc2VyVG9rZW5EYXRhKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBleHBpcnlUaW1lOiBudW1iZXIgPSB0aGlzLmdldERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgIGlmIChleHBpcnlUaW1lID4gbmV3IERhdGUoKS5nZXRUaW1lKCkpIHtcclxuICAgICAgcmV0dXJuIHRoaXMuY29va2llU2VydmljZS5jaGVjaygndXNlclRva2VuJykgPyBBZXNVdGlscy5kZWNyeXB0KHRoaXMuY29va2llU2VydmljZS5nZXQoJ3VzZXJUb2tlbicpLCB0aGlzLmhhc2hLZXkpIDogbnVsbDtcclxuICAgIH1cclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgc2V0U2Vzc2lvbkRhdGFGb3JNb2R1bGVSZXN0cmljdGlvbihtb2R1bGVSZXN0cmljdGlvbjogSlNPTiwga2V5OiBzdHJpbmcgPSAnbW9kdWxlUmVzdHJpY3Rpb24nKTogdm9pZCB7XHJcbiAgICBpZiAodHlwZW9mKFN0b3JhZ2UpKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkobW9kdWxlUmVzdHJpY3Rpb24pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdMb2NhbCBTdG9yZ2FlIG5vdCBhdmFpbGFibGUnKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXRTZXNzaW9uRGF0YUZvck1vZHVsZVJlc3RyaWN0aW9uKGtleTogc3RyaW5nID0gJ21vZHVsZVJlc3RyaWN0aW9uJyk6IEpTT04ge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpIDogJ3t9Jyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBKU09OLnBhcnNlKCd7fScpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFNlc3Npb25EYXRhRm9yU3RydWN0dXJlZFJlc3RyaWN0aW9uKHN0cnVjdHVyZWRSZXN0cmljdGlvbjogSlNPTiwga2V5OiBzdHJpbmcgPSAnc3RydWN0dXJlZFJlc3RyaWN0aW9uJyk6IHZvaWQge1xyXG4gICAgaWYgKHR5cGVvZihTdG9yYWdlKSkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KHN0cnVjdHVyZWRSZXN0cmljdGlvbikpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coJ0xvY2FsIFN0b3JnYWUgbm90IGF2YWlsYWJsZScpO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGdldFNlc3Npb25EYXRhRm9yU3RydWN0dXJlZFJlc3RyaWN0aW9uKGtleTogc3RyaW5nID0gJ3N0cnVjdHVyZWRSZXN0cmljdGlvbicpOiBKU09OIHtcclxuICAgIGNvbnN0IGV4cGlyeVRpbWU6IG51bWJlciA9IHRoaXMuZ2V0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgaWYgKGV4cGlyeVRpbWUgPiBuZXcgRGF0ZSgpLmdldFRpbWUoKSkge1xyXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA6ICd7fScpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5jbGVhclNlc3Npb25EYXRhQW5kR290b1Nlc3Npb25FeHBpcmVQYWdlKCk7XHJcbiAgICByZXR1cm4gSlNPTi5wYXJzZSgne30nKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBzZXRTZXNzaW9uRGF0YUZvck5vZGVDaXJjbGVSZXN0cmljdGlvbihub2RlQ2lyY2xlUmVzdHJpY3Rpb246IEpTT04sIGtleTogc3RyaW5nID0gJ25vZGVDaXJjbGVSZXN0cmljdGlvbicpOiB2b2lkIHtcclxuICAgIGlmICh0eXBlb2YoU3RvcmFnZSkpIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeShub2RlQ2lyY2xlUmVzdHJpY3Rpb24pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdMb2NhbCBTdG9yZ2FlIG5vdCBhdmFpbGFibGUnKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXRTZXNzaW9uRGF0YUZvck5vZGVDaXJjbGVSZXN0cmljdGlvbihrZXk6IHN0cmluZyA9ICdub2RlQ2lyY2xlUmVzdHJpY3Rpb24nKTogSlNPTiB7XHJcbiAgICBjb25zdCBleHBpcnlUaW1lOiBudW1iZXIgPSB0aGlzLmdldERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgIGlmIChleHBpcnlUaW1lID4gbmV3IERhdGUoKS5nZXRUaW1lKCkpIHtcclxuICAgICAgcmV0dXJuIEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA/IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgOiAne30nKTtcclxuICAgIH1cclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgcmV0dXJuIEpTT04ucGFyc2UoJ3t9Jyk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpOiB2b2lkIHtcclxuICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YSgpO1xyXG4gICAgaWYodGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKSkge1xyXG4gICAgICBjb25zb2xlLmxvZyh0aGlzLmFwcFNldHRpbmcuZ2V0Q29uZmlndXJhdGlvbigpLnNlc3Npb25FeHBpcmVkUGFnZSk7XHJcbiAgICAgIHRoaXMubmF2aWdhdGVTZXJ2aWNlLm5hdmlnYXRlKFt0aGlzLmFwcFNldHRpbmcuZ2V0Q29uZmlndXJhdGlvbigpLnNlc3Npb25FeHBpcmVkUGFnZV0pO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvTG9nb3V0UGFnZSgpOiB2b2lkIHtcclxuICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YSgpO1xyXG4gICAgaWYodGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKSkge1xyXG4gICAgICB0aGlzLm5hdmlnYXRlU2VydmljZS5uYXZpZ2F0ZShbdGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5sb2dvdXRQYXRoXSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHByaXZhdGUgcmVzZXRWYXJpYWJsZXMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmdsb2JhbHMgPSBudWxsO1xyXG4gICAgdGhpcy5zZWxlY3RlZENpcmNsZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZWxlY3RlZE5lTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlbGVjdGVkTmVTaG9ydE5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5wYXJzZWROb2RlQ2lyY2xlSnNvbiA9IG51bGw7XHJcbiAgICB0aGlzLm5vZGVOYW1lQ2lyY2xlID0gbnVsbDtcclxuICAgIHRoaXMuc3RydWN0dXJlZFJlc3RyaWN0aW9uID0gbnVsbDtcclxuICAgIHRoaXMubW9kdWxlUmVzdHJpY3Rpb24gPSBudWxsO1xyXG4gICAgdGhpcy5tYXBOZU5hbWVDaXJjbGVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMubm9kZU5hbWVMaXN0ID0gW107XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVlc3RTZXNzaW9uRGF0YSB7XHJcbiAgdXNlck5hbWU6IHN0cmluZztcclxuICBhcHBEYXRhOiBKU09OO1xyXG4gIG5vZGVOYW1lQ2lyY2xlOiBzdHJpbmc7XHJcbiAgYWVzS2V5Pzogc3RyaW5nO1xyXG4gIG5lTmFtZUNpcmNsZU5hbWU/OiBKU09OO1xyXG59XHJcbmV4cG9ydCBpbnRlcmZhY2UgUmVzcG9uc2VTZXNzaW9uRGF0YSB7XHJcbiAgZ2xvYmFscz86IHtcclxuICAgIGN1cnJlbnRVc2VyOiB7XHJcbiAgICAgIHVzZXJOYW1lPzogc3RyaW5nO1xyXG4gICAgICBhcHBEYXRhPzogSlNPTjtcclxuICAgICAgbm9kZU5hbWVDaXJjbGU/OiBzdHJpbmc7XHJcbiAgICAgIG5lTmFtZUNpcmNsZU5hbWU/OiBKU09OO1xyXG4gICAgfTtcclxuICB9O1xyXG4gIGFlc0tleT86IHN0cmluZztcclxufVxyXG4iLCJpbXBvcnQgeyBXZWJTb2NrZXRDYWxsYmFja3MgfSBmcm9tICcuL2lhbS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5leHBvcnQgY2xhc3MgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcyBpbXBsZW1lbnRzIFdlYlNvY2tldENhbGxiYWNrcyB7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBvbk1lc3NhZ2VTdWJqZWN0OiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBvbk9wZW5TdWJqZWN0OiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBvbkNsb3NlU3ViamVjdDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25FcnJvclN1YmplY3Q6IFN1YmplY3Q8YW55PiA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgIHByaXZhdGUgc3RhdGljIG9uV2Vic29ja2V0UmVjb25uZWN0U3ViamVjdDogU3ViamVjdDx2b2lkPiA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbk1lc3NhZ2VPYnNlcnZhYmxlKCk6IE9ic2VydmFibGU8TWVzc2FnZUV2ZW50PiB7XHJcbiAgICAgICAgcmV0dXJuIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25NZXNzYWdlU3ViamVjdC5hc09ic2VydmFibGUoKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0T25PcGVuT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uT3BlblN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE9uQ2xvc2VPYnNlcnZhYmxlKCk6IE9ic2VydmFibGU8TWVzc2FnZUV2ZW50PiB7XHJcbiAgICAgICAgcmV0dXJuIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25DbG9zZVN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE9uRXJyb3JPYnNlcnZhYmxlKCk6IE9ic2VydmFibGU8TWVzc2FnZUV2ZW50PiB7XHJcbiAgICAgICAgcmV0dXJuIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25FcnJvclN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE9uV2Vic29ja2V0UmVjb25uZWN0T2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcclxuICAgICAgICByZXR1cm4gV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbldlYnNvY2tldFJlY29ubmVjdFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlSW5pdGlhbGl6ZU9ic2VydmFibGVzKCk6IHZvaWQge1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25NZXNzYWdlU3ViamVjdCA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uT3BlblN1YmplY3QgID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25DbG9zZVN1YmplY3QgID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25FcnJvclN1YmplY3QgPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICB9XHJcbiAgICBvbk1lc3NhZ2UoZXZlbnQ6IE1lc3NhZ2VFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25NZXNzYWdlU3ViamVjdC5uZXh0KGV2ZW50KTtcclxuICAgIH1cclxuICAgIG9uQ2xvc2UoZXZlbnQ6IE1lc3NhZ2VFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd3ZWJzb2NrZXQgY2xvc2VkJyk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbkNsb3NlU3ViamVjdC5uZXh0KGV2ZW50KTtcclxuICAgIH1cclxuICAgIG9uRXJyb3IoZXZlbnQ6IE1lc3NhZ2VFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGV2ZW50KTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uRXJyb3JTdWJqZWN0Lm5leHQoZXZlbnQpO1xyXG4gICAgfVxyXG4gICAgb25PcGVuKGV2ZW50OiBNZXNzYWdlRXZlbnQsIHdlYnNvY2tldDogV2ViU29ja2V0KTogdm9pZCB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3dlYnNvY2tldCBvcGVuZWQnKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uT3BlblN1YmplY3QubmV4dChldmVudCk7XHJcbiAgICB9XHJcbiAgICBvblJlY29ubmVjdCgpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnd2Vic29ja2V0IHJlLWNvbm5lY3RlZCcpO1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25XZWJzb2NrZXRSZWNvbm5lY3RTdWJqZWN0Lm5leHQoKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vbi9odHRwXCI7XG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBNZXNzYWdlTWFwcGluZyB7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7IH1cbiAgcHJpdmF0ZSBzdGF0aWMgbWVzc2FnZU1hcDogTWFwPG51bWJlciwgc3RyaW5nPiA9IG5ldyBNYXA8bnVtYmVyLCBzdHJpbmc+KCk7XG4gIHB1YmxpYyBzdGF0aWMgZ2V0TWVzc2FnZShjb2RlOiBudW1iZXIpOiBhbnkge1xuICAgICAgcmV0dXJuIE1lc3NhZ2VNYXBwaW5nLm1lc3NhZ2VNYXAuaGFzKGNvZGUpID8gTWVzc2FnZU1hcHBpbmcubWVzc2FnZU1hcC5nZXQoY29kZSkgOiAndW5rbm93biBlcnJvciBjb2RlIHJlY2VpdmVkJztcbiAgfVxuICBwdWJsaWMgbG9hZE1lc2FnZU1hcChmaWxlUGF0aDpzdHJpbmcpOiB2b2lkIHtcbiAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8SlNPTj4oZmlsZVBhdGgpLnRvUHJvbWlzZSgpLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgbmV3IE1hcDxzdHJpbmcsc3RyaW5nPihPYmplY3QuZW50cmllcyhyZXNwb25zZSkpLmZvckVhY2goKHZhbHVlOiBzdHJpbmcsIGtleTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICBNZXNzYWdlTWFwcGluZy5tZXNzYWdlTWFwLnNldChOdW1iZXIucGFyc2VJbnQoa2V5KSx2YWx1ZSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pLmNhdGNoKChyZXNwb25zZTogYW55KSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgY291bGQgbm90IGxvYWQgY29uZmlndXJhdGlvbiBmaWxlIGVycm9yOiBcXG4gJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YCk7XG4gICAgICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkluaXQsIE9uRGVzdHJveSwgSG9zdExpc3RlbmVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09OU1RBTlRTIH0gZnJvbSAnLi9jb25zdGFudCc7XHJcbmltcG9ydCB7IEh0dHBIZWFkZXJzLCBIdHRwQ2xpZW50LCBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyByZXRyeSwgY2F0Y2hFcnJvciwgZGVsYXkgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IHRocm93RXJyb3IsIE9ic2VydmFibGUsIFN1YnNjcmliZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUnNhVXRpbHMgfSBmcm9tICcuL3JzYS11dGlscyc7XHJcbmltcG9ydCB7IFNlc3Npb25TZXJ2aWNlLCBSZXNwb25zZVNlc3Npb25EYXRhIH0gZnJvbSAnLi9zZXNzaW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCAqIGFzIGZvcmdlIGZyb20gJ25vZGUtZm9yZ2UnO1xyXG5pbXBvcnQgeyBBZXNVdGlscyB9IGZyb20gJy4vYWVzLXV0aWxzJztcclxuaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcyB9IGZyb20gJy4vd2ViLXNvY2tldC1jYWxsYmFja3MtY2xhc3MnO1xyXG5pbXBvcnQgeyBNZXNzYWdlTWFwcGluZyB9IGZyb20gJy4vbWVzc2FnZS1tYXBwaW5nJztcclxuaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tzIH0gZnJvbSAnLi9pYW0uc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDYWNoZU1hbmFnZXJTZXJ2aWNlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gIHB1YmxpYyBlbmNyeXB0aW9uS2V5OiBhbnk7XHJcbiAgcHVibGljIHRpbWVBZGp1c3RtZW50OiBudW1iZXI7XHJcbiAgcHVibGljIGNpcmNsZUZ1bGxOYW1lSnNvblJlc3BvbnNlOiBhbnk7XHJcbiAgcHVibGljIG5lU2hvcnROYW1lRnVsbE5hbWVKc29uOiBhbnk7XHJcbiAgcHVibGljIG1hcE5lU2hvcnROYW1lRnVsbE5hbWU6IGFueTtcclxuICBwdWJsaWMgc2hvcnRDb2RlVG9JZE1hcDogYW55O1xyXG4gIHB1YmxpYyBub2RlVG9JZE1hcDogYW55O1xyXG4gIHB1YmxpYyBjaXJjbGVUb0lkTWFwOiBhbnk7XHJcbiAgcHVibGljIE9wZXJhdGlvblRvQWNjZXNzTWFwcGluZzogYW55O1xyXG4gIHB1YmxpYyBsb2dpblVzZXJJbWFnZTogYW55O1xyXG4gIHB1YmxpYyB3ZWJzb2NrZXQ6IFdlYlNvY2tldDtcclxuICBwdWJsaWMgWF9TT0NLRVRfQUREUkVTUzogc3RyaW5nO1xyXG4gIHB1YmxpYyBYX1VTRVJOQU1FOiBzdHJpbmc7XHJcbiAgcHVibGljIFNPQ0tFVF9JUDogc3RyaW5nO1xyXG4gIHB1YmxpYyByZXNvbHZlRm46ICgpID0+IHZvaWQ7XHJcbiAgcHVibGljIHJlamVjdEZuOiAoKSA9PiB2b2lkO1xyXG4gIHB1YmxpYyB3ZWJzb2NrZXRPcGVuUHJvbWlzZTogUHJvbWlzZTx2b2lkPiA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgIHRoaXMucmVzb2x2ZUZuID0gcmVzb2x2ZTtcclxuICAgIHRoaXMucmVqZWN0Rm4gPSByZWplY3Q7XHJcbiAgfSk7XHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBhcHBDb25maWd1cmF0aW9uOiBBcHBDb25maWd1cmF0aW9uU2VydmljZSwgcHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50LFxyXG4gICAgcHJpdmF0ZSBzZXNzaW9uU2VydmljZTogU2Vzc2lvblNlcnZpY2UsIHByaXZhdGUgbG9jYXRpb246IExvY2F0aW9uLHByaXZhdGUgbWVzc2FnZU1hcHBpbmc6TWVzc2FnZU1hcHBpbmcpIHsgfVxyXG4gIG5nT25Jbml0KCkgeyB9XHJcbiAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICBpZiAodGhpcy53ZWJzb2NrZXQpIHtcclxuICAgICAgdGhpcy53ZWJzb2NrZXQuY2xvc2UoKTtcclxuICAgIH1cclxuICB9XHJcbiAgZ2V0QXV0aEtleSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCkuY29uY2F0KCc/b3BlcmF0aW9uPWdldGF1dGhrZXknKTtcclxuICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICBoZWFkZXJzOiBuZXcgSHR0cEhlYWRlcnMoeyAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCwgJ29wZXJhdGlvbic6ICdnZXRhdXRoa2V5JyB9KSxcclxuICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YToge1xyXG4gICAgICAgICAgcGVtRmlsZTogc3RyaW5nXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEh0dHBSZXNwb25zZTxSZXNwb25zZT4+KHVybCwgaHR0cE9wdGlvbnMpXHJcbiAgICAgICAgLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIGlmIChyZXNwLmJvZHkuc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIFJzYVV0aWxzLnB1YmxpY0tleUZyb21QRU0ocmVzcC5ib2R5LnN0YXR1c0NvZGUuQXBwRGF0YS5wZW1GaWxlKTtcclxuICAgICAgICAgICAgdGhpcy5lbmNyeXB0aW9uS2V5ID0gcmVzcC5ib2R5LnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgY29uc3Qgc2VydmVyVGltZSA9IHJlc3AuaGVhZGVycy5oYXMoJ0RhdGUnKSA/IG5ldyBEYXRlKHJlc3AuaGVhZGVycy5nZXQoJ0RhdGUnKSkuZ2V0VGltZSgpIDogbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgIGNvbnN0IGNsaWVudFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcclxuICAgICAgICAgICAgdGhpcy50aW1lQWRqdXN0bWVudCA9IHNlcnZlclRpbWUgLSBjbGllbnRUaW1lO1xyXG4gICAgICAgICAgICAvL3RoaXMuc2Vzc2lvblNlcnZpY2UucHV0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWplY3QoKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnZmV0Y2hpbmcgcnNhIGtleSBmYWlsZWQnKTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZUpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0Tm9kZVNob3J0TmFtZUZ1bGxOYW1lJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldE5vZGVTaG9ydE5hbWVGdWxsTmFtZSdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMubmVTaG9ydE5hbWVGdWxsTmFtZUpzb24gPSB7XHJcbiAgICAgICAgICAgICAgJ05vZGVOYW1lJzogcmVzcC5zdGF0dXNDb2RlLkFwcERhdGFcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Q2lyY2xlU2hvcnROYW1lRnVsbE5hbWVKc29uKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCkuY29uY2F0KCc/b3BlcmF0aW9uPWdldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5jaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZSA9IHtcclxuICAgICAgICAgICAgICBDaXJjbGVOYW1lOiByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWplY3QocmVzcCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRNb2R1bGVUb0lkSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRTaG9ydENvZGVUb0lkTWFwJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldFNob3J0Q29kZVRvSWRNYXAnXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IEpTT04sXHJcbiAgICAgICAgdHlwZTogc3RyaW5nLFxyXG4gICAgICAgIGh0dHBzdGF0dXNjb2RlOiBzdHJpbmcsXHJcbiAgICAgICAgb3BTdGF0dXNDb2RlOiBzdHJpbmdcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8UmVzcG9uc2U+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIGlmIChyZXNwLnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNob3J0Q29kZVRvSWRNYXAgPSByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Tm9kZVRvSWRKc29uKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCkuY29uY2F0KCc/b3BlcmF0aW9uPWdldE5vZGVUb0lkTWFwJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldE5vZGVUb0lkTWFwJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlVG9JZE1hcCA9IHJlc3Auc3RhdHVzQ29kZS5BcHBEYXRhO1xyXG4gICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWplY3QocmVzcCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDaXJjbGVUb0lkSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRDaXJjbGVUb0lkTWFwJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldENpcmNsZVRvSWRNYXAnXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IEpTT04sXHJcbiAgICAgICAgdHlwZTogc3RyaW5nLFxyXG4gICAgICAgIGh0dHBzdGF0dXNjb2RlOiBzdHJpbmcsXHJcbiAgICAgICAgb3BTdGF0dXNDb2RlOiBzdHJpbmdcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8UmVzcG9uc2U+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIGlmIChyZXNwLnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNpcmNsZVRvSWRNYXAgPSByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRPcGVyYXRpb25Ub01vZHVsZU5vZGVDaXJjbGUnKTtcclxuICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICBoZWFkZXJzOiBuZXcgSHR0cEhlYWRlcnMoe1xyXG4gICAgICAgICdwcm9qZWN0JzogdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0LFxyXG4gICAgICAgICdvcGVyYXRpb24nOiAnZ2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmcgPSByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0UGF0aE5hbWUoKSB7XHJcbiAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoLnN1YnN0cigxKTtcclxufVxyXG4gIG9uU3RhcnR1cFJvdXRlQ2hhbmdlKGV2ZW50KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscyA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzO1xyXG4gICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscykge1xyXG4gICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscyA9IHt9O1xyXG4gICAgICB9XHJcbiAgICAgIGlmICh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmxvZ2luUGFnZSAmJiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlc1xyXG4gICAgICAgICYmIHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luKSB7XHJcbiAgICAgICAgbGV0IHBhdGhOYW1lID0gdGhpcy5sb2NhdGlvbi5wYXRoKCk7XHJcbiAgICAgICAgaWYocGF0aE5hbWUuaW5jbHVkZXMoXCI/XCIpKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhdGhOYW1lPXBhdGhOYW1lLnNwbGl0KFwiP1wiKVswXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgcmVzdHJpY3RlZFBhZ2U6IGJvb2xlYW4gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlcy5pbmRleE9mKHBhdGhOYW1lKT09PS0xO1xyXG4gICAgICAgIGNvbnN0IGxvZ2dlZEluID0gdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzLmN1cnJlbnRVc2VyO1xyXG4gICAgICAgaWYgKHJlc3RyaWN0ZWRQYWdlICYmICFsb2dnZWRJbikge1xyXG4gICAgICAgICAgdGhpcy5sb2NhdGlvbi5nbyh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmxvZ2luUGFnZSk7XHJcbiAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChsb2dnZWRJbikge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLnNlc3Npb25TZXJ2aWNlLm1vZHVsZVJlc3RyaWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5tb2R1bGVSZXN0cmljdGlvbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGFGb3JNb2R1bGVSZXN0cmljdGlvbigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb24pIHtcclxuICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnN0cnVjdHVyZWRSZXN0cmljdGlvbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGFGb3JTdHJ1Y3R1cmVkUmVzdHJpY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UucGFyc2VkTm9kZUNpcmNsZUpzb24pIHtcclxuICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YUZvck5vZGVDaXJjbGVSZXN0cmljdGlvbigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IGxvZ2luUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubm9uUmVzdHJpY3RlZFBhZ2VzLmluZGV4T2YocGF0aE5hbWUpIT0tMTtcclxuICAgICAgICAgICAgaWYgKGxvZ2luUGFnZSkge1xyXG4gICAgICAgICAgICAgIHRoaXMubG9jYXRpb24uZ28odGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5kZWZhdWx0UGFnZUFmdGVyTG9naW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMub3BlbldlYlNvY2tldENoYW5uZWwobmV3IFdlYlNvY2tldENhbGxiYWNrQ2xhc3MoKSkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNhbGxXaGVuQ29uZmlnTG9hZHMoKSB7XHJcbiAgICBjb25zdCB1c2VyRGV0YWlscyA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscztcclxuICAgIGNvbnN0IGFlc0tleSA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5hZXNLZXk7XHJcbiAgICB0aGlzLm1lc3NhZ2VNYXBwaW5nLmxvYWRNZXNhZ2VNYXAoJ2Fzc2V0cy9jb25maWd1cmF0aW9uL21lc3NhZ2VtYXBwaW5nLmpzb24nKTtcclxuICAgIGlmIChhZXNLZXkpIHtcclxuICAgICAgQWVzVXRpbHMuc2V0QWVzRW5jcnlwdGlvbktleShhZXNLZXkpO1xyXG4gICAgfVxyXG4gICAgaWYgKHVzZXJEZXRhaWxzICYmIHVzZXJEZXRhaWxzLmN1cnJlbnRVc2VyICYmIHVzZXJEZXRhaWxzLmN1cnJlbnRVc2VyLnVzZXJuYW1lICYmICF0aGlzLmxvZ2luVXNlckltYWdlKSB7XHJcbiAgICAgIGludGVyZmFjZSBVc2VySW1hZ2VSZXNwb25zZSB7XHJcbiAgICAgICAgc3VjY2VzczogYm9vbGVhbjtcclxuICAgICAgICBBcHBEYXRhOiB7XHJcbiAgICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICB1c2VySW1hZ2U6IHN0cmluZztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuZ2V0VXNlckltYWdlPFVzZXJJbWFnZVJlc3BvbnNlPih1c2VyRGV0YWlscy5jdXJyZW50VXNlci51c2VybmFtZSkudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3VjY2Vzcykge1xyXG4gICAgICAgICAgdGhpcy5sb2dpblVzZXJJbWFnZSA9IHJlc3BvbnNlLkFwcERhdGEudXNlckluZm8udXNlckltYWdlID8gcmVzcG9uc2UuQXBwRGF0YS51c2VySW5mby51c2VySW1hZ2UgOiAnbm9JbWFnZSc7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LCBmdW5jdGlvbiAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGdldFVzZXJJbWFnZTxUPih1c2VyTmFtZTogc3RyaW5nKTogUHJvbWlzZTxUPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRVc2VySW1hZ2UmdXNlck5hbWU9JykuY29uY2F0KHVzZXJOYW1lKTtcclxuICAgIGNvbnN0IHVzZXJUb2tlbiA9IGAke3VzZXJOYW1lfS10aGlzLnNlc3Npb25TZXJ2aWNlLmdldFVzZXJUb2tlbkRhdGEoKWA7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldFVzZXJJbWFnZScsXHJcbiAgICAgICAgJ3VzZXJUb2tlbic6IGAke3VzZXJOYW1lfS0ke3RoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0VXNlclRva2VuRGF0YSgpfWBcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFQ+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIHJlc29sdmUocmVzcCk7XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBvcGVuV2ViU29ja2V0Q2hhbm5lbCh3ZWJzb2NrZXRDYWxsYmFja3M6IFdlYlNvY2tldENhbGxiYWNrcyk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgbGV0IHJlc3BvbnNlU2Vzc2lvbkRhdGE6IFJlc3BvbnNlU2Vzc2lvbkRhdGEgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCk7XHJcbiAgICBjb25zdCBwcm90b2NvbCA9IENPTlNUQU5UUy5XRUJTT0NLRVRfUFJPVE9DT0w7XHJcbiAgICBjb25zdCBpcCA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXA7XHJcbiAgICBjb25zdCBwb3J0ID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0O1xyXG4gICAgY29uc3Qgd2Vic29ja2V0UG9ydCA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkud2Vic29ja2V0UG9ydDtcclxuICAgIGNvbnN0IHByb2plY3QgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3Q7XHJcbiAgICBjb25zdCB1c2VyTmFtZSA9IHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscy5jdXJyZW50VXNlci51c2VyTmFtZTtcclxuICAgIGNvbnN0IGJhc2U2NHRva2VuID0gZm9yZ2UudXRpbC5lbmNvZGU2NChgJHt1c2VyTmFtZX0tJHt0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFVzZXJUb2tlbkRhdGEoKX1gKTtcclxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gYD9vcGVyYXRpb249YXV0aGVudGljYXRlV2ViU29ja2V0JnByb2plY3Q9JHtwcm9qZWN0fSZ1c2VyVG9rZW49JHtiYXNlNjR0b2tlbn0mcHJvamVjdFVybD0ke2lwfToke3BvcnR9YDtcclxuICAgIGNvbnN0IHdlYlNvY2tldFVSTCA9IGAke3Byb3RvY29sfSR7aXB9OiR7d2Vic29ja2V0UG9ydH0vd2Vic29ja2V0JHtxdWVyeVN0cmluZ31gO1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHZvaWQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICBsZXQgZmxhZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHRoaXMud2Vic29ja2V0ID0gbmV3IFdlYlNvY2tldCh3ZWJTb2NrZXRVUkwpO1xyXG4gICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25PcGVuKSB7XHJcbiAgICAgICAgICB0aGlzLndlYnNvY2tldC5vbm9wZW4gPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHdlYnNvY2tldENhbGxiYWNrcy5vbk9wZW4oKTtcclxuICAgICAgICAgICAgY29uc3QgbWFwOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gdGhpcy5nZXRDb29raWVzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuWF9TT0NLRVRfQUREUkVTUyA9IG1hcC5oYXMoJ1gtU09DS0VULUFERFJFU1MnKSA/IG1hcC5nZXQoJ1gtU09DS0VULUFERFJFU1MnKSA6IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMuWF9VU0VSTkFNRSA9IG1hcC5oYXMoJ1gtVVNFUk5BTUUnKSA/IG1hcC5nZXQoJ1gtVVNFUk5BTUUnKSA6IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMuU09DS0VUX0lQID0gbWFwLmhhcygnc29ja2V0SXAnKSA/IG1hcC5nZXQoJ3NvY2tldElwJykgOiBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLnJlc29sdmVGbigpO1xyXG4gICAgICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgICAgICAgZmxhZyA9IHRydWU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25DbG9zZSkge1xyXG4gICAgICAgICAgdGhpcy53ZWJzb2NrZXQub25jbG9zZSA9ICgpID0+IHtcclxuICAgICAgICAgICAgd2Vic29ja2V0Q2FsbGJhY2tzLm9uQ2xvc2UoKTtcclxuICAgICAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5yZUluaXRpYWxpemVPYnNlcnZhYmxlcygpO1xyXG4gICAgICAgICAgICB0aGlzLnJlSW5pdGlhbGl6ZVdlYnNvY2tldE9wZW5Qcm9taXNlKCk7XHJcbiAgICAgICAgICAgIGNvbnN0w4LCoG1hcDrDgsKgTWFwPHN0cmluZyzDgsKgc3RyaW5nPsOCwqA9w4LCoHRoaXMuZ2V0Q29va2llcygpO1xyXG4gICAgICAgICAgICAgcmVzcG9uc2VTZXNzaW9uRGF0YT10aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCk7XHJcbiAgICAgICAgICAgIGlmKG1hcC5oYXMoJ1gtVVNFUk5BTUUnKSAmJiBmbGFnJiZyZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMmJnJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscy5jdXJyZW50VXNlcinDgsKge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGNhbGxiYWNrID0gbmV3w4LCoFdlYlNvY2tldENhbGxiYWNrQ2xhc3MoKTtcclxuICAgICAgICAgICAgw4LCoMOCwqB0aGlzLm9wZW5XZWJTb2NrZXRDaGFubmVsKGNhbGxiYWNrKS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjay5vblJlY29ubmVjdCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSBcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlc29sdmVGbiA9IHRoaXMucmVzb2x2ZUZuO1xyXG4gICAgICAgIHRoaXMud2Vic29ja2V0Lm9uZXJyb3IgPSBmdW5jdGlvbihlcnJvcikge1xyXG4gICAgICAgICAgaWYgKHdlYnNvY2tldENhbGxiYWNrcy5vbkVycm9yKSB7XHJcbiAgICAgICAgICAgIHdlYnNvY2tldENhbGxiYWNrcy5vbkVycm9yKGVycm9yKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNvbnNvbGUubG9nKCdyZS1jb25uZWN0aW5nIHRvIHdlYnNvY2tldCBzZXJ2ZXIuLi4nKTtcclxuICAgICAgICAgIHJlc29sdmVGbigpO1xyXG4gICAgICAgICAgb2JzZXJ2ZS5lcnJvcigpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaWYgKHdlYnNvY2tldENhbGxiYWNrcy5vbk1lc3NhZ2UpIHtcclxuICAgICAgICAgIHRoaXMud2Vic29ja2V0Lm9ubWVzc2FnZSA9IHdlYnNvY2tldENhbGxiYWNrcy5vbk1lc3NhZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHRoaXMucmVzb2x2ZUZuKCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9KS5waXBlKGRlbGF5KDIwMDApKS5waXBlKHJldHJ5KDE1KSk7XHJcbiAgfVxyXG4gIHByaXZhdGUgZ2V0Q29va2llcygpOiBNYXA8c3RyaW5nLCBzdHJpbmc+IHtcclxuICAgIGNvbnN0IGNvb2tpZVN0cjogc3RyaW5nID0gZG9jdW1lbnQuY29va2llO1xyXG4gICAgY29uc3QgY29va2llczogc3RyaW5nW10gPSBjb29raWVTdHIuc3BsaXQoJzsnKTtcclxuICAgIGNvbnN0IG1hcDogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcbiAgICBjb29raWVzLmZvckVhY2goY29va2llID0+IHtcclxuICAgICAgaWYgKGNvb2tpZSkge1xyXG4gICAgICAgIGNvbnN0IGtleVZhbCA9IGNvb2tpZS50cmltKCkuc3BsaXQoJz0nKTtcclxuICAgICAgICBtYXAuc2V0KGtleVZhbFswXS50cmltKCksIGtleVZhbFsxXS50cmltKCkpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBtYXA7XHJcbiAgfVxyXG4gIHByaXZhdGUgaGFuZGxlRXJyb3IoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSB7XHJcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvckV2ZW50KSB7XHJcbiAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBDb3VsZCBub3QgY29ubmVjdCB0byBzZXJ2ZXIuXFxuOiR7ZXJyb3J9YCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihgU2VydmVyIHJldHVybmVkIGNvZGUgJHtlcnJvci5zdGF0dXN9LCBib2R5IHdhczogJHtlcnJvci5lcnJvcn1gKTtcclxuICAgIH1cclxuICB9XHJcbiAgcHJpdmF0ZSByZUluaXRpYWxpemVXZWJzb2NrZXRPcGVuUHJvbWlzZSgpOiB2b2lkIHtcclxuICAgIHRoaXMud2Vic29ja2V0T3BlblByb21pc2UgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMucmVzb2x2ZUZuID0gcmVzb2x2ZTtcclxuICAgICAgdGhpcy5yZWplY3RGbiA9IHJlamVjdDtcclxuICAgIH0pO1xyXG4gIH1cclxuICBASG9zdExpc3RlbmVyKCd3aW5kb3c6b25iZWZvcmV1bmxvYWQnLFsnJGV2ZW50J10pXHJcbiAgb25iZWZvcmV1bmxvYWRIYW5kbGVyKGV2ZW50OiBFdmVudCkge1xyXG4gICAgY29uc3QgbG9naW5QYWdlID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKVxyXG4gICAgICAgICAgLm5vblJlc3RyaWN0ZWRQYWdlcy5pbmNsdWRlcyh0aGlzLmxvY2F0aW9uLnBhdGgoKSk7XHJcbiAgICBpZihsb2dpblBhZ2UpXHJcbiAgICB7XHJcbiAgICAgIHRoaXMud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBIZWFkZXJzLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IENPTlNUQU5UUyB9IGZyb20gJy4vY29uc3RhbnQnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSwgQXBwQ29uZmlndXJhdGlvbiB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IHRocm93RXJyb3IsIE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgcmV0cnksIGNhdGNoRXJyb3IgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IENhY2hlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuL2NhY2hlLW1hbmFnZXIuc2VydmljZSc7XHJcbmltcG9ydCB7IFNlc3Npb25TZXJ2aWNlIH0gZnJvbSAnLi9zZXNzaW9uLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgSHR0cFNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQsIHByaXZhdGUgYXBwQ29uZmlndXJhdGlvbjogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsXHJcbiAgcHJpdmF0ZSBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSwgcHJpdmF0ZSBzZXNzaW9uU2VydmljZTogU2Vzc2lvblNlcnZpY2UpIHsgfVxyXG4gIHByaXZhdGUgcGFyc2VRdWVyeVN0cmluZyhxdWVyeVN0cmluZzogc3RyaW5nLCBrZXk6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICBsZXQgdG9rZW5zOiBzdHJpbmdbXTtcclxuICAgIGlmIChxdWVyeVN0cmluZykge1xyXG4gICAgICB0b2tlbnMgPSBxdWVyeVN0cmluZy5zcGxpdCgnJicpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICBjb25zdCBtYXA6IE1hcDxzdHJpbmcsIHN0cmluZz4gPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xyXG4gICAgZm9yIChjb25zdCB0b2tlbiBvZiB0b2tlbnMpIHtcclxuICAgICAgY29uc3Qga2V5VmFsdWU6IHN0cmluZ1tdID0gdG9rZW4uc3BsaXQoJz0nKTtcclxuICAgICAgbWFwLnNldChrZXlWYWx1ZVswXSwga2V5VmFsdWVbMV0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG1hcC5oYXMoa2V5KSA/IG1hcC5nZXQoa2V5KSA6IG51bGw7XHJcbiAgfVxyXG4gIHBhcnNlVXJsKHVybDogc3RyaW5nKTogTWFwPHN0cmluZywgc3RyaW5nPiB7XHJcbiAgICBjb25zdCBwYXJzZWRQYXJhbWV0ZXJzOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSB1cmwuc3BsaXQoJz8nKVsxXTtcclxuICAgIGNvbnN0IHBhcmFtZXRlclBhaXJMaXN0OiBzdHJpbmdbXSA9IHF1ZXJ5U3RyaW5nLnNwbGl0KCcmJyk7XHJcbiAgICBwYXJhbWV0ZXJQYWlyTGlzdC5mb3JFYWNoKHBhcmFtZXRlclBhaXIgPT4ge1xyXG4gICAgICBjb25zdCBrZXlWYWx1ZTogc3RyaW5nW10gPSBwYXJhbWV0ZXJQYWlyLnNwbGl0KCc9Jyk7XHJcbiAgICAgIHBhcnNlZFBhcmFtZXRlcnNba2V5VmFsdWVbMF1dID0ga2V5VmFsdWVbMV07XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBwYXJzZWRQYXJhbWV0ZXJzO1xyXG4gIH1cclxuICBwcml2YXRlIGNoZWNrQXV0aG9yaXphdGlvbih1cmw6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgaWYgKCF0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmNsaWVudFNpZGVSZXF1ZXN0QmFycmluZykge1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICAgIGNvbnN0ICBwYXJzZWRQYXJhbWV0ZXJzOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gdGhpcy5wYXJzZVVybCh1cmwpO1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gcGFyc2VkUGFyYW1ldGVyc1snb3BlcmF0aW9uJ107XHJcbiAgICBsZXQgYWNjZXNzR3JhbnRlZE1vZHVsZSA9IGZhbHNlO1xyXG4gICAgbGV0IGFjY2Vzc0dyYW50ZWROb2RlID0gZmFsc2U7XHJcbiAgICBsZXQgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgc3dpdGNoIChvcGVyYXRpb24pIHtcclxuICAgIGNhc2UgJ2RvTG9naW4nOlxyXG4gICAgY2FzZSAnbG9nb3V0VXNlcic6XHJcbiAgICAgIGFjY2Vzc0dyYW50ZWRNb2R1bGUgPSB0cnVlO1xyXG4gICAgICBicmVhaztcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0ubW9kdWxlICE9PSAnZnJlZUFsbG93Jykge1xyXG4gICAgICAgIGNvbnN0IGFjY2Vzc1JlcXVpcmVkID0gdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5hY2Nlc3M7XHJcbiAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2Uuc3RydWN0dXJlZFJlc3RyaWN0aW9uW3RoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0ubW9kdWxlXSkge1xyXG4gICAgICAgICAgYWNjZXNzR3JhbnRlZE1vZHVsZSA9XHJcbiAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnN0cnVjdHVyZWRSZXN0cmljdGlvblt0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZV1bYWNjZXNzUmVxdWlyZWRdID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2UgaWYgKHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0gJiZcclxuICAgICAgICAgIHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0ubW9kdWxlID09PSAnZnJlZUFsbG93Jykge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWRNb2R1bGUgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWRNb2R1bGUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBpZiAoIWFjY2Vzc0dyYW50ZWRNb2R1bGUpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0gJiYgdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5jaXJjbGUpIHtcclxuICAgICAgaWYgKHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0ubm9kZSkge1xyXG4gICAgICAgIGNvbnN0IGNpcmNsZUFjY2Vzc1JlcXVpcmVkID0gcGFyc2VkUGFyYW1ldGVyc1snY2lyY2xlTmFtZSddO1xyXG4gICAgICAgIGNvbnN0IG5vZGVBY2Nlc3NSZXF1aXJlZCA9IHBhcnNlZFBhcmFtZXRlcnNbJ25vZGVOYW1lJ107XHJcbiAgICAgICAgaWYgKGNpcmNsZUFjY2Vzc1JlcXVpcmVkICYmIG5vZGVBY2Nlc3NSZXF1aXJlZCkge1xyXG4gICAgICAgICAgaWYgKG5vZGVBY2Nlc3NSZXF1aXJlZC5wYXJzZWROb2RlQ2lyY2xlSnNvbltub2RlQWNjZXNzUmVxdWlyZWRdICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UucGFyc2VkTm9kZUNpcmNsZUpzb25bbm9kZUFjY2Vzc1JlcXVpcmVkXVtjaXJjbGVBY2Nlc3NSZXF1aXJlZF0pIHtcclxuICAgICAgICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IHRydWU7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBhY2Nlc3NHcmFudGVkQ2lyY2xlID0gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0gJiZcclxuICAgICAgICAhdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5jaXJjbGUpIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhY2Nlc3NHcmFudGVkQ2lyY2xlID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBpZiAoIWFjY2Vzc0dyYW50ZWRDaXJjbGUpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0gJiZcclxuICAgICAgICB0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm5vZGUpIHtcclxuICAgICAgY29uc3Qgbm9kZUFjY2Vzc1JlcXVpcmVkID0gcGFyc2VkUGFyYW1ldGVyc1snbm9kZU5hbWUnXTtcclxuICAgICAgaWYgKG5vZGVBY2Nlc3NSZXF1aXJlZCkge1xyXG4gICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uW25vZGVBY2Nlc3NSZXF1aXJlZF0pIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWROb2RlID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgIXRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0ubm9kZSkge1xyXG4gICAgICBhY2Nlc3NHcmFudGVkTm9kZSA9IHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhY2Nlc3NHcmFudGVkTm9kZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGFjY2Vzc0dyYW50ZWROb2RlO1xyXG4gIH1cclxuICBnZXREYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBjb25zb2xlLmxvZyh1cmwpO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGlmIChyZXF1ZXN0LnJlc3BvbnNlVHlwZSkge1xyXG4gICAgICAgICAgcmVxdWVzdC5oZWFkZXJzLnNldCgncmVzcG9uc2VUeXBlJywgcmVxdWVzdC5yZXNwb25zZVR5cGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVycz9yZXF1ZXN0LmhlYWRlcnM6e30gYXMgSHR0cEhlYWRlcnMsXHJcbiAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnIGFzICdib2R5J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaHR0cE9wdGlvbnMuaGVhZGVyc1snb3BlcmF0aW9uJ10gPSBvcGVyYXRpb247XHJcbiAgICAgICAgaWYocmVxdWVzdC5yZXNwb25zZVR5cGUpIHtcclxuICAgICAgICAgIGh0dHBPcHRpb25zWydyZXNwb25zZVR5cGUnXSA9IHJlcXVlc3QucmVzcG9uc2VUeXBlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihvYnNlcnZlID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgaWYgKHJlcXVlc3QuY2FsbGJhY2tmdW5jdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3QuY2FsbGJhY2tmdW5jdGlvbih7Ym9keTogcmVzcG9uc2UuYm9keSwgaGVhZGVyczogcmVzcG9uc2UuaGVhZGVycywgc3RhdHVzOiByZXNwb25zZS5zdGF0dXN9KTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBvYnNlcnZlLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcclxuICAgICAgICAgICAgICBpZiAocmVxdWVzdC5jYWxsYmFja2Z1bmN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmNhbGxiYWNrZnVuY3Rpb24oe2JvZHk6IHJlc3BvbnNlLmJvZHksIGhlYWRlcnM6IHJlc3BvbnNlLmhlYWRlcnMsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzfSk7XHJcbiAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwb3N0RGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgY29uc29sZS5sb2codXJsKTtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVycz9yZXF1ZXN0LmhlYWRlcnM6e30gYXMgSHR0cEhlYWRlcnMsXHJcbiAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnIGFzICdib2R5J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaHR0cE9wdGlvbnMuaGVhZGVyc1snb3BlcmF0aW9uJ10gPSBvcGVyYXRpb247XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4oc3Vic2NyaWJlciA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LnBvc3Q8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIHJlcXVlc3QuZGF0YSwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wb3N0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihgTm90IGF1dGhvcml6ZWQgZm9yIGFjY2Vzc2luZyAke3VybH06IDQwMWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHB1dERhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wdXQ8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIHJlcXVlc3QuZGF0YSwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wdXQ8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIHJlcXVlc3QuZGF0YSwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uc2UgPT4gc3Vic2NyaWJlci5uZXh0KHJlc3BvbnNlKSwgZXJyb3IgPT4gc3Vic2NyaWJlci5lcnJvcihlcnJvcikpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBOb3QgYXV0aG9yaXplZCBmb3IgYWNjZXNzaW5nICR7dXJsfTogNDAxYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgZGVsZXRlRGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVycz9yZXF1ZXN0LmhlYWRlcnM6e30gYXMgSHR0cEhlYWRlcnMsXHJcbiAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnIGFzICdib2R5J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaHR0cE9wdGlvbnMuaGVhZGVyc1snb3BlcmF0aW9uJ10gPSBvcGVyYXRpb247XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4oc3Vic2NyaWJlciA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LmRlbGV0ZTxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5kZWxldGU8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihgTm90IGF1dGhvcml6ZWQgZm9yIGFjY2Vzc2luZyAke3VybH06IDQwMWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGhlYWREYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzP3JlcXVlc3QuaGVhZGVyczp7fSBhcyBIdHRwSGVhZGVycyxcclxuICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICAgICAgfTtcclxuICAgICAgICBodHRwT3B0aW9ucy5oZWFkZXJzWydvcGVyYXRpb24nXSA9IG9wZXJhdGlvbjtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihzdWJzY3JpYmVyID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuaGVhZDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5oZWFkPEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwYXRjaERhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wYXRjaDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgcmVxdWVzdC5kYXRhLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uc2UgPT4gc3Vic2NyaWJlci5uZXh0KHJlc3BvbnNlKSwgZXJyb3IgPT4gc3Vic2NyaWJlci5lcnJvcihlcnJvcikpO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LnBhdGNoPEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihgTm90IGF1dGhvcml6ZWQgZm9yIGFjY2Vzc2luZyAke3VybH06IDQwMWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHByaXZhdGUgaGFuZGxlRXJyb3IoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSB7XHJcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvckV2ZW50KSB7XHJcbiAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBDb3VsZCBub3QgY29ubmVjdCB0byBzZXJ2ZXIuXFxuOiR7ZXJyb3J9YCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihlcnJvcik7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmV4cG9ydCBpbnRlcmZhY2UgUmVxdWVzdCB7XHJcbiAgY29udGV4dDogc3RyaW5nO1xyXG4gIGRhdGE/OiBhbnk7XHJcbiAgaGVhZGVycz86IEh0dHBIZWFkZXJzO1xyXG4gIHF1ZXJ5U3RyaW5nPzogc3RyaW5nO1xyXG4gIHJlc3BvbnNlVHlwZT86IHN0cmluZztcclxuICByZXFVcmw/OiBzdHJpbmc7XHJcbiAgY2FsbGJhY2tmdW5jdGlvbj8oLi4uYXJncyk6IGFueTtcclxufVxyXG5leHBvcnQgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICBib2R5PzogYW55O1xyXG4gIGhlYWRlcnM/OiBhbnk7XHJcbiAgc3RhdHVzPzogYW55O1xyXG4gIHF1ZXJ5U3RyaW5nPzogYW55O1xyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBTZXJ2aWNlLCBSZXF1ZXN0IH0gZnJvbSAnLi9odHRwLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgQXBwQ29uZmlndXJhdGlvblNlcnZpY2UgfSBmcm9tICcuL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDT05TVEFOVFMgfSBmcm9tICcuL2NvbnN0YW50JztcclxuaW1wb3J0IHsgU2Vzc2lvblNlcnZpY2UsIFJlc3BvbnNlU2Vzc2lvbkRhdGEsIFJlcXVlc3RTZXNzaW9uRGF0YSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgUnNhVXRpbHMgfSBmcm9tICcuL3JzYS11dGlscyc7XHJcbmltcG9ydCB7IEFlc1V0aWxzIH0gZnJvbSAnLi9hZXMtdXRpbHMnO1xyXG5pbXBvcnQgeyBIdHRwSGVhZGVycywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5pbXBvcnQgeyBXZWJTb2NrZXRDYWxsYmFja0NsYXNzIH0gZnJvbSAnLi93ZWItc29ja2V0LWNhbGxiYWNrcy1jbGFzcyc7XHJcbmltcG9ydCB7IGhlYWRlcnNUb1N0cmluZyB9IGZyb20gJ3NlbGVuaXVtLXdlYmRyaXZlci9odHRwJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIElhbVNlcnZpY2UgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcbiAgcHJpdmF0ZSB3ZWJzb2NrZXQ6IFdlYlNvY2tldDtcclxuICBldmVudDogYW55O1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cFNlcnZpY2U6IEh0dHBTZXJ2aWNlLCBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBzZXNzaW9uU2VydmljZTogU2Vzc2lvblNlcnZpY2UsXHJcbiAgICBwcml2YXRlIGNhY2hlOiBDYWNoZU1hbmFnZXJTZXJ2aWNlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbikge1xyXG4gICAgdGhpcy5zdGFydExpc3RlbmluZ1RvUm91dGVDaGFuZ2UoKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygnc3RhcnRlZCBsaXN0ZW5pbmcgZm9yIHJvdXRlIGNoYW5nZScpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gIH1cclxuICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgIHRoaXMud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgfVxyXG4gIHByaXZhdGUgZG9Mb2dpbjxUPihwYXlsb2FkLCBwcm9qZWN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKCkuc2V0KCdwcm9qZWN0JyxcclxuICAgICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoKS5zZXQoJ3Byb2plY3QnLFxyXG4gICAgICAgIHByb2plY3QpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWRvTG9naW4nLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCk7XHJcbiAgfVxyXG4gIHN0YXJ0TGlzdGVuaW5nVG9Sb3V0ZUNoYW5nZSgpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTx2b2lkPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5yb3V0ZXIuZXZlbnRzLnBpcGUoXHJcbiAgICAgICAgZmlsdGVyKGV2ZW50ID0+IGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZClcclxuICAgICAgKS5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgIHRoaXMub25Sb3V0ZUNoYW5nZShldmVudCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGF1dGhlbnRpY2F0ZVVzZXI8VD4odXNlck5hbWU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZywgcHJvamVjdD86IHN0cmluZyk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihvYnNlcnZlID0+IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2VTZXNzaW9uRGF0YTogUmVzcG9uc2VTZXNzaW9uRGF0YSA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKTtcclxuICAgICAgaWYgKHJlc3BvbnNlU2Vzc2lvbkRhdGEgJiYgcmVzcG9uc2VTZXNzaW9uRGF0YS5nbG9iYWxzICYmXHJcbiAgICAgICAgcmVzcG9uc2VTZXNzaW9uRGF0YS5nbG9iYWxzLmN1cnJlbnRVc2VyICYmIHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscy5jdXJyZW50VXNlci51c2VyTmFtZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd1c2VyIGFscmVhZHkgbG9nZ2VkIGluJyk7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW3RoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luXSk7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgcmFuZG9tQWVzS2V5ID0gQWVzVXRpbHMuZ2VuZXJhdGVSYW5kb21BZXNLZXkoKTtcclxuICAgICAgICBjb25zdCBjcmVkZW50aWFscyA9IHtcclxuICAgICAgICAgIHVzZXJOYW1lOiB1c2VyTmFtZSxcclxuICAgICAgICAgIHVzZXJQYXNzd29yZDogUnNhVXRpbHMuZW5jcnlwdChwYXNzd29yZCksXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgQXBwRGF0YToge1xyXG4gICAgICAgICAgICB1c2VySW5mbzogY3JlZGVudGlhbHMsXHJcbiAgICAgICAgICAgIGVuY3J5cHRpb25LZXk6IFJzYVV0aWxzLmVuY3J5cHQocmFuZG9tQWVzS2V5KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5kb0xvZ2luPFQ+KHBheWxvYWQsIHByb2plY3QpLnN1YnNjcmliZShyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuYm9keSAmJiByZXNwb25zZS5ib2R5LnN0YXR1c0NvZGUgJiYgcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEgJiYgcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEudXNlclRva2VuKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHN1YlRva2Vuczogc3RyaW5nW10gPSByZXNwb25zZS5ib2R5LnN0YXR1c0NvZGUuQXBwRGF0YS51c2VyVG9rZW4uc3BsaXQoJ0AnKTtcclxuICAgICAgICAgICAgbGV0IG1vZHVsZVJlc3RyaWN0aW9uID0gbnVsbDtcclxuICAgICAgICAgICAgbGV0IHN0cnVjdHVyZWRSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICAgICAgICAgIGxldCBub2RlTmFtZUNpcmNsZSA9IG51bGw7XHJcbiAgICAgICAgICAgIGlmIChzdWJUb2tlbnNbMV0gJiYgc3ViVG9rZW5zWzFdLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICBtb2R1bGVSZXN0cmljdGlvbiA9IHRoaXMucGFyc2VUb2tlbihBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1sxXSwgcmFuZG9tQWVzS2V5KSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgbW9kdWxlUmVzdHJpY3Rpb24gPSB7fTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSB0aGlzLnJlc3RydWN0dXJlQWNjZXNzSnNvbihtb2R1bGVSZXN0cmljdGlvbiwge30pO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhRm9yTW9kdWxlUmVzdHJpY3Rpb24obW9kdWxlUmVzdHJpY3Rpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhRm9yU3RydWN0dXJlZFJlc3RyaWN0aW9uKHN0cnVjdHVyZWRSZXN0cmljdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2V0VXNlclRva2VuRGF0YShzdWJUb2tlbnNbMF0pO1xyXG4gICAgICAgICAgICBpZiAoc3ViVG9rZW5zWzJdICYmIHN1YlRva2Vuc1syXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgbm9kZU5hbWVDaXJjbGUgPSBBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1syXSwgcmFuZG9tQWVzS2V5KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICBub2RlTmFtZUNpcmNsZSA9ICcnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZE5vZGVDaXJjbGVKc29uID0gdGhpcy5wYXJzZU5vZGVDaXJjbGVUb2tlbihub2RlTmFtZUNpcmNsZSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24ocGFyc2VkTm9kZUNpcmNsZUpzb24gYXMgSlNPTik7XHJcbiAgICAgICAgICAgIGNvbnN0IG5lTmFtZXNDaXJjbGVMaXN0OiBzdHJpbmdbXSA9IG5vZGVOYW1lQ2lyY2xlLnNwbGl0KCcjJyk7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QpIHtcclxuICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdCA9IFtdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5tYXBOZU5hbWVDaXJjbGVOYW1lKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5tYXBOZU5hbWVDaXJjbGVOYW1lID0ge307XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yIChsZXQgaXRyID0gMDsgaXRyIDwgbmVOYW1lc0NpcmNsZUxpc3QubGVuZ3RoOyBpdHIrKykge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGNpcmxlTmFtZXNGb3JORSA9IG5lTmFtZXNDaXJjbGVMaXN0W2l0cl0uc3BsaXQoJzonKTtcclxuICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdC5wdXNoKGNpcmxlTmFtZXNGb3JORVswXSk7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5tYXBOZU5hbWVDaXJjbGVOYW1lW2NpcmxlTmFtZXNGb3JORVswXV0gPSBjaXJsZU5hbWVzRm9yTkVbMV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZWxlY3RlZE5lU2hvcnROYW1lID0gdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3RbMF07XHJcbiAgICAgICAgICAgIHRoaXMubmVTaG9ydE5hbWVGdWxsTmFtZU1hcHBpbmcoKTtcclxuICAgICAgICAgICAgdGhpcy5uZUNpcmNsZVNob3J0TmFtZUZ1bGxOYW1lTWFwcGluZygpO1xyXG4gICAgICAgICAgICBjb25zdCBuZU5hbWVDaXJjbGVOYW1lOiBKU09OID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgc2VsZWN0ZWROZU5hbWU6IHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZU5hbWUsXHJcbiAgICAgICAgICAgICAgc2VsZWN0ZWRDaXJjbGVOYW1lOiB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkQ2lyY2xlTmFtZVxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3REYXRhOiBSZXF1ZXN0U2Vzc2lvbkRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgIGFwcERhdGE6IHJlc3BvbnNlLmJvZHkuc3RhdHVzQ29kZS5BcHBEYXRhLFxyXG4gICAgICAgICAgICAgIG5vZGVOYW1lQ2lyY2xlOiBub2RlTmFtZUNpcmNsZSxcclxuICAgICAgICAgICAgICBhZXNLZXk6IEFlc1V0aWxzLmRlY3J5cHQoc3ViVG9rZW5zWzNdLCByYW5kb21BZXNLZXkpLFxyXG4gICAgICAgICAgICAgIG5lTmFtZUNpcmNsZU5hbWU6IG5lTmFtZUNpcmNsZU5hbWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5wdXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2V0U2Vzc2lvbkRhdGEocmVxdWVzdERhdGEpO1xyXG4gICAgICAgICAgICBBZXNVdGlscy5zZXRBZXNFbmNyeXB0aW9uS2V5KEFlc1V0aWxzLmRlY3J5cHQoc3ViVG9rZW5zWzNdLCByYW5kb21BZXNLZXkpKTtcclxuICAgICAgICAgICAgaW50ZXJmYWNlIFVzZXJJbWFnZVJlc3BvbnNlIHtcclxuICAgICAgICAgICAgICBzdWNjZXNzOiBib29sZWFuO1xyXG4gICAgICAgICAgICAgIEFwcERhdGE6IHtcclxuICAgICAgICAgICAgICAgIHVzZXJJbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJJbWFnZTogc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5jYWNoZS5nZXRVc2VySW1hZ2U8VXNlckltYWdlUmVzcG9uc2U+KHVzZXJOYW1lKS50aGVuKGZ1bmN0aW9uIChyZXNwKSB7XHJcbiAgICAgICAgICAgICAgaWYgKHJlc3Auc3VjY2Vzcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYWNoZS5sb2dpblVzZXJJbWFnZSA9IHJlc3AuQXBwRGF0YS51c2VySW5mby51c2VySW1hZ2UgPyByZXNwLkFwcERhdGEudXNlckluZm8udXNlckltYWdlIDogJ25vSW1hZ2UnO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLmNhY2hlLm9wZW5XZWJTb2NrZXRDaGFubmVsKG5ldyBXZWJTb2NrZXRDYWxsYmFja0NsYXNzKCkpLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW3RoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luXSk7XHJcbiAgICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRvTG9nb3V0KHVzZXJOYW1lKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICBpZiAoIXVzZXJOYW1lKSB7XHJcbiAgICAgIHRocm93RXJyb3IoJ3VzZXJOYW1lIGlzIHVuZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiBgb3BlcmF0aW9uPWxvZ291dFVzZXImdXNlck5hbWU9JHt1c2VyTmFtZX1gLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTx2b2lkPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5kZWxldGVEYXRhPHsgc3VjY2VzczogYm9vbGVhbiB9PihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGxvZ291dFVzZXIoKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIGNvbnN0IGdsb2JhbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscztcclxuICAgICAgaWYgKGdsb2JhbHMgJiYgZ2xvYmFscy5jdXJyZW50VXNlciAmJiBnbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lKSB7XHJcbiAgICAgICAgY29uc3QgaW5Vc2VyTmFtZSA9IGdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWU7XHJcbiAgICAgICAgdGhpcy5kb0xvZ291dChpblVzZXJOYW1lKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgdGhpcy5yZXNldFZhcmlhYmxlcygpO1xyXG4gICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5jbGVhclNlc3Npb25EYXRhQW5kR290b0xvZ291dFBhZ2UoKTtcclxuICAgICAgICAgIGlmICh0aGlzLmNhY2hlLndlYnNvY2tldCAmJiB0aGlzLmNhY2hlLndlYnNvY2tldC5jbG9zZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldCA9IG51bGw7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9Mb2dvdXRQYWdlKCk7XHJcbiAgICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQgJiYgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UoKTtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQgPSBudWxsO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb2JzZXJ2ZS5lcnJvcigpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvTG9nb3V0UGFnZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmNhY2hlLndlYnNvY2tldCAmJiB0aGlzLmNhY2hlLndlYnNvY2tldC5jbG9zZSkge1xyXG4gICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UoKTtcclxuICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0ID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ25vIHVzZXIgdG8gbG9nb3V0Jyk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRQYXRoTmFtZSgpIHtcclxuICAgIHJldHVybiB3aW5kb3cubG9jYXRpb24gJiYgd2luZG93LmxvY2F0aW9uLmhhc2ggJiYgd2luZG93LmxvY2F0aW9uLmhhc2guc3Vic3RyKDEpO1xyXG59XHJcbiAgb25Sb3V0ZUNoYW5nZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscztcclxuICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzKSB7XHJcbiAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscyA9IHt9O1xyXG4gICAgfVxyXG4gICAgaWYoIHRoaXMucm91dGVyLnVybCA9PSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnNlc3Npb25FeHBpcmVkUGFnZSlcclxuICAgIHtcclxuICAgICAgdHJ5XHJcbiAgICAgIHtcclxuICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQpIHtcclxuICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGNhdGNoKEVycm9yRXZlbnQpXHJcbiAgICAgIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhFcnJvckV2ZW50KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubG9naW5QYWdlICYmXHJcbiAgICAgIHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubm9uUmVzdHJpY3RlZFBhZ2VzICYmXHJcbiAgICAgIHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luKSB7XHJcbiAgICAgICAgbGV0IHBhdGhOYW1lID0gdGhpcy5sb2NhdGlvbi5wYXRoKCk7XHJcbiAgICAgICAgaWYocGF0aE5hbWUuaW5jbHVkZXMoXCI/XCIpKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhdGhOYW1lPXBhdGhOYW1lLnNwbGl0KFwiP1wiKVswXTtcclxuICAgICAgICB9XHJcbiAgICAgIGNvbnN0IHJlc3RyaWN0ZWRQYWdlID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5ub25SZXN0cmljdGVkUGFnZXMuaW5kZXhPZihwYXRoTmFtZSk9PT0tMTtcclxuICAgICAgY29uc3QgbG9nZ2VkSW4gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMuY3VycmVudFVzZXI7XHJcbiAgICAgIGlmIChyZXN0cmljdGVkUGFnZSAmJiAhbG9nZ2VkSW4pIHtcclxuICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5sb2dpblBhZ2VdKTtcclxuICAgICAgfSBlbHNlIGlmIChsb2dnZWRJbikge1xyXG4gICAgICAgIGNvbnN0IGxvZ2luUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKClcclxuICAgICAgICAgIC5ub25SZXN0cmljdGVkUGFnZXMuaW5kZXhPZihwYXRoTmFtZSkhPS0xO1xyXG4gICAgICAgIGlmIChsb2dpblBhZ2UpIHtcclxuICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBnZXRBbGxyb2xlaWQ8VD4ocHJvamVjdD86IHN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEFsbFJvbGVTZWxlY3RlZEZpbGVkJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjcmVhdGVTaW5nbGVVc2VyPFQ+KGNyZWF0aW5nVXNlcjogc3RyaW5nLCBBcHBEYXRhOiBhbnkscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIEFwcERhdGEudXNlckluZm8udXNlclBhc3N3b3JkID0gQWVzVXRpbHMuZW5jcnlwdChBcHBEYXRhLnVzZXJJbmZvLnVzZXJQYXNzd29yZCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6IGBvcGVyYXRpb249Y3JlYXRlU2luZ2xlVXNlciZjcmVhdGluZ1VzZXI9JHtjcmVhdGluZ1VzZXJ9YCxcclxuICAgICAgZGF0YTogeyBBcHBEYXRhIH0sXHJcbiAgICAgIGhlYWRlcnM6aGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlQWNjb3VudDxUPiggQXBwRGF0YTogYW55LHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBBcHBEYXRhLnVzZXJJbmZvLnVzZXJQYXNzd29yZCA9IEFlc1V0aWxzLmVuY3J5cHQoQXBwRGF0YS51c2VySW5mby51c2VyUGFzc3dvcmQpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNyZWF0ZUFjY291bnQnLFxyXG4gICAgICBkYXRhOiB7QXBwRGF0YX0sXHJcbiAgICAgIGhlYWRlcnM6aGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlQnVsa1VzZXI8VD4oY3JlYXRpbmdVc2VyOiBzdHJpbmcsIGZpbGU6IGFueSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiBgb3BlcmF0aW9uPWNyZWF0ZUJ1bGtVc2VyJmNyZWF0aW5nVXNlcj0ke2NyZWF0aW5nVXNlcn1gLFxyXG4gICAgICBkYXRhOiBmaWxlLFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNyZWF0ZUJ1bGtSb2xlc2FuZFVzZXJzPFQ+KGNyZWF0aW5nVXNlcjogc3RyaW5nLCBmaWxlOiBhbnkscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogYG9wZXJhdGlvbj1jcmVhdGVCdWxrUm9sZXNhbmRVc2VycyZjcmVhdGluZ1VzZXI9JHtjcmVhdGluZ1VzZXJ9YCxcclxuICAgICAgZGF0YTogZmlsZSxcclxuICAgICAgaGVhZGVyczpoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBkb3dubG9hZEJ1bGtVc2Vycyhwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxBcnJheUJ1ZmZlcj4+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEJ1bGtVc2VyJyxcclxuICAgICAgcmVzcG9uc2VUeXBlOiAnYXJyYXlidWZmZXInLFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxBcnJheUJ1ZmZlcj4+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8QXJyYXlCdWZmZXI+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwICA9PiB7XHJcbiAgICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtyZXNwLmJvZHldLCB7XHJcbiAgICAgICAgICB0eXBlOiAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQsYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHZhciBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XHJcbiAgICAgIGEuaHJlZiA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgIGEuZG93bmxvYWQgPSBcIlVzZXJMaXN0Lnhsc3hcIjtcclxuICAgICAgYS5jbGljaygpO1xyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZG93bmxvYWRVc2VyVGVtcGxhdGUocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRUZW1wbGF0ZScsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YShyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgbGV0IGRhdGExID0gcmVzcC5ib2R5O1xyXG4gICAgICAgIGxldCBkYXRhID0gcmVzcC5ib2R5WydzdGF0dXNDb2RlJ11bJ0FwcERhdGEnXVsnQmFzZTY0U3RyZWFtJ107XHJcbiAgICAgICAgdmFyIGJpbmRhdGEgPSB3aW5kb3cuYXRvYihkYXRhKTtcclxuICAgICAgICB2YXIgbGVuID0gYmluZGF0YS5sZW5ndGg7XHJcbiAgICAgICAgdmFyIGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkobGVuKTtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgICBieXRlc1tpXSA9IGJpbmRhdGEuY2hhckNvZGVBdChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGZpbGUgPSBuZXcgQmxvYihbYnl0ZXMuYnVmZmVyXSwge1xyXG4gICAgICAgICAgdHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0OydcclxuICAgICAgICB9KTtcclxuICAgICAgICB3aW5kb3cuc2F2ZUFzKGZpbGUsIFwidXNlcnRlbXBsYXRlXCIgKyBcIi54bHN4XCIpXHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRlbGV0ZVVzZXI8VD4odXNlck5hbWU6IHN0cmluZyxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaWYgKCF1c2VyTmFtZSkge1xyXG4gICAgICB0aHJvd0Vycm9yKCd1c2VyTmFtZSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWRlbGV0ZVVzZXImdXNlck5hbWU9JyArIHVzZXJOYW1lLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmRlbGV0ZURhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3ApO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3AuYm9keSk7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5VXNlcjxUPih1c2VyTmFtZTogc3RyaW5nLCB1c2VySW5mbyxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaWYgKCF1c2VyTmFtZSkge1xyXG4gICAgICB0aHJvd0Vycm9yKCd1c2VyTmFtZSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPW1vZGlmeVVzZXImdXNlck5hbWU9JyArIHVzZXJOYW1lLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgICBkYXRhOiB7ICdBcHBEYXRhJzogdXNlckluZm8gfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1VzZXI8VD4odXNlck5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB2aWV3VXNlckxpc3RBY2NvcmRpbmd0b1JvbGU8VD4ocm9sZUlkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBpZiAoIXJvbGVJZCkge1xyXG4gICAgICB0aHJvd0Vycm9yKCdyb2xlSWQgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRVc2Vyc0xpc3Qmcm9sZUlkPScgKyByb2xlSWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgYmxvY2tVc2VyPFQ+KHVzZXJJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaWYgKCF1c2VySWQpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlcklkIGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249YmxvY2tVc2VyJnVzZXJJZD0nICsgdXNlcklkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNoZWNrVXNlckV4aXN0ZW5jZTxUPih1c2VyTmFtZTogc3RyaW5nLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCF1c2VyTmFtZSkge1xyXG4gICAgICB0aHJvd0Vycm9yKCd1c2VyTmFtZSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Y2hlY2tVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRBbGxVc2VyPFQ+KGluZGV4OiBudW1iZXIsIHNpemU6IG51bWJlcixwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEFsbFVzZXImZnJvbT0nICsgaW5kZXggKyAnJnNpemU9JyArIHNpemUsXHJcbiAgICAgIGhlYWRlcnM6aGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRSZXN0cmljdGVkVXNlcjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEFsbFVzZXJTZWxlY3RlZEZpZWxkJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjcmVhdGVSb2xlPFQ+KHJvbGVEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCBjdXJyZW50RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWydjcmVhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWydjcmVhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIHJvbGVEYXRhLnJvbGVJbmZvLnJvbGVbJ3VwZGF0ZWRPbiddID0gbmV3IERhdGUoY3VycmVudERhdGUuZ2V0VGltZSgpICsgdGhpcy5jYWNoZS50aW1lQWRqdXN0bWVudCArIDE5ODAwMDAwKTtcclxuICAgIHJvbGVEYXRhLnJvbGVJbmZvLnJvbGVbJ3VwZGF0ZWRCeSddID0gdGhpcy5jYWNoZS5YX1VTRVJOQU1FO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1jcmVhdGVSb2xlJyxcclxuICAgICAgZGF0YTogeyAnQXBwRGF0YSc6IHJvbGVEYXRhIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJlc2V0VmFyaWFibGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWRDaXJjbGVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZWxlY3RlZE5lU2hvcnROYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UucGFyc2VkTm9kZUNpcmNsZUpzb24gPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUNpcmNsZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnN0cnVjdHVyZWRSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm1vZHVsZVJlc3RyaWN0aW9uID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdCA9IFtdO1xyXG4gIH1cclxuICBnZXRDb29raWUoa2V5KTogYW55IHtcclxuICAgIGNvbnN0IGNvb2tpZVN0ciA9IGRvY3VtZW50LmNvb2tpZTtcclxuICAgIGNvbnN0IGNvb2tpZXM6IHN0cmluZ1tdID0gY29va2llU3RyLnNwbGl0KCc7Jyk7XHJcbiAgICBjb25zdCBtYXAgPSB7fTtcclxuICAgIGNvb2tpZXMuZm9yRWFjaChjb29raWUgPT4ge1xyXG4gICAgICBpZiAoY29va2llKSB7XHJcbiAgICAgICAgY29uc3Qga2V5dmFsID0gY29va2llLnRyaW0oKS5zcGxpdCgnPScpO1xyXG4gICAgICAgIG1hcFtrZXl2YWxbMF0udHJpbSgpXSA9IGtleXZhbFsxXS50cmltKCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIG1hcFtrZXldO1xyXG4gIH1cclxuICByZXN0cnVjdHVyZUFjY2Vzc0pzb24obW9kdWxlLCBzdHJ1Y3R1cmVkSnNvbikge1xyXG4gICAgZm9yIChjb25zdCBrZXkgaW4gbW9kdWxlKSB7XHJcbiAgICAgIGlmIChtb2R1bGUuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gbW9kdWxlW2tleV07XHJcbiAgICAgICAgaWYgKHZhbHVlLmFjY2Vzcykge1xyXG4gICAgICAgICAgY29uc3QgYWNjZXNzID0ge307XHJcbiAgICAgICAgICBmb3IgKGNvbnN0IGt5IGluIHZhbHVlLmFjY2Vzcykge1xyXG4gICAgICAgICAgICBpZiAodmFsdWUuYWNjZXNzLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gdmFsdWUuYWNjZXNzW2t5XTtcclxuICAgICAgICAgICAgICBzd2l0Y2ggKGt5KSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdSJzpcclxuICAgICAgICAgICAgICAgICAgYWNjZXNzWydSZWFkJ10gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ1cnOlxyXG4gICAgICAgICAgICAgICAgICBhY2Nlc3NbJ1dyaXRlJ10gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ0QnOlxyXG4gICAgICAgICAgICAgICAgICBhY2Nlc3NbJ0RlbGV0ZSddID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBzdHJ1Y3R1cmVkSnNvbltrZXldID0gYWNjZXNzO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLnJlc3RydWN0dXJlQWNjZXNzSnNvbih2YWx1ZSwgc3RydWN0dXJlZEpzb24pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHN0cnVjdHVyZWRKc29uO1xyXG4gIH1cclxuICAvLyB2YXIgYXV0aFRva2VuPVwiU0MxLjE6UkQjU0MxLjI6UldEI1NDMS4zOlJEI1NDNS4xOlJEI1NDMi4xOlJXRCNTQzMuMi4xOlJEXCI7XHJcbiAgcGFyc2VUb2tlbihhdXRoVG9rZW46IHN0cmluZykge1xyXG4gICAgY29uc3QganNvbiA9IHt9O1xyXG4gICAgaWYgKCFhdXRoVG9rZW4pIHtcclxuICAgICAgcmV0dXJuIGpzb247XHJcbiAgICB9XHJcbiAgICBjb25zdCB0b2tlbnM6IHN0cmluZ1tdID0gYXV0aFRva2VuLnNwbGl0KCcjJyk7XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRva2Vucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBjb25zdCB0b2tlbiA9IHRva2Vuc1tpXTtcclxuICAgICAgY29uc3Qgc2hvcnRDb2RlcyA9IHRva2VuLnNwbGl0KCcuJyk7XHJcbiAgICAgIGxldCB0ZW1wTmFtZSA9ICcnO1xyXG4gICAgICBsZXQgdGVtcCA9IGpzb247XHJcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgc2hvcnRDb2Rlcy5sZW5ndGggLSAxOyBqKyspIHtcclxuICAgICAgICBjb25zdCBzaG9ydENvZGUgPSBzaG9ydENvZGVzW2pdO1xyXG4gICAgICAgIGlmICh0ZW1wTmFtZSA9PT0gJycpIHtcclxuICAgICAgICAgIHRlbXBOYW1lID0gc2hvcnRDb2RlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0ZW1wTmFtZSA9IGAke3RlbXBOYW1lfS4ke3Nob3J0Q29kZX1gO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRlbXAuaGFzT3duUHJvcGVydHkodGVtcE5hbWUpKSB7XHJcbiAgICAgICAgICB0ZW1wW3RlbXBOYW1lXSA9IHt9O1xyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wID0gdGVtcFt0ZW1wTmFtZV07XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHRlbXBOYW1lID09PSAnJykge1xyXG4gICAgICAgIHRlbXBOYW1lID0gc2hvcnRDb2Rlc1tzaG9ydENvZGVzLmxlbmd0aCAtIDFdLnNwbGl0KCc6JylbMF07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGVtcE5hbWUgPSBgJHt0ZW1wTmFtZX0uJHtzaG9ydENvZGVzW3Nob3J0Q29kZXMubGVuZ3RoIC0gMV0uc3BsaXQoJzonKVswXX1gO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghdGVtcC5oYXNPd25Qcm9wZXJ0eSh0ZW1wTmFtZSkpIHtcclxuICAgICAgICBjb25zdCByZXN0cmljdEpzb24gPSB7fTtcclxuICAgICAgICBjb25zdCByZXN0cmljdGlvbiA9IHNob3J0Q29kZXNbc2hvcnRDb2Rlcy5sZW5ndGggLSAxXS5zcGxpdCgnOicpWzFdLnNwbGl0KCcnKTtcclxuICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IHJlc3RyaWN0aW9uLmxlbmd0aDsgaysrKSB7XHJcbiAgICAgICAgICByZXN0cmljdEpzb25bcmVzdHJpY3Rpb25ba11dID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRlbXBbdGVtcE5hbWVdID0geyBhY2Nlc3M6IHJlc3RyaWN0SnNvbiB9O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4ganNvbjtcclxuICB9XHJcbiAgcHJpdmF0ZSBwYXJzZU5vZGVDaXJjbGVUb2tlbih0b2tlbikge1xyXG4gICAgY29uc3QgcGFyc2VkSnNvbiA9IHt9O1xyXG4gICAgaWYgKCF0b2tlbiB8fCB0b2tlbiA9PT0gJycpIHtcclxuICAgICAgcmV0dXJuIHBhcnNlZEpzb247XHJcbiAgICB9XHJcbiAgICBjb25zdCBzaW5nbGVOb2RlQ2lyY2xlTGlzdDogc3RyaW5nW10gPSB0b2tlbi5zcGxpdCgnIycpO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaW5nbGVOb2RlQ2lyY2xlTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICBjb25zdCBzaW5nbGVOb2RlQ2lyY2xlID0gc2luZ2xlTm9kZUNpcmNsZUxpc3RbaV07XHJcbiAgICAgIGNvbnN0IG5vZGUgPSBzaW5nbGVOb2RlQ2lyY2xlLnNwbGl0KCc6JylbMF07XHJcbiAgICAgIGNvbnN0IGNpcmNsZXNMaXN0ID0gc2luZ2xlTm9kZUNpcmNsZS5zcGxpdCgnOicpWzFdLnNwbGl0KCcsJyk7XHJcbiAgICAgIGNvbnN0IGNpcmNsZUpzb24gPSB7fTtcclxuICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBjaXJjbGVzTGlzdC5sZW5ndGg7IGorKykge1xyXG4gICAgICAgIGNpcmNsZUpzb25bdGhpcy5jYWNoZS5jaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZVsnQ2lyY2xlTmFtZSddW2NpcmNsZXNMaXN0W2pdXV0gPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICAgIHBhcnNlZEpzb25bbm9kZV0gPSBjaXJjbGVKc29uO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHBhcnNlZEpzb247XHJcbiAgfVxyXG4gIG5lU2hvcnROYW1lRnVsbE5hbWVNYXBwaW5nKCk6IHZvaWQge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB0aGlzLmNhY2hlLm5lU2hvcnROYW1lRnVsbE5hbWVKc29uO1xyXG4gICAgY29uc3QgbmVTaG9ydE5hbWUgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdFswXTtcclxuICAgIGlmIChyZXNwb25zZS5Ob2RlTmFtZSkge1xyXG4gICAgICBjb25zdCBub2RlRnVsbE5hbWUgPSByZXNwb25zZS5Ob2RlTmFtZVtuZVNob3J0TmFtZV07XHJcbiAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZU5hbWUgPSBub2RlRnVsbE5hbWU7XHJcbiAgICB9XHJcbiAgICBpZiAoIXRoaXMuY2FjaGUubWFwTmVTaG9ydE5hbWVGdWxsTmFtZSkge1xyXG4gICAgICB0aGlzLmNhY2hlLm1hcE5lU2hvcnROYW1lRnVsbE5hbWUgPSB7fTtcclxuICAgIH1cclxuICAgIGZvciAobGV0IGl0ciA9IDA7IGl0ciA8IHJlc3BvbnNlLk5vZGVOYW1lICYmIHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0Lmxlbmd0aDsgaXRyKyspIHtcclxuICAgICAgdGhpcy5jYWNoZS5tYXBOZVNob3J0TmFtZUZ1bGxOYW1lW3Jlc3BvbnNlLk5vZGVOYW1lW3RoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0W2l0cl1dXSA9IHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0W2l0cl07XHJcbiAgICB9XHJcbiAgfVxyXG4gIG5lQ2lyY2xlU2hvcnROYW1lRnVsbE5hbWVNYXBwaW5nKCk6IHZvaWQge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB0aGlzLmNhY2hlLmNpcmNsZUZ1bGxOYW1lSnNvblJlc3BvbnNlO1xyXG4gICAgY29uc3QgY2lyY2xlU2hvcnROYW1lc0xpc3QgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLm1hcE5lTmFtZUNpcmNsZU5hbWVbdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3RbMF1dO1xyXG4gICAgaWYgKGNpcmNsZVNob3J0TmFtZXNMaXN0KSB7XHJcbiAgICAgIGNvbnN0IGNpcmNsZSA9IGNpcmNsZVNob3J0TmFtZXNMaXN0LnNwbGl0KCcsJyk7XHJcbiAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWRDaXJjbGVOYW1lID0gcmVzcG9uc2UuQ2lyY2xlTmFtZVtjaXJjbGVbMF1dO1xyXG4gICAgfVxyXG4gIH1cclxuICBnZXRBY2Nlc3NKc29uPFQ+KHByb2R1Y3RJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRNb2R1bGVTdWJNb2R1bGVEYXRhJnByb2R1Y3RJZD0nICsgcHJvZHVjdElkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVDaXJjbGVKc29uPFQ+KHByb2R1Y3RJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXROb2RlQ2lyY2xlRGF0YSZwcm9kdWN0SWQ9JyArIHByb2R1Y3RJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRNb2R1bGVUb0lkSnNvbjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRTaG9ydENvZGVUb0lkTWFwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXROb2RlVG9JZEpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Tm9kZVRvSWRNYXAnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldENpcmNsZVRvSWRKc29uPFQ+KHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldENpcmNsZVRvSWRNYXAnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZScsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Tm9kZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXROb2RlU2hvcnROYW1lRnVsbE5hbWUnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZUpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBkZWxldGVSb2xlPFQ+KHJvbGVJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghcm9sZUlkKVxyXG4gICAgICB0aHJvdyBcIlJvbGUgaWQgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1kZWxldGVSb2xlJnJvbGVJZD0nICsgcm9sZUlkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5kZWxldGVEYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBtb2RpZnlSb2xlPFQ+KHJvbGVJZCwgcm9sZURhdGEscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIXJvbGVJZClcclxuICAgICAgdGhyb3cgXCJSb2xlIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIHtcclxuICAgICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICAgIHJvbGVEYXRhLnJvbGVJbmZvLnJvbGVbJ3VwZGF0ZWRCeSddID0gdGhpcy5jYWNoZS5YX1VTRVJOQU1FO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj11cGRhdGVSb2xlJnJvbGVJZD0nICsgcm9sZUlkLFxyXG4gICAgICBkYXRhOiB7IFwiQXBwRGF0YVwiOiByb2xlRGF0YSB9LFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB2aWV3Um9sZTxUPihyb2xlSWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIXJvbGVJZClcclxuICAgICAgdGhyb3cgXCJSb2xlIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdSb2xlJnJvbGVJZD0nICsgcm9sZUlkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRBbGxSb2xlPFQ+KGZyb20sIHNpemUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0QWxsUm9sZSZmcm9tPScgKyBmcm9tICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjaGVja1JvbGVFeGlzdGVuY2U8VD4ocm9sZW5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIXJvbGVuYW1lKVxyXG4gICAgICB0aHJvdyBcInJvbGVuYW1lIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Y2hlY2tSb2xlJnJvbGVOYW1lPScgKyByb2xlbmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjcmVhdGVVc2VyR3JvdXA8VD4oZ3JvdXBEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCBjdXJyZW50RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWydjcmVhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWydjcmVhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRPbiddID0gbmV3IERhdGUoY3VycmVudERhdGUuZ2V0VGltZSgpICsgdGhpcy5jYWNoZS50aW1lQWRqdXN0bWVudCArIDE5ODAwMDAwKTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRCeSddID0gdGhpcy5jYWNoZS5YX1VTRVJOQU1FO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNyZWF0ZUdyb3VwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogeyAnQXBwRGF0YSc6IGdyb3VwRGF0YSB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgdmlld1VzZXJHcm91cDxUPihncm91cElkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFncm91cElkKVxyXG4gICAgICB0aHJvdyBcImdyb3VwSWQgaWQgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdHcm91cCZncm91cElkPScgKyBncm91cElkLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB2aWV3VXNlckdyb3VwTGlzdDxUPihmcm9tLCBzaXplLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dmlld0dyb3VwTGlzdCZmcm9tPScgKyBmcm9tICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHZpZXdBbGxHcm91cDxUPihmcm9tLCBzaXplLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dmlld0FsbEdyb3VwJmZyb209JyArIGZyb20gKyAnJnNpemU9JyArIHNpemUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZGVsZXRlVXNlckdyb3VwPFQ+KGdyb3VwSWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIWdyb3VwSWQpXHJcbiAgICAgIHRocm93IFwiZ3JvdXBJZCBpZCBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249ZGVsZXRlR3JvdXAmZ3JvdXBJZD0nICsgZ3JvdXBJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5kZWxldGVEYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBtb2RpZnlVc2VyR3JvdXA8VD4oZ3JvdXBJZCwgZ3JvdXBEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFncm91cElkKVxyXG4gICAgICB0aHJvdyBcImdyb3VwSWQgaWQgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1sndXBkYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1sndXBkYXRlZEJ5J10gPSB0aGlzLmNhY2hlLlhfVVNFUk5BTUU7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249bW9kaWZ5R3JvdXAmZ3JvdXBJZD0nICsgZ3JvdXBJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogeyAnQXBwRGF0YSc6IGdyb3VwRGF0YSB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBsb2NrVXNlcjxUPih1c2VyTmFtZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWxvY2tVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB1bmxvY2tVc2VyPFQ+KHVzZXJOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dW5sb2NrVXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbG9ja0dyb3VwPFQ+KGdyb3VwTmFtZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWxvY2tHcm91cCZncm91cE5hbWU9JyArIGdyb3VwTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB1bmxvY2tHcm91cDxUPihncm91cE5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj11bmxvY2tHcm91cCZncm91cE5hbWU9JyArIGdyb3VwTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDb3VudFVzZXJzPFQ+KHJvbGVJZEpzb24scHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRDb3VudFVzZXJzJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTpyb2xlSWRKc29uXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjaGFuZ2VQYXNzd29yZDxUPih1c2VyTmFtZSwgb2xkUGFzc3dvcmQsIG5ld1Bhc3N3b3JkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Y2hhbmdlUGFzc3dvcmQmdXNlck5hbWU9JyArIHVzZXJOYW1lLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgXCJ1c2VySW5mb1wiOiB7XHJcbiAgICAgICAgICBcInVzZXJOYW1lXCI6IHVzZXJOYW1lLFxyXG4gICAgICAgICAgXCJvbGRVc2VyUGFzc3dvcmRcIjogQWVzVXRpbHMuZW5jcnlwdChvbGRQYXNzd29yZCksXHJcbiAgICAgICAgICBcIm5ld1VzZXJQYXNzd29yZFwiOiBBZXNVdGlscy5lbmNyeXB0KG5ld1Bhc3N3b3JkKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZm9yZ290UGFzc3dvcmQ8VD4odXNlck5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1mb3Jnb3RQYXNzb3dvcmQnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGluc2VydFRyYWNlRGF0YTxUPih1c2VyTmFtZSxvcGVyYXRpb246c3RyaW5nLHJlcXVlc3RQYXJhbWV0ZXJzOnN0cmluZyxyZXF1ZXN0SGVhZGVyczpzdHJpbmcscHJvamVjdD86c3RyaW5nLCk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBsZXQgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgaGVhZGVycz1oZWFkZXJzLmFwcGVuZChcInVzZXJOYW1lXCIsdXNlck5hbWUpLmFwcGVuZChcIm9wZXJhdGlvblwiLG9wZXJhdGlvbikuYXBwZW5kKFwidGltZXN0YW1wXCIsY3VycmVudERhdGUuZ2V0VGltZSgpLnRvU3RyaW5nKCkpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLlRSQUNFX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWluc2VydFRyYWNlRGF0YScsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICAgIFwicmVxdWVzdFBhcmFtZXRlcnNcIjoge3JlcXVlc3RQYXJhbWV0ZXJzfSxcclxuICAgICAgICAgIFwicmVxdWVzdEhlYWRlcnNcIjoge3JlcXVlc3RIZWFkZXJzfSxcclxuICAgICAgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0VHJhY2VEYXRhPFQ+KHVzZXJOYW1lLG9wZXJhdGlvbjpzdHJpbmcsdHJhY2VMZXZlbDpzdHJpbmcsZnJvbVRpbWVTdGFtcDpzdHJpbmcsdG9UaW1lU3RhbXA6c3RyaW5nLHByb2plY3Q/OnN0cmluZywpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaGVhZGVycz1oZWFkZXJzLmFwcGVuZChcInVzZXJOYW1lXCIsdXNlck5hbWUpLmFwcGVuZChcIm9wZXJhdGlvblwiLG9wZXJhdGlvbikuYXBwZW5kKFwidHJhY2VMZXZlbFwiLHRyYWNlTGV2ZWwpLmFwcGVuZChcImZyb21UaW1lU3RhbXBcIixmcm9tVGltZVN0YW1wKS5hcHBlbmQoXCJ0b1RpbWVTdGFtcFwiLHRvVGltZVN0YW1wKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5UUkFDRV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRUcmFjZURhdGEnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJlc2V0UGFzc3dvcmQ8VD4odXNlck5hbWU6IHN0cmluZywgb3RwOiBTdHJpbmcsIG5ld1Bhc3N3b3JkOiBzdHJpbmcsY29uZmlybVBhc3N3b3JkOiBzdHJpbmcsIHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBoZWFkZXJzPWhlYWRlcnMuYXBwZW5kKFwidXNlck5hbWVcIix1c2VyTmFtZSk7XHJcbiAgICBsZXQgcGFzc3dvcmQ6c3RyaW5nID1Sc2FVdGlscy5lbmNyeXB0KG5ld1Bhc3N3b3JkKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1yZXNldFBhc3N3b3JkJyxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIFwidXNlckluZm9cIjoge1xyXG4gICAgICAgICAgXCJ1c2VyTmFtZVwiOiB1c2VyTmFtZSxcclxuICAgICAgICAgIFwibmV3UGFzc3dvcmRcIjogcGFzc3dvcmQsXHJcbiAgICAgICAgICBcImNvbmZpcm1QYXNzd29yZFwiOiBwYXNzd29yZCxcclxuICAgICAgICAgIFwib3RwXCI6b3RwXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZW5lcmF0ZVBhc3N3b3JkPFQ+KHVzZXJOYW1lOiBzdHJpbmcsIG90cDogU3RyaW5nLCBuZXdQYXNzd29yZDogc3RyaW5nLGNvbmZpcm1QYXNzd29yZDogc3RyaW5nLCBwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaGVhZGVycz1oZWFkZXJzLmFwcGVuZChcInVzZXJOYW1lXCIsdXNlck5hbWUpO1xyXG4gICAgbGV0IHBhc3N3b3JkOnN0cmluZyA9UnNhVXRpbHMuZW5jcnlwdChuZXdQYXNzd29yZCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2VuZXJhdGVQYXNzd29yZCcsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBcInVzZXJJbmZvXCI6IHtcclxuICAgICAgICAgIFwidXNlck5hbWVcIjogdXNlck5hbWUsXHJcbiAgICAgICAgICBcIm5ld1Bhc3N3b3JkXCI6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgXCJjb25maXJtUGFzc3dvcmRcIjogcGFzc3dvcmQsXHJcbiAgICAgICAgICBcIm90cFwiOm90cFxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5VXNlckltYWdlPFQ+KHVzZXJOYW1lLCBBcHBEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCF1c2VyTmFtZSlcclxuICAgICAgdGhyb3cgXCJ1c2VyTmFtZSBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249bW9kaWZ5VXNlckltYWdlJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgICdBcHBEYXRhJzogQXBwRGF0YVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBXZWJTb2NrZXRDYWxsYmFja3Mge1xyXG4gIG9uT3Blbj86IChldmVudD86IGFueSx3ZWJzb2NrZXQ/OiBXZWJTb2NrZXQpID0+IHZvaWQ7XHJcbiAgb25DbG9zZT86IChldmVudD86IGFueSkgPT4gdm9pZDtcclxuICBvbkVycm9yPzogKGV2ZW50PzogYW55KSA9PiB2b2lkO1xyXG4gIG9uTWVzc2FnZTogKGV2ZW50PzogYW55KSA9PiB2b2lkO1xyXG59XHJcbiIsImltcG9ydCB7IEh0dHBJbnRlcmNlcHRvciwgSHR0cFJlcXVlc3QsIEh0dHBIYW5kbGVyLCBIdHRwUmVzcG9uc2UsIEh0dHBFdmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ2FjaGVNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4vY2FjaGUtbWFuYWdlci5zZXJ2aWNlJztcclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgSHR0cFJlc3BvbnNlSW50ZXJjZXB0b3IgaW1wbGVtZW50cyBIdHRwSW50ZXJjZXB0b3Ige1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBzZXNzaW9uU2VydmljZTogU2Vzc2lvblNlcnZpY2UsIHByaXZhdGUgYXBwQ29uZmlndXJhdGlvbjogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsXHJcbiAgICAgICAgcHJpdmF0ZSBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSkgeyB9XHJcbiAgICBpbnRlcmNlcHQocmVxOiBIdHRwUmVxdWVzdDxhbnk+LCBuZXh0OiBIdHRwSGFuZGxlcik6IE9ic2VydmFibGU8SHR0cEV2ZW50PGFueT4+IHtcclxuICAgICAgICBpZiAodGhpcy5jYWNoZS5YX1NPQ0tFVF9BRERSRVNTKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ1gtU09DS0VULUFERFJFU1MnOiB0aGlzLmNhY2hlLlhfU09DS0VUX0FERFJFU1NcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNhY2hlLlhfVVNFUk5BTUUpIHtcclxuICAgICAgICAgICAgcmVxID0gcmVxLmNsb25lKHtcclxuICAgICAgICAgICAgICAgIHNldEhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnWC1VU0VSTkFNRSc6IHRoaXMuY2FjaGUuWF9VU0VSTkFNRVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUuU09DS0VUX0lQKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ3NvY2tldElwJzogdGhpcy5jYWNoZS5TT0NLRVRfSVBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXEuaGVhZGVycy5oYXMoJ1gtRXZlbnQtTmFtZScpKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3BlcmF0aW9uOiByZXEuaGVhZGVycy5nZXQoJ1gtRXZlbnQtTmFtZScpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChyZXEuaGVhZGVycy5oYXMoJ0V2ZW50LUtleScpKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3BlcmF0aW9uOiByZXEuaGVhZGVycy5nZXQoJ0V2ZW50LUtleScpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gIGVsc2UgaWYgKHJlcS5wYXJhbXMuaGFzKCdvcGVyYXRpb24nKSkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogcmVxLnBhcmFtcy5nZXQoJ29wZXJhdGlvbicpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiYgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWUgJiZcclxuICAgICAgICAgICAgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKSAmJiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QpIHtcclxuICAgICAgICAgICAgY29uc3QgdXNlclRva2VuID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRVc2VyVG9rZW5EYXRhKCk7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJOYW1lID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWU7XHJcbiAgICAgICAgICAgIGxldCBwcm9kdWN0OiBzdHJpbmc7XHJcbiAgICAgICAgICAgIHByb2R1Y3QgPSByZXEuaGVhZGVycy5nZXQoXCJwcm9qZWN0XCIpO1xyXG4gICAgICAgICAgICBpZiAoIXByb2R1Y3QpIHtcclxuICAgICAgICAgICAgICAgIHByb2R1Y3QgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3Q7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVxID0gcmVxLmNsb25lKHtcclxuICAgICAgICAgICAgICAgIHNldEhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyVG9rZW46IGAke3VzZXJOYW1lfS0ke3VzZXJUb2tlbn1gLFxyXG4gICAgICAgICAgICAgICAgICAgIHByb2plY3Q6IHByb2R1Y3RcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBuZXh0LmhhbmRsZShyZXEpLnBpcGUodGFwKHJlc3BvbnNlID0+IHtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlIGluc3RhbmNlb2YgSHR0cFJlc3BvbnNlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwID0gcmVzcG9uc2UgYXMgSHR0cFJlc3BvbnNlPGFueT47XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcC5oZWFkZXJzLmhhcygndXNlclRva2VuJykpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFVzZXJUb2tlbkRhdGEocmVzcC5oZWFkZXJzLmdldCgndXNlclRva2VuJykpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UucHV0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHkgJiYgcmVzcG9uc2UuYm9keVsnc3RhdHVzQ29kZSddICYmXHJcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UuYm9keVsnc3RhdHVzQ29kZSddWydodHRwc3RhdHVzY29kZSddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXVsnaHR0cHN0YXR1c2NvZGUnXSA9PT0gNDAxICYmIChyZXNwb25zZS5ib2R5WydzdGF0dXNDb2RlJ11bJ29wU3RhdHVzQ29kZSddXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID09PSA5MDMgfHwgcmVzcG9uc2UuYm9keVsnc3RhdHVzQ29kZSddWydvcFN0YXR1c0NvZGUnXSA9PT0gNDAzMCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5jbGVhclNlc3Npb25EYXRhQW5kR290b1Nlc3Npb25FeHBpcmVQYWdlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkpO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1pYW0nLFxyXG4gIHRlbXBsYXRlOiBgXHJcbiAgICA8cD5cclxuICAgICAgaWFtIHdvcmtzIVxyXG4gICAgPC9wPlxyXG4gIGAsXHJcbiAgc3R5bGVzOiBbXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgSWFtQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IENhY2hlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuL2NhY2hlLW1hbmFnZXIuc2VydmljZSc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbml0aWFsaXplQXBwKGFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlOiBBcHBDb25maWd1cmF0aW9uU2VydmljZSxcclxuICAgIGNhY2hlOiBDYWNoZU1hbmFnZXJTZXJ2aWNlKSB7XHJcbiAgICByZXR1cm4gKCkgPT4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICBhcHBDb25maWd1cmF0aW9uU2VydmljZS5sb2FkQ29uZmlndXJhdGlvbignYXNzZXRzL2NvbmZpZ3VyYXRpb24vY29uZmlnLmpzb24nKS50aGVuKCgpID0+IHtcclxuICAgICAgICBjb25zdCBnZXRSc2FLZXlQcm9taXNlID0gY2FjaGUuZ2V0QXV0aEtleSgpO1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0VXBSb3V0ZUNoYW5nZVByb21pc2UgPSBjYWNoZS5vblN0YXJ0dXBSb3V0ZUNoYW5nZShldmVudCk7XHJcbiAgICAgICAgUHJvbWlzZS5hbGwoW2dldFJzYUtleVByb21pc2UsIHN0YXJ0VXBSb3V0ZUNoYW5nZVByb21pc2VdKS50aGVuKCgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IG5vZGVTaG9ydEZ1bGxQcm9taXNlID0gY2FjaGUuZ2V0Tm9kZVNob3J0TmFtZUZ1bGxOYW1lSnNvbigpO1xyXG4gICAgICAgICAgY29uc3QgY2lyY2xlU2hvcnRGdWxsUHJvbWlzZSA9IGNhY2hlLmdldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lSnNvbigpO1xyXG4gICAgICAgICAgY29uc3QgbW9kdWxlVG9JZFByb21pc2UgPSBjYWNoZS5nZXRNb2R1bGVUb0lkSnNvbigpO1xyXG4gICAgICAgICAgY29uc3Qgbm9kZVRvSWRQcm9taXNlID0gY2FjaGUuZ2V0Tm9kZVRvSWRKc29uKCk7XHJcbiAgICAgICAgICBjb25zdCBjaXJjbGVUb0lkUHJvbWlzZSA9IGNhY2hlLmdldENpcmNsZVRvSWRKc29uKCk7XHJcbiAgICAgICAgICBjb25zdCBvcGVyYXRpb25Ub01vZHVsZU5vZGVDaXJjbGVQcm9taXNlID0gY2FjaGUuZ2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlSnNvbigpO1xyXG4gICAgICAgICAgUHJvbWlzZS5hbGwoW25vZGVTaG9ydEZ1bGxQcm9taXNlLCBjaXJjbGVTaG9ydEZ1bGxQcm9taXNlLCBtb2R1bGVUb0lkUHJvbWlzZSxcclxuICAgICAgICAgICAgbm9kZVRvSWRQcm9taXNlLCBjaXJjbGVUb0lkUHJvbWlzZSwgb3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlUHJvbWlzZV0pLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgY2FjaGUuY2FsbFdoZW5Db25maWdMb2FkcygpO1xyXG4gICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSwgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgICByZWplY3QoKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0sIChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sIChlcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICByZWplY3QoKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiIsImltcG9ydCB7IE5nTW9kdWxlLCBBUFBfSU5JVElBTElaRVIsIE1vZHVsZVdpdGhQcm92aWRlcnMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSWFtQ29tcG9uZW50IH0gZnJvbSAnLi9pYW0uY29tcG9uZW50JztcclxuaW1wb3J0IHsgQXBwQ29uZmlndXJhdGlvblNlcnZpY2UgfSBmcm9tICcuL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgSWFtU2VydmljZSB9IGZyb20gJy4vaWFtLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb29raWVTZXJ2aWNlIH0gZnJvbSAnbmd4LWNvb2tpZS1zZXJ2aWNlJztcclxuaW1wb3J0IHsgSFRUUF9JTlRFUkNFUFRPUlMgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEh0dHBSZXNwb25zZUludGVyY2VwdG9yIH0gZnJvbSAnLi9odHRwLXJlc3BvbnNlLWludGVyY2VwdG9yJztcclxuaW1wb3J0IHsgaW5pdGlhbGl6ZUFwcCB9IGZyb20gJy4vY29uZmlndXJhdGlvbi1mYWN0b3J5JztcclxuXHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICBdLFxyXG4gIGRlY2xhcmF0aW9uczogW0lhbUNvbXBvbmVudF0sXHJcbiAgZXhwb3J0czogW0lhbUNvbXBvbmVudF0sXHJcbiAgcHJvdmlkZXJzOiBbIElhbVNlcnZpY2UsIENvb2tpZVNlcnZpY2UgLCBTZXNzaW9uU2VydmljZSwgQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIENhY2hlTWFuYWdlclNlcnZpY2UsIHtcclxuICAgIHByb3ZpZGU6IEFQUF9JTklUSUFMSVpFUixcclxuICAgIHVzZUZhY3Rvcnk6IGluaXRpYWxpemVBcHAsXHJcbiAgICBkZXBzOiBbQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIENhY2hlTWFuYWdlclNlcnZpY2VdLFxyXG4gICAgbXVsdGk6IHRydWVcclxuICB9LCB7XHJcbiAgICBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SUyxcclxuICAgIHVzZUNsYXNzOiBIdHRwUmVzcG9uc2VJbnRlcmNlcHRvcixcclxuICAgIG11bHRpOiB0cnVlXHJcbiAgfV1cclxufSlcclxuZXhwb3J0IGNsYXNzIElhbU1vZHVsZSB7XHJcbiAgcHVibGljIHN0YXRpYyBmb3JSb290KCk6IE1vZHVsZVdpdGhQcm92aWRlcnMge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbmdNb2R1bGU6IElhbU1vZHVsZSxcclxuICAgICAgcHJvdmlkZXJzOiBbXVxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbIkluamVjdGFibGUiLCJIdHRwQ2xpZW50IiwiZm9yZ2UiLCJhZXNqcy51dGlscyIsImFlc2pzLnBhZGRpbmciLCJhZXNqcy5Nb2RlT2ZPcGVyYXRpb24iLCJSb3V0ZXIiLCJ0c2xpYl8xLl9fdmFsdWVzIiwiQ29va2llU2VydmljZSIsIkFwcFNldHRpbmciLCJTdWJqZWN0IiwiSHR0cEhlYWRlcnMiLCJyZXRyeSIsImNhdGNoRXJyb3IiLCJmb3JnZS51dGlsIiwiT2JzZXJ2YWJsZSIsImRlbGF5IiwidGhyb3dFcnJvciIsIkxvY2F0aW9uIiwiSG9zdExpc3RlbmVyIiwiZmlsdGVyIiwiTmF2aWdhdGlvbkVuZCIsInRhcCIsIkh0dHBSZXNwb25zZSIsIkNvbXBvbmVudCIsIk5nTW9kdWxlIiwiQVBQX0lOSVRJQUxJWkVSIiwiSFRUUF9JTlRFUkNFUFRPUlMiXSwibWFwcGluZ3MiOiI7Ozs7OztJQUFBOzs7Ozs7Ozs7Ozs7OztBQWNBLHNCQTRGeUIsQ0FBQztRQUN0QixJQUFJLENBQUMsR0FBRyxPQUFPLE1BQU0sS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4QixPQUFPO1lBQ0gsSUFBSSxFQUFFO2dCQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtvQkFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7Z0JBQ25DLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO2FBQzNDO1NBQ0osQ0FBQztJQUNOLENBQUM7Ozs7Ozs7Ozs7OztRQzVHRywrQkFBVzs7O1lBQVg7Z0JBQ0ksT0FBTyxRQUFRLENBQUMsUUFBUSxDQUFDO2FBQzVCOzZCQVA0QyxRQUFRLENBQUMsUUFBUSxPQUFJO3VDQUNkLFFBQVEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxRQUFRLEdBQUcsT0FBTztxQ0FDdEUsZ0JBQWdCO21DQUNsQixjQUFjO2tDQUNmLGFBQWE7d0JBTmhFOzs7Ozs7O0FDQUE7UUFRRSxpQ0FBb0IsVUFBc0I7WUFBdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtTQUFLOzs7OztRQUMvQyxtREFBaUI7Ozs7WUFBakIsVUFBa0IsUUFBZ0I7Z0JBQWxDLGlCQVdDO2dCQVZDLE9BQU8sSUFBSSxPQUFPLENBQVEsVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDeEMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQW1CLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLFFBQVE7d0JBQ3hFLEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7d0JBQ2pDLE9BQU8sRUFBRSxDQUFDO3FCQUNYLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxRQUFhO3dCQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLGlEQUErQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBRyxDQUFDLENBQUM7d0JBQ3ZGLE1BQU0sQ0FBQyxpREFBK0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUcsQ0FBQyxDQUFDO3FCQUNyRixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7UUFDTSxrREFBZ0I7Ozs7Z0JBQ3JCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDOzs7b0JBbkJoQ0EsYUFBVSxTQUFDO3dCQUNWLFVBQVUsRUFBRSxNQUFNO3FCQUNuQjs7Ozs7d0JBSlFDLGFBQVU7Ozs7c0NBRG5COzs7Ozs7OztJQ0FBLElBQU9DLE9BQUssR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7O1FBSWpDO1NBQWdCOzs7OztRQUNGLDBCQUFpQjs7OztzQkFBQyxnQkFBd0I7Z0JBQ3BELFFBQVEsQ0FBQyxVQUFVLEdBQUdBLE9BQUssQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzs7Ozs7UUFFMUQsdUJBQWM7Ozs7Z0JBQ3hCLE9BQU9BLE9BQUssQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQzs7Ozs7O1FBRTFDLHlCQUFnQjs7OztzQkFBQyxnQkFBd0I7Z0JBQ25ELFFBQVEsQ0FBQyxTQUFTLEdBQUdBLE9BQUssQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzs7Ozs7OztRQUV4RCxnQkFBTzs7Ozs7c0JBQUMsT0FBZSxFQUFFLFlBQXFCO2dCQUN4RCxJQUFJLFlBQVksRUFBRTtvQkFDZCxPQUFPQSxPQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQ0EsT0FBSyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRTt3QkFDOUYsRUFBRSxFQUFFQSxPQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7d0JBQzVCLElBQUksRUFBRTs0QkFDRixFQUFFLEVBQUVBLE9BQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTt5QkFDN0I7cUJBQ0osQ0FBQyxDQUFDLENBQUM7aUJBQ1A7cUJBQU0sSUFBSSxRQUFRLENBQUMsU0FBUyxFQUFFO29CQUMzQixPQUFPQSxPQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFO3dCQUN2RSxFQUFFLEVBQUVBLE9BQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTt3QkFDNUIsSUFBSSxFQUFFOzRCQUNGLEVBQUUsRUFBRUEsT0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO3lCQUM3QjtxQkFDSixDQUFDLENBQUMsQ0FBQztpQkFDUDtxQkFBTTtvQkFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUM7b0JBQ3pDLE9BQU8sSUFBSSxDQUFDO2lCQUNmOzs7Ozs7O1FBRVMsZ0JBQU87Ozs7O3NCQUFDLFVBQWtCLEVBQUUsYUFBc0I7Z0JBQzVELElBQUksYUFBYSxFQUFFO29CQUNmLE9BQU9BLE9BQUssQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDQSxPQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRSxVQUFVLEVBQUU7d0JBQ25HLEVBQUUsRUFBRUEsT0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO3dCQUM1QixJQUFJLEVBQUU7NEJBQ0YsRUFBRSxFQUFFQSxPQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7eUJBQzdCO3FCQUNKLENBQUMsQ0FBQztpQkFDTjtxQkFBTSxJQUFJLFFBQVEsQ0FBQyxVQUFVLEVBQUU7b0JBQzVCLE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUNBLE9BQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLFVBQVUsRUFBRTt3QkFDNUUsRUFBRSxFQUFFQSxPQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7d0JBQzVCLElBQUksRUFBRTs0QkFDRixFQUFFLEVBQUVBLE9BQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTt5QkFDN0I7cUJBQ0osQ0FBQyxDQUFDO2lCQUNOO3FCQUFNO29CQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQztvQkFDMUMsT0FBTyxJQUFJLENBQUM7aUJBQ2Y7Ozs7O1FBRUwsa0NBQWU7OztZQUFmOztnQkFDSSxJQUFNLGFBQWEsR0FBR0EsT0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7O2dCQUN0RSxJQUFNLGNBQWMsR0FBR0EsT0FBSyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDbEUsT0FBT0EsT0FBSyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUN4RDs2QkF4RDBCLElBQUk7OEJBQ0gsSUFBSTt1QkFIcEM7Ozs7Ozs7QUNBQTtRQUtJO1NBQWdCOzs7OztRQUNGLDRCQUFtQjs7OztzQkFBQyxNQUFjO2dCQUM1QyxRQUFRLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzs7Ozs7OztRQUVmLGdCQUFPOzs7OztzQkFBQyxPQUFlLEVBQUUsTUFBZTtnQkFDbEQsSUFBSSxDQUFDLE1BQU0sRUFBRTtvQkFDVCxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztpQkFDNUI7O2dCQUNELElBQU0sR0FBRyxHQUFHQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzs7Z0JBQzdDLElBQUksU0FBUyxHQUFHQSxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbEQsU0FBUyxHQUFHLElBQUlDLGFBQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDOztnQkFDbkQsSUFBTSxNQUFNLEdBQUcsSUFBSUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztnQkFDbEQsSUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDakQsT0FBT0YsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7UUFFdkMsZ0JBQU87Ozs7O3NCQUFDLE1BQWMsRUFBRSxNQUFlO2dCQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNULE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO2lCQUM1Qjs7Z0JBQ0QsSUFBTSxHQUFHLEdBQUdBLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztnQkFDN0MsSUFBTSxNQUFNLEdBQUcsSUFBSUUscUJBQXFCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztnQkFDbEQsSUFBTSxjQUFjLEdBQUdGLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztnQkFDdkQsSUFBSSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDcEQsY0FBYyxHQUFHQyxhQUFhLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDM0QsT0FBUUQsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7OztRQUV6Qyw2QkFBb0I7Ozs7c0JBQUMsTUFBa0I7Z0JBQWxCLHVCQUFBO29CQUFBLFdBQWtCOzs7Z0JBQ2pELElBQU0sR0FBRyxHQUF3QixJQUFJLEdBQUcsRUFBa0IsQ0FBQztnQkFDM0QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztvQkFDM0UsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7b0JBQ3RGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7b0JBQ2hFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO29CQUMxRixHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQztvQkFDMUYsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7b0JBQzFGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO29CQUMxRixHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQzs7Z0JBQzlFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM3QixHQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDN0Q7Z0JBQ0QsT0FBTyxHQUFHLENBQUM7Ozs7O1FBRWYsMkJBQVE7OztZQUFSO2FBQ0M7MEJBNUMrQixJQUFJO3VCQUp4Qzs7Ozs7OztBQ0FBO1FBUUUseUJBQW9CLE1BQWM7WUFBZCxXQUFNLEdBQU4sTUFBTSxDQUFRO1NBQUs7Ozs7O1FBQ3ZDLGtDQUFROzs7O1lBQVIsVUFBUyxJQUFjO2dCQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUM1Qjs7b0JBUkZILGFBQVUsU0FBQzt3QkFDVixVQUFVLEVBQUUsTUFBTTtxQkFDbkI7Ozs7O3dCQUpRTSxXQUFNOzs7OzhCQURmOzs7Ozs7OztnQ0N5QjZCLGFBQTRCLEVBQVUsVUFBc0IsRUFBVSxlQUFnQztZQUF0RyxrQkFBYSxHQUFiLGFBQWEsQ0FBZTtZQUFVLGVBQVUsR0FBVixVQUFVLENBQVk7WUFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7MkJBWHZHLElBQUksWUFBWSxDQUFDLEVBQUMsY0FBYyxFQUFHLElBQUksRUFBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDOzs7Ozs7Ozs7UUFlbEcsdUNBQWM7Ozs7WUFBZCxVQUFlLEdBQXVCO2dCQUF2QixvQkFBQTtvQkFBQSxlQUF1Qjs7O2dCQUVwQyxJQUFJLElBQUksQ0FBTzs7Z0JBQ2YsSUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7Z0JBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7b0JBQ25DLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO2lCQUN6SDtxQkFBTTtvQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7b0JBQ3JDLElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO29CQUNoRCxJQUFJLHFCQUFHLEVBQVUsQ0FBQSxDQUFDO2lCQUNuQjtnQkFDRCx5QkFBTyxJQUEyQixFQUFDO2FBQ3BDOzs7Ozs7OztRQUlELGtDQUFTOzs7O1lBQVQsVUFBVSxHQUFzQjtnQkFBdEIsb0JBQUE7b0JBQUEsY0FBc0I7OztnQkFDOUIsSUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7Z0JBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7b0JBQ3JDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDO2lCQUMzRztnQkFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztnQkFDaEQsT0FBTyxJQUFJLENBQUM7YUFDYjs7Ozs7Ozs7O1FBSUQsdUNBQWM7Ozs7O1lBQWQsVUFBZSxXQUErQixFQUFFLEdBQWU7Z0JBQWYsb0JBQUE7b0JBQUEsZUFBZTs7O2dCQUM3RCxJQUFNLElBQUksR0FBRyxFQUFFLENBQUM7O2dCQUNoQixJQUFNLGVBQWUsR0FBRztvQkFDcEIsV0FBVyxFQUFFO3dCQUNYLFFBQVEsRUFBRSxXQUFXLENBQUMsUUFBUTt3QkFDOUIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxPQUFPO3dCQUM1QixjQUFjLEVBQUUsV0FBVyxDQUFDLGNBQWM7cUJBQzNDO2lCQUNKLENBQUM7Z0JBQ0YsSUFBSSxXQUFXLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ2hDLGVBQWUsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsR0FBRyxXQUFXLENBQUMsZ0JBQWdCLENBQUM7aUJBQ2hGO2dCQUNELElBQUksV0FBVyxDQUFDLE1BQU0sRUFBRTtvQkFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7aUJBQ3JDO2dCQUNELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxlQUFlLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7YUFDbkY7Ozs7Ozs7O1FBSUQseUNBQWdCOzs7O1lBQWhCO2dCQUFpQixjQUFpQjtxQkFBakIsVUFBaUIsRUFBakIscUJBQWlCLEVBQWpCLElBQWlCO29CQUFqQix5QkFBaUI7O2dCQUNoQyxJQUFLLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOzt3QkFDcEIsS0FBa0IsSUFBQSxTQUFBQyxTQUFBLElBQUksQ0FBQSwwQkFBQTs0QkFBakIsSUFBTSxHQUFHLGlCQUFBOzRCQUNaLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUNoQzs7Ozs7Ozs7Ozs7Ozs7O2lCQUNGO3FCQUFNO29CQUNMLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQy9CLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDdEI7O2FBQ0Y7Ozs7Ozs7O1FBSUQsK0NBQXNCOzs7O1lBQXRCLFVBQXVCLFNBQWtCOztnQkFDdkMsSUFBSSxXQUFXLEdBQVEsTUFBTSxDQUFDO2dCQUM5QixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFDckM7b0JBQ0UsV0FBVyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxjQUFjLENBQUM7aUJBQy9EO2dCQUNELElBQUksQ0FBQyxTQUFTLEVBQUU7b0JBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztpQkFDdkY7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lCQUNqRDthQUNGOzs7Ozs7O1FBSUQsK0NBQXNCOzs7WUFBdEI7O2dCQUNFLElBQUksV0FBVyxHQUFRLE1BQU0sQ0FBQztnQkFDOUIsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEVBQ3JDO29CQUNFLFdBQVcsR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUMsY0FBYyxDQUFDO2lCQUMvRDtnQkFDRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFO29CQUMzQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztpQkFDN0Q7Z0JBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztnQkFDdEYsUUFBUSxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLFdBQVcsRUFBRTthQUM3Qzs7Ozs7Ozs7UUFJRCx5Q0FBZ0I7Ozs7WUFBaEIsVUFBaUIsU0FBaUI7Z0JBQ2hDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNoRjs7Ozs7OztRQUlELHlDQUFnQjs7O1lBQWhCOztnQkFDRSxJQUFNLFVBQVUsR0FBVyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztnQkFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtvQkFDckMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQzNIO2dCQUNELElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO2dCQUNoRCxPQUFPLElBQUksQ0FBQzthQUNiOzs7Ozs7Ozs7UUFJRCwyREFBa0M7Ozs7O1lBQWxDLFVBQW1DLGlCQUF1QixFQUFFLEdBQWlDO2dCQUFqQyxvQkFBQTtvQkFBQSx5QkFBaUM7O2dCQUMzRixJQUFJLFFBQU8sT0FBTyxDQUFDLEVBQUU7b0JBQ25CLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO2lCQUM5RDtxQkFBTTtvQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7aUJBQzVDO2FBQ0Y7Ozs7Ozs7O1FBSUQsMkRBQWtDOzs7O1lBQWxDLFVBQW1DLEdBQWlDO2dCQUFqQyxvQkFBQTtvQkFBQSx5QkFBaUM7OztnQkFDbEUsSUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7Z0JBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7b0JBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQ2pGO2dCQUNELElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO2dCQUNoRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekI7Ozs7Ozs7OztRQUlELCtEQUFzQzs7Ozs7WUFBdEMsVUFBdUMscUJBQTJCLEVBQUUsR0FBcUM7Z0JBQXJDLG9CQUFBO29CQUFBLDZCQUFxQzs7Z0JBQ3ZHLElBQUksUUFBTyxPQUFPLENBQUMsRUFBRTtvQkFDbkIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7aUJBQ2xFO3FCQUFNO29CQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztpQkFDNUM7YUFDRjs7Ozs7Ozs7UUFJRCwrREFBc0M7Ozs7WUFBdEMsVUFBdUMsR0FBcUM7Z0JBQXJDLG9CQUFBO29CQUFBLDZCQUFxQzs7O2dCQUMxRSxJQUFNLFVBQVUsR0FBVyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztnQkFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtvQkFDckMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztpQkFDakY7Z0JBQ0QsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLENBQUM7Z0JBQ2hELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6Qjs7Ozs7Ozs7O1FBSUQsK0RBQXNDOzs7OztZQUF0QyxVQUF1QyxxQkFBMkIsRUFBRSxHQUFxQztnQkFBckMsb0JBQUE7b0JBQUEsNkJBQXFDOztnQkFDdkcsSUFBSSxRQUFPLE9BQU8sQ0FBQyxFQUFFO29CQUNuQixZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztpQkFDbEU7cUJBQU07b0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO2lCQUM1QzthQUNGOzs7Ozs7OztRQUlELCtEQUFzQzs7OztZQUF0QyxVQUF1QyxHQUFxQztnQkFBckMsb0JBQUE7b0JBQUEsNkJBQXFDOzs7Z0JBQzFFLElBQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUN6RCxJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFO29CQUNyQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO2lCQUNqRjtnQkFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztnQkFDaEQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCOzs7Ozs7O1FBSUQsaUVBQXdDOzs7WUFBeEM7Z0JBQ0UsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEVBQUU7b0JBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUM7b0JBQ25FLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztpQkFDeEY7YUFDRjs7Ozs7OztRQUlELDBEQUFpQzs7O1lBQWpDO2dCQUNFLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3hCLElBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFO29CQUNyQyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUNoRjthQUNGOzs7O1FBQ08sdUNBQWM7Ozs7Z0JBQ3BCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO2dCQUMvQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztnQkFDM0IsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztnQkFDaEMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQztnQkFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzs7b0JBNU4xQlAsYUFBVSxTQUFDO3dCQUNWLFVBQVUsRUFBRSxNQUFNO3FCQUNuQjs7Ozs7d0JBVFFRLDhCQUFhO3dCQUdjQyx1QkFBVTt3QkFFckMsZUFBZTs7Ozs2QkFOeEI7Ozs7Ozs7QUNDQTs7Ozs7O1FBUWtCLDZDQUFzQjs7OztnQkFDaEMsT0FBTyxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFFcEQsMENBQW1COzs7O2dCQUM3QixPQUFPLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFFakQsMkNBQW9COzs7O2dCQUM5QixPQUFPLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFFbEQsMkNBQW9COzs7O2dCQUM5QixPQUFPLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFFbEQsd0RBQWlDOzs7O2dCQUMzQyxPQUFPLHNCQUFzQixDQUFDLDJCQUEyQixDQUFDLFlBQVksRUFBRSxDQUFDOzs7OztRQUUvRCw4Q0FBdUI7Ozs7Z0JBQ2pDLHNCQUFzQixDQUFDLGdCQUFnQixHQUFHLElBQUlDLFlBQU8sRUFBZ0IsQ0FBQztnQkFDdEUsc0JBQXNCLENBQUMsYUFBYSxHQUFJLElBQUlBLFlBQU8sRUFBZ0IsQ0FBQztnQkFDcEUsc0JBQXNCLENBQUMsY0FBYyxHQUFJLElBQUlBLFlBQU8sRUFBZ0IsQ0FBQztnQkFDckUsc0JBQXNCLENBQUMsY0FBYyxHQUFHLElBQUlBLFlBQU8sRUFBZ0IsQ0FBQzs7Ozs7O1FBRXhFLDBDQUFTOzs7O1lBQVQsVUFBVSxLQUFtQjtnQkFDekIsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZEOzs7OztRQUNELHdDQUFPOzs7O1lBQVAsVUFBUSxLQUFtQjtnQkFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2dCQUNoQyxzQkFBc0IsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3JEOzs7OztRQUNELHdDQUFPOzs7O1lBQVAsVUFBUSxLQUFtQjtnQkFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkIsc0JBQXNCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNyRDs7Ozs7O1FBQ0QsdUNBQU07Ozs7O1lBQU4sVUFBTyxLQUFtQixFQUFFLFNBQW9CO2dCQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ2hDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDcEQ7Ozs7UUFDRCw0Q0FBVzs7O1lBQVg7Z0JBQ0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUN0QyxzQkFBc0IsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUM3RDtrREE3QytDLElBQUlBLFlBQU8sRUFBZ0I7K0NBQzlCLElBQUlBLFlBQU8sRUFBZ0I7Z0RBQzFCLElBQUlBLFlBQU8sRUFBZ0I7Z0RBQzNCLElBQUlBLFlBQU8sRUFBZ0I7NkRBQ2IsSUFBSUEsWUFBTyxFQUFRO3FDQVBuRjs7Ozs7OztBQ0FBO1FBT0Usd0JBQW9CLFVBQXNCO1lBQXRCLGVBQVUsR0FBVixVQUFVLENBQVk7U0FBSzs7Ozs7UUFFakMseUJBQVU7Ozs7c0JBQUMsSUFBWTtnQkFDakMsT0FBTyxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyw2QkFBNkIsQ0FBQzs7Ozs7O1FBRTlHLHNDQUFhOzs7O3NCQUFDLFFBQWU7Z0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLFFBQVE7b0JBQzFELElBQUksR0FBRyxDQUFnQixNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUMsS0FBYSxFQUFFLEdBQVc7d0JBQ2xGLGNBQWMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUMsS0FBSyxDQUFDLENBQUM7cUJBQzNELENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsUUFBYTtvQkFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpREFBK0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUcsQ0FBQyxDQUFDO2lCQUMxRixDQUFDLENBQUM7O29DQVp3QyxJQUFJLEdBQUcsRUFBa0I7O29CQU4zRVYsYUFBVSxTQUFDO3dCQUNWLFVBQVUsRUFBRSxNQUFNO3FCQUNuQjs7Ozs7d0JBSFFDLGFBQVU7Ozs7NkJBRG5COzs7Ozs7O0FDQUE7UUF1Q0UsNkJBQW9CLGdCQUF5QyxFQUFVLFVBQXNCLEVBQ25GLGdCQUF3QyxRQUFrQixFQUFTLGNBQTZCO1lBRDFHLGlCQUMrRztZQUQzRixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQXlCO1lBQVUsZUFBVSxHQUFWLFVBQVUsQ0FBWTtZQUNuRixtQkFBYyxHQUFkLGNBQWM7WUFBMEIsYUFBUSxHQUFSLFFBQVEsQ0FBVTtZQUFTLG1CQUFjLEdBQWQsY0FBYyxDQUFlO3dDQUw3RCxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO2dCQUM3RSxLQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztnQkFDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7YUFDeEIsQ0FBQztTQUU2Rzs7OztRQUMvRyxzQ0FBUTs7O1lBQVIsZUFBYzs7OztRQUNkLHlDQUFXOzs7WUFBWDtnQkFDRSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7aUJBQ3hCO2FBQ0Y7Ozs7UUFDRCx3Q0FBVTs7O1lBQVY7Z0JBQUEsaUJBc0NDOztnQkFyQ0MsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO3FCQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDOztnQkFDdEUsSUFBTSxXQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxJQUFJVSxjQUFXLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsQ0FBQztvQkFDcEgsT0FBTyxvQkFBRSxVQUFvQixDQUFBO2lCQUM5QixDQUFDO2dCQVdGLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQXlCLEdBQUcsRUFBRSxXQUFXLENBQUM7eUJBQzFELElBQUksQ0FBQ0MsZUFBSyxDQUFDLENBQUMsQ0FBQyxFQUFFQyxvQkFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQzFELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOzRCQUM3QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUNoRSxLQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzs7NEJBQ2xELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7NEJBQ2xILElBQU0sVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3hDLEtBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQzs7NEJBRTlDLE9BQU8sRUFBRSxDQUFDO3lCQUNYOzZCQUFNOzRCQUNMLE1BQU0sRUFBRSxDQUFDO3lCQUNWO3FCQUNGLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsQ0FBQzt3QkFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsTUFBTSxFQUFFLENBQUM7cUJBQ1YsQ0FBQyxDQUFDO2lCQUNOLENBQUMsQ0FBQzthQUNKOzs7O1FBQ0QsMERBQTRCOzs7WUFBNUI7Z0JBQUEsaUJBa0NDOztnQkFqQ0MsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO3FCQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMscUNBQXFDLENBQUMsQ0FBQzs7Z0JBQ2xGLElBQU0sV0FBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsSUFBSUYsY0FBVyxDQUFDO3dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTzt3QkFDM0QsV0FBVyxFQUFFLDBCQUEwQjtxQkFDeEMsQ0FBQztpQkFDSCxDQUFDO2dCQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQVcsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQ0MsZUFBSyxDQUFDLENBQUMsQ0FBQyxFQUFFQyxvQkFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzt5QkFDekYsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOzRCQUN4QixLQUFJLENBQUMsdUJBQXVCLEdBQUc7Z0NBQzdCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU87NkJBQ3BDLENBQUM7NEJBQ0YsT0FBTyxFQUFFLENBQUM7eUJBQ1g7NkJBQU07NEJBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUNkO3FCQUNGLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDZixDQUFDLENBQUM7aUJBQ04sQ0FBQyxDQUFDO2FBQ0o7Ozs7UUFDRCw0REFBOEI7OztZQUE5QjtnQkFBQSxpQkFrQ0M7O2dCQWpDQyxJQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7cUJBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDOztnQkFDcEYsSUFBTSxXQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxJQUFJRixjQUFXLENBQUM7d0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO3dCQUMzRCxXQUFXLEVBQUUsNEJBQTRCO3FCQUMxQyxDQUFDO2lCQUNILENBQUM7Z0JBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO29CQUN2QyxLQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDQyxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lCQUN6RixTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNiLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7NEJBQ3hCLEtBQUksQ0FBQywwQkFBMEIsR0FBRztnQ0FDaEMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTzs2QkFDcEMsQ0FBQzs0QkFDRixPQUFPLEVBQUUsQ0FBQzt5QkFDWDs2QkFBTTs0QkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ2Q7cUJBQ0YsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNmLENBQUMsQ0FBQztpQkFDTixDQUFDLENBQUM7YUFDSjs7OztRQUNELCtDQUFpQjs7O1lBQWpCO2dCQUFBLGlCQWdDQzs7Z0JBL0JDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQztxQkFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLGdDQUFnQyxDQUFDLENBQUM7O2dCQUM3RSxJQUFNLFdBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLElBQUlGLGNBQVcsQ0FBQzt3QkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87d0JBQzNELFdBQVcsRUFBRSxxQkFBcUI7cUJBQ25DLENBQUM7aUJBQ0gsQ0FBQztnQkFTRixPQUFPLElBQUksT0FBTyxDQUFPLFVBQUMsT0FBTyxFQUFFLE1BQU07b0JBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNDLGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTs0QkFDeEIsS0FBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOzRCQUNoRCxPQUFPLEVBQUUsQ0FBQzt5QkFDWDs2QkFBTTs0QkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ2Q7cUJBQ0YsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNmLENBQUMsQ0FBQztpQkFDTixDQUFDLENBQUM7YUFDSjs7OztRQUNELDZDQUFlOzs7WUFBZjtnQkFBQSxpQkFnQ0M7O2dCQS9CQyxJQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7cUJBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDOztnQkFDeEUsSUFBTSxXQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxJQUFJRixjQUFXLENBQUM7d0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO3dCQUMzRCxXQUFXLEVBQUUsZ0JBQWdCO3FCQUM5QixDQUFDO2lCQUNILENBQUM7Z0JBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO29CQUN2QyxLQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDQyxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lCQUN6RixTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNiLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7NEJBQ3hCLEtBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7NEJBQzNDLE9BQU8sRUFBRSxDQUFDO3lCQUNYOzZCQUFNOzRCQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt5QkFDZDtxQkFDRixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ2YsQ0FBQyxDQUFDO2lCQUNOLENBQUMsQ0FBQzthQUNKOzs7O1FBQ0QsK0NBQWlCOzs7WUFBakI7Z0JBQUEsaUJBZ0NDOztnQkEvQkMsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO3FCQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQzs7Z0JBQzFFLElBQU0sV0FBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsSUFBSUYsY0FBVyxDQUFDO3dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTzt3QkFDM0QsV0FBVyxFQUFFLGtCQUFrQjtxQkFDaEMsQ0FBQztpQkFDSCxDQUFDO2dCQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDdkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQVcsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQ0MsZUFBSyxDQUFDLENBQUMsQ0FBQyxFQUFFQyxvQkFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzt5QkFDekYsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFOzRCQUN4QixLQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOzRCQUM3QyxPQUFPLEVBQUUsQ0FBQzt5QkFDWDs2QkFBTTs0QkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ2Q7cUJBQ0YsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNmLENBQUMsQ0FBQztpQkFDTixDQUFDLENBQUM7YUFDSjs7OztRQUNELGdFQUFrQzs7O1lBQWxDO2dCQUFBLGlCQWdDQzs7Z0JBL0JDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQztxQkFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLDJDQUEyQyxDQUFDLENBQUM7O2dCQUN4RixJQUFNLFdBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLElBQUlGLGNBQVcsQ0FBQzt3QkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87d0JBQzNELFdBQVcsRUFBRSxnQ0FBZ0M7cUJBQzlDLENBQUM7aUJBQ0gsQ0FBQztnQkFTRixPQUFPLElBQUksT0FBTyxDQUFPLFVBQUMsT0FBTyxFQUFFLE1BQU07b0JBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNDLGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ3pGLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTs0QkFDeEIsS0FBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOzRCQUN4RCxPQUFPLEVBQUUsQ0FBQzt5QkFDWDs2QkFBTTs0QkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ2Q7cUJBQ0YsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNmLENBQUMsQ0FBQztpQkFDTixDQUFDLENBQUM7YUFDSjs7OztRQUNELHlDQUFXOzs7WUFBWDtnQkFDRSxPQUFPLE1BQU0sQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BGOzs7OztRQUNDLGtEQUFvQjs7OztZQUFwQixVQUFxQixLQUFLO2dCQUExQixpQkFnREM7Z0JBOUNDLE9BQU8sSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDdkMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUM7b0JBQzNFLElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRTt3QkFDaEMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO3FCQUNsQztvQkFDRCxJQUFJLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsSUFBSSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0I7MkJBQ2hILEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixFQUFFOzt3QkFDbkUsSUFBSSxRQUFRLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDcEMsSUFBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUN6Qjs0QkFDRSxRQUFRLEdBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDakM7O3dCQUNELElBQU0sY0FBYyxHQUFZLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQzs7d0JBQ25ILElBQU0sUUFBUSxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQzt3QkFDMUQsSUFBSSxjQUFjLElBQUksQ0FBQyxRQUFRLEVBQUU7NEJBQzlCLEtBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUNyRSxPQUFPLEVBQUUsQ0FBQzt5QkFDWDs2QkFBTSxJQUFJLFFBQVEsRUFBRTs0QkFDbkIsSUFBSTtnQ0FDRixJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsRUFBRTtvQ0FDMUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLGtDQUFrQyxFQUFFLENBQUM7aUNBQ2xHO2dDQUNELElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLHFCQUFxQixFQUFFO29DQUM5QyxLQUFJLENBQUMsY0FBYyxDQUFDLHFCQUFxQixHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsc0NBQXNDLEVBQUUsQ0FBQztpQ0FDMUc7Z0NBQ0QsSUFBSSxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLEVBQUU7b0NBQzdDLEtBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxzQ0FBc0MsRUFBRSxDQUFDO2lDQUN6Rzs7Z0NBQ0QsSUFBTSxTQUFTLEdBQUcsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDO2dDQUNwRyxJQUFJLFNBQVMsRUFBRTtvQ0FDYixLQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2lDQUNsRjtnQ0FDRCxLQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxzQkFBc0IsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQ0FDcEUsT0FBTyxFQUFFLENBQUM7aUNBQ1gsRUFBRSxVQUFBLEtBQUs7b0NBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQ0FDbkIsT0FBTyxFQUFFLENBQUM7aUNBQ1gsQ0FBQyxDQUFDOzZCQUNKOzRCQUFDLE9BQU8sQ0FBQyxFQUFFO2dDQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7NkJBQ2hCO3lCQUNGOzZCQUFNOzRCQUNMLE9BQU8sRUFBRSxDQUFDO3lCQUNYO3FCQUNGO2lCQUNGLENBQUMsQ0FBQzthQUNKOzs7O1FBQ0QsaURBQW1COzs7WUFBbkI7O2dCQUNFLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDOztnQkFDaEQsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxNQUFNLENBQUM7Z0JBQzNELElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7Z0JBQzlFLElBQUksTUFBTSxFQUFFO29CQUNWLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsSUFBSSxXQUFXLElBQUksV0FBVyxDQUFDLFdBQVcsSUFBSSxXQUFXLENBQUMsV0FBVyxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBU3RHLElBQUksQ0FBQyxZQUFZLENBQW9CLFdBQVcsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsUUFBUTt3QkFDNUYsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFOzRCQUNwQixJQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO3lCQUM3RztxQkFDRixFQUFFLFVBQVUsR0FBRzt3QkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNsQixDQUFDLENBQUM7aUJBQ0o7YUFDRjs7Ozs7O1FBQ0QsMENBQVk7Ozs7O1lBQVosVUFBZ0IsUUFBZ0I7Z0JBQWhDLGlCQW9CQzs7Z0JBbkJDLElBQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQztxQkFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7O2dCQUVuRyxJQUFNLFdBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLElBQUlGLGNBQVcsQ0FBQzt3QkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87d0JBQzNELFdBQVcsRUFBRSxjQUFjO3dCQUMzQixXQUFXLEVBQUssUUFBUSxTQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUk7cUJBQ3JFLENBQUM7aUJBQ0gsQ0FBQztnQkFDRixPQUFPLElBQUksT0FBTyxDQUFJLFVBQUMsT0FBTyxFQUFFLE1BQU07b0JBQ3BDLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFJLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNDLGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ2xGLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2IsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUNmLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDZixDQUFDLENBQUM7aUJBQ04sQ0FBQyxDQUFDO2FBQ0o7Ozs7O1FBQ0Qsa0RBQW9COzs7O1lBQXBCLFVBQXFCLGtCQUFzQztnQkFBM0QsaUJBNERDOztnQkEzREMsSUFBSSxtQkFBbUIsR0FBd0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQzs7Z0JBQ3BGLElBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQzs7Z0JBQzlDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzs7Z0JBQ3ZELElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQzs7Z0JBQzNELElBQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGFBQWEsQ0FBQzs7Z0JBQzdFLElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sQ0FBQzs7Z0JBQ2pFLElBQU0sUUFBUSxHQUFHLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDOztnQkFDbEUsSUFBTSxXQUFXLEdBQUdDLFVBQVUsQ0FBQyxRQUFRLENBQUksUUFBUSxTQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUksQ0FBQyxDQUFDOztnQkFDakcsSUFBTSxXQUFXLEdBQUcsOENBQTRDLE9BQU8sbUJBQWMsV0FBVyxvQkFBZSxFQUFFLFNBQUksSUFBTSxDQUFDOztnQkFDNUgsSUFBTSxZQUFZLEdBQUcsS0FBRyxRQUFRLEdBQUcsRUFBRSxTQUFJLGFBQWEsa0JBQWEsV0FBYSxDQUFDO2dCQUNqRixPQUFPLElBQUlDLGVBQVUsQ0FBTyxVQUFBLE9BQU87O29CQUNqQyxJQUFJLElBQUksR0FBWSxLQUFLLENBQUM7b0JBQzFCLElBQUk7d0JBQ0YsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDN0MsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUU7NEJBQzdCLEtBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHO2dDQUN0QixrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7Z0NBQzVCLElBQU0sR0FBRyxHQUF3QixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0NBQ25ELEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQztnQ0FDekYsS0FBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDO2dDQUN2RSxLQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUM7Z0NBQ2xFLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQ0FDakIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2dDQUNmLElBQUksR0FBRyxJQUFJLENBQUM7NkJBQ2IsQ0FBQTt5QkFDRjt3QkFDRCxJQUFJLGtCQUFrQixDQUFDLE9BQU8sRUFBRTs0QkFDOUIsS0FBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUc7Z0NBQ3ZCLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxDQUFDO2dDQUM3QixzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO2dDQUNqRCxLQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQzs7Z0NBQ3hDLElBQU0sR0FBRyxHQUF3QixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0NBQ2xELG1CQUFtQixHQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7Z0NBQzFELElBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUUsbUJBQW1CLENBQUMsT0FBTyxJQUFFLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7O29DQUN0RyxJQUFNLFVBQVEsR0FBRyxJQUFJLHNCQUFzQixFQUFFLENBQUM7b0NBQzlDLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dDQUNoRCxVQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7cUNBQzFCLENBQUMsQ0FBQztpQ0FDRjs2QkFDRixDQUFDO3lCQUNIOzt3QkFDRCxJQUFNLFdBQVMsR0FBRyxLQUFJLENBQUMsU0FBUyxDQUFDO3dCQUNqQyxLQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxVQUFTLEtBQUs7NEJBQ3JDLElBQUksa0JBQWtCLENBQUMsT0FBTyxFQUFFO2dDQUM5QixrQkFBa0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7NkJBQ25DOzRCQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQzs0QkFDcEQsV0FBUyxFQUFFLENBQUM7NEJBQ1osT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO3lCQUNqQixDQUFDO3dCQUNGLElBQUksa0JBQWtCLENBQUMsU0FBUyxFQUFFOzRCQUNoQyxLQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7eUJBQ3pEO3FCQUNGO29CQUFDLE9BQU8sS0FBSyxFQUFFO3dCQUNkLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzt3QkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEI7aUJBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQ0MsZUFBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDSixlQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN0Qzs7OztRQUNPLHdDQUFVOzs7OztnQkFDaEIsSUFBTSxTQUFTLEdBQVcsUUFBUSxDQUFDLE1BQU0sQ0FBQzs7Z0JBQzFDLElBQU0sT0FBTyxHQUFhLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O2dCQUMvQyxJQUFNLEdBQUcsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7Z0JBQzNELE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBQSxNQUFNO29CQUNwQixJQUFJLE1BQU0sRUFBRTs7d0JBQ1YsSUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDeEMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7cUJBQzdDO2lCQUNGLENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsQ0FBQzs7Ozs7O1FBRUwseUNBQVc7Ozs7c0JBQUMsS0FBd0I7Z0JBQzFDLElBQUksS0FBSyxZQUFZLFVBQVUsRUFBRTtvQkFDL0IsT0FBT0ssZUFBVSxDQUFDLG9DQUFrQyxLQUFPLENBQUMsQ0FBQztpQkFDOUQ7cUJBQU07b0JBQ0wsT0FBT0EsZUFBVSxDQUFDLDBCQUF3QixLQUFLLENBQUMsTUFBTSxvQkFBZSxLQUFLLENBQUMsS0FBTyxDQUFDLENBQUM7aUJBQ3JGOzs7OztRQUVLLDhEQUFnQzs7Ozs7Z0JBQ3RDLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLE9BQU8sQ0FBTyxVQUFDLE9BQU8sRUFBRSxNQUFNO29CQUM1RCxLQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztvQkFDekIsS0FBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7aUJBQ3hCLENBQUMsQ0FBQzs7Ozs7O1FBR0wsbURBQXFCOzs7O1lBRHJCLFVBQ3NCLEtBQVk7O2dCQUNoQyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUU7cUJBQ25ELGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQ3pELElBQUcsU0FBUyxFQUNaO29CQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7aUJBQ3hCO2FBQ0Y7O29CQWpkRmpCLGFBQVUsU0FBQzt3QkFDVixVQUFVLEVBQUUsTUFBTTtxQkFDbkI7Ozs7O3dCQWhCUSx1QkFBdUI7d0JBRVZDLGFBQVU7d0JBSXZCLGNBQWM7d0JBQ2RpQixXQUFRO3dCQUlSLGNBQWM7Ozs7NENBNGNwQkMsZUFBWSxTQUFDLHVCQUF1QixFQUFDLENBQUMsUUFBUSxDQUFDOzs7a0NBeGRsRDs7Ozs7Ozs7UUNjRSxxQkFBb0IsVUFBc0IsRUFBVSxnQkFBeUMsRUFDckYsT0FBb0MsY0FBOEI7WUFEdEQsZUFBVSxHQUFWLFVBQVUsQ0FBWTtZQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBeUI7WUFDckYsVUFBSyxHQUFMLEtBQUs7WUFBK0IsbUJBQWMsR0FBZCxjQUFjLENBQWdCO1NBQUs7Ozs7OztRQUN2RSxzQ0FBZ0I7Ozs7O3NCQUFDLFdBQW1CLEVBQUUsR0FBVzs7Z0JBQ3ZELElBQUksTUFBTSxDQUFXO2dCQUNyQixJQUFJLFdBQVcsRUFBRTtvQkFDZixNQUFNLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDakM7cUJBQU07b0JBQ0wsT0FBTyxJQUFJLENBQUM7aUJBQ2I7O2dCQUNELElBQU0sR0FBRyxHQUF3QixJQUFJLEdBQUcsRUFBa0IsQ0FBQzs7b0JBQzNELEtBQW9CLElBQUEsV0FBQVosU0FBQSxNQUFNLENBQUEsOEJBQUE7d0JBQXJCLElBQU0sS0FBSyxtQkFBQTs7d0JBQ2QsSUFBTSxRQUFRLEdBQWEsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDNUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ25DOzs7Ozs7Ozs7Ozs7Ozs7Z0JBQ0QsT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDOzs7Ozs7O1FBRTVDLDhCQUFROzs7O1lBQVIsVUFBUyxHQUFXOztnQkFDbEIsSUFBTSxnQkFBZ0IsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7O2dCQUN4RSxJQUFNLFdBQVcsR0FBVyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztnQkFDOUMsSUFBTSxpQkFBaUIsR0FBYSxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxhQUFhOztvQkFDckMsSUFBTSxRQUFRLEdBQWEsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDcEQsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM3QyxDQUFDLENBQUM7Z0JBQ0gsT0FBTyxnQkFBZ0IsQ0FBQzthQUN6Qjs7Ozs7UUFDTyx3Q0FBa0I7Ozs7c0JBQUMsR0FBVztnQkFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHdCQUF3QixFQUFFO29CQUN0RSxPQUFPLElBQUksQ0FBQztpQkFDYjs7Z0JBQ0QsSUFBTyxnQkFBZ0IsR0FBd0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Z0JBQ2xFLElBQU0sU0FBUyxHQUFHLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDOztnQkFDaEQsSUFBSSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7O2dCQUNoQyxJQUFJLGlCQUFpQixHQUFHLEtBQUssQ0FBQzs7Z0JBQzlCLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO2dCQUNoQyxRQUFRLFNBQVM7b0JBQ2pCLEtBQUssU0FBUyxDQUFDO29CQUNmLEtBQUssWUFBWTt3QkFDZixtQkFBbUIsR0FBRyxJQUFJLENBQUM7d0JBQzNCLE1BQU07b0JBQ1I7d0JBQ0UsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQzs0QkFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFOzs0QkFDM0UsSUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUM7NEJBQzdFLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dDQUNwRyxtQkFBbUI7b0NBQ25CLElBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDOzZCQUNqSTtpQ0FBTTtnQ0FDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7NkJBQzdCO3lCQUNGOzZCQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUM7NEJBQ3JELElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTs0QkFDekUsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO3lCQUM1Qjs2QkFBTTs0QkFDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7eUJBQzdCO3dCQUNILE1BQU07aUJBQ0w7Z0JBQ0QsSUFBSSxDQUFDLG1CQUFtQixFQUFFO29CQUN4QixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUU7b0JBQzNHLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUU7O3dCQUN2RCxJQUFNLG9CQUFvQixHQUFHLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDOzt3QkFDNUQsSUFBTSxrQkFBa0IsR0FBRyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDeEQsSUFBSSxvQkFBb0IsSUFBSSxrQkFBa0IsRUFBRTs0QkFDOUMsSUFBSSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsQ0FBQztnQ0FDN0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUU7Z0NBQ3BGLG1CQUFtQixHQUFHLElBQUksQ0FBQzs2QkFDNUI7aUNBQU07Z0NBQ0wsbUJBQW1CLEdBQUcsS0FBSyxDQUFDOzZCQUM3Qjt5QkFDRjs2QkFBTTs0QkFDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7eUJBQzdCO3FCQUNGO3lCQUFNO3dCQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztxQkFDN0I7aUJBQ0Y7cUJBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztvQkFDckQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtvQkFDMUQsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO2lCQUM1QjtxQkFBTTtvQkFDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7aUJBQzdCO2dCQUNELElBQUksQ0FBQyxtQkFBbUIsRUFBRTtvQkFDeEIsT0FBTyxLQUFLLENBQUM7aUJBQ2Q7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztvQkFDOUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUU7O29CQUN2RCxJQUFNLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUN4RCxJQUFJLGtCQUFrQixFQUFFO3dCQUN0QixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsRUFBRTs0QkFDaEUsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO3lCQUMxQjs2QkFBTTs0QkFDTCxpQkFBaUIsR0FBRyxLQUFLLENBQUM7eUJBQzNCO3FCQUNGO3lCQUFNO3dCQUNMLGlCQUFpQixHQUFHLEtBQUssQ0FBQztxQkFDM0I7aUJBQ0Y7cUJBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztvQkFDckQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRTtvQkFDeEQsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2lCQUMxQjtxQkFBTTtvQkFDTCxpQkFBaUIsR0FBRyxLQUFLLENBQUM7aUJBQzNCO2dCQUNELE9BQU8saUJBQWlCLENBQUM7Ozs7Ozs7UUFFM0IsNkJBQU87Ozs7O1lBQVAsVUFBVyxPQUFnQjtnQkFBM0IsaUJBMkRDOztnQkExREMsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O2dCQUMxRSxJQUFJLEdBQUcsQ0FBUzs7Z0JBQ2hCLElBQU0sTUFBTSxHQUFxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO29CQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztpQkFDdEI7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO3FCQUMxQjt5QkFBTTt3QkFDTCxPQUFPLENBQUMsV0FBVyxHQUFHLE1BQUksT0FBTyxDQUFDLFdBQWEsQ0FBQztxQkFDakQ7b0JBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO29CQUNqRyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDaEMsSUFBSSxPQUFPLENBQUMsWUFBWSxFQUFFOzRCQUN4QixPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO3lCQUMzRDs7d0JBQ0QsSUFBTSxhQUFXLEdBQUc7NEJBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7NEJBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTt5QkFDOUIsQ0FBQzt3QkFDRixhQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQzt3QkFDN0MsSUFBRyxPQUFPLENBQUMsWUFBWSxFQUFFOzRCQUN2QixhQUFXLENBQUMsY0FBYyxDQUFDLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQzt5QkFDcEQ7d0JBQ0QsT0FBTyxJQUFJUSxlQUFVLENBQWtCLFVBQUEsT0FBTzs0QkFDNUMsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87Z0NBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQ0FDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7b0NBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDSCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lDQUNsRyxTQUFTLENBQUMsVUFBQSxRQUFRO3dDQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3dDQUNyQixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTs0Q0FDNUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDO3lDQUNyRzs2Q0FBTTs0Q0FDTCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lDQUN4QjtxQ0FDRixFQUFFLFVBQUEsS0FBSzt3Q0FDSixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FDQUN4QixDQUFDLENBQUM7aUNBQ0osQ0FBQyxDQUFDOzZCQUNOO2lDQUFNO2dDQUNMLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDRCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3FDQUNsRyxTQUFTLENBQUMsVUFBQSxRQUFRO29DQUNqQixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTt3Q0FDNUIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDO3FDQUNyRzt5Q0FBTTt3Q0FDTCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FDQUN4QjtpQ0FDRixFQUFFLFVBQUEsS0FBSztvQ0FDSixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lDQUN4QixDQUFDLENBQUM7NkJBQ0o7eUJBQ0YsQ0FBQyxDQUFDO3FCQUNKO3lCQUFNO3dCQUNMLE9BQU9JLGVBQVUsQ0FBQyxrQ0FBZ0MsR0FBRyxVQUFPLENBQUMsQ0FBQztxQkFDL0Q7aUJBQ0Y7YUFDRjs7Ozs7O1FBQ0QsOEJBQVE7Ozs7O1lBQVIsVUFBWSxPQUFnQjtnQkFBNUIsaUJBb0NDOztnQkFuQ0MsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O2dCQUMxRSxJQUFJLEdBQUcsQ0FBUzs7Z0JBQ2hCLElBQU0sTUFBTSxHQUFxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO29CQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztpQkFDdEI7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO3FCQUMxQjt5QkFBTTt3QkFDTCxPQUFPLENBQUMsV0FBVyxHQUFHLE1BQUksT0FBTyxDQUFDLFdBQWEsQ0FBQztxQkFDakQ7b0JBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO29CQUNqRyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7d0JBQ2hDLElBQU0sYUFBVyxHQUFHOzRCQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBOzRCQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7eUJBQzlCLENBQUM7d0JBQ0YsYUFBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7d0JBQzdDLE9BQU8sSUFBSUYsZUFBVSxDQUFrQixVQUFBLFVBQVU7NEJBQy9DLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO2dDQUM5QyxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0NBQ3hELEtBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO29DQUNuQyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDSCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lDQUNqSCxTQUFTLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFBLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQztpQ0FDckYsQ0FBQyxDQUFDOzZCQUNOO2lDQUFNO2dDQUNMLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNELGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7cUNBQ2pILFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDOzZCQUNyRjt5QkFDRixDQUFDLENBQUM7cUJBQ0o7eUJBQU07d0JBQ0wsT0FBT0ksZUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO3FCQUMvRDtpQkFDRjthQUNGOzs7Ozs7UUFDRCw2QkFBTzs7Ozs7WUFBUCxVQUFXLE9BQWdCO2dCQUEzQixpQkFtQ0M7O2dCQWxDQyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7Z0JBQzFFLElBQUksR0FBRyxDQUFTOztnQkFDaEIsSUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7b0JBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2lCQUN0QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7cUJBQzFCO3lCQUFNO3dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsTUFBSSxPQUFPLENBQUMsV0FBYSxDQUFDO3FCQUNqRDtvQkFDRCxHQUFHLEdBQUcsS0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLFNBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFhLENBQUM7b0JBQ2pHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFOzt3QkFDaEMsSUFBTSxhQUFXLEdBQUc7NEJBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7NEJBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTt5QkFDOUIsQ0FBQzt3QkFDRixhQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQzt3QkFDN0MsT0FBTyxJQUFJRixlQUFVLENBQWtCLFVBQUEsVUFBVTs0QkFDL0MsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87Z0NBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQ0FDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7b0NBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNILGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7eUNBQ2hILFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO2lDQUNyRixDQUFDLENBQUM7NkJBQ047aUNBQU07Z0NBQ0wsS0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLGFBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQ0QsZUFBSyxDQUFDLENBQUMsQ0FBQyxFQUFFQyxvQkFBVSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztxQ0FDaEgsU0FBUyxDQUFDLFVBQUEsUUFBUSxJQUFJLE9BQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBQSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBQSxDQUFDLENBQUM7NkJBQ3JGO3lCQUNGLENBQUMsQ0FBQztxQkFDSjt5QkFBTTt3QkFDTCxPQUFPSSxlQUFVLENBQUMsa0NBQWdDLEdBQUcsVUFBTyxDQUFDLENBQUM7cUJBQy9EO2lCQUNGO2FBQ0Y7Ozs7OztRQUNELGdDQUFVOzs7OztZQUFWLFVBQWMsT0FBZ0I7Z0JBQTlCLGlCQW1DQzs7Z0JBbENDLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztnQkFDMUUsSUFBSSxHQUFHLENBQVM7O2dCQUNoQixJQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtvQkFDbEIsR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO3dCQUN4QixPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztxQkFDMUI7eUJBQU07d0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxNQUFJLE9BQU8sQ0FBQyxXQUFhLENBQUM7cUJBQ2pEO29CQUNELEdBQUcsR0FBRyxLQUFHLFNBQVMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsU0FBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQWEsQ0FBQztvQkFDakcsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7O3dCQUNoQyxJQUFNLGFBQVcsR0FBRzs0QkFDbEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUMsT0FBTyxDQUFDLE9BQU8scUJBQUMsRUFBaUIsQ0FBQTs0QkFDMUQsT0FBTyxvQkFBRSxVQUFvQixDQUFBO3lCQUM5QixDQUFDO3dCQUNGLGFBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO3dCQUM3QyxPQUFPLElBQUlGLGVBQVUsQ0FBa0IsVUFBQSxVQUFVOzRCQUMvQyxJQUFJLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTztnQ0FDOUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO2dDQUN4RCxLQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQztvQ0FDbkMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQWtCLEdBQUcsRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNILGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7eUNBQ3JHLFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDO2lDQUNyRixDQUFDLENBQUM7NkJBQ047aUNBQU07Z0NBQ0wsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQWtCLEdBQUcsRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNELGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7cUNBQ3JHLFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDOzZCQUNyRjt5QkFDRixDQUFDLENBQUM7cUJBQ0o7eUJBQU07d0JBQ0wsT0FBT0ksZUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO3FCQUMvRDtpQkFDRjthQUNGOzs7Ozs7UUFDRCw4QkFBUTs7Ozs7WUFBUixVQUFZLE9BQWdCO2dCQUE1QixpQkFtQ0M7O2dCQWxDQyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7Z0JBQzFFLElBQUksR0FBRyxDQUFTOztnQkFDaEIsSUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7b0JBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2lCQUN0QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7cUJBQzFCO3lCQUFNO3dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsTUFBSSxPQUFPLENBQUMsV0FBYSxDQUFDO3FCQUNqRDtvQkFDRCxHQUFHLEdBQUcsS0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLFNBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFhLENBQUM7b0JBQ2pHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFOzt3QkFDaEMsSUFBTSxhQUFXLEdBQUc7NEJBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7NEJBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTt5QkFDOUIsQ0FBQzt3QkFDRixhQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQzt3QkFDN0MsT0FBTyxJQUFJRixlQUFVLENBQWtCLFVBQUEsVUFBVTs0QkFDL0MsSUFBSSxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87Z0NBQzlDLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQ0FDeEQsS0FBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7b0NBQ25DLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDSCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lDQUNuRyxTQUFTLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFBLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQztpQ0FDckYsQ0FBQyxDQUFDOzZCQUNOO2lDQUFNO2dDQUNMLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFrQixHQUFHLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDRCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3FDQUNuRyxTQUFTLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFBLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQzs2QkFDckY7eUJBQ0YsQ0FBQyxDQUFDO3FCQUNKO3lCQUFNO3dCQUNMLE9BQU9JLGVBQVUsQ0FBQyxrQ0FBZ0MsR0FBRyxVQUFPLENBQUMsQ0FBQztxQkFDL0Q7aUJBQ0Y7YUFDRjs7Ozs7O1FBQ0QsK0JBQVM7Ozs7O1lBQVQsVUFBYSxPQUFnQjtnQkFBN0IsaUJBbUNDOztnQkFsQ0MsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O2dCQUMxRSxJQUFJLEdBQUcsQ0FBUzs7Z0JBQ2hCLElBQU0sTUFBTSxHQUFxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO29CQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztpQkFDdEI7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO3FCQUMxQjt5QkFBTTt3QkFDTCxPQUFPLENBQUMsV0FBVyxHQUFHLE1BQUksT0FBTyxDQUFDLFdBQWEsQ0FBQztxQkFDakQ7b0JBQ0QsR0FBRyxHQUFHLEtBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxTQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBYSxDQUFDO29CQUNqRyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7d0JBQ2hDLElBQU0sYUFBVyxHQUFHOzRCQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBOzRCQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7eUJBQzlCLENBQUM7d0JBQ0YsYUFBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7d0JBQzdDLE9BQU8sSUFBSUYsZUFBVSxDQUFrQixVQUFBLFVBQVU7NEJBQy9DLElBQUksS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO2dDQUM5QyxLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0NBQ3hELEtBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO29DQUNuQyxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsYUFBVyxDQUFDLENBQUMsSUFBSSxDQUFDSCxlQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUVDLG9CQUFVLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3lDQUNsSCxTQUFTLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFBLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQztpQ0FDckYsQ0FBQyxDQUFDOzZCQUNOO2lDQUFNO2dDQUNMLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFXLENBQUMsQ0FBQyxJQUFJLENBQUNELGVBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsb0JBQVUsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7cUNBQ2xILFNBQVMsQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUEsRUFBRSxVQUFBLEtBQUssSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFDOzZCQUNyRjt5QkFDRixDQUFDLENBQUM7cUJBQ0o7eUJBQU07d0JBQ0wsT0FBT0ksZUFBVSxDQUFDLGtDQUFnQyxHQUFHLFVBQU8sQ0FBQyxDQUFDO3FCQUMvRDtpQkFDRjthQUNGOzs7OztRQUNPLGlDQUFXOzs7O3NCQUFDLEtBQXdCO2dCQUMxQyxJQUFJLEtBQUssWUFBWSxVQUFVLEVBQUU7b0JBQy9CLE9BQU9BLGVBQVUsQ0FBQyxvQ0FBa0MsS0FBTyxDQUFDLENBQUM7aUJBQzlEO3FCQUFNO29CQUNMLE9BQU9BLGVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDMUI7OztvQkF0V0pqQixhQUFVLFNBQUM7d0JBQ1YsVUFBVSxFQUFFLE1BQU07cUJBQ25COzs7Ozt3QkFWUUMsYUFBVTt3QkFFVix1QkFBdUI7d0JBR3ZCLG1CQUFtQjt3QkFDbkIsY0FBYzs7OzswQkFQdkI7Ozs7Ozs7QUNBQTtRQXVCRSxvQkFBb0IsV0FBd0IsRUFBVSxnQkFBeUMsRUFDckYsZ0JBQ0EsT0FBb0MsTUFBYyxFQUFVLFFBQWtCO1lBRnBFLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1lBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtZQUNyRixtQkFBYyxHQUFkLGNBQWM7WUFDZCxVQUFLLEdBQUwsS0FBSztZQUErQixXQUFNLEdBQU4sTUFBTSxDQUFRO1lBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBVTtZQUN0RixJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQyxTQUFTLENBQUM7Z0JBQzNDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQzthQUNuRCxDQUFDLENBQUM7U0FDSjs7OztRQUNELDZCQUFROzs7WUFBUjthQUNDOzs7O1FBQ0QsZ0NBQVc7OztZQUFYO2dCQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDeEI7Ozs7Ozs7UUFDTyw0QkFBTzs7Ozs7O3NCQUFJLE9BQU8sRUFBRSxPQUFPOztnQkFDakMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlVLGNBQVcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQ3ZDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUNyRDtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFDdkMsT0FBTyxDQUFDLENBQUM7aUJBQ1o7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLG1CQUFtQjtvQkFDaEMsT0FBTyxFQUFFLE9BQU87b0JBQ2hCLElBQUksRUFBRSxPQUFPO2lCQUNkLENBQUM7Z0JBQ0YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQzs7Ozs7UUFFL0MsZ0RBQTJCOzs7WUFBM0I7Z0JBQUEsaUJBV0M7Z0JBVkMsT0FBTyxJQUFJSSxlQUFVLENBQU8sVUFBQSxPQUFPO29CQUNqQyxLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQ3JCSyxnQkFBTSxDQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxZQUFZQyxrQkFBYSxHQUFBLENBQUMsQ0FDaEQsQ0FBQyxTQUFTLENBQUMsVUFBQSxLQUFLO3dCQUNmLElBQUksS0FBSyxZQUFZQSxrQkFBYSxFQUFFOzRCQUNsQyxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO3lCQUMzQjtxQkFDRixDQUFDLENBQUM7b0JBQ0gsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2lCQUNoQixDQUFDLENBQUM7YUFDSjs7Ozs7Ozs7UUFFRCxxQ0FBZ0I7Ozs7Ozs7WUFBaEIsVUFBb0IsUUFBZ0IsRUFBRSxRQUFnQixFQUFFLE9BQWdCO2dCQUF4RSxpQkFxR0M7Z0JBcEdDLE9BQU8sSUFBSU4sZUFBVSxDQUFrQixVQUFBLE9BQU87O29CQUM1QyxJQUFNLG1CQUFtQixHQUF3QixLQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0RixJQUFJLG1CQUFtQixJQUFJLG1CQUFtQixDQUFDLE9BQU87d0JBQ3BELG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLElBQUksbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7d0JBQzdGLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQzt3QkFDdEMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZGLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFDaEI7eUJBQU07O3dCQUNMLElBQU0sY0FBWSxHQUFHLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzt3QkFDckQsSUFBTSxXQUFXLEdBQUc7NEJBQ2xCLFFBQVEsRUFBRSxRQUFROzRCQUNsQixZQUFZLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7eUJBQ3pDLENBQUM7O3dCQUNGLElBQU0sT0FBTyxHQUFHOzRCQUNkLE9BQU8sRUFBRTtnQ0FDUCxRQUFRLEVBQUUsV0FBVztnQ0FDckIsYUFBYSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBWSxDQUFDOzZCQUM5Qzt5QkFDRixDQUFDO3dCQUNGLEtBQUksQ0FBQyxPQUFPLENBQUksT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLFFBQVE7NEJBQ2xELElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTs7Z0NBQy9ILElBQU0sU0FBUyxHQUFhLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztnQ0FDbEYsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7O2dDQUM3QixJQUFJLHFCQUFxQixHQUFHLElBQUksQ0FBQzs7Z0NBQ2pDLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQztnQ0FDMUIsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0NBQzNDLGlCQUFpQixHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsY0FBWSxDQUFDLENBQUMsQ0FBQztpQ0FDbkY7cUNBQU07b0NBQ0wsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO2lDQUN4QjtnQ0FDRCxxQkFBcUIsR0FBRyxLQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQzFFLEtBQUksQ0FBQyxjQUFjLENBQUMsa0NBQWtDLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQ0FDMUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxzQ0FBc0MsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2dDQUNsRixLQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRCxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQ0FDM0MsY0FBYyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLGNBQVksQ0FBQyxDQUFDO2lDQUMvRDtxQ0FBTTtvQ0FDTCxjQUFjLEdBQUcsRUFBRSxDQUFDO2lDQUNyQjs7Z0NBQ0QsSUFBTSxvQkFBb0IsR0FBRyxLQUFJLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUM7Z0NBQ3ZFLEtBQUksQ0FBQyxjQUFjLENBQUMsc0NBQXNDLG1CQUFDLG9CQUE0QixFQUFDLENBQUM7O2dDQUN6RixJQUFNLGlCQUFpQixHQUFhLGNBQWMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0NBQzlELElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRTtvQ0FDckMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2lDQUN2QztnQ0FDRCxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsRUFBRTtvQ0FDNUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUM7aUNBQzlDO2dDQUNELEtBQUssSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLEVBQUU7O29DQUN2RCxJQUFNLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0NBQzFELEtBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDMUQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7aUNBQ2xGO2dDQUNELEtBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlFLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO2dDQUNsQyxLQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQzs7Z0NBQ3hDLElBQU0sZ0JBQWdCLEdBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO29DQUN2RCxjQUFjLEVBQUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjO29DQUNsRCxrQkFBa0IsRUFBRSxLQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQjtpQ0FDM0QsQ0FBQyxDQUFDLENBQUM7O2dDQUNKLElBQU0sV0FBVyxHQUF1QjtvQ0FDdEMsUUFBUSxFQUFFLFFBQVE7b0NBQ2xCLE9BQU8sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPO29DQUN6QyxjQUFjLEVBQUUsY0FBYztvQ0FDOUIsTUFBTSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLGNBQVksQ0FBQztvQ0FDcEQsZ0JBQWdCLEVBQUUsZ0JBQWdCO2lDQUNuQyxDQUFDO2dDQUNGLEtBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztnQ0FDN0MsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7Z0NBQ2hELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFZLENBQUMsQ0FBQyxDQUFDO2dDQVMzRSxLQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBb0IsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSTtvQ0FDdEUsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO3dDQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztxQ0FDM0c7aUNBQ0YsRUFBRSxVQUFVLEdBQUc7b0NBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQ0FDbEIsQ0FBQyxDQUFDO2dDQUNILEtBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxzQkFBc0IsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO29DQUN0RSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztvQ0FDdkYsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztpQ0FDeEIsRUFBRTtvQ0FDRCxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztvQ0FDdkYsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztpQ0FDeEIsQ0FBQyxDQUFDOzZCQUNKO2lDQUFNO2dDQUNMLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7NkJBQ3hCO3lCQUNGLEVBQUUsVUFBQSxLQUFLOzRCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7eUJBQ3RCLENBQUMsQ0FBQztxQkFDSjtpQkFDRixDQUFDLENBQUM7YUFDSjs7Ozs7UUFDRCw2QkFBUTs7OztZQUFSLFVBQVMsUUFBUTtnQkFBakIsaUJBZUM7Z0JBZEMsSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDYkUsZUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7aUJBQ3JDOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxtQ0FBaUMsUUFBVTtpQkFDekQsQ0FBQztnQkFDRixPQUFPLElBQUlGLGVBQVUsQ0FBTyxVQUFBLE9BQU87b0JBQ2pDLEtBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUF1QixPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxRQUFRO3dCQUMzRSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7cUJBQ2hCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7OztRQUNELCtCQUFVOzs7WUFBVjtnQkFBQSxpQkFpQ0M7Z0JBaENDLE9BQU8sSUFBSUEsZUFBVSxDQUFPLFVBQUEsT0FBTzs7b0JBQ2pDLElBQU0sT0FBTyxHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO29CQUM3RCxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFOzt3QkFDbEUsSUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUM7d0JBQ2hELEtBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDOzRCQUNsQyxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7NEJBQ3RCLEtBQUksQ0FBQyxjQUFjLENBQUMsaUNBQWlDLEVBQUUsQ0FBQzs0QkFDeEQsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUU7Z0NBQ3RELEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO2dDQUM3QixLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7NkJBQzdCOzRCQUNELE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzt5QkFDaEIsRUFBRSxVQUFDLEtBQUs7NEJBQ1AsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDOzRCQUN0QixLQUFJLENBQUMsY0FBYyxDQUFDLGlDQUFpQyxFQUFFLENBQUM7NEJBQ3hELElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFO2dDQUN0RCxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQ0FDN0IsS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDOzZCQUM3Qjs0QkFDRCxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7eUJBQ2pCLENBQUMsQ0FBQztxQkFDSjt5QkFBTTt3QkFDTCxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7d0JBQ3RCLEtBQUksQ0FBQyxjQUFjLENBQUMsaUNBQWlDLEVBQUUsQ0FBQzt3QkFDeEQsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUU7NEJBQ3RELEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDOzRCQUM3QixLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7eUJBQzdCO3dCQUNELE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDZixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7cUJBQ2xDO2lCQUNGLENBQUMsQ0FBQzthQUNKOzs7O1FBQ0QsZ0NBQVc7OztZQUFYO2dCQUNFLE9BQU8sTUFBTSxDQUFDLFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEY7Ozs7O1FBQ0Msa0NBQWE7Ozs7WUFBYixVQUFjLEtBQVU7Z0JBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO2dCQUMzRSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7b0JBQ2hDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztpQkFDbEM7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsRUFDbEY7b0JBQ0UsSUFDQTt3QkFDRSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFOzRCQUN4QixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs0QkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3lCQUM3QjtxQkFDRjtvQkFDRCxPQUFNLFVBQVUsRUFDaEI7d0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztxQkFDekI7aUJBQ0Y7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTO29CQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0I7b0JBQzNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixFQUFFOztvQkFDOUQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDcEMsSUFBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUN6Qjt3QkFDRSxRQUFRLEdBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDakM7O29CQUNILElBQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQzs7b0JBQzFHLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDekQsSUFBSSxjQUFjLElBQUksQ0FBQyxRQUFRLEVBQUU7d0JBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztxQkFDNUU7eUJBQU0sSUFBSSxRQUFRLEVBQUU7O3dCQUNuQixJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUU7NkJBQ3ZELGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDNUMsSUFBSSxTQUFTLEVBQUU7NEJBQ2IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7eUJBQ3hGO3FCQUNGO2lCQUNGO2FBQ0Y7Ozs7OztRQUNELGlDQUFZOzs7OztZQUFaLFVBQWdCLE9BQWdCO2dCQUFoQyxpQkFvQkM7O2dCQW5CQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7b0JBQ2pDLFdBQVcsRUFBRSxtQ0FBbUM7b0JBQ2hELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7Ozs7UUFDRCxxQ0FBZ0I7Ozs7Ozs7WUFBaEIsVUFBb0IsWUFBb0IsRUFBRSxPQUFZLEVBQUMsT0FBZTtnQkFBdEUsaUJBc0JDOztnQkFyQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DO2dCQUNELE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7Z0JBQ2hGLElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLDZDQUEyQyxZQUFjO29CQUN0RSxJQUFJLEVBQUUsRUFBRSxPQUFPLFNBQUEsRUFBRTtvQkFDakIsT0FBTyxFQUFDLE9BQU87aUJBQ2hCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBQ0Qsa0NBQWE7Ozs7OztZQUFiLFVBQWtCLE9BQVksRUFBQyxPQUFlO2dCQUE5QyxpQkFzQkM7O2dCQXJCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7Z0JBQ0QsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDOztnQkFDaEYsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUseUJBQXlCO29CQUN0QyxJQUFJLEVBQUUsRUFBQyxPQUFPLFNBQUEsRUFBQztvQkFDZixPQUFPLEVBQUMsT0FBTztpQkFDaEIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0QsbUNBQWM7Ozs7Ozs7WUFBZCxVQUFrQixZQUFvQixFQUFFLElBQVMsRUFBQyxPQUFlO2dCQUFqRSxpQkFxQkM7O2dCQXBCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLDJDQUF5QyxZQUFjO29CQUNwRSxJQUFJLEVBQUUsSUFBSTtvQkFDVixPQUFPLEVBQUMsT0FBTztpQkFDaEIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0QsNENBQXVCOzs7Ozs7O1lBQXZCLFVBQTJCLFlBQW9CLEVBQUUsSUFBUyxFQUFDLE9BQWU7Z0JBQTFFLGlCQXFCQzs7Z0JBcEJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsb0RBQWtELFlBQWM7b0JBQzdFLElBQUksRUFBRSxJQUFJO29CQUNWLE9BQU8sRUFBQyxPQUFPO2lCQUNoQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7UUFDRCxzQ0FBaUI7Ozs7WUFBakIsVUFBa0IsT0FBZTtnQkFBakMsaUJBNkJDOztnQkE1QkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSx1QkFBdUI7b0JBQ3BDLFlBQVksRUFBRSxhQUFhO29CQUMzQixPQUFPLEVBQUMsT0FBTztpQkFDaEIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBNEIsVUFBQSxPQUFPO29CQUN0RCxLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBYyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJOzt3QkFDM0QsSUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQ2pDLElBQUksRUFBRSw0RkFBNEY7eUJBQ25HLENBQUMsQ0FBQzs7d0JBQ0gsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDdEMsQ0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNuQyxDQUFDLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQzt3QkFDN0IsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUNSLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFDaEIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbkIsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO3FCQUNqQixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7O1FBQ0QseUNBQW9COzs7O1lBQXBCLFVBQXFCLE9BQWU7Z0JBQXBDLGlCQWdDQzs7Z0JBL0JDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsdUJBQXVCO29CQUNwQyxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBTyxVQUFBLE9BQU87b0JBQ2pDLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7O3dCQUM5QyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOzt3QkFDdEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQzs7d0JBQzlELElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7O3dCQUNoQyxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDOzt3QkFDekIsSUFBSSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ2hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQzVCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUNsQzs7d0JBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7NEJBQ2xDLElBQUksRUFBRSxvRUFBb0U7eUJBQzNFLENBQUMsQ0FBQzt3QkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxjQUFjLEdBQUcsT0FBTyxDQUFDLENBQUE7d0JBQzdDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFDaEIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO3FCQUNqQixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCwrQkFBVTs7Ozs7O1lBQVYsVUFBYyxRQUFnQixFQUFDLE9BQWU7Z0JBQTlDLGlCQXlCQzs7Z0JBeEJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQztnQkFDRCxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUNiTSxlQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQztpQkFDdkM7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLFFBQVE7b0JBQ3hELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUYsZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3ZCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0QsK0JBQVU7Ozs7Ozs7WUFBVixVQUFjLFFBQWdCLEVBQUUsUUFBUSxFQUFDLE9BQWU7Z0JBQXhELGlCQXdCQzs7Z0JBdkJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQztnQkFDRCxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUNiTSxlQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQztpQkFDdkM7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLFFBQVE7b0JBQ3hELE9BQU8sRUFBRSxPQUFPO29CQUNoQixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO2lCQUM5QixDQUFDO2dCQUNGLE9BQU8sSUFBSUYsZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUNELDZCQUFROzs7Ozs7WUFBUixVQUFZLFFBQVEsRUFBQyxPQUFlO2dCQUFwQyxpQkF1QkM7O2dCQXRCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7Z0JBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDYk0sZUFBVSxDQUFDLHlCQUF5QixDQUFDLENBQUM7aUJBQ3ZDOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSw2QkFBNkIsR0FBRyxRQUFRO29CQUNyRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlGLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCxnREFBMkI7Ozs7OztZQUEzQixVQUErQixNQUFNLEVBQUMsT0FBZTtnQkFBckQsaUJBdUJDOztnQkF0QkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DO2dCQUNELElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ1hNLGVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2lCQUNyQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsTUFBTTtvQkFDdEQsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJRixlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBQ0QsOEJBQVM7Ozs7OztZQUFULFVBQWEsTUFBTSxFQUFDLE9BQWU7Z0JBQW5DLGlCQXVCQzs7Z0JBdEJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQztnQkFDRCxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYTSxlQUFVLENBQUMsdUJBQXVCLENBQUMsQ0FBQztpQkFDckM7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLDZCQUE2QixHQUFHLE1BQU07b0JBQ25ELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUYsZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUNELHVDQUFrQjs7Ozs7O1lBQWxCLFVBQXNCLFFBQWdCLEVBQUMsT0FBZTtnQkFBdEQsaUJBdUJDO2dCQXRCQyxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUNiRSxlQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQztpQkFDdkM7O2dCQUNELElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJTixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsK0JBQStCLEdBQUcsUUFBUTtvQkFDdkQsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7OztRQUNELCtCQUFVOzs7Ozs7O1lBQVYsVUFBYyxLQUFhLEVBQUUsSUFBWSxFQUFDLE9BQWU7Z0JBQXpELGlCQW9CQzs7Z0JBbkJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsS0FBSyxHQUFHLFFBQVEsR0FBRyxJQUFJO29CQUNuRSxPQUFPLEVBQUMsT0FBTztpQkFDaEIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7OztRQUNELHNDQUFpQjs7Ozs7WUFBakIsVUFBcUIsT0FBZTtnQkFBcEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxtQ0FBbUM7b0JBQ2hELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUNELCtCQUFVOzs7Ozs7WUFBVixVQUFjLFFBQVEsRUFBQyxPQUFlO2dCQUF0QyxpQkEwQkM7O2dCQXpCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQy9CLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQztnQkFDN0csUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7Z0JBQzVELFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQztnQkFDN0csUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7O2dCQUM1RCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsc0JBQXNCO29CQUNuQyxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO29CQUM3QixPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7UUFDRCxtQ0FBYzs7O1lBQWQ7Z0JBQ0UsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNuQyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztnQkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMxQyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztnQkFDL0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUM7Z0JBQ2hELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztnQkFDMUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2dCQUM3QyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztnQkFDL0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2FBQ3ZDOzs7OztRQUNELDhCQUFTOzs7O1lBQVQsVUFBVSxHQUFHOztnQkFDWCxJQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDOztnQkFDbEMsSUFBTSxPQUFPLEdBQWEsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Z0JBQy9DLElBQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDZixPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUEsTUFBTTtvQkFDcEIsSUFBSSxNQUFNLEVBQUU7O3dCQUNWLElBQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ3hDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7cUJBQzFDO2lCQUNGLENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNqQjs7Ozs7O1FBQ0QsMENBQXFCOzs7OztZQUFyQixVQUFzQixNQUFNLEVBQUUsY0FBYztnQkFDMUMsS0FBSyxJQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUU7b0JBQ3hCLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTs7d0JBQzlCLElBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDMUIsSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFOzs0QkFDaEIsSUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDOzRCQUNsQixLQUFLLElBQU0sRUFBRSxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7Z0NBQzdCLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7O29DQUNwQyxJQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29DQUNqQyxRQUFRLEVBQUU7d0NBQ1IsS0FBSyxHQUFHOzRDQUNOLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7NENBQ3RCLE1BQU07d0NBQ1IsS0FBSyxHQUFHOzRDQUNOLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUM7NENBQ3ZCLE1BQU07d0NBQ1IsS0FBSyxHQUFHOzRDQUNOLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUM7NENBQ3hCLE1BQU07cUNBQ1Q7aUNBQ0Y7NkJBQ0Y7NEJBQ0QsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQzt5QkFDOUI7NkJBQU07NEJBQ0wsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQzt5QkFDbkQ7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsT0FBTyxjQUFjLENBQUM7YUFDdkI7Ozs7OztRQUVELCtCQUFVOzs7O1lBQVYsVUFBVyxTQUFpQjs7Z0JBQzFCLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDZCxPQUFPLElBQUksQ0FBQztpQkFDYjs7Z0JBQ0QsSUFBTSxNQUFNLEdBQWEsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDOUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O29CQUN0QyxJQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7O29CQUN4QixJQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztvQkFDcEMsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDOztvQkFDbEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO29CQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O3dCQUM5QyxJQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hDLElBQUksUUFBUSxLQUFLLEVBQUUsRUFBRTs0QkFDbkIsUUFBUSxHQUFHLFNBQVMsQ0FBQzt5QkFDdEI7NkJBQU07NEJBQ0wsUUFBUSxHQUFNLFFBQVEsU0FBSSxTQUFXLENBQUM7eUJBQ3ZDO3dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFOzRCQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDO3lCQUNyQjt3QkFDRCxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUN2QjtvQkFDRCxJQUFJLFFBQVEsS0FBSyxFQUFFLEVBQUU7d0JBQ25CLFFBQVEsR0FBRyxVQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzVEO3lCQUFNO3dCQUNMLFFBQVEsR0FBTSxRQUFRLFNBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBRyxDQUFDO3FCQUM3RTtvQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTs7d0JBQ2xDLElBQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQzs7d0JBQ3hCLElBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQzlFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOzRCQUMzQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO3lCQUVyQzt3QkFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLENBQUM7cUJBQzNDO2lCQUNGO2dCQUNELE9BQU8sSUFBSSxDQUFDO2FBQ2I7Ozs7O1FBQ08seUNBQW9COzs7O3NCQUFDLEtBQUs7O2dCQUNoQyxJQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxLQUFLLEVBQUUsRUFBRTtvQkFDMUIsT0FBTyxVQUFVLENBQUM7aUJBQ25COztnQkFDRCxJQUFNLG9CQUFvQixHQUFhLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3hELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O29CQUNwRCxJQUFNLGdCQUFnQixHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDOztvQkFDakQsSUFBTSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztvQkFDNUMsSUFBTSxXQUFXLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzs7b0JBQzlELElBQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztvQkFDdEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQzNDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLFlBQVksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO3FCQUN4RjtvQkFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDO2lCQUMvQjtnQkFDRCxPQUFPLFVBQVUsQ0FBQzs7Ozs7UUFFcEIsK0NBQTBCOzs7WUFBMUI7O2dCQUNFLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsdUJBQXVCLENBQUM7O2dCQUNwRCxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDeEQsSUFBSSxRQUFRLENBQUMsUUFBUSxFQUFFOztvQkFDckIsSUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEdBQUcsWUFBWSxDQUFDO2lCQUNuRDtnQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsRUFBRTtvQkFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsR0FBRyxFQUFFLENBQUM7aUJBQ3hDO2dCQUNELEtBQUssSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxRQUFRLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRTtvQkFDM0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDckk7YUFDRjs7OztRQUNELHFEQUFnQzs7O1lBQWhDOztnQkFDRSxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDOztnQkFDdkQsSUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzFHLElBQUksb0JBQW9CLEVBQUU7O29CQUN4QixJQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQy9DLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDekU7YUFDRjs7Ozs7OztRQUNELGtDQUFhOzs7Ozs7WUFBYixVQUFpQixTQUFTLEVBQUMsT0FBZTtnQkFBMUMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsNkNBQTZDLEdBQUcsU0FBUztvQkFDdEUsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBQ0Qsc0NBQWlCOzs7Ozs7WUFBakIsVUFBcUIsU0FBUyxFQUFDLE9BQWU7Z0JBQTlDLGlCQW9CQzs7Z0JBbkJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztvQkFDakMsV0FBVyxFQUFFLHdDQUF3QyxHQUFHLFNBQVM7b0JBQ2pFLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7O1FBQ0Qsc0NBQWlCOzs7OztZQUFqQixVQUFxQixPQUFlO2dCQUFwQyxpQkFvQkM7O2dCQW5CQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7b0JBQ2pDLFdBQVcsRUFBRSwrQkFBK0I7b0JBQzVDLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7O1FBQ0Qsb0NBQWU7Ozs7O1lBQWYsVUFBbUIsT0FBZTtnQkFBbEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsMEJBQTBCO29CQUN2QyxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7OztRQUNELHNDQUFpQjs7Ozs7WUFBakIsVUFBcUIsT0FBZTtnQkFBcEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsNEJBQTRCO29CQUN6QyxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7OztRQUNELG1EQUE4Qjs7Ozs7WUFBOUIsVUFBa0MsT0FBZTtnQkFBakQsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsc0NBQXNDO29CQUNuRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7OztRQUNELGlEQUE0Qjs7Ozs7WUFBNUIsVUFBZ0MsT0FBZTtnQkFBL0MsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsb0NBQW9DO29CQUNqRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7OztRQUNELHVEQUFrQzs7Ozs7WUFBbEMsVUFBc0MsT0FBZTtnQkFBckQsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsMENBQTBDO29CQUN2RCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCwrQkFBVTs7Ozs7O1lBQVYsVUFBYyxNQUFNLEVBQUMsT0FBZTtnQkFBcEMsaUJBc0JDO2dCQXJCQyxJQUFJLENBQUMsTUFBTTtvQkFDVCxNQUFNLHNCQUFzQixDQUFDOztnQkFDN0IsSUFBSSxPQUFPLENBQWM7Z0JBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsTUFBTTtvQkFDcEQsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNwRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7OztRQUNELCtCQUFVOzs7Ozs7O1lBQVYsVUFBYyxNQUFNLEVBQUUsUUFBUSxFQUFDLE9BQWU7Z0JBQTlDLGlCQTBCQztnQkF6QkMsSUFBSSxDQUFDLE1BQU07b0JBQ1QsTUFBTSxzQkFBc0IsQ0FBQzs7Z0JBQzdCLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDL0IsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxDQUFDO2dCQUM3RyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQzs7Z0JBQzlELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7b0JBQ2pDLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxNQUFNO29CQUNwRCxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO29CQUM3QixPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCw2QkFBUTs7Ozs7O1lBQVIsVUFBWSxNQUFNLEVBQUMsT0FBZTtnQkFBbEMsaUJBc0JDO2dCQXJCQyxJQUFJLENBQUMsTUFBTTtvQkFDVCxNQUFNLHNCQUFzQixDQUFDOztnQkFDL0IsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO29CQUNqQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsTUFBTTtvQkFDbEQsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7OztRQUNELCtCQUFVOzs7Ozs7O1lBQVYsVUFBYyxJQUFJLEVBQUUsSUFBSSxFQUFDLE9BQWU7Z0JBQXhDLGlCQW9CQzs7Z0JBbkJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztvQkFDakMsV0FBVyxFQUFFLDRCQUE0QixHQUFHLElBQUksR0FBRyxRQUFRLEdBQUcsSUFBSTtvQkFDbEUsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBRUQsdUNBQWtCOzs7Ozs7WUFBbEIsVUFBc0IsUUFBUSxFQUFDLE9BQWU7Z0JBQTlDLGlCQXNCQztnQkFyQkMsSUFBSSxDQUFDLFFBQVE7b0JBQ1gsTUFBTSx1QkFBdUIsQ0FBQzs7Z0JBQzlCLElBQUksT0FBTyxDQUFjO2dCQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztvQkFDakMsV0FBVyxFQUFFLCtCQUErQixHQUFHLFFBQVE7b0JBQ3ZELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUNELG9DQUFlOzs7Ozs7WUFBZixVQUFtQixTQUFTLEVBQUMsT0FBZTtnQkFBNUMsaUJBMEJDOztnQkF6QkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUMvQixTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQztnQkFDMUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQkFDekQsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7Z0JBQzFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7O2dCQUN6RCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSx1QkFBdUI7b0JBQ3BDLE9BQU8sRUFBRSxPQUFPO29CQUNoQixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFO2lCQUMvQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUVELGtDQUFhOzs7Ozs7WUFBYixVQUFpQixPQUFPLEVBQUMsT0FBZTtnQkFBeEMsaUJBc0JDO2dCQXJCQyxJQUFJLENBQUMsT0FBTztvQkFDVixNQUFNLHlCQUF5QixDQUFDOztnQkFDaEMsSUFBSSxPQUFPLENBQWM7Z0JBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLE9BQU8sRUFBRSxPQUFPO29CQUNoQixXQUFXLEVBQUUsOEJBQThCLEdBQUcsT0FBTztpQkFDdEQsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0Qsc0NBQWlCOzs7Ozs7O1lBQWpCLFVBQXFCLElBQUksRUFBRSxJQUFJLEVBQUMsT0FBZTtnQkFBL0MsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSwrQkFBK0IsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7b0JBQ3JFLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7Ozs7UUFDRCxpQ0FBWTs7Ozs7OztZQUFaLFVBQWdCLElBQUksRUFBRSxJQUFJLEVBQUMsT0FBZTtnQkFBMUMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7b0JBQ3BFLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7OztRQUNELG9DQUFlOzs7Ozs7WUFBZixVQUFtQixPQUFPLEVBQUMsT0FBZTtnQkFBMUMsaUJBc0JDO2dCQXJCQyxJQUFJLENBQUMsT0FBTztvQkFDVixNQUFNLHlCQUF5QixDQUFDOztnQkFDaEMsSUFBSSxPQUFPLENBQWM7Z0JBQzNCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxPQUFPO29CQUN2RCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ3BELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0Qsb0NBQWU7Ozs7Ozs7WUFBZixVQUFtQixPQUFPLEVBQUUsU0FBUyxFQUFDLE9BQWU7Z0JBQXJELGlCQTBCQztnQkF6QkMsSUFBSSxDQUFDLE9BQU87b0JBQ1YsTUFBTSx5QkFBeUIsQ0FBQzs7Z0JBQ2hDLElBQUksT0FBTyxDQUFjO2dCQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDL0IsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7Z0JBQzFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7O2dCQUN6RCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxPQUFPO29CQUN2RCxPQUFPLEVBQUUsT0FBTztvQkFDaEIsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtpQkFDL0IsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCw2QkFBUTs7Ozs7O1lBQVIsVUFBWSxRQUFRLEVBQUMsT0FBZTtnQkFBcEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxRQUFRO29CQUN0RCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCwrQkFBVTs7Ozs7O1lBQVYsVUFBYyxRQUFRLEVBQUMsT0FBZTtnQkFBdEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxRQUFRO29CQUN4RCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCw4QkFBUzs7Ozs7O1lBQVQsVUFBYSxTQUFTLEVBQUMsT0FBZTtnQkFBdEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxTQUFTO29CQUN6RCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCxnQ0FBVzs7Ozs7O1lBQVgsVUFBZSxTQUFTLEVBQUMsT0FBZTtnQkFBeEMsaUJBb0JDOztnQkFuQkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DOztnQkFDRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSxrQ0FBa0MsR0FBRyxTQUFTO29CQUMzRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7UUFDRCxrQ0FBYTs7Ozs7O1lBQWIsVUFBaUIsVUFBVSxFQUFDLE9BQWU7Z0JBQTNDLGlCQXFCQzs7Z0JBcEJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUseUJBQXlCO29CQUN0QyxPQUFPLEVBQUUsT0FBTztvQkFDaEIsSUFBSSxFQUFDLFVBQVU7aUJBQ2hCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7Ozs7UUFDRCxtQ0FBYzs7Ozs7Ozs7WUFBZCxVQUFrQixRQUFRLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBQyxPQUFlO2dCQUFwRSxpQkEyQkM7O2dCQTFCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtvQkFDbkMsV0FBVyxFQUFFLG9DQUFvQyxHQUFHLFFBQVE7b0JBQzVELElBQUksRUFBRTt3QkFDSixVQUFVLEVBQUU7NEJBQ1YsVUFBVSxFQUFFLFFBQVE7NEJBQ3BCLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDOzRCQUNoRCxpQkFBaUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQzt5QkFDakQ7cUJBQ0Y7b0JBQ0QsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBQ0YsT0FBTyxJQUFJSSxlQUFVLENBQUksVUFBQSxPQUFPO29CQUM5QixLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO3dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekIsRUFBRSxVQUFBLEtBQUs7d0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdEIsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBQ0QsbUNBQWM7Ozs7OztZQUFkLFVBQWtCLFFBQVEsRUFBQyxPQUFlO2dCQUExQyxpQkFxQkM7O2dCQXBCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7Z0JBQ0QsT0FBTyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDOztnQkFDNUMsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUsMkJBQTJCO29CQUN4QyxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7Ozs7UUFDRCxvQ0FBZTs7Ozs7Ozs7O1lBQWYsVUFBbUIsUUFBUSxFQUFDLFNBQWdCLEVBQUMsaUJBQXdCLEVBQUMsY0FBcUIsRUFBQyxPQUFlO2dCQUEzRyxpQkEwQkM7O2dCQXpCQyxJQUFJLE9BQU8sQ0FBYztnQkFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixPQUFPLEdBQUcsSUFBSUosY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQ3pGO3FCQUNJO29CQUNILE9BQU8sR0FBRyxJQUFJQSxjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtpQkFDL0M7O2dCQUNELElBQUksV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQzdCLE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7O2dCQUMvSCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxhQUFhO29CQUNoQyxXQUFXLEVBQUUsMkJBQTJCO29CQUN4QyxJQUFJLEVBQUU7d0JBQ0YsbUJBQW1CLEVBQUUsRUFBQyxpQkFBaUIsbUJBQUEsRUFBQzt3QkFDeEMsZ0JBQWdCLEVBQUUsRUFBQyxjQUFjLGdCQUFBLEVBQUM7cUJBQ3JDO29CQUNELE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7Ozs7Ozs7UUFDRCxpQ0FBWTs7Ozs7Ozs7OztZQUFaLFVBQWdCLFFBQVEsRUFBQyxTQUFnQixFQUFDLFVBQWlCLEVBQUMsYUFBb0IsRUFBQyxXQUFrQixFQUFDLE9BQWU7Z0JBQW5ILGlCQXFCQzs7Z0JBcEJDLElBQUksT0FBTyxDQUFjO2dCQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQztnQkFDRCxPQUFPLEdBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBQyxXQUFXLENBQUMsQ0FBQzs7Z0JBQ2xMLElBQU0sT0FBTyxHQUFZO29CQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGFBQWE7b0JBQ2hDLFdBQVcsRUFBRSx3QkFBd0I7b0JBQ3JDLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUNGLE9BQU8sSUFBSUksZUFBVSxDQUFJLFVBQUEsT0FBTztvQkFDOUIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTt3QkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCLEVBQUUsVUFBQSxLQUFLO3dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3RCLENBQUMsQ0FBQztpQkFDSixDQUFDLENBQUM7YUFDSjs7Ozs7Ozs7OztRQUNELGtDQUFhOzs7Ozs7Ozs7WUFBYixVQUFpQixRQUFnQixFQUFFLEdBQVcsRUFBRSxXQUFtQixFQUFDLGVBQXVCLEVBQUUsT0FBZTtnQkFBNUcsaUJBOEJDOztnQkE3QkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DO2dCQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQzs7Z0JBQzVDLElBQUksUUFBUSxHQUFTLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7O2dCQUNuRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSx5QkFBeUI7b0JBQ3RDLElBQUksRUFBRTt3QkFDSixVQUFVLEVBQUU7NEJBQ1YsVUFBVSxFQUFFLFFBQVE7NEJBQ3BCLGFBQWEsRUFBRSxRQUFROzRCQUN2QixpQkFBaUIsRUFBRSxRQUFROzRCQUMzQixLQUFLLEVBQUMsR0FBRzt5QkFDVjtxQkFDRjtvQkFDRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7Ozs7UUFDRCxxQ0FBZ0I7Ozs7Ozs7OztZQUFoQixVQUFvQixRQUFnQixFQUFFLEdBQVcsRUFBRSxXQUFtQixFQUFDLGVBQXVCLEVBQUUsT0FBZTtnQkFBL0csaUJBOEJDOztnQkE3QkMsSUFBSSxPQUFPLENBQWM7Z0JBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7b0JBQ1osT0FBTyxHQUFHLElBQUlKLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO2lCQUN6RjtxQkFDSTtvQkFDSCxPQUFPLEdBQUcsSUFBSUEsY0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7aUJBQy9DO2dCQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQzs7Z0JBQzVDLElBQUksUUFBUSxHQUFTLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7O2dCQUNuRCxJQUFNLE9BQU8sR0FBWTtvQkFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7b0JBQ25DLFdBQVcsRUFBRSw0QkFBNEI7b0JBQ3pDLElBQUksRUFBRTt3QkFDSixVQUFVLEVBQUU7NEJBQ1YsVUFBVSxFQUFFLFFBQVE7NEJBQ3BCLGFBQWEsRUFBRSxRQUFROzRCQUN2QixpQkFBaUIsRUFBRSxRQUFROzRCQUMzQixLQUFLLEVBQUMsR0FBRzt5QkFDVjtxQkFDRjtvQkFDRCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7Ozs7Ozs7O1FBQ0Qsb0NBQWU7Ozs7Ozs7WUFBZixVQUFtQixRQUFRLEVBQUUsT0FBTyxFQUFDLE9BQWU7Z0JBQXBELGlCQXlCQztnQkF4QkMsSUFBSSxDQUFDLFFBQVE7b0JBQ1gsTUFBTSx1QkFBdUIsQ0FBQzs7Z0JBQzlCLElBQUksT0FBTyxDQUFjO2dCQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNaLE9BQU8sR0FBRyxJQUFJSixjQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztpQkFDekY7cUJBQ0k7b0JBQ0gsT0FBTyxHQUFHLElBQUlBLGNBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO2lCQUMvQzs7Z0JBQ0QsSUFBTSxPQUFPLEdBQVk7b0JBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO29CQUNuQyxXQUFXLEVBQUUscUNBQXFDLEdBQUcsUUFBUTtvQkFDN0QsT0FBTyxFQUFFLE9BQU87b0JBQ2hCLElBQUksRUFBRTt3QkFDSixTQUFTLEVBQUUsT0FBTztxQkFDbkI7aUJBQ0YsQ0FBQztnQkFDRixPQUFPLElBQUlJLGVBQVUsQ0FBSSxVQUFBLE9BQU87b0JBQzlCLEtBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7d0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QixFQUFFLFVBQUEsS0FBSzt3QkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN0QixDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ0o7O29CQWw5Q0ZmLGFBQVUsU0FBQzt3QkFDVixVQUFVLEVBQUUsTUFBTTtxQkFDbkI7Ozs7O3dCQWxCUSxXQUFXO3dCQUdYLHVCQUF1Qjt3QkFFdkIsY0FBYzt3QkFJZCxtQkFBbUI7d0JBQ25CTSxXQUFNO3dCQUNOWSxXQUFROzs7O3lCQVpqQjs7Ozs7OztBQ0FBO1FBU0ksaUNBQW9CLGNBQThCLEVBQVUsZ0JBQXlDLEVBQ3pGO1lBRFEsbUJBQWMsR0FBZCxjQUFjLENBQWdCO1lBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtZQUN6RixVQUFLLEdBQUwsS0FBSztTQUEwQjs7Ozs7O1FBQzNDLDJDQUFTOzs7OztZQUFULFVBQVUsR0FBcUIsRUFBRSxJQUFpQjtnQkFBbEQsaUJBMkVDO2dCQTFFRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUU7b0JBQzdCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO3dCQUNaLFVBQVUsRUFBRTs0QkFDUixrQkFBa0IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQjt5QkFDbEQ7cUJBQ0osQ0FBQyxDQUFDO2lCQUNOO2dCQUNELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQ3ZCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO3dCQUNaLFVBQVUsRUFBRTs0QkFDUixZQUFZLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVO3lCQUN0QztxQkFDSixDQUFDLENBQUM7aUJBQ047Z0JBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRTtvQkFDdEIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7d0JBQ1osVUFBVSxFQUFFOzRCQUNSLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVM7eUJBQ25DO3FCQUNKLENBQUMsQ0FBQztpQkFDTjtnQkFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUNqQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQzt3QkFDWixVQUFVLEVBQUU7NEJBQ1IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQzt5QkFDN0M7cUJBQ0osQ0FBQyxDQUFDO2lCQUNOO3FCQUNJLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQ25DLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO3dCQUNaLFVBQVUsRUFBRTs0QkFDUixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO3lCQUMxQztxQkFDSixDQUFDLENBQUM7aUJBQ047cUJBQU8sSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtvQkFDckMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7d0JBQ1osVUFBVSxFQUFFOzRCQUNSLFNBQVMsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7eUJBQ3pDO3FCQUNKLENBQUMsQ0FBQztpQkFDTjtnQkFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVc7b0JBQ3hHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRO29CQUNqRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUU7O29CQUM5RixJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixFQUFFLENBQUM7O29CQUN6RCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDOztvQkFDbkYsSUFBSSxPQUFPLFVBQVM7b0JBQ3BCLE9BQU8sR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDckMsSUFBSSxDQUFDLE9BQU8sRUFBRTt3QkFDVixPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxDQUFDO3FCQUM5RDtvQkFDRCxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQzt3QkFDWixVQUFVLEVBQUU7NEJBQ1IsU0FBUyxFQUFLLFFBQVEsU0FBSSxTQUFXOzRCQUNyQyxPQUFPLEVBQUUsT0FBTzt5QkFDbkI7cUJBQ0osQ0FBQyxDQUFDO2lCQUNOO2dCQUNELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUNJLGFBQUcsQ0FBQyxVQUFBLFFBQVE7b0JBQ3JDLElBQUksUUFBUSxZQUFZQyxlQUFZLEVBQUU7O3dCQUNsQyxJQUFNLElBQUksSUFBRyxRQUE2QixFQUFDO3dCQUMzQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFOzRCQUMvQixLQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7NEJBQ3BFLEtBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLEVBQUUsQ0FBQzt5QkFDaEQ7d0JBQ0QsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDOzRCQUM1QyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7NEJBQy9DLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEdBQUcsS0FBSyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLGNBQWMsQ0FBQztvQ0FDakcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0NBQ2xFLEtBQUksQ0FBQyxjQUFjLENBQUMsd0NBQXdDLEVBQUUsQ0FBQzs2QkFDbEU7eUJBQ0o7cUJBQ0o7aUJBQ0osQ0FBQyxDQUFDLENBQUM7YUFDUDs7b0JBL0VKdkIsYUFBVTs7Ozs7d0JBTEYsY0FBYzt3QkFHZCx1QkFBdUI7d0JBQ3ZCLG1CQUFtQjs7O3NDQU41Qjs7Ozs7OztBQ0FBO1FBYUU7U0FBaUI7Ozs7UUFFakIsK0JBQVE7OztZQUFSO2FBQ0M7O29CQWRGd0IsWUFBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSxTQUFTO3dCQUNuQixRQUFRLEVBQUUsMkNBSVQ7d0JBQ0QsTUFBTSxFQUFFLEVBQUU7cUJBQ1g7Ozs7MkJBVkQ7Ozs7Ozs7Ozs7OztBQ0dBLDJCQUE4Qix1QkFBZ0QsRUFDMUUsS0FBMEI7UUFDMUIsT0FBTztZQUFNLE9BQUEsSUFBSSxPQUFPLENBQU8sVUFBQyxPQUFPLEVBQUUsTUFBTTtnQkFDN0MsdUJBQXVCLENBQUMsaUJBQWlCLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxJQUFJLENBQUM7O29CQUNqRixJQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQzs7b0JBQzVDLElBQU0seUJBQXlCLEdBQUcsS0FBSyxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUseUJBQXlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7d0JBQzlELElBQU0sb0JBQW9CLEdBQUcsS0FBSyxDQUFDLDRCQUE0QixFQUFFLENBQUM7O3dCQUNsRSxJQUFNLHNCQUFzQixHQUFHLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxDQUFDOzt3QkFDdEUsSUFBTSxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs7d0JBQ3BELElBQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQzs7d0JBQ2hELElBQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7O3dCQUNwRCxJQUFNLGtDQUFrQyxHQUFHLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDO3dCQUN0RixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCOzRCQUMxRSxlQUFlLEVBQUUsaUJBQWlCLEVBQUUsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs0QkFDN0UsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7NEJBQzVCLE9BQU8sRUFBRSxDQUFDO3lCQUNaLEVBQUUsVUFBQyxLQUFLOzRCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ25CLE1BQU0sRUFBRSxDQUFDO3lCQUNkLENBQUMsQ0FBQztxQkFDSixFQUFFLFVBQUMsS0FBSzt3QkFDUCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNuQixNQUFNLEVBQUUsQ0FBQztxQkFDVixDQUFDLENBQUM7aUJBQ0osRUFBRSxVQUFDLEtBQUs7b0JBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbkIsTUFBTSxFQUFFLENBQUM7aUJBQ1YsQ0FBQyxDQUFDO2FBQ0osQ0FBQztTQUFBLENBQUM7S0FDSjs7Ozs7O0FDakNILGFBbUJnQixhQUFhOzs7Ozs7O1FBVWIsaUJBQU87Ozs7Z0JBQ25CLE9BQU87b0JBQ0wsUUFBUSxFQUFFLFNBQVM7b0JBQ25CLFNBQVMsRUFBRSxFQUFFO2lCQUNkLENBQUM7OztvQkFyQkxDLFdBQVEsU0FBQzt3QkFDUixPQUFPLEVBQUUsRUFDUjt3QkFDRCxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUM7d0JBQzVCLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQzt3QkFDdkIsU0FBUyxFQUFFLENBQUUsVUFBVSxFQUFFakIsOEJBQWEsRUFBRyxjQUFjLEVBQUUsdUJBQXVCLEVBQUUsbUJBQW1CLEVBQUU7Z0NBQ3JHLE9BQU8sRUFBRWtCLGtCQUFlO2dDQUN4QixVQUFVLElBQWU7Z0NBQ3pCLElBQUksRUFBRSxDQUFDLHVCQUF1QixFQUFFLG1CQUFtQixDQUFDO2dDQUNwRCxLQUFLLEVBQUUsSUFBSTs2QkFDWixFQUFFO2dDQUNELE9BQU8sRUFBRUMsb0JBQWlCO2dDQUMxQixRQUFRLEVBQUUsdUJBQXVCO2dDQUNqQyxLQUFLLEVBQUUsSUFBSTs2QkFDWixDQUFDO3FCQUNIOzt3QkEzQkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyJ9