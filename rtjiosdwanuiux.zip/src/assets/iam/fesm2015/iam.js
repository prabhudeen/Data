import { Injectable, NgModule, APP_INITIALIZER, Component, HostListener, defineInjectable, inject } from '@angular/core';
import { HttpClient, HttpResponse, HTTP_INTERCEPTORS, HttpHeaders } from '@angular/common/http';
import { utils, padding, ModeOfOperation } from 'aes-js';
import { Router, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as Fingerprint2 from 'fingerprintjs2sync';
import { CookieService as CookieService$1 } from 'ngx-cookie-service/cookie-service/cookie.service';
import { Subject, throwError, Observable } from 'rxjs';
import { retry, catchError, delay, filter, tap } from 'rxjs/operators';
import { Location } from '@angular/common';
import { util } from 'node-forge';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CONSTANTS {
    /**
     * @return {?}
     */
    getProtocol() {
        return location.protocol;
    }
}
CONSTANTS.PROTOCOL = `${location.protocol}//`;
CONSTANTS.WEBSOCKET_PROTOCOL = location.protocol.localeCompare('https:') === 0 ? 'wss://' : 'ws://';
CONSTANTS.IDENTITY_CONTEXT = '/IAM/identity/';
CONSTANTS.ACCESS_CONTEXT = '/IAM/access/';
CONSTANTS.TRACE_CONTEXT = '/IAM/trace/';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class AppConfigurationService {
    /**
     * @param {?} httpClient
     */
    constructor(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * @param {?} filePath
     * @return {?}
     */
    loadConfiguration(filePath) {
        return new Promise((resolve, reject) => {
            this.httpClient.get(filePath).toPromise().then((response) => {
                this.appConfiguration = response;
                resolve();
            }).catch((response) => {
                console.log(response);
                console.log(`could not load configuration file error: \n ${JSON.stringify(response)}`);
                reject(`could not load configuration file error: \n ${JSON.stringify(response)}`);
            });
        });
    }
    /**
     * @return {?}
     */
    getConfiguration() {
        return this.appConfiguration;
    }
}
AppConfigurationService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
AppConfigurationService.ctorParameters = () => [
    { type: HttpClient }
];
/** @nocollapse */ AppConfigurationService.ngInjectableDef = defineInjectable({ factory: function AppConfigurationService_Factory() { return new AppConfigurationService(inject(HttpClient)); }, token: AppConfigurationService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const forge = require('node-forge');
class RsaUtils {
    constructor() { }
    /**
     * @param {?} pem_file_content
     * @return {?}
     */
    static privateKeyFromPEM(pem_file_content) {
        RsaUtils.privateKey = forge.pki.privateKeyFromPem(pem_file_content);
    }
    /**
     * @return {?}
     */
    static publicKeyToPEM() {
        return forge.pki.publicKeyToPem(RsaUtils.publicKey);
    }
    /**
     * @param {?} pem_file_content
     * @return {?}
     */
    static publicKeyFromPEM(pem_file_content) {
        RsaUtils.publicKey = forge.pki.publicKeyFromPem(pem_file_content);
    }
    /**
     * @param {?} message
     * @param {?=} pemPublicKey
     * @return {?}
     */
    static encrypt(message, pemPublicKey) {
        if (pemPublicKey) {
            return forge.util.encode64(forge.pki.privateKeyFromPem(pemPublicKey).encrypt(message, 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            }));
        }
        else if (RsaUtils.publicKey) {
            return forge.util.encode64(RsaUtils.publicKey.encrypt(message, 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            }));
        }
        else {
            console.log('public key is not defined');
            return null;
        }
    }
    /**
     * @param {?} cipherText
     * @param {?=} pemPrivateKey
     * @return {?}
     */
    static decrypt(cipherText, pemPrivateKey) {
        if (pemPrivateKey) {
            return forge.pki.privateKeyFromPem(pemPrivateKey).decrypt(forge.util.decode64(cipherText), 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            });
        }
        else if (RsaUtils.privateKey) {
            return RsaUtils.privateKey.decrypt(forge.util.decode64(cipherText), 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha1.create()
                }
            });
        }
        else {
            console.log('private key is not defined');
            return null;
        }
    }
    /**
     * @return {?}
     */
    privateKeyToPEM() {
        /** @type {?} */
        const rsaPrivateKey = forge.pki.privateKeyToAsn1(RsaUtils.privateKey);
        /** @type {?} */
        const privateKeyInfo = forge.pki.wrapRsaPrivateKey(rsaPrivateKey);
        return forge.pki.privateKeyInfoToPem(privateKeyInfo);
    }
}
RsaUtils.publicKey = null;
RsaUtils.privateKey = null;

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class AesUtils {
    constructor() { }
    /**
     * @param {?} aesKey
     * @return {?}
     */
    static setAesEncryptionKey(aesKey) {
        AesUtils.aesKey = aesKey;
    }
    /**
     * @param {?} message
     * @param {?=} aesKey
     * @return {?}
     */
    static encrypt(message, aesKey) {
        if (!aesKey) {
            aesKey = AesUtils.aesKey;
        }
        /** @type {?} */
        const key = utils.utf8.toBytes(aesKey);
        /** @type {?} */
        let textBytes = utils.utf8.toBytes(message);
        textBytes = new padding.pkcs7.pad(textBytes);
        /** @type {?} */
        const aesEcb = new ModeOfOperation.ecb(key);
        /** @type {?} */
        const encryptedBytes = aesEcb.encrypt(textBytes);
        return utils.hex.fromBytes(encryptedBytes);
    }
    /**
     * @param {?} cipher
     * @param {?=} aesKey
     * @return {?}
     */
    static decrypt(cipher, aesKey) {
        if (!aesKey) {
            aesKey = AesUtils.aesKey;
        }
        /** @type {?} */
        const key = utils.utf8.toBytes(aesKey);
        /** @type {?} */
        const aesEcb = new ModeOfOperation.ecb(key);
        /** @type {?} */
        const encryptedBytes = utils.hex.toBytes(cipher);
        /** @type {?} */
        let decryptedBytes = aesEcb.decrypt(encryptedBytes);
        decryptedBytes = padding.pkcs7.strip(decryptedBytes);
        return utils.utf8.fromBytes(decryptedBytes);
    }
    /**
     * @param {?=} length
     * @return {?}
     */
    static generateRandomAesKey(length = 16) {
        /** @type {?} */
        const map = new Map();
        map.set(0, 'a').set(1, 'b').set(2, 'c').set(3, 'd').set(4, 'e').set(5, 'f').
            set(6, 'g').set(7, 'h').set(8, 'i').set(9, 'j').set(10, 'k').set(11, 'l').set(12, 'm').
            set(13, 'n').set(14, 'o').set(15, 'p').set(16, 'q').set(17, 'r').
            set(18, 's').set(19, 't').set(20, 'u').set(21, 'v').set(22, 'w').set(23, 'x').set(24, 'y').
            set(25, 'z').set(26, 'A').set(27, 'B').set(28, 'C').set(29, 'D').set(30, 'E').set(31, 'F').
            set(32, 'G').set(33, 'H').set(34, 'I').set(35, 'J').set(36, 'K').set(37, 'L').set(38, 'M').
            set(39, 'N').set(40, 'O').set(41, 'P').set(42, 'Q').set(43, 'R').set(44, 'S').set(45, 'T').
            set(46, 'U').set(47, 'V').set(48, 'W').set(49, 'X').set(50, 'Y').set(51, 'Z');
        /** @type {?} */
        let key = '';
        for (let i = 0; i < length; i++) {
            key = key.concat(map.get(Math.floor(Math.random() * 52)));
        }
        return key;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
}
AesUtils.aesKey = null;

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class NavigateService {
    /**
     * @param {?} router
     */
    constructor(router) {
        this.router = router;
    }
    /**
     * @param {?} path
     * @return {?}
     */
    navigate(path) {
        this.router.navigate(path);
    }
}
NavigateService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
NavigateService.ctorParameters = () => [
    { type: Router }
];
/** @nocollapse */ NavigateService.ngInjectableDef = defineInjectable({ factory: function NavigateService_Factory() { return new NavigateService(inject(Router)); }, token: NavigateService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class SessionService {
    /**
     * @param {?} cookieService
     * @param {?} appSetting
     * @param {?} navigateService
     */
    constructor(cookieService, appSetting, navigateService) {
        this.cookieService = cookieService;
        this.appSetting = appSetting;
        this.navigateService = navigateService;
        this.hashKey = new Fingerprint2({ excludeAdBlock: true }).getSync().fprint.substr(0, 16);
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    getSessionData(key = 'globals') {
        /** @type {?} */
        let data;
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            data = JSON.parse(this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : '{}');
        }
        else {
            console.log('into clearing session');
            this.clearSessionDataAndGotoSessionExpirePage();
            data = /** @type {?} */ ({});
        }
        return /** @type {?} */ (data);
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    getAesKey(key = 'aesKey') {
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return this.cookieService.check(key) ? AesUtils.decrypt(this.cookieService.get(key), this.hashKey) : null;
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return null;
    }
    /**
     * @param {?} sessionData
     * @param {?=} key
     * @return {?}
     */
    setSessionData(sessionData, key = 'globals') {
        /** @type {?} */
        const data = {};
        /** @type {?} */
        const userInformation = {
            currentUser: {
                userName: sessionData.userName,
                appData: sessionData.appData,
                nodeNameCircle: sessionData.nodeNameCircle
            }
        };
        if (sessionData.neNameCircleName) {
            userInformation.currentUser['neNameCircleName'] = sessionData.neNameCircleName;
        }
        if (sessionData.aesKey) {
            data['aesKey'] = sessionData.aesKey;
        }
        data[key] = userInformation;
        this.cookieService.set(key, AesUtils.encrypt(JSON.stringify(data), this.hashKey));
    }
    /**
     * @param {...?} args
     * @return {?}
     */
    clearSessionData(...args) {
        if (args.length > 0) {
            for (const arg of args) {
                this.cookieService.delete(arg);
            }
        }
        else {
            this.cookieService.deleteAll();
            localStorage.clear();
        }
    }
    /**
     * @param {?=} timeStamp
     * @return {?}
     */
    putDateForCookieExpiry(timeStamp) {
        /** @type {?} */
        let sessionTime = 600000;
        if (this.appSetting.getConfiguration()) {
            sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
        }
        if (!timeStamp) {
            this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
        }
        else {
            this.cookieService.set('expiryTime', timeStamp);
        }
    }
    /**
     * @return {?}
     */
    getDateForCookieExpiry() {
        /** @type {?} */
        let sessionTime = 600000;
        if (this.appSetting.getConfiguration()) {
            sessionTime = this.appSetting.getConfiguration().sessionTimeOut;
        }
        if (this.cookieService.check('expiryTime')) {
            return Number.parseInt(this.cookieService.get('expiryTime'));
        }
        this.cookieService.set('expiryTime', (new Date().getTime() + sessionTime).toString());
        return (new Date().getTime() + sessionTime);
    }
    /**
     * @param {?} userToken
     * @return {?}
     */
    setUserTokenData(userToken) {
        this.cookieService.set('userToken', AesUtils.encrypt(userToken, this.hashKey));
    }
    /**
     * @return {?}
     */
    getUserTokenData() {
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return this.cookieService.check('userToken') ? AesUtils.decrypt(this.cookieService.get('userToken'), this.hashKey) : null;
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return null;
    }
    /**
     * @param {?} moduleRestriction
     * @param {?=} key
     * @return {?}
     */
    setSessionDataForModuleRestriction(moduleRestriction, key = 'moduleRestriction') {
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(moduleRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    getSessionDataForModuleRestriction(key = 'moduleRestriction') {
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    }
    /**
     * @param {?} structuredRestriction
     * @param {?=} key
     * @return {?}
     */
    setSessionDataForStructuredRestriction(structuredRestriction, key = 'structuredRestriction') {
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(structuredRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    getSessionDataForStructuredRestriction(key = 'structuredRestriction') {
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    }
    /**
     * @param {?} nodeCircleRestriction
     * @param {?=} key
     * @return {?}
     */
    setSessionDataForNodeCircleRestriction(nodeCircleRestriction, key = 'nodeCircleRestriction') {
        if (typeof (Storage)) {
            localStorage.setItem(key, JSON.stringify(nodeCircleRestriction));
        }
        else {
            console.log('Local Storgae not available');
        }
    }
    /**
     * @param {?=} key
     * @return {?}
     */
    getSessionDataForNodeCircleRestriction(key = 'nodeCircleRestriction') {
        /** @type {?} */
        const expiryTime = this.getDateForCookieExpiry();
        if (expiryTime > new Date().getTime()) {
            return JSON.parse(localStorage.getItem(key) ? localStorage.getItem(key) : '{}');
        }
        this.clearSessionDataAndGotoSessionExpirePage();
        return JSON.parse('{}');
    }
    /**
     * @return {?}
     */
    clearSessionDataAndGotoSessionExpirePage() {
        this.resetVariables();
        this.clearSessionData();
        if (this.appSetting.getConfiguration()) {
            console.log(this.appSetting.getConfiguration().sessionExpiredPage);
            this.navigateService.navigate([this.appSetting.getConfiguration().sessionExpiredPage]);
        }
    }
    /**
     * @return {?}
     */
    clearSessionDataAndGotoLogoutPage() {
        this.resetVariables();
        this.clearSessionData();
        if (this.appSetting.getConfiguration()) {
            this.navigateService.navigate([this.appSetting.getConfiguration().logoutPath]);
        }
    }
    /**
     * @return {?}
     */
    resetVariables() {
        this.globals = null;
        this.selectedCircleName = null;
        this.selectedNeName = null;
        this.selectedNeShortName = null;
        this.parsedNodeCircleJson = null;
        this.nodeNameCircle = null;
        this.structuredRestriction = null;
        this.moduleRestriction = null;
        this.mapNeNameCircleName = null;
        this.nodeNameList = [];
    }
}
SessionService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
SessionService.ctorParameters = () => [
    { type: CookieService },
    { type: AppConfigurationService },
    { type: NavigateService }
];
/** @nocollapse */ SessionService.ngInjectableDef = defineInjectable({ factory: function SessionService_Factory() { return new SessionService(inject(CookieService$1), inject(AppConfigurationService), inject(NavigateService)); }, token: SessionService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class WebSocketCallbackClass {
    /**
     * @return {?}
     */
    static getOnMessageObservable() {
        return WebSocketCallbackClass.onMessageSubject.asObservable();
    }
    /**
     * @return {?}
     */
    static getOnOpenObservable() {
        return WebSocketCallbackClass.onOpenSubject.asObservable();
    }
    /**
     * @return {?}
     */
    static getOnCloseObservable() {
        return WebSocketCallbackClass.onCloseSubject.asObservable();
    }
    /**
     * @return {?}
     */
    static getOnErrorObservable() {
        return WebSocketCallbackClass.onErrorSubject.asObservable();
    }
    /**
     * @return {?}
     */
    static getOnWebsocketReconnectObservable() {
        return WebSocketCallbackClass.onWebsocketReconnectSubject.asObservable();
    }
    /**
     * @return {?}
     */
    static reInitializeObservables() {
        WebSocketCallbackClass.onMessageSubject = new Subject();
        WebSocketCallbackClass.onOpenSubject = new Subject();
        WebSocketCallbackClass.onCloseSubject = new Subject();
        WebSocketCallbackClass.onErrorSubject = new Subject();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onMessage(event) {
        WebSocketCallbackClass.onMessageSubject.next(event);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onClose(event) {
        console.log('websocket closed');
        WebSocketCallbackClass.onCloseSubject.next(event);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onError(event) {
        console.log(event);
        WebSocketCallbackClass.onErrorSubject.next(event);
    }
    /**
     * @param {?} event
     * @param {?} websocket
     * @return {?}
     */
    onOpen(event, websocket) {
        console.log('websocket opened');
        WebSocketCallbackClass.onOpenSubject.next(event);
    }
    /**
     * @return {?}
     */
    onReconnect() {
        console.log('websocket re-connected');
        WebSocketCallbackClass.onWebsocketReconnectSubject.next();
    }
}
WebSocketCallbackClass.onMessageSubject = new Subject();
WebSocketCallbackClass.onOpenSubject = new Subject();
WebSocketCallbackClass.onCloseSubject = new Subject();
WebSocketCallbackClass.onErrorSubject = new Subject();
WebSocketCallbackClass.onWebsocketReconnectSubject = new Subject();

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class MessageMapping {
    /**
     * @param {?} httpClient
     */
    constructor(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * @param {?} code
     * @return {?}
     */
    static getMessage(code) {
        return MessageMapping.messageMap.has(code) ? MessageMapping.messageMap.get(code) : 'unknown error code received';
    }
    /**
     * @param {?} filePath
     * @return {?}
     */
    loadMesageMap(filePath) {
        this.httpClient.get(filePath).toPromise().then((response) => {
            new Map(Object.entries(response)).forEach((value, key) => {
                MessageMapping.messageMap.set(Number.parseInt(key), value);
            });
        }).catch((response) => {
            console.log(response);
            console.log(`could not load configuration file error: \n ${JSON.stringify(response)}`);
        });
    }
}
MessageMapping.messageMap = new Map();
MessageMapping.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
MessageMapping.ctorParameters = () => [
    { type: HttpClient }
];
/** @nocollapse */ MessageMapping.ngInjectableDef = defineInjectable({ factory: function MessageMapping_Factory() { return new MessageMapping(inject(HttpClient)); }, token: MessageMapping, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CacheManagerService {
    /**
     * @param {?} appConfiguration
     * @param {?} httpClient
     * @param {?} sessionService
     * @param {?} location
     * @param {?} messageMapping
     */
    constructor(appConfiguration, httpClient, sessionService, location, messageMapping) {
        this.appConfiguration = appConfiguration;
        this.httpClient = httpClient;
        this.sessionService = sessionService;
        this.location = location;
        this.messageMapping = messageMapping;
        this.websocketOpenPromise = new Promise((resolve, reject) => {
            this.resolveFn = resolve;
            this.rejectFn = reject;
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() { }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.websocket) {
            this.websocket.close();
        }
    }
    /**
     * @return {?}
     */
    getAuthKey() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getauthkey');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project, 'operation': 'getauthkey' }),
            observe: /** @type {?} */ ('response')
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions)
                .pipe(retry(2), catchError(this.handleError)).subscribe(resp => {
                if (resp.body.statusCode.type) {
                    RsaUtils.publicKeyFromPEM(resp.body.statusCode.AppData.pemFile);
                    this.encryptionKey = resp.body.statusCode.AppData;
                    /** @type {?} */
                    const serverTime = resp.headers.has('Date') ? new Date(resp.headers.get('Date')).getTime() : new Date().getTime();
                    /** @type {?} */
                    const clientTime = new Date().getTime();
                    this.timeAdjustment = serverTime - clientTime;
                    //this.sessionService.putDateForCookieExpiry();
                    resolve();
                }
                else {
                    reject();
                }
            }, error => {
                console.log('fetching rsa key failed');
                console.log(error);
                reject();
            });
        });
    }
    /**
     * @return {?}
     */
    getNodeShortNameFullNameJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeShortNameFullName');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getNodeShortNameFullName'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.neShortNameFullNameJson = {
                        'NodeName': resp.statusCode.AppData
                    };
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getCircleShortNameFullNameJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleShortNameFullName');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getCircleShortNameFullName'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.circleFullNameJsonResponse = {
                        CircleName: resp.statusCode.AppData
                    };
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getModuleToIdJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getShortCodeToIdMap');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getShortCodeToIdMap'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.shortCodeToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getNodeToIdJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getNodeToIdMap');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getNodeToIdMap'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.nodeToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getCircleToIdJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getCircleToIdMap');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getCircleToIdMap'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.circleToIdMap = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getOperationToModuleNodeCircleJson() {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.ACCESS_CONTEXT).concat('?operation=getOperationToModuleNodeCircle');
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getOperationToModuleNodeCircle'
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                if (resp.statusCode.type) {
                    this.OperationToAccessMapping = resp.statusCode.AppData;
                    resolve();
                }
                else {
                    reject(resp);
                }
            }, error => {
                console.log(error);
                reject(error);
            });
        });
    }
    /**
     * @return {?}
     */
    getPathName() {
        return window.location && window.location.hash && window.location.hash.substr(1);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onStartupRouteChange(event) {
        return new Promise((resolve, reject) => {
            this.sessionService.globals = this.sessionService.getSessionData().globals;
            if (!this.sessionService.globals) {
                this.sessionService.globals = {};
            }
            if (this.appConfiguration.getConfiguration().loginPage && this.appConfiguration.getConfiguration().nonRestrictedPages
                && this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
                /** @type {?} */
                let pathName = this.location.path();
                if (pathName.includes("?")) {
                    pathName = pathName.split("?")[0];
                }
                /** @type {?} */
                const restrictedPage = this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
                /** @type {?} */
                const loggedIn = this.sessionService.globals.currentUser;
                if (restrictedPage && !loggedIn) {
                    this.location.go(this.appConfiguration.getConfiguration().loginPage);
                    resolve();
                }
                else if (loggedIn) {
                    try {
                        if (!this.sessionService.moduleRestriction) {
                            this.sessionService.moduleRestriction = this.sessionService.getSessionDataForModuleRestriction();
                        }
                        if (!this.sessionService.structuredRestriction) {
                            this.sessionService.structuredRestriction = this.sessionService.getSessionDataForStructuredRestriction();
                        }
                        if (!this.sessionService.parsedNodeCircleJson) {
                            this.sessionService.parsedNodeCircleJson = this.sessionService.getSessionDataForNodeCircleRestriction();
                        }
                        /** @type {?} */
                        const loginPage = this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) != -1;
                        if (loginPage) {
                            this.location.go(this.appConfiguration.getConfiguration().defaultPageAfterLogin);
                        }
                        this.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(resp => {
                            resolve();
                        }, error => {
                            console.log(error);
                            resolve();
                        });
                    }
                    catch (e) {
                        console.log(e);
                    }
                }
                else {
                    resolve();
                }
            }
        });
    }
    /**
     * @return {?}
     */
    callWhenConfigLoads() {
        /** @type {?} */
        const userDetails = this.sessionService.globals;
        /** @type {?} */
        const aesKey = this.sessionService.getSessionData().aesKey;
        this.messageMapping.loadMesageMap('assets/configuration/messagemapping.json');
        if (aesKey) {
            AesUtils.setAesEncryptionKey(aesKey);
        }
        if (userDetails && userDetails.currentUser && userDetails.currentUser.username && !this.loginUserImage) {
            this.getUserImage(userDetails.currentUser.username).then(function (response) {
                if (response.success) {
                    this.loginUserImage = response.AppData.userInfo.userImage ? response.AppData.userInfo.userImage : 'noImage';
                }
            }, function (err) {
                console.log(err);
            });
        }
    }
    /**
     * @template T
     * @param {?} userName
     * @return {?}
     */
    getUserImage(userName) {
        /** @type {?} */
        const url = CONSTANTS.PROTOCOL.concat(this.appConfiguration.getConfiguration().ip)
            .concat(':').concat(this.appConfiguration.getConfiguration().port.toString())
            .concat(CONSTANTS.IDENTITY_CONTEXT).concat('?operation=getUserImage&userName=').concat(userName);
        /** @type {?} */
        const httpOptions = {
            headers: new HttpHeaders({
                'project': this.appConfiguration.getConfiguration().project,
                'operation': 'getUserImage',
                'userToken': `${userName}-${this.sessionService.getUserTokenData()}`
            })
        };
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                .subscribe(resp => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    /**
     * @param {?} websocketCallbacks
     * @return {?}
     */
    openWebSocketChannel(websocketCallbacks) {
        /** @type {?} */
        let responseSessionData = this.sessionService.getSessionData();
        /** @type {?} */
        const protocol = CONSTANTS.WEBSOCKET_PROTOCOL;
        /** @type {?} */
        const ip = this.appConfiguration.getConfiguration().ip;
        /** @type {?} */
        const port = this.appConfiguration.getConfiguration().port;
        /** @type {?} */
        const websocketPort = this.appConfiguration.getConfiguration().websocketPort;
        /** @type {?} */
        const project = this.appConfiguration.getConfiguration().project;
        /** @type {?} */
        const userName = responseSessionData.globals.currentUser.userName;
        /** @type {?} */
        const base64token = util.encode64(`${userName}-${this.sessionService.getUserTokenData()}`);
        /** @type {?} */
        const queryString = `?operation=authenticateWebSocket&project=${project}&userToken=${base64token}&projectUrl=${ip}:${port}`;
        /** @type {?} */
        const webSocketURL = `${protocol}${ip}:${websocketPort}/websocket${queryString}`;
        return new Observable(observe => {
            /** @type {?} */
            let flag = false;
            try {
                this.websocket = new WebSocket(webSocketURL);
                if (websocketCallbacks.onOpen) {
                    this.websocket.onopen = () => {
                        websocketCallbacks.onOpen();
                        /** @type {?} */
                        const map = this.getCookies();
                        this.X_SOCKET_ADDRESS = map.has('X-SOCKET-ADDRESS') ? map.get('X-SOCKET-ADDRESS') : null;
                        this.X_USERNAME = map.has('X-USERNAME') ? map.get('X-USERNAME') : null;
                        this.SOCKET_IP = map.has('socketIp') ? map.get('socketIp') : null;
                        this.resolveFn();
                        observe.next();
                        flag = true;
                    };
                }
                if (websocketCallbacks.onClose) {
                    this.websocket.onclose = () => {
                        websocketCallbacks.onClose();
                        WebSocketCallbackClass.reInitializeObservables();
                        this.reInitializeWebsocketOpenPromise();
                        /** @type {?} */
                        const map = this.getCookies();
                        responseSessionData = this.sessionService.getSessionData();
                        if (map.has('X-USERNAME') && flag && responseSessionData.globals && responseSessionData.globals.currentUser) {
                            /** @type {?} */
                            const callback = new WebSocketCallbackClass();
                            this.openWebSocketChannel(callback).subscribe(resp => {
                                callback.onReconnect();
                            });
                        }
                    };
                }
                /** @type {?} */
                const resolveFn = this.resolveFn;
                this.websocket.onerror = function (error) {
                    if (websocketCallbacks.onError) {
                        websocketCallbacks.onError(error);
                    }
                    console.log('re-connecting to websocket server...');
                    resolveFn();
                    observe.error();
                };
                if (websocketCallbacks.onMessage) {
                    this.websocket.onmessage = websocketCallbacks.onMessage;
                }
            }
            catch (error) {
                this.resolveFn();
                console.log(error);
                observe.error(error);
            }
        }).pipe(delay(2000)).pipe(retry(15));
    }
    /**
     * @return {?}
     */
    getCookies() {
        /** @type {?} */
        const cookieStr = document.cookie;
        /** @type {?} */
        const cookies = cookieStr.split(';');
        /** @type {?} */
        const map = new Map();
        cookies.forEach(cookie => {
            if (cookie) {
                /** @type {?} */
                const keyVal = cookie.trim().split('=');
                map.set(keyVal[0].trim(), keyVal[1].trim());
            }
        });
        return map;
    }
    /**
     * @param {?} error
     * @return {?}
     */
    handleError(error) {
        if (error instanceof ErrorEvent) {
            return throwError(`Could not connect to server.\n:${error}`);
        }
        else {
            return throwError(`Server returned code ${error.status}, body was: ${error.error}`);
        }
    }
    /**
     * @return {?}
     */
    reInitializeWebsocketOpenPromise() {
        this.websocketOpenPromise = new Promise((resolve, reject) => {
            this.resolveFn = resolve;
            this.rejectFn = reject;
        });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onbeforeunloadHandler(event) {
        /** @type {?} */
        const loginPage = this.appConfiguration.getConfiguration()
            .nonRestrictedPages.includes(this.location.path());
        if (loginPage) {
            this.websocket.close();
        }
    }
}
CacheManagerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
CacheManagerService.ctorParameters = () => [
    { type: AppConfigurationService },
    { type: HttpClient },
    { type: SessionService },
    { type: Location },
    { type: MessageMapping }
];
CacheManagerService.propDecorators = {
    onbeforeunloadHandler: [{ type: HostListener, args: ['window:onbeforeunload', ['$event'],] }]
};
/** @nocollapse */ CacheManagerService.ngInjectableDef = defineInjectable({ factory: function CacheManagerService_Factory() { return new CacheManagerService(inject(AppConfigurationService), inject(HttpClient), inject(SessionService), inject(Location), inject(MessageMapping)); }, token: CacheManagerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class HttpService {
    /**
     * @param {?} httpClient
     * @param {?} appConfiguration
     * @param {?} cache
     * @param {?} sessionService
     */
    constructor(httpClient, appConfiguration, cache, sessionService) {
        this.httpClient = httpClient;
        this.appConfiguration = appConfiguration;
        this.cache = cache;
        this.sessionService = sessionService;
    }
    /**
     * @param {?} queryString
     * @param {?} key
     * @return {?}
     */
    parseQueryString(queryString, key) {
        /** @type {?} */
        let tokens;
        if (queryString) {
            tokens = queryString.split('&');
        }
        else {
            return null;
        }
        /** @type {?} */
        const map = new Map();
        for (const token of tokens) {
            /** @type {?} */
            const keyValue = token.split('=');
            map.set(keyValue[0], keyValue[1]);
        }
        return map.has(key) ? map.get(key) : null;
    }
    /**
     * @param {?} url
     * @return {?}
     */
    parseUrl(url) {
        /** @type {?} */
        const parsedParameters = new Map();
        /** @type {?} */
        const queryString = url.split('?')[1];
        /** @type {?} */
        const parameterPairList = queryString.split('&');
        parameterPairList.forEach(parameterPair => {
            /** @type {?} */
            const keyValue = parameterPair.split('=');
            parsedParameters[keyValue[0]] = keyValue[1];
        });
        return parsedParameters;
    }
    /**
     * @param {?} url
     * @return {?}
     */
    checkAuthorization(url) {
        if (!this.appConfiguration.getConfiguration().clientSideRequestBarring) {
            return true;
        }
        /** @type {?} */
        const parsedParameters = this.parseUrl(url);
        /** @type {?} */
        const operation = parsedParameters['operation'];
        /** @type {?} */
        let accessGrantedModule = false;
        /** @type {?} */
        let accessGrantedNode = false;
        /** @type {?} */
        let accessGrantedCircle = false;
        switch (operation) {
            case 'doLogin':
            case 'logoutUser':
                accessGrantedModule = true;
                break;
            default:
                if (this.cache.OperationToAccessMapping[operation] &&
                    this.cache.OperationToAccessMapping[operation].module !== 'freeAllow') {
                    /** @type {?} */
                    const accessRequired = this.cache.OperationToAccessMapping[operation].access;
                    if (this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module]) {
                        accessGrantedModule =
                            this.sessionService.structuredRestriction[this.cache.OperationToAccessMapping[operation].module][accessRequired] ? true : false;
                    }
                    else {
                        accessGrantedModule = false;
                    }
                }
                else if (this.cache.OperationToAccessMapping[operation] &&
                    this.cache.OperationToAccessMapping[operation].module === 'freeAllow') {
                    accessGrantedModule = true;
                }
                else {
                    accessGrantedModule = false;
                }
                break;
        }
        if (!accessGrantedModule) {
            return false;
        }
        if (this.cache.OperationToAccessMapping[operation] && this.cache.OperationToAccessMapping[operation].circle) {
            if (this.cache.OperationToAccessMapping[operation].node) {
                /** @type {?} */
                const circleAccessRequired = parsedParameters['circleName'];
                /** @type {?} */
                const nodeAccessRequired = parsedParameters['nodeName'];
                if (circleAccessRequired && nodeAccessRequired) {
                    if (nodeAccessRequired.parsedNodeCircleJson[nodeAccessRequired] &&
                        this.sessionService.parsedNodeCircleJson[nodeAccessRequired][circleAccessRequired]) {
                        accessGrantedCircle = true;
                    }
                    else {
                        accessGrantedCircle = false;
                    }
                }
                else {
                    accessGrantedCircle = false;
                }
            }
            else {
                accessGrantedCircle = false;
            }
        }
        else if (this.cache.OperationToAccessMapping[operation] &&
            !this.cache.OperationToAccessMapping[operation].circle) {
            accessGrantedCircle = true;
        }
        else {
            accessGrantedCircle = false;
        }
        if (!accessGrantedCircle) {
            return false;
        }
        if (this.cache.OperationToAccessMapping[operation] &&
            this.cache.OperationToAccessMapping[operation].node) {
            /** @type {?} */
            const nodeAccessRequired = parsedParameters['nodeName'];
            if (nodeAccessRequired) {
                if (this.sessionService.parsedNodeCircleJson[nodeAccessRequired]) {
                    accessGrantedNode = true;
                }
                else {
                    accessGrantedNode = false;
                }
            }
            else {
                accessGrantedNode = false;
            }
        }
        else if (this.cache.OperationToAccessMapping[operation] &&
            !this.cache.OperationToAccessMapping[operation].node) {
            accessGrantedNode = true;
        }
        else {
            accessGrantedNode = false;
        }
        return accessGrantedNode;
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    getData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            console.log(url);
            if (this.checkAuthorization(url)) {
                if (request.responseType) {
                    request.headers.set('responseType', request.responseType);
                }
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                if (request.responseType) {
                    httpOptions['responseType'] = request.responseType;
                }
                return new Observable(observe => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => {
                                console.log(response);
                                if (request.callbackfunction) {
                                    request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                                }
                                else {
                                    observe.next(response);
                                }
                            }, error => {
                                observe.error(error);
                            });
                        });
                    }
                    else {
                        this.httpClient.get(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => {
                            if (request.callbackfunction) {
                                request.callbackfunction({ body: response.body, headers: response.headers, status: response.status });
                            }
                            else {
                                observe.next(response);
                            }
                        }, error => {
                            observe.error(error);
                        });
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    postData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            console.log(url);
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                return new Observable(subscriber => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.post(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                        });
                    }
                    else {
                        this.httpClient.post(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    putData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                return new Observable(subscriber => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.put(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                        });
                    }
                    else {
                        this.httpClient.put(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    deleteData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                return new Observable(subscriber => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.delete(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                        });
                    }
                    else {
                        this.httpClient.delete(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    headData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                return new Observable(subscriber => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.head(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                        });
                    }
                    else {
                        this.httpClient.head(url, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @template T
     * @param {?} request
     * @return {?}
     */
    patchData(request) {
        /** @type {?} */
        const operation = this.parseQueryString(request.queryString, 'operation');
        /** @type {?} */
        let url;
        /** @type {?} */
        const config = this.appConfiguration.getConfiguration();
        if (request.reqUrl) {
            url = request.reqUrl;
        }
        else {
            if (!request.queryString) {
                request.queryString = '';
            }
            else {
                request.queryString = `?${request.queryString}`;
            }
            url = `${CONSTANTS.PROTOCOL}${config.ip}:${config.port}${request.context}${request.queryString}`;
            if (this.checkAuthorization(url)) {
                /** @type {?} */
                const httpOptions = {
                    headers: request.headers ? request.headers : /** @type {?} */ ({}),
                    observe: /** @type {?} */ ('response')
                };
                httpOptions.headers['operation'] = operation;
                return new Observable(subscriber => {
                    if (this.sessionService.getSessionData().globals &&
                        this.sessionService.getSessionData().globals.currentUser) {
                        this.cache.websocketOpenPromise.then(() => {
                            this.httpClient.patch(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                                .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                        });
                    }
                    else {
                        this.httpClient.patch(url, request.data, httpOptions).pipe(retry(2), catchError(this.handleError))
                            .subscribe(response => subscriber.next(response), error => subscriber.error(error));
                    }
                });
            }
            else {
                return throwError(`Not authorized for accessing ${url}: 401`);
            }
        }
    }
    /**
     * @param {?} error
     * @return {?}
     */
    handleError(error) {
        if (error instanceof ErrorEvent) {
            return throwError(`Could not connect to server.\n:${error}`);
        }
        else {
            return throwError(error);
        }
    }
}
HttpService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
HttpService.ctorParameters = () => [
    { type: HttpClient },
    { type: AppConfigurationService },
    { type: CacheManagerService },
    { type: SessionService }
];
/** @nocollapse */ HttpService.ngInjectableDef = defineInjectable({ factory: function HttpService_Factory() { return new HttpService(inject(HttpClient), inject(AppConfigurationService), inject(CacheManagerService), inject(SessionService)); }, token: HttpService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class IamService {
    /**
     * @param {?} httpService
     * @param {?} appConfiguration
     * @param {?} sessionService
     * @param {?} cache
     * @param {?} router
     * @param {?} location
     */
    constructor(httpService, appConfiguration, sessionService, cache, router, location) {
        this.httpService = httpService;
        this.appConfiguration = appConfiguration;
        this.sessionService = sessionService;
        this.cache = cache;
        this.router = router;
        this.location = location;
        this.startListeningToRouteChange().subscribe(() => {
            console.log('started listening for route change');
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.websocket.close();
    }
    /**
     * @template T
     * @param {?} payload
     * @param {?} project
     * @return {?}
     */
    doLogin(payload, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders().set('project', this.appConfiguration.getConfiguration().project);
        }
        else {
            headers = new HttpHeaders().set('project', project);
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=doLogin',
            headers: headers,
            data: payload
        };
        return this.httpService.postData(request);
    }
    /**
     * @return {?}
     */
    startListeningToRouteChange() {
        return new Observable(observe => {
            this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
                if (event instanceof NavigationEnd) {
                    this.onRouteChange(event);
                }
            });
            observe.next();
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} password
     * @param {?=} project
     * @return {?}
     */
    authenticateUser(userName, password, project) {
        return new Observable(observe => {
            /** @type {?} */
            const responseSessionData = this.sessionService.getSessionData();
            if (responseSessionData && responseSessionData.globals &&
                responseSessionData.globals.currentUser && responseSessionData.globals.currentUser.userName) {
                console.log('user already logged in');
                this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                observe.next();
            }
            else {
                /** @type {?} */
                const randomAesKey = AesUtils.generateRandomAesKey();
                /** @type {?} */
                const credentials = {
                    userName: userName,
                    userPassword: RsaUtils.encrypt(password),
                };
                /** @type {?} */
                const payload = {
                    AppData: {
                        userInfo: credentials,
                        encryptionKey: RsaUtils.encrypt(randomAesKey)
                    }
                };
                this.doLogin(payload, project).subscribe(response => {
                    if (response.body && response.body.statusCode && response.body.statusCode.AppData && response.body.statusCode.AppData.userToken) {
                        /** @type {?} */
                        const subTokens = response.body.statusCode.AppData.userToken.split('@');
                        /** @type {?} */
                        let moduleRestriction = null;
                        /** @type {?} */
                        let structuredRestriction = null;
                        /** @type {?} */
                        let nodeNameCircle = null;
                        if (subTokens[1] && subTokens[1].length > 0) {
                            moduleRestriction = this.parseToken(AesUtils.decrypt(subTokens[1], randomAesKey));
                        }
                        else {
                            moduleRestriction = {};
                        }
                        structuredRestriction = this.restructureAccessJson(moduleRestriction, {});
                        this.sessionService.setSessionDataForModuleRestriction(moduleRestriction);
                        this.sessionService.setSessionDataForStructuredRestriction(structuredRestriction);
                        this.sessionService.setUserTokenData(subTokens[0]);
                        if (subTokens[2] && subTokens[2].length > 0) {
                            nodeNameCircle = AesUtils.decrypt(subTokens[2], randomAesKey);
                        }
                        else {
                            nodeNameCircle = '';
                        }
                        /** @type {?} */
                        const parsedNodeCircleJson = this.parseNodeCircleToken(nodeNameCircle);
                        this.sessionService.setSessionDataForNodeCircleRestriction(/** @type {?} */ (parsedNodeCircleJson));
                        /** @type {?} */
                        const neNamesCircleList = nodeNameCircle.split('#');
                        if (!this.sessionService.nodeNameList) {
                            this.sessionService.nodeNameList = [];
                        }
                        if (!this.sessionService.mapNeNameCircleName) {
                            this.sessionService.mapNeNameCircleName = {};
                        }
                        for (let itr = 0; itr < neNamesCircleList.length; itr++) {
                            /** @type {?} */
                            const cirleNamesForNE = neNamesCircleList[itr].split(':');
                            this.sessionService.nodeNameList.push(cirleNamesForNE[0]);
                            this.sessionService.mapNeNameCircleName[cirleNamesForNE[0]] = cirleNamesForNE[1];
                        }
                        this.sessionService.selectedNeShortName = this.sessionService.nodeNameList[0];
                        this.neShortNameFullNameMapping();
                        this.neCircleShortNameFullNameMapping();
                        /** @type {?} */
                        const neNameCircleName = JSON.parse(JSON.stringify({
                            selectedNeName: this.sessionService.selectedNeName,
                            selectedCircleName: this.sessionService.selectedCircleName
                        }));
                        /** @type {?} */
                        const requestData = {
                            userName: userName,
                            appData: response.body.statusCode.AppData,
                            nodeNameCircle: nodeNameCircle,
                            aesKey: AesUtils.decrypt(subTokens[3], randomAesKey),
                            neNameCircleName: neNameCircleName
                        };
                        this.sessionService.putDateForCookieExpiry();
                        this.sessionService.setSessionData(requestData);
                        AesUtils.setAesEncryptionKey(AesUtils.decrypt(subTokens[3], randomAesKey));
                        this.cache.getUserImage(userName).then(function (resp) {
                            if (resp.success) {
                                this.cache.loginUserImage = resp.AppData.userInfo.userImage ? resp.AppData.userInfo.userImage : 'noImage';
                            }
                        }, function (err) {
                            console.log(err);
                        });
                        this.cache.openWebSocketChannel(new WebSocketCallbackClass()).subscribe(() => {
                            this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                            observe.next(response);
                        }, () => {
                            this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                            observe.next(response);
                        });
                    }
                    else {
                        observe.next(response);
                    }
                }, error => {
                    observe.error(error);
                });
            }
        });
    }
    /**
     * @param {?} userName
     * @return {?}
     */
    doLogout(userName) {
        if (!userName) {
            throwError('userName is undefined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: `operation=logoutUser&userName=${userName}`,
        };
        return new Observable(observe => {
            this.httpService.deleteData(request).subscribe(response => {
                observe.next();
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @return {?}
     */
    logoutUser() {
        return new Observable(observe => {
            /** @type {?} */
            const globals = this.sessionService.getSessionData().globals;
            if (globals && globals.currentUser && globals.currentUser.userName) {
                /** @type {?} */
                const inUserName = globals.currentUser.userName;
                this.doLogout(inUserName).subscribe(() => {
                    this.resetVariables();
                    this.sessionService.clearSessionDataAndGotoLogoutPage();
                    if (this.cache.websocket && this.cache.websocket.close) {
                        this.cache.websocket.close();
                        this.cache.websocket = null;
                    }
                    observe.next();
                }, (error) => {
                    this.resetVariables();
                    this.sessionService.clearSessionDataAndGotoLogoutPage();
                    if (this.cache.websocket && this.cache.websocket.close) {
                        this.cache.websocket.close();
                        this.cache.websocket = null;
                    }
                    observe.error();
                });
            }
            else {
                this.resetVariables();
                this.sessionService.clearSessionDataAndGotoLogoutPage();
                if (this.cache.websocket && this.cache.websocket.close) {
                    this.cache.websocket.close();
                    this.cache.websocket = null;
                }
                observe.next();
                console.log('no user to logout');
            }
        });
    }
    /**
     * @return {?}
     */
    getPathName() {
        return window.location && window.location.hash && window.location.hash.substr(1);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onRouteChange(event) {
        this.sessionService.globals = this.sessionService.getSessionData().globals;
        if (!this.sessionService.globals) {
            this.sessionService.globals = {};
        }
        if (this.router.url == this.appConfiguration.getConfiguration().sessionExpiredPage) {
            try {
                if (this.cache.websocket) {
                    this.cache.websocket.close();
                    this.cache.websocket = null;
                }
            }
            catch (ErrorEvent) {
                console.log(ErrorEvent);
            }
        }
        if (this.appConfiguration.getConfiguration().loginPage &&
            this.appConfiguration.getConfiguration().nonRestrictedPages &&
            this.appConfiguration.getConfiguration().defaultPageAfterLogin) {
            /** @type {?} */
            let pathName = this.location.path();
            if (pathName.includes("?")) {
                pathName = pathName.split("?")[0];
            }
            /** @type {?} */
            const restrictedPage = this.appConfiguration.getConfiguration().nonRestrictedPages.indexOf(pathName) === -1;
            /** @type {?} */
            const loggedIn = this.sessionService.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                this.router.navigate([this.appConfiguration.getConfiguration().loginPage]);
            }
            else if (loggedIn) {
                /** @type {?} */
                const loginPage = this.appConfiguration.getConfiguration()
                    .nonRestrictedPages.indexOf(pathName) != -1;
                if (loginPage) {
                    this.router.navigate([this.appConfiguration.getConfiguration().defaultPageAfterLogin]);
                }
            }
        }
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getAllroleid(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getAllRoleSelectedFiled',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    createSingleUser(creatingUser, AppData, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: `operation=createSingleUser&creatingUser=${creatingUser}`,
            data: { AppData },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    createAccount(AppData, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        AppData.userInfo.userPassword = AesUtils.encrypt(AppData.userInfo.userPassword);
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=createAccount',
            data: { AppData },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    createBulkUser(creatingUser, file, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: `operation=createBulkUser&creatingUser=${creatingUser}`,
            data: file,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} creatingUser
     * @param {?} file
     * @param {?=} project
     * @return {?}
     */
    createBulkRolesandUsers(creatingUser, file, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: `operation=createBulkRolesandUsers&creatingUser=${creatingUser}`,
            data: file,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @param {?=} project
     * @return {?}
     */
    downloadBulkUsers(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getBulkUser',
            responseType: 'arraybuffer',
            headers: headers,
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                /** @type {?} */
                const blob = new Blob([resp.body], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel'
                });
                /** @type {?} */
                var a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "UserList.xlsx";
                a.click();
                observe.next();
            }, error => {
                console.log(error);
                observe.error();
            });
        });
    }
    /**
     * @param {?=} project
     * @return {?}
     */
    downloadUserTemplate(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getTemplate',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                /** @type {?} */
                let data1 = resp.body;
                /** @type {?} */
                let data = resp.body['statusCode']['AppData']['Base64Stream'];
                /** @type {?} */
                var bindata = window.atob(data);
                /** @type {?} */
                var len = bindata.length;
                /** @type {?} */
                var bytes = new Uint8Array(len);
                for (var i = 0; i < len; i++) {
                    bytes[i] = bindata.charCodeAt(i);
                }
                /** @type {?} */
                var file = new Blob([bytes.buffer], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
                });
                window.saveAs(file, "usertemplate" + ".xlsx");
                observe.next();
            }, error => {
                observe.error();
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    deleteUser(userName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=deleteUser&userName=' + userName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.deleteData(request).subscribe(resp => {
                console.log(resp);
                console.log(resp.body);
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} userInfo
     * @param {?=} project
     * @return {?}
     */
    modifyUser(userName, userInfo, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyUser&userName=' + userName,
            headers: headers,
            data: { 'AppData': userInfo }
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    viewUser(userName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getUser&userName=' + userName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    viewUserListAccordingtoRole(roleId, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!roleId) {
            throwError('roleId is not defined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getUsersList&roleId=' + roleId,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userId
     * @param {?=} project
     * @return {?}
     */
    blockUser(userId, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        if (!userId) {
            throwError('userId is not defined');
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=blockUser&userId=' + userId,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    checkUserExistence(userName, project) {
        if (!userName) {
            throwError('userName is not defined');
        }
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=checkUser&userName=' + userName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} index
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    getAllUser(index, size, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getAllUser&from=' + index + '&size=' + size,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getRestrictedUser(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getAllUserSelectedField',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    createRole(roleData, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const currentDate = new Date();
        roleData.roleInfo.role['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['createdBy'] = this.cache.X_USERNAME;
        roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=createRole',
            data: { 'AppData': roleData },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @return {?}
     */
    resetVariables() {
        this.sessionService.globals = null;
        this.sessionService.selectedCircleName = null;
        this.sessionService.selectedNeName = null;
        this.sessionService.selectedNeShortName = null;
        this.sessionService.parsedNodeCircleJson = null;
        this.sessionService.nodeNameCircle = null;
        this.sessionService.structuredRestriction = null;
        this.sessionService.moduleRestriction = null;
        this.sessionService.mapNeNameCircleName = null;
        this.sessionService.nodeNameList = [];
    }
    /**
     * @param {?} key
     * @return {?}
     */
    getCookie(key) {
        /** @type {?} */
        const cookieStr = document.cookie;
        /** @type {?} */
        const cookies = cookieStr.split(';');
        /** @type {?} */
        const map = {};
        cookies.forEach(cookie => {
            if (cookie) {
                /** @type {?} */
                const keyval = cookie.trim().split('=');
                map[keyval[0].trim()] = keyval[1].trim();
            }
        });
        return map[key];
    }
    /**
     * @param {?} module
     * @param {?} structuredJson
     * @return {?}
     */
    restructureAccessJson(module, structuredJson) {
        for (const key in module) {
            if (module.hasOwnProperty(key)) {
                /** @type {?} */
                const value = module[key];
                if (value.access) {
                    /** @type {?} */
                    const access = {};
                    for (const ky in value.access) {
                        if (value.access.hasOwnProperty(key)) {
                            /** @type {?} */
                            const element = value.access[ky];
                            switch (ky) {
                                case 'R':
                                    access['Read'] = true;
                                    break;
                                case 'W':
                                    access['Write'] = true;
                                    break;
                                case 'D':
                                    access['Delete'] = true;
                                    break;
                            }
                        }
                    }
                    structuredJson[key] = access;
                }
                else {
                    this.restructureAccessJson(value, structuredJson);
                }
            }
        }
        return structuredJson;
    }
    /**
     * @param {?} authToken
     * @return {?}
     */
    parseToken(authToken) {
        /** @type {?} */
        const json = {};
        if (!authToken) {
            return json;
        }
        /** @type {?} */
        const tokens = authToken.split('#');
        for (let i = 0; i < tokens.length; i++) {
            /** @type {?} */
            const token = tokens[i];
            /** @type {?} */
            const shortCodes = token.split('.');
            /** @type {?} */
            let tempName = '';
            /** @type {?} */
            let temp = json;
            for (let j = 0; j < shortCodes.length - 1; j++) {
                /** @type {?} */
                const shortCode = shortCodes[j];
                if (tempName === '') {
                    tempName = shortCode;
                }
                else {
                    tempName = `${tempName}.${shortCode}`;
                }
                if (!temp.hasOwnProperty(tempName)) {
                    temp[tempName] = {};
                }
                temp = temp[tempName];
            }
            if (tempName === '') {
                tempName = shortCodes[shortCodes.length - 1].split(':')[0];
            }
            else {
                tempName = `${tempName}.${shortCodes[shortCodes.length - 1].split(':')[0]}`;
            }
            if (!temp.hasOwnProperty(tempName)) {
                /** @type {?} */
                const restrictJson = {};
                /** @type {?} */
                const restriction = shortCodes[shortCodes.length - 1].split(':')[1].split('');
                for (let k = 0; k < restriction.length; k++) {
                    restrictJson[restriction[k]] = true;
                }
                temp[tempName] = { access: restrictJson };
            }
        }
        return json;
    }
    /**
     * @param {?} token
     * @return {?}
     */
    parseNodeCircleToken(token) {
        /** @type {?} */
        const parsedJson = {};
        if (!token || token === '') {
            return parsedJson;
        }
        /** @type {?} */
        const singleNodeCircleList = token.split('#');
        for (let i = 0; i < singleNodeCircleList.length; i++) {
            /** @type {?} */
            const singleNodeCircle = singleNodeCircleList[i];
            /** @type {?} */
            const node = singleNodeCircle.split(':')[0];
            /** @type {?} */
            const circlesList = singleNodeCircle.split(':')[1].split(',');
            /** @type {?} */
            const circleJson = {};
            for (let j = 0; j < circlesList.length; j++) {
                circleJson[this.cache.circleFullNameJsonResponse['CircleName'][circlesList[j]]] = true;
            }
            parsedJson[node] = circleJson;
        }
        return parsedJson;
    }
    /**
     * @return {?}
     */
    neShortNameFullNameMapping() {
        /** @type {?} */
        const response = this.cache.neShortNameFullNameJson;
        /** @type {?} */
        const neShortName = this.sessionService.nodeNameList[0];
        if (response.NodeName) {
            /** @type {?} */
            const nodeFullName = response.NodeName[neShortName];
            this.sessionService.selectedNeName = nodeFullName;
        }
        if (!this.cache.mapNeShortNameFullName) {
            this.cache.mapNeShortNameFullName = {};
        }
        for (let itr = 0; itr < response.NodeName && this.sessionService.nodeNameList.length; itr++) {
            this.cache.mapNeShortNameFullName[response.NodeName[this.sessionService.nodeNameList[itr]]] = this.sessionService.nodeNameList[itr];
        }
    }
    /**
     * @return {?}
     */
    neCircleShortNameFullNameMapping() {
        /** @type {?} */
        const response = this.cache.circleFullNameJsonResponse;
        /** @type {?} */
        const circleShortNamesList = this.sessionService.mapNeNameCircleName[this.sessionService.nodeNameList[0]];
        if (circleShortNamesList) {
            /** @type {?} */
            const circle = circleShortNamesList.split(',');
            this.sessionService.selectedCircleName = response.CircleName[circle[0]];
        }
    }
    /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    getAccessJson(productId, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getModuleSubModuleData&productId=' + productId,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} productId
     * @param {?=} project
     * @return {?}
     */
    getNodeCircleJson(productId, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeCircleData&productId=' + productId,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getModuleToIdJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getShortCodeToIdMap',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getNodeToIdJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeToIdMap',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getCircleToIdJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getCircleToIdMap',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getCircleShortNameFullNameJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getCircleShortNameFullName',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getNodeShortNameFullNameJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getNodeShortNameFullName',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?=} project
     * @return {?}
     */
    getOperationToModuleNodeCircleJson(project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getOperationToModuleNodeCircle',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    deleteRole(roleId, project) {
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=deleteRole&roleId=' + roleId,
            headers: headers,
        };
        return new Observable(observe => {
            this.httpService.deleteData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleId
     * @param {?} roleData
     * @param {?=} project
     * @return {?}
     */
    modifyRole(roleId, roleData, project) {
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const currentDate = new Date();
        roleData.roleInfo.role['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        roleData.roleInfo.role['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=updateRole&roleId=' + roleId,
            data: { "AppData": roleData },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleId
     * @param {?=} project
     * @return {?}
     */
    viewRole(roleId, project) {
        if (!roleId)
            throw "Role id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=viewRole&roleId=' + roleId,
            headers: headers,
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    getAllRole(from, size, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=getAllRole&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} rolename
     * @param {?=} project
     * @return {?}
     */
    checkRoleExistence(rolename, project) {
        if (!rolename)
            throw "rolename is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.ACCESS_CONTEXT,
            queryString: 'operation=checkRole&roleName=' + rolename,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    createUserGroup(groupData, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const currentDate = new Date();
        groupData.groupInfo['createdOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['createdBy'] = this.cache.X_USERNAME;
        groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=createGroup',
            headers: headers,
            data: { 'AppData': groupData }
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    viewUserGroup(groupId, project) {
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            headers: headers,
            queryString: 'operation=viewGroup&groupId=' + groupId,
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    viewUserGroupList(from, size, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=viewGroupList&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} from
     * @param {?} size
     * @param {?=} project
     * @return {?}
     */
    viewAllGroup(from, size, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=viewAllGroup&from=' + from + '&size=' + size,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupId
     * @param {?=} project
     * @return {?}
     */
    deleteUserGroup(groupId, project) {
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=deleteGroup&groupId=' + groupId,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.deleteData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupId
     * @param {?} groupData
     * @param {?=} project
     * @return {?}
     */
    modifyUserGroup(groupId, groupData, project) {
        if (!groupId)
            throw "groupId id is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const currentDate = new Date();
        groupData.groupInfo['updatedOn'] = new Date(currentDate.getTime() + this.cache.timeAdjustment + 19800000);
        groupData.groupInfo['updatedBy'] = this.cache.X_USERNAME;
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyGroup&groupId=' + groupId,
            headers: headers,
            data: { 'AppData': groupData }
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    lockUser(userName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=lockUser&userName=' + userName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    unlockUser(userName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=unlockUser&userName=' + userName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    lockGroup(groupName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=lockGroup&groupName=' + groupName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} groupName
     * @param {?=} project
     * @return {?}
     */
    unlockGroup(groupName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=unlockGroup&groupName=' + groupName,
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} roleIdJson
     * @param {?=} project
     * @return {?}
     */
    getCountUsers(roleIdJson, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=getCountUsers',
            headers: headers,
            data: roleIdJson
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} oldPassword
     * @param {?} newPassword
     * @param {?=} project
     * @return {?}
     */
    changePassword(userName, oldPassword, newPassword, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=changePassword&userName=' + userName,
            data: {
                "userInfo": {
                    "userName": userName,
                    "oldUserPassword": AesUtils.encrypt(oldPassword),
                    "newUserPassword": AesUtils.encrypt(newPassword)
                }
            },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?=} project
     * @return {?}
     */
    forgotPassword(userName, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=forgotPassoword',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} requestParameters
     * @param {?} requestHeaders
     * @param {?=} project
     * @return {?}
     */
    insertTraceData(userName, operation, requestParameters, requestHeaders, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        let currentDate = new Date();
        headers = headers.append("userName", userName).append("operation", operation).append("timestamp", currentDate.getTime().toString());
        /** @type {?} */
        const request = {
            context: CONSTANTS.TRACE_CONTEXT,
            queryString: 'operation=insertTraceData',
            data: {
                "requestParameters": { requestParameters },
                "requestHeaders": { requestHeaders },
            },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} operation
     * @param {?} traceLevel
     * @param {?} fromTimeStamp
     * @param {?} toTimeStamp
     * @param {?=} project
     * @return {?}
     */
    getTraceData(userName, operation, traceLevel, fromTimeStamp, toTimeStamp, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName).append("operation", operation).append("traceLevel", traceLevel).append("fromTimeStamp", fromTimeStamp).append("toTimeStamp", toTimeStamp);
        /** @type {?} */
        const request = {
            context: CONSTANTS.TRACE_CONTEXT,
            queryString: 'operation=getTraceData',
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.getData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    resetPassword(userName, otp, newPassword, confirmPassword, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        let password = RsaUtils.encrypt(newPassword);
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=resetPassword',
            data: {
                "userInfo": {
                    "userName": userName,
                    "newPassword": password,
                    "confirmPassword": password,
                    "otp": otp
                }
            },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} otp
     * @param {?} newPassword
     * @param {?} confirmPassword
     * @param {?=} project
     * @return {?}
     */
    generatePassword(userName, otp, newPassword, confirmPassword, project) {
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        headers = headers.append("userName", userName);
        /** @type {?} */
        let password = RsaUtils.encrypt(newPassword);
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=generatePassword',
            data: {
                "userInfo": {
                    "userName": userName,
                    "newPassword": password,
                    "confirmPassword": password,
                    "otp": otp
                }
            },
            headers: headers
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
    /**
     * @template T
     * @param {?} userName
     * @param {?} AppData
     * @param {?=} project
     * @return {?}
     */
    modifyUserImage(userName, AppData, project) {
        if (!userName)
            throw "userName is undefined";
        /** @type {?} */
        let headers;
        if (!project) {
            headers = new HttpHeaders({ 'project': this.appConfiguration.getConfiguration().project });
        }
        else {
            headers = new HttpHeaders({ 'project': project });
        }
        /** @type {?} */
        const request = {
            context: CONSTANTS.IDENTITY_CONTEXT,
            queryString: 'operation=modifyUserImage&userName=' + userName,
            headers: headers,
            data: {
                'AppData': AppData
            }
        };
        return new Observable(observe => {
            this.httpService.postData(request).subscribe(resp => {
                observe.next(resp.body);
            }, error => {
                observe.error(error);
            });
        });
    }
}
IamService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
/** @nocollapse */
IamService.ctorParameters = () => [
    { type: HttpService },
    { type: AppConfigurationService },
    { type: SessionService },
    { type: CacheManagerService },
    { type: Router },
    { type: Location }
];
/** @nocollapse */ IamService.ngInjectableDef = defineInjectable({ factory: function IamService_Factory() { return new IamService(inject(HttpService), inject(AppConfigurationService), inject(SessionService), inject(CacheManagerService), inject(Router), inject(Location)); }, token: IamService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class HttpResponseInterceptor {
    /**
     * @param {?} sessionService
     * @param {?} appConfiguration
     * @param {?} cache
     */
    constructor(sessionService, appConfiguration, cache) {
        this.sessionService = sessionService;
        this.appConfiguration = appConfiguration;
        this.cache = cache;
    }
    /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    intercept(req, next) {
        if (this.cache.X_SOCKET_ADDRESS) {
            req = req.clone({
                setHeaders: {
                    'X-SOCKET-ADDRESS': this.cache.X_SOCKET_ADDRESS
                }
            });
        }
        if (this.cache.X_USERNAME) {
            req = req.clone({
                setHeaders: {
                    'X-USERNAME': this.cache.X_USERNAME
                }
            });
        }
        if (this.cache.SOCKET_IP) {
            req = req.clone({
                setHeaders: {
                    'socketIp': this.cache.SOCKET_IP
                }
            });
        }
        if (req.headers.has('X-Event-Name')) {
            req = req.clone({
                setHeaders: {
                    operation: req.headers.get('X-Event-Name')
                }
            });
        }
        else if (req.headers.has('Event-Key')) {
            req = req.clone({
                setHeaders: {
                    operation: req.headers.get('Event-Key')
                }
            });
        }
        else if (req.params.has('operation')) {
            req = req.clone({
                setHeaders: {
                    operation: req.params.get('operation')
                }
            });
        }
        if (this.sessionService.getSessionData().globals && this.sessionService.getSessionData().globals.currentUser &&
            this.sessionService.getSessionData().globals.currentUser.userName &&
            this.appConfiguration.getConfiguration() && this.appConfiguration.getConfiguration().project) {
            /** @type {?} */
            const userToken = this.sessionService.getUserTokenData();
            /** @type {?} */
            const userName = this.sessionService.getSessionData().globals.currentUser.userName;
            /** @type {?} */
            let product;
            product = req.headers.get("project");
            if (!product) {
                product = this.appConfiguration.getConfiguration().project;
            }
            req = req.clone({
                setHeaders: {
                    userToken: `${userName}-${userToken}`,
                    project: product
                }
            });
        }
        return next.handle(req).pipe(tap(response => {
            if (response instanceof HttpResponse) {
                /** @type {?} */
                const resp = /** @type {?} */ (response);
                if (resp.headers.has('userToken')) {
                    this.sessionService.setUserTokenData(resp.headers.get('userToken'));
                    this.sessionService.putDateForCookieExpiry();
                }
                if (response.body && response.body['statusCode'] &&
                    response.body['statusCode']['httpstatuscode']) {
                    if (response.body['statusCode']['httpstatuscode'] === 401 && (response.body['statusCode']['opStatusCode']
                        === 903 || response.body['statusCode']['opStatusCode'] === 4030)) {
                        this.sessionService.clearSessionDataAndGotoSessionExpirePage();
                    }
                }
            }
        }));
    }
}
HttpResponseInterceptor.decorators = [
    { type: Injectable },
];
/** @nocollapse */
HttpResponseInterceptor.ctorParameters = () => [
    { type: SessionService },
    { type: AppConfigurationService },
    { type: CacheManagerService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class IamComponent {
    constructor() { }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
}
IamComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-iam',
                template: `
    <p>
      iam works!
    </p>
  `,
                styles: []
            },] },
];
/** @nocollapse */
IamComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/**
 * @param {?} appConfigurationService
 * @param {?} cache
 * @return {?}
 */
function initializeApp(appConfigurationService, cache) {
    return () => new Promise((resolve, reject) => {
        appConfigurationService.loadConfiguration('assets/configuration/config.json').then(() => {
            /** @type {?} */
            const getRsaKeyPromise = cache.getAuthKey();
            /** @type {?} */
            const startUpRouteChangePromise = cache.onStartupRouteChange(event);
            Promise.all([getRsaKeyPromise, startUpRouteChangePromise]).then(() => {
                /** @type {?} */
                const nodeShortFullPromise = cache.getNodeShortNameFullNameJson();
                /** @type {?} */
                const circleShortFullPromise = cache.getCircleShortNameFullNameJson();
                /** @type {?} */
                const moduleToIdPromise = cache.getModuleToIdJson();
                /** @type {?} */
                const nodeToIdPromise = cache.getNodeToIdJson();
                /** @type {?} */
                const circleToIdPromise = cache.getCircleToIdJson();
                /** @type {?} */
                const operationToModuleNodeCirclePromise = cache.getOperationToModuleNodeCircleJson();
                Promise.all([nodeShortFullPromise, circleShortFullPromise, moduleToIdPromise,
                    nodeToIdPromise, circleToIdPromise, operationToModuleNodeCirclePromise]).then(() => {
                    cache.callWhenConfigLoads();
                    resolve();
                }, (error) => {
                    console.log(error);
                    reject();
                });
            }, (error) => {
                console.log(error);
                reject();
            });
        }, (error) => {
            console.log(error);
            reject();
        });
    });
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
const ɵ0 = initializeApp;
class IamModule {
    /**
     * @return {?}
     */
    static forRoot() {
        return {
            ngModule: IamModule,
            providers: []
        };
    }
}
IamModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                declarations: [IamComponent],
                exports: [IamComponent],
                providers: [IamService, CookieService, SessionService, AppConfigurationService, CacheManagerService, {
                        provide: APP_INITIALIZER,
                        useFactory: ɵ0,
                        deps: [AppConfigurationService, CacheManagerService],
                        multi: true
                    }, {
                        provide: HTTP_INTERCEPTORS,
                        useClass: HttpResponseInterceptor,
                        multi: true
                    }]
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

export { IamService, AppConfigurationService, CacheManagerService, CONSTANTS, HttpResponseInterceptor, HttpService, MessageMapping, NavigateService, SessionService, WebSocketCallbackClass, IamComponent, IamModule, initializeApp as ɵa };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWFtLmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9pYW0vbGliL2NvbnN0YW50LnRzIiwibmc6Ly9pYW0vbGliL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UudHMiLCJuZzovL2lhbS9saWIvcnNhLXV0aWxzLnRzIiwibmc6Ly9pYW0vbGliL2Flcy11dGlscy50cyIsIm5nOi8vaWFtL2xpYi9uYXZpZ2F0ZS5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL3Nlc3Npb24uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi93ZWItc29ja2V0LWNhbGxiYWNrcy1jbGFzcy50cyIsIm5nOi8vaWFtL2xpYi9tZXNzYWdlLW1hcHBpbmcudHMiLCJuZzovL2lhbS9saWIvY2FjaGUtbWFuYWdlci5zZXJ2aWNlLnRzIiwibmc6Ly9pYW0vbGliL2h0dHAuc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9pYW0uc2VydmljZS50cyIsIm5nOi8vaWFtL2xpYi9odHRwLXJlc3BvbnNlLWludGVyY2VwdG9yLnRzIiwibmc6Ly9pYW0vbGliL2lhbS5jb21wb25lbnQudHMiLCJuZzovL2lhbS9saWIvY29uZmlndXJhdGlvbi1mYWN0b3J5LnRzIiwibmc6Ly9pYW0vbGliL2lhbS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIENPTlNUQU5UUyB7XHJcbiAgICAvL3B1YmxpYyBzdGF0aWMgcmVhZG9ubHkgU0VTU0lPTl9USU1FT1VUOiBudW1iZXIgPSAxICogNjAgKiA2MCAqIDEwMDA7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1RPQ09MOiBzdHJpbmcgPSBgJHtsb2NhdGlvbi5wcm90b2NvbH0vL2A7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFdFQlNPQ0tFVF9QUk9UT0NPTDogc3RyaW5nID0gbG9jYXRpb24ucHJvdG9jb2wubG9jYWxlQ29tcGFyZSgnaHR0cHM6JykgPT09IDAgPyAnd3NzOi8vJyA6ICd3czovLyc7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IElERU5USVRZX0NPTlRFWFQ6IHN0cmluZyA9ICcvSUFNL2lkZW50aXR5Lyc7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFDQ0VTU19DT05URVhUOiBzdHJpbmcgPSAnL0lBTS9hY2Nlc3MvJztcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVFJBQ0VfQ09OVEVYVDogc3RyaW5nID0gJy9JQU0vdHJhY2UvJztcclxuICAgIGdldFByb3RvY29sKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIGxvY2F0aW9uLnByb3RvY29sO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIHtcclxuICBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb247XHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7IH1cclxuICBsb2FkQ29uZmlndXJhdGlvbihmaWxlUGF0aDogc3RyaW5nKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4gKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxBcHBDb25maWd1cmF0aW9uPihmaWxlUGF0aCkudG9Qcm9taXNlKCkudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24gPSByZXNwb25zZTtcclxuICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgIH0pLmNhdGNoKChyZXNwb25zZTogYW55KSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhgY291bGQgbm90IGxvYWQgY29uZmlndXJhdGlvbiBmaWxlIGVycm9yOiBcXG4gJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YCk7XHJcbiAgICAgICAgICByZWplY3QoYGNvdWxkIG5vdCBsb2FkIGNvbmZpZ3VyYXRpb24gZmlsZSBlcnJvcjogXFxuICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpfWApO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBwdWJsaWMgZ2V0Q29uZmlndXJhdGlvbigpOiBBcHBDb25maWd1cmF0aW9uIHtcclxuICAgIHJldHVybiB0aGlzLmFwcENvbmZpZ3VyYXRpb247XHJcbiAgfVxyXG4gIFxyXG59XHJcbmV4cG9ydCBpbnRlcmZhY2UgQXBwQ29uZmlndXJhdGlvbiB7XHJcbiAgaXA6IHN0cmluZztcclxuICBwb3J0OiBudW1iZXI7XHJcbiAgd2Vic29ja2V0UG9ydDogbnVtYmVyO1xyXG4gIHByb2plY3Q6IHN0cmluZztcclxuICBub25SZXN0cmljdGVkUGFnZXM6IEFycmF5PHN0cmluZz47XHJcbiAgZGVmYXVsdFBhZ2VBZnRlckxvZ2luOiBzdHJpbmc7XHJcbiAgbG9naW5QYWdlOiBzdHJpbmc7XHJcbiAgc2Vzc2lvbkV4cGlyZWRQYWdlOiBzdHJpbmc7XHJcbiAgbG9nb3V0UGF0aDogc3RyaW5nO1xyXG4gIGNsaWVudFNpZGVSZXF1ZXN0QmFycmluZzogYm9vbGVhbjtcclxuICBzZXNzaW9uVGltZU91dDogbnVtYmVyO1xyXG59XHJcbiIsImNvbnN0ICBmb3JnZSA9IHJlcXVpcmUoJ25vZGUtZm9yZ2UnKTtcclxuZXhwb3J0IGNsYXNzIFJzYVV0aWxzIHtcclxuICAgIHByaXZhdGUgc3RhdGljIHB1YmxpY0tleSA9IG51bGw7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBwcml2YXRlS2V5ID0gbnVsbDtcclxuICAgIGNvbnN0cnVjdG9yKCkge31cclxuICAgIHB1YmxpYyBzdGF0aWMgcHJpdmF0ZUtleUZyb21QRU0ocGVtX2ZpbGVfY29udGVudDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgUnNhVXRpbHMucHJpdmF0ZUtleSA9IGZvcmdlLnBraS5wcml2YXRlS2V5RnJvbVBlbShwZW1fZmlsZV9jb250ZW50KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgcHVibGljS2V5VG9QRU0oKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gZm9yZ2UucGtpLnB1YmxpY0tleVRvUGVtKFJzYVV0aWxzLnB1YmxpY0tleSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIHB1YmxpY0tleUZyb21QRU0ocGVtX2ZpbGVfY29udGVudDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgUnNhVXRpbHMucHVibGljS2V5ID0gZm9yZ2UucGtpLnB1YmxpY0tleUZyb21QZW0ocGVtX2ZpbGVfY29udGVudCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVuY3J5cHQobWVzc2FnZTogc3RyaW5nLCBwZW1QdWJsaWNLZXk/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChwZW1QdWJsaWNLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZvcmdlLnV0aWwuZW5jb2RlNjQoZm9yZ2UucGtpLnByaXZhdGVLZXlGcm9tUGVtKHBlbVB1YmxpY0tleSkuZW5jcnlwdChtZXNzYWdlLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2UgaWYgKFJzYVV0aWxzLnB1YmxpY0tleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9yZ2UudXRpbC5lbmNvZGU2NChSc2FVdGlscy5wdWJsaWNLZXkuZW5jcnlwdChtZXNzYWdlLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncHVibGljIGtleSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGRlY3J5cHQoY2lwaGVyVGV4dDogc3RyaW5nLCBwZW1Qcml2YXRlS2V5Pzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAocGVtUHJpdmF0ZUtleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9yZ2UucGtpLnByaXZhdGVLZXlGcm9tUGVtKHBlbVByaXZhdGVLZXkpLmRlY3J5cHQoZm9yZ2UudXRpbC5kZWNvZGU2NChjaXBoZXJUZXh0KSwgJ1JTQS1PQUVQJywge1xyXG4gICAgICAgICAgICAgICAgbWQ6IGZvcmdlLm1kLnNoYTI1Ni5jcmVhdGUoKSxcclxuICAgICAgICAgICAgICAgIG1nZjE6IHtcclxuICAgICAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMS5jcmVhdGUoKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKFJzYVV0aWxzLnByaXZhdGVLZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFJzYVV0aWxzLnByaXZhdGVLZXkuZGVjcnlwdChmb3JnZS51dGlsLmRlY29kZTY0KGNpcGhlclRleHQpLCAnUlNBLU9BRVAnLCB7XHJcbiAgICAgICAgICAgICAgICBtZDogZm9yZ2UubWQuc2hhMjU2LmNyZWF0ZSgpLFxyXG4gICAgICAgICAgICAgICAgbWdmMToge1xyXG4gICAgICAgICAgICAgICAgICAgIG1kOiBmb3JnZS5tZC5zaGExLmNyZWF0ZSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdwcml2YXRlIGtleSBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBwcml2YXRlS2V5VG9QRU0oKTogc3RyaW5nIHtcclxuICAgICAgICBjb25zdCByc2FQcml2YXRlS2V5ID0gZm9yZ2UucGtpLnByaXZhdGVLZXlUb0FzbjEoUnNhVXRpbHMucHJpdmF0ZUtleSk7XHJcbiAgICAgICAgY29uc3QgcHJpdmF0ZUtleUluZm8gPSBmb3JnZS5wa2kud3JhcFJzYVByaXZhdGVLZXkocnNhUHJpdmF0ZUtleSk7XHJcbiAgICAgICAgcmV0dXJuIGZvcmdlLnBraS5wcml2YXRlS2V5SW5mb1RvUGVtKHByaXZhdGVLZXlJbmZvKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgKiBhcyBhZXNqcyBmcm9tICdhZXMtanMnO1xyXG5pbXBvcnQgeyBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmV4cG9ydCBjbGFzcyBBZXNVdGlscyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBhZXNLZXk6IHN0cmluZyA9IG51bGw7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHt9XHJcbiAgICBwdWJsaWMgc3RhdGljIHNldEFlc0VuY3J5cHRpb25LZXkoYWVzS2V5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBBZXNVdGlscy5hZXNLZXkgPSBhZXNLZXk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGVuY3J5cHQobWVzc2FnZTogc3RyaW5nLCBhZXNLZXk/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghYWVzS2V5KSB7XHJcbiAgICAgICAgICAgIGFlc0tleSA9IEFlc1V0aWxzLmFlc0tleTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3Qga2V5ID0gYWVzanMudXRpbHMudXRmOC50b0J5dGVzKGFlc0tleSk7XHJcbiAgICAgICAgbGV0IHRleHRCeXRlcyA9IGFlc2pzLnV0aWxzLnV0ZjgudG9CeXRlcyhtZXNzYWdlKTtcclxuICAgICAgICB0ZXh0Qnl0ZXMgPSBuZXcgYWVzanMucGFkZGluZy5wa2NzNy5wYWQodGV4dEJ5dGVzKTtcclxuICAgICAgICBjb25zdCBhZXNFY2IgPSBuZXcgYWVzanMuTW9kZU9mT3BlcmF0aW9uLmVjYihrZXkpO1xyXG4gICAgICAgIGNvbnN0IGVuY3J5cHRlZEJ5dGVzID0gYWVzRWNiLmVuY3J5cHQodGV4dEJ5dGVzKTtcclxuICAgICAgICByZXR1cm4gYWVzanMudXRpbHMuaGV4LmZyb21CeXRlcyhlbmNyeXB0ZWRCeXRlcyk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGRlY3J5cHQoY2lwaGVyOiBzdHJpbmcsIGFlc0tleT86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFhZXNLZXkpIHtcclxuICAgICAgICAgICAgYWVzS2V5ID0gQWVzVXRpbHMuYWVzS2V5O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBrZXkgPSBhZXNqcy51dGlscy51dGY4LnRvQnl0ZXMoYWVzS2V5KTtcclxuICAgICAgICBjb25zdCBhZXNFY2IgPSBuZXcgYWVzanMuTW9kZU9mT3BlcmF0aW9uLmVjYihrZXkpO1xyXG4gICAgICAgIGNvbnN0IGVuY3J5cHRlZEJ5dGVzID0gYWVzanMudXRpbHMuaGV4LnRvQnl0ZXMoY2lwaGVyKTtcclxuICAgICAgICBsZXQgZGVjcnlwdGVkQnl0ZXMgPSBhZXNFY2IuZGVjcnlwdChlbmNyeXB0ZWRCeXRlcyk7XHJcbiAgICAgICAgZGVjcnlwdGVkQnl0ZXMgPSBhZXNqcy5wYWRkaW5nLnBrY3M3LnN0cmlwKGRlY3J5cHRlZEJ5dGVzKTtcclxuICAgICAgICByZXR1cm4gIGFlc2pzLnV0aWxzLnV0ZjguZnJvbUJ5dGVzKGRlY3J5cHRlZEJ5dGVzKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2VuZXJhdGVSYW5kb21BZXNLZXkobGVuZ3RoOiBudW1iZXI9IDE2KTogc3RyaW5nIHtcclxuICAgICAgICBjb25zdCBtYXA6IE1hcDxudW1iZXIsIHN0cmluZz4gPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xyXG4gICAgICAgIG1hcC5zZXQoMCwgJ2EnKS5zZXQoMSwgJ2InKS5zZXQoMiwgJ2MnKS5zZXQoMywgJ2QnKS5zZXQoNCwgJ2UnKS5zZXQoNSwgJ2YnKS5cclxuICAgICAgICBzZXQoNiwgJ2cnKS5zZXQoNywgJ2gnKS5zZXQoOCwgJ2knKS5zZXQoOSwgJ2onKS5zZXQoMTAsICdrJykuc2V0KDExLCAnbCcpLnNldCgxMiwgJ20nKS5cclxuICAgICAgICBzZXQoMTMsICduJykuc2V0KDE0LCAnbycpLnNldCgxNSwgJ3AnKS5zZXQoMTYsICdxJykuc2V0KDE3LCAncicpLlxyXG4gICAgICAgIHNldCgxOCwgJ3MnKS5zZXQoMTksICd0Jykuc2V0KDIwLCAndScpLnNldCgyMSwgJ3YnKS5zZXQoMjIsICd3Jykuc2V0KDIzLCAneCcpLnNldCgyNCwgJ3knKS5cclxuICAgICAgICBzZXQoMjUsICd6Jykuc2V0KDI2LCAnQScpLnNldCgyNywgJ0InKS5zZXQoMjgsICdDJykuc2V0KDI5LCAnRCcpLnNldCgzMCwgJ0UnKS5zZXQoMzEsICdGJykuXHJcbiAgICAgICAgc2V0KDMyLCAnRycpLnNldCgzMywgJ0gnKS5zZXQoMzQsICdJJykuc2V0KDM1LCAnSicpLnNldCgzNiwgJ0snKS5zZXQoMzcsICdMJykuc2V0KDM4LCAnTScpLlxyXG4gICAgICAgIHNldCgzOSwgJ04nKS5zZXQoNDAsICdPJykuc2V0KDQxLCAnUCcpLnNldCg0MiwgJ1EnKS5zZXQoNDMsICdSJykuc2V0KDQ0LCAnUycpLnNldCg0NSwgJ1QnKS5cclxuICAgICAgICBzZXQoNDYsICdVJykuc2V0KDQ3LCAnVicpLnNldCg0OCwgJ1cnKS5zZXQoNDksICdYJykuc2V0KDUwLCAnWScpLnNldCg1MSwgJ1onKTtcclxuICAgICAgICBsZXQga2V5ID0gJyc7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBrZXkgPSBrZXkuY29uY2F0KG1hcC5nZXQoTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNTIpKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBrZXk7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0ZVNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyKSB7IH1cclxuICBuYXZpZ2F0ZShwYXRoOiBzdHJpbmdbXSk6IHZvaWQge1xyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUocGF0aCk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb29raWVTZXJ2aWNlIH0gZnJvbSAnbmd4LWNvb2tpZS1zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09OU1RBTlRTIH0gZnJvbSAnLi9jb25zdGFudCc7XHJcbmltcG9ydCB7IEFlc1V0aWxzIH0gZnJvbSAnLi9hZXMtdXRpbHMnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSBhcyBBcHBTZXR0aW5nIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0ICogYXMgRmluZ2VycHJpbnQyIGZyb20gJ2ZpbmdlcnByaW50anMyc3luYyc7XHJcbmltcG9ydCB7IE5hdmlnYXRlU2VydmljZSB9IGZyb20gJy4vbmF2aWdhdGUuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgU2Vzc2lvblNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGhhc2hLZXk6IHN0cmluZyA9IG5ldyBGaW5nZXJwcmludDIoe2V4Y2x1ZGVBZEJsb2NrIDogdHJ1ZX0pLmdldFN5bmMoKS5mcHJpbnQuc3Vic3RyKDAsIDE2KTtcclxuICBwdWJsaWMgZ2xvYmFsczogYW55O1xyXG4gIHB1YmxpYyBzZWxlY3RlZENpcmNsZU5hbWU6IHN0cmluZztcclxuICBwdWJsaWMgc2VsZWN0ZWROZU5hbWU6IHN0cmluZztcclxuICBwdWJsaWMgc2VsZWN0ZWROZVNob3J0TmFtZTogc3RyaW5nO1xyXG4gIHB1YmxpYyBwYXJzZWROb2RlQ2lyY2xlSnNvbjogYW55O1xyXG4gIHB1YmxpYyBub2RlTmFtZUNpcmNsZTogYW55O1xyXG4gIHB1YmxpYyBzdHJ1Y3R1cmVkUmVzdHJpY3Rpb246IGFueTtcclxuICBwdWJsaWMgbW9kdWxlUmVzdHJpY3Rpb246IGFueTtcclxuICBwdWJsaWMgbWFwTmVOYW1lQ2lyY2xlTmFtZTogYW55O1xyXG4gIHB1YmxpYyBub2RlTmFtZUxpc3Q6IGFueTtcclxuICBwdWJsaWMgY29uc3RydWN0b3IocHJpdmF0ZSBjb29raWVTZXJ2aWNlOiBDb29raWVTZXJ2aWNlLCBwcml2YXRlIGFwcFNldHRpbmc6IEFwcFNldHRpbmcsIHByaXZhdGUgbmF2aWdhdGVTZXJ2aWNlOiBOYXZpZ2F0ZVNlcnZpY2UpIHt9XHJcbiAgLypcclxuICAqVGhpcyBmdW5jdGlvbiBpcyB1c2VkIHRvIGZldGNoIHN0b3JlZCBzZXNzaW9uIGRhdGFcclxuICAqL1xyXG4gIGdldFNlc3Npb25EYXRhKGtleTogc3RyaW5nID0gJ2dsb2JhbHMnKTogUmVzcG9uc2VTZXNzaW9uRGF0YSB7XHJcbiAgICBjb25zdCBjb29raWU6IFJlc3BvbnNlU2Vzc2lvbkRhdGEgPSB7fTtcclxuICAgIGxldCBkYXRhOiBKU09OO1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgICAgZGF0YSA9IEpTT04ucGFyc2UodGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKGtleSkgPyBBZXNVdGlscy5kZWNyeXB0KHRoaXMuY29va2llU2VydmljZS5nZXQoa2V5KSwgdGhpcy5oYXNoS2V5KSA6ICd7fScpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coJ2ludG8gY2xlYXJpbmcgc2Vzc2lvbicpO1xyXG4gICAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgICAgZGF0YSA9IHt9IGFzIEpTT047XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZGF0YSBhcyBSZXNwb25zZVNlc3Npb25EYXRhO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGdldEFlc0tleShrZXk6IHN0cmluZyA9ICdhZXNLZXknKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGV4cGlyeVRpbWU6IG51bWJlciA9IHRoaXMuZ2V0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgaWYgKGV4cGlyeVRpbWUgPiBuZXcgRGF0ZSgpLmdldFRpbWUoKSkge1xyXG4gICAgICByZXR1cm4gdGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKGtleSkgPyBBZXNVdGlscy5kZWNyeXB0KHRoaXMuY29va2llU2VydmljZS5nZXQoa2V5KSwgdGhpcy5oYXNoS2V5KSA6IG51bGw7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFNlc3Npb25EYXRhKHNlc3Npb25EYXRhOiBSZXF1ZXN0U2Vzc2lvbkRhdGEsIGtleSA9ICdnbG9iYWxzJyApOiB2b2lkIHtcclxuICAgIGNvbnN0IGRhdGEgPSB7fTtcclxuICAgIGNvbnN0IHVzZXJJbmZvcm1hdGlvbiA9IHtcclxuICAgICAgICBjdXJyZW50VXNlcjoge1xyXG4gICAgICAgICAgdXNlck5hbWU6IHNlc3Npb25EYXRhLnVzZXJOYW1lLFxyXG4gICAgICAgICAgYXBwRGF0YTogc2Vzc2lvbkRhdGEuYXBwRGF0YSxcclxuICAgICAgICAgIG5vZGVOYW1lQ2lyY2xlOiBzZXNzaW9uRGF0YS5ub2RlTmFtZUNpcmNsZVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBpZiAoc2Vzc2lvbkRhdGEubmVOYW1lQ2lyY2xlTmFtZSkge1xyXG4gICAgICB1c2VySW5mb3JtYXRpb24uY3VycmVudFVzZXJbJ25lTmFtZUNpcmNsZU5hbWUnXSA9IHNlc3Npb25EYXRhLm5lTmFtZUNpcmNsZU5hbWU7XHJcbiAgICB9XHJcbiAgICBpZiAoc2Vzc2lvbkRhdGEuYWVzS2V5KSB7XHJcbiAgICAgIGRhdGFbJ2Flc0tleSddID0gc2Vzc2lvbkRhdGEuYWVzS2V5O1xyXG4gICAgfVxyXG4gICAgZGF0YVtrZXldID0gdXNlckluZm9ybWF0aW9uO1xyXG4gICAgdGhpcy5jb29raWVTZXJ2aWNlLnNldChrZXksIEFlc1V0aWxzLmVuY3J5cHQoSlNPTi5zdHJpbmdpZnkoZGF0YSksIHRoaXMuaGFzaEtleSkpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGNsZWFyU2Vzc2lvbkRhdGEoLi4uYXJnczogc3RyaW5nW10pOiB2b2lkIHtcclxuICAgIGlmICggYXJncy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGZvciAoY29uc3QgYXJnIG9mIGFyZ3MpIHtcclxuICAgICAgICB0aGlzLmNvb2tpZVNlcnZpY2UuZGVsZXRlKGFyZyk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuY29va2llU2VydmljZS5kZWxldGVBbGwoKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgcHV0RGF0ZUZvckNvb2tpZUV4cGlyeSh0aW1lU3RhbXA/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIGxldCBzZXNzaW9uVGltZTpudW1iZXI9NjAwMDAwO1xyXG4gICAgaWYodGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKSlcclxuICAgIHtcclxuICAgICAgc2Vzc2lvblRpbWU9dGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uVGltZU91dDtcclxuICAgIH1cclxuICAgIGlmICghdGltZVN0YW1wKSB7XHJcbiAgICAgIHRoaXMuY29va2llU2VydmljZS5zZXQoJ2V4cGlyeVRpbWUnLCAobmV3IERhdGUoKS5nZXRUaW1lKCkgKyBzZXNzaW9uVGltZSkudG9TdHJpbmcoKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCdleHBpcnlUaW1lJywgdGltZVN0YW1wKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXREYXRlRm9yQ29va2llRXhwaXJ5KCk6IG51bWJlciB7XHJcbiAgICBsZXQgc2Vzc2lvblRpbWU6bnVtYmVyPTYwMDAwMDtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpXHJcbiAgICB7XHJcbiAgICAgIHNlc3Npb25UaW1lPXRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkuc2Vzc2lvblRpbWVPdXQ7XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5jb29raWVTZXJ2aWNlLmNoZWNrKCdleHBpcnlUaW1lJykpIHtcclxuICAgICByZXR1cm4gTnVtYmVyLnBhcnNlSW50KHRoaXMuY29va2llU2VydmljZS5nZXQoJ2V4cGlyeVRpbWUnKSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCdleHBpcnlUaW1lJywgKG5ldyBEYXRlKCkuZ2V0VGltZSgpICsgc2Vzc2lvblRpbWUpLnRvU3RyaW5nKCkpO1xyXG4gICAgcmV0dXJuIChuZXcgRGF0ZSgpLmdldFRpbWUoKSArIHNlc3Npb25UaW1lKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBzZXRVc2VyVG9rZW5EYXRhKHVzZXJUb2tlbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICB0aGlzLmNvb2tpZVNlcnZpY2Uuc2V0KCd1c2VyVG9rZW4nLCBBZXNVdGlscy5lbmNyeXB0KHVzZXJUb2tlbiwgdGhpcy5oYXNoS2V5KSk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0VXNlclRva2VuRGF0YSgpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLmNvb2tpZVNlcnZpY2UuY2hlY2soJ3VzZXJUb2tlbicpID8gQWVzVXRpbHMuZGVjcnlwdCh0aGlzLmNvb2tpZVNlcnZpY2UuZ2V0KCd1c2VyVG9rZW4nKSwgdGhpcy5oYXNoS2V5KSA6IG51bGw7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIHNldFNlc3Npb25EYXRhRm9yTW9kdWxlUmVzdHJpY3Rpb24obW9kdWxlUmVzdHJpY3Rpb246IEpTT04sIGtleTogc3RyaW5nID0gJ21vZHVsZVJlc3RyaWN0aW9uJyk6IHZvaWQge1xyXG4gICAgaWYgKHR5cGVvZihTdG9yYWdlKSkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIEpTT04uc3RyaW5naWZ5KG1vZHVsZVJlc3RyaWN0aW9uKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZygnTG9jYWwgU3RvcmdhZSBub3QgYXZhaWxhYmxlJyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0U2Vzc2lvbkRhdGFGb3JNb2R1bGVSZXN0cmljdGlvbihrZXk6IHN0cmluZyA9ICdtb2R1bGVSZXN0cmljdGlvbicpOiBKU09OIHtcclxuICAgIGNvbnN0IGV4cGlyeVRpbWU6IG51bWJlciA9IHRoaXMuZ2V0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgaWYgKGV4cGlyeVRpbWUgPiBuZXcgRGF0ZSgpLmdldFRpbWUoKSkge1xyXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA6ICd7fScpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5jbGVhclNlc3Npb25EYXRhQW5kR290b1Nlc3Npb25FeHBpcmVQYWdlKCk7XHJcbiAgICByZXR1cm4gSlNPTi5wYXJzZSgne30nKTtcclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBzZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihzdHJ1Y3R1cmVkUmVzdHJpY3Rpb246IEpTT04sIGtleTogc3RyaW5nID0gJ3N0cnVjdHVyZWRSZXN0cmljdGlvbicpOiB2b2lkIHtcclxuICAgIGlmICh0eXBlb2YoU3RvcmFnZSkpIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeShzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdMb2NhbCBTdG9yZ2FlIG5vdCBhdmFpbGFibGUnKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBnZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihrZXk6IHN0cmluZyA9ICdzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24nKTogSlNPTiB7XHJcbiAgICBjb25zdCBleHBpcnlUaW1lOiBudW1iZXIgPSB0aGlzLmdldERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgIGlmIChleHBpcnlUaW1lID4gbmV3IERhdGUoKS5nZXRUaW1lKCkpIHtcclxuICAgICAgcmV0dXJuIEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KSA/IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgOiAne30nKTtcclxuICAgIH1cclxuICAgIHRoaXMuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgcmV0dXJuIEpTT04ucGFyc2UoJ3t9Jyk7XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgc2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24obm9kZUNpcmNsZVJlc3RyaWN0aW9uOiBKU09OLCBrZXk6IHN0cmluZyA9ICdub2RlQ2lyY2xlUmVzdHJpY3Rpb24nKTogdm9pZCB7XHJcbiAgICBpZiAodHlwZW9mKFN0b3JhZ2UpKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkobm9kZUNpcmNsZVJlc3RyaWN0aW9uKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZygnTG9jYWwgU3RvcmdhZSBub3QgYXZhaWxhYmxlJyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qXHJcbiAgKlxyXG4gICovXHJcbiAgZ2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24oa2V5OiBzdHJpbmcgPSAnbm9kZUNpcmNsZVJlc3RyaWN0aW9uJyk6IEpTT04ge1xyXG4gICAgY29uc3QgZXhwaXJ5VGltZTogbnVtYmVyID0gdGhpcy5nZXREYXRlRm9yQ29va2llRXhwaXJ5KCk7XHJcbiAgICBpZiAoZXhwaXJ5VGltZSA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpKSB7XHJcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSkgPyBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpIDogJ3t9Jyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTtcclxuICAgIHJldHVybiBKU09OLnBhcnNlKCd7fScpO1xyXG4gIH1cclxuICAvKlxyXG4gICpcclxuICAqL1xyXG4gIGNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvU2Vzc2lvbkV4cGlyZVBhZ2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGEoKTtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpIHtcclxuICAgICAgY29uc29sZS5sb2codGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2UpO1xyXG4gICAgICB0aGlzLm5hdmlnYXRlU2VydmljZS5uYXZpZ2F0ZShbdGhpcy5hcHBTZXR0aW5nLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2VdKTtcclxuICAgIH1cclxuICB9XHJcbiAgLypcclxuICAqXHJcbiAgKi9cclxuICBjbGVhclNlc3Npb25EYXRhQW5kR290b0xvZ291dFBhZ2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICB0aGlzLmNsZWFyU2Vzc2lvbkRhdGEoKTtcclxuICAgIGlmKHRoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkpIHtcclxuICAgICAgdGhpcy5uYXZpZ2F0ZVNlcnZpY2UubmF2aWdhdGUoW3RoaXMuYXBwU2V0dGluZy5nZXRDb25maWd1cmF0aW9uKCkubG9nb3V0UGF0aF0pO1xyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIHJlc2V0VmFyaWFibGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5nbG9iYWxzID0gbnVsbDtcclxuICAgIHRoaXMuc2VsZWN0ZWRDaXJjbGVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2VsZWN0ZWROZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZWxlY3RlZE5lU2hvcnROYW1lID0gbnVsbDtcclxuICAgIHRoaXMucGFyc2VkTm9kZUNpcmNsZUpzb24gPSBudWxsO1xyXG4gICAgdGhpcy5ub2RlTmFtZUNpcmNsZSA9IG51bGw7XHJcbiAgICB0aGlzLnN0cnVjdHVyZWRSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICB0aGlzLm1vZHVsZVJlc3RyaWN0aW9uID0gbnVsbDtcclxuICAgIHRoaXMubWFwTmVOYW1lQ2lyY2xlTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLm5vZGVOYW1lTGlzdCA9IFtdO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0U2Vzc2lvbkRhdGEge1xyXG4gIHVzZXJOYW1lOiBzdHJpbmc7XHJcbiAgYXBwRGF0YTogSlNPTjtcclxuICBub2RlTmFtZUNpcmNsZTogc3RyaW5nO1xyXG4gIGFlc0tleT86IHN0cmluZztcclxuICBuZU5hbWVDaXJjbGVOYW1lPzogSlNPTjtcclxufVxyXG5leHBvcnQgaW50ZXJmYWNlIFJlc3BvbnNlU2Vzc2lvbkRhdGEge1xyXG4gIGdsb2JhbHM/OiB7XHJcbiAgICBjdXJyZW50VXNlcjoge1xyXG4gICAgICB1c2VyTmFtZT86IHN0cmluZztcclxuICAgICAgYXBwRGF0YT86IEpTT047XHJcbiAgICAgIG5vZGVOYW1lQ2lyY2xlPzogc3RyaW5nO1xyXG4gICAgICBuZU5hbWVDaXJjbGVOYW1lPzogSlNPTjtcclxuICAgIH07XHJcbiAgfTtcclxuICBhZXNLZXk/OiBzdHJpbmc7XHJcbn1cclxuIiwiaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tzIH0gZnJvbSAnLi9pYW0uc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuZXhwb3J0IGNsYXNzIFdlYlNvY2tldENhbGxiYWNrQ2xhc3MgaW1wbGVtZW50cyBXZWJTb2NrZXRDYWxsYmFja3Mge1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25NZXNzYWdlU3ViamVjdDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25PcGVuU3ViamVjdDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgcHJpdmF0ZSBzdGF0aWMgb25DbG9zZVN1YmplY3Q6IFN1YmplY3Q8YW55PiA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgIHByaXZhdGUgc3RhdGljIG9uRXJyb3JTdWJqZWN0OiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICBwcml2YXRlIHN0YXRpYyBvbldlYnNvY2tldFJlY29ubmVjdFN1YmplY3Q6IFN1YmplY3Q8dm9pZD4gPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0T25NZXNzYWdlT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc3RhdGljIGdldE9uT3Blbk9ic2VydmFibGUoKTogT2JzZXJ2YWJsZTxNZXNzYWdlRXZlbnQ+IHtcclxuICAgICAgICByZXR1cm4gV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbkNsb3NlT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uQ2xvc2VTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbkVycm9yT2JzZXJ2YWJsZSgpOiBPYnNlcnZhYmxlPE1lc3NhZ2VFdmVudD4ge1xyXG4gICAgICAgIHJldHVybiBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uRXJyb3JTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRPbldlYnNvY2tldFJlY29ubmVjdE9ic2VydmFibGUoKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICAgICAgcmV0dXJuIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25XZWJzb2NrZXRSZWNvbm5lY3RTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXRpYyByZUluaXRpYWxpemVPYnNlcnZhYmxlcygpOiB2b2lkIHtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QgPSBuZXcgU3ViamVjdDxNZXNzYWdlRXZlbnQ+KCk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0ICA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uQ2xvc2VTdWJqZWN0ICA9IG5ldyBTdWJqZWN0PE1lc3NhZ2VFdmVudD4oKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uRXJyb3JTdWJqZWN0ID0gbmV3IFN1YmplY3Q8TWVzc2FnZUV2ZW50PigpO1xyXG4gICAgfVxyXG4gICAgb25NZXNzYWdlKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uTWVzc2FnZVN1YmplY3QubmV4dChldmVudCk7XHJcbiAgICB9XHJcbiAgICBvbkNsb3NlKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnd2Vic29ja2V0IGNsb3NlZCcpO1xyXG4gICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3Mub25DbG9zZVN1YmplY3QubmV4dChldmVudCk7XHJcbiAgICB9XHJcbiAgICBvbkVycm9yKGV2ZW50OiBNZXNzYWdlRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbkVycm9yU3ViamVjdC5uZXh0KGV2ZW50KTtcclxuICAgIH1cclxuICAgIG9uT3BlbihldmVudDogTWVzc2FnZUV2ZW50LCB3ZWJzb2NrZXQ6IFdlYlNvY2tldCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd3ZWJzb2NrZXQgb3BlbmVkJyk7XHJcbiAgICAgICAgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcy5vbk9wZW5TdWJqZWN0Lm5leHQoZXZlbnQpO1xyXG4gICAgfVxyXG4gICAgb25SZWNvbm5lY3QoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3dlYnNvY2tldCByZS1jb25uZWN0ZWQnKTtcclxuICAgICAgICBXZWJTb2NrZXRDYWxsYmFja0NsYXNzLm9uV2Vic29ja2V0UmVjb25uZWN0U3ViamVjdC5uZXh0KCk7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gXCJAYW5ndWxhci9jb21tb24vaHR0cFwiO1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCdcbn0pXG5leHBvcnQgY2xhc3MgTWVzc2FnZU1hcHBpbmcge1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cENsaWVudDogSHR0cENsaWVudCkgeyB9XG4gIHByaXZhdGUgc3RhdGljIG1lc3NhZ2VNYXA6IE1hcDxudW1iZXIsIHN0cmluZz4gPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nPigpO1xuICBwdWJsaWMgc3RhdGljIGdldE1lc3NhZ2UoY29kZTogbnVtYmVyKTogYW55IHtcbiAgICAgIHJldHVybiBNZXNzYWdlTWFwcGluZy5tZXNzYWdlTWFwLmhhcyhjb2RlKSA/IE1lc3NhZ2VNYXBwaW5nLm1lc3NhZ2VNYXAuZ2V0KGNvZGUpIDogJ3Vua25vd24gZXJyb3IgY29kZSByZWNlaXZlZCc7XG4gIH1cbiAgcHVibGljIGxvYWRNZXNhZ2VNYXAoZmlsZVBhdGg6c3RyaW5nKTogdm9pZCB7XG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEpTT04+KGZpbGVQYXRoKS50b1Byb21pc2UoKS50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgIG5ldyBNYXA8c3RyaW5nLHN0cmluZz4oT2JqZWN0LmVudHJpZXMocmVzcG9uc2UpKS5mb3JFYWNoKCh2YWx1ZTogc3RyaW5nLCBrZXk6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgTWVzc2FnZU1hcHBpbmcubWVzc2FnZU1hcC5zZXQoTnVtYmVyLnBhcnNlSW50KGtleSksdmFsdWUpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KS5jYXRjaCgocmVzcG9uc2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYGNvdWxkIG5vdCBsb2FkIGNvbmZpZ3VyYXRpb24gZmlsZSBlcnJvcjogXFxuICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpfWApO1xuICAgICAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25Jbml0LCBPbkRlc3Ryb3ksIEhvc3RMaXN0ZW5lciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IENPTlNUQU5UUyB9IGZyb20gJy4vY29uc3RhbnQnO1xyXG5pbXBvcnQgeyBIdHRwSGVhZGVycywgSHR0cENsaWVudCwgSHR0cEVycm9yUmVzcG9uc2UsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgcmV0cnksIGNhdGNoRXJyb3IsIGRlbGF5IH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyB0aHJvd0Vycm9yLCBPYnNlcnZhYmxlLCBTdWJzY3JpYmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJzYVV0aWxzIH0gZnJvbSAnLi9yc2EtdXRpbHMnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSwgUmVzcG9uc2VTZXNzaW9uRGF0YSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgKiBhcyBmb3JnZSBmcm9tICdub2RlLWZvcmdlJztcclxuaW1wb3J0IHsgQWVzVXRpbHMgfSBmcm9tICcuL2Flcy11dGlscyc7XHJcbmltcG9ydCB7IFdlYlNvY2tldENhbGxiYWNrQ2xhc3MgfSBmcm9tICcuL3dlYi1zb2NrZXQtY2FsbGJhY2tzLWNsYXNzJztcclxuaW1wb3J0IHsgTWVzc2FnZU1hcHBpbmcgfSBmcm9tICcuL21lc3NhZ2UtbWFwcGluZyc7XHJcbmltcG9ydCB7IFdlYlNvY2tldENhbGxiYWNrcyB9IGZyb20gJy4vaWFtLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQ2FjaGVNYW5hZ2VyU2VydmljZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICBwdWJsaWMgZW5jcnlwdGlvbktleTogYW55O1xyXG4gIHB1YmxpYyB0aW1lQWRqdXN0bWVudDogbnVtYmVyO1xyXG4gIHB1YmxpYyBjaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZTogYW55O1xyXG4gIHB1YmxpYyBuZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjogYW55O1xyXG4gIHB1YmxpYyBtYXBOZVNob3J0TmFtZUZ1bGxOYW1lOiBhbnk7XHJcbiAgcHVibGljIHNob3J0Q29kZVRvSWRNYXA6IGFueTtcclxuICBwdWJsaWMgbm9kZVRvSWRNYXA6IGFueTtcclxuICBwdWJsaWMgY2lyY2xlVG9JZE1hcDogYW55O1xyXG4gIHB1YmxpYyBPcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmc6IGFueTtcclxuICBwdWJsaWMgbG9naW5Vc2VySW1hZ2U6IGFueTtcclxuICBwdWJsaWMgd2Vic29ja2V0OiBXZWJTb2NrZXQ7XHJcbiAgcHVibGljIFhfU09DS0VUX0FERFJFU1M6IHN0cmluZztcclxuICBwdWJsaWMgWF9VU0VSTkFNRTogc3RyaW5nO1xyXG4gIHB1YmxpYyBTT0NLRVRfSVA6IHN0cmluZztcclxuICBwdWJsaWMgcmVzb2x2ZUZuOiAoKSA9PiB2b2lkO1xyXG4gIHB1YmxpYyByZWplY3RGbjogKCkgPT4gdm9pZDtcclxuICBwdWJsaWMgd2Vic29ja2V0T3BlblByb21pc2U6IFByb21pc2U8dm9pZD4gPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICB0aGlzLnJlc29sdmVGbiA9IHJlc29sdmU7XHJcbiAgICB0aGlzLnJlamVjdEZuID0gcmVqZWN0O1xyXG4gIH0pO1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgYXBwQ29uZmlndXJhdGlvbjogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIHByaXZhdGUgaHR0cENsaWVudDogSHR0cENsaWVudCxcclxuICAgIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLCBwcml2YXRlIGxvY2F0aW9uOiBMb2NhdGlvbixwcml2YXRlIG1lc3NhZ2VNYXBwaW5nOk1lc3NhZ2VNYXBwaW5nKSB7IH1cclxuICBuZ09uSW5pdCgpIHsgfVxyXG4gIG5nT25EZXN0cm95KCkge1xyXG4gICAgaWYgKHRoaXMud2Vic29ja2V0KSB7XHJcbiAgICAgIHRoaXMud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGdldEF1dGhLZXkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRhdXRoa2V5Jyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHsgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsICdvcGVyYXRpb24nOiAnZ2V0YXV0aGtleScgfSksXHJcbiAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IHtcclxuICAgICAgICAgIHBlbUZpbGU6IHN0cmluZ1xyXG4gICAgICAgIH1cclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxIdHRwUmVzcG9uc2U8UmVzcG9uc2U+Pih1cmwsIGh0dHBPcHRpb25zKVxyXG4gICAgICAgIC5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5ib2R5LnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICBSc2FVdGlscy5wdWJsaWNLZXlGcm9tUEVNKHJlc3AuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEucGVtRmlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZW5jcnlwdGlvbktleSA9IHJlc3AuYm9keS5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIGNvbnN0IHNlcnZlclRpbWUgPSByZXNwLmhlYWRlcnMuaGFzKCdEYXRlJykgPyBuZXcgRGF0ZShyZXNwLmhlYWRlcnMuZ2V0KCdEYXRlJykpLmdldFRpbWUoKSA6IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xyXG4gICAgICAgICAgICBjb25zdCBjbGllbnRUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgIHRoaXMudGltZUFkanVzdG1lbnQgPSBzZXJ2ZXJUaW1lIC0gY2xpZW50VGltZTtcclxuICAgICAgICAgICAgLy90aGlzLnNlc3Npb25TZXJ2aWNlLnB1dERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coJ2ZldGNoaW5nIHJzYSBrZXkgZmFpbGVkJyk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXROb2RlU2hvcnROYW1lRnVsbE5hbWVKc29uKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCkuY29uY2F0KCc/b3BlcmF0aW9uPWdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZScpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXROb2RlU2hvcnROYW1lRnVsbE5hbWUnXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgaW50ZXJmYWNlIFJlc3BvbnNlIHtcclxuICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgIEFwcERhdGE6IEpTT04sXHJcbiAgICAgICAgdHlwZTogc3RyaW5nLFxyXG4gICAgICAgIGh0dHBzdGF0dXNjb2RlOiBzdHJpbmcsXHJcbiAgICAgICAgb3BTdGF0dXNDb2RlOiBzdHJpbmdcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cENsaWVudC5nZXQ8UmVzcG9uc2U+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgIGlmIChyZXNwLnN0YXR1c0NvZGUudHlwZSkge1xyXG4gICAgICAgICAgICB0aGlzLm5lU2hvcnROYW1lRnVsbE5hbWVKc29uID0ge1xyXG4gICAgICAgICAgICAgICdOb2RlTmFtZSc6IHJlc3Auc3RhdHVzQ29kZS5BcHBEYXRhXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldENpcmNsZVNob3J0TmFtZUZ1bGxOYW1lSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZScpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZSdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2lyY2xlRnVsbE5hbWVKc29uUmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgICAgQ2lyY2xlTmFtZTogcmVzcC5zdGF0dXNDb2RlLkFwcERhdGFcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0TW9kdWxlVG9JZEpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0U2hvcnRDb2RlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRTaG9ydENvZGVUb0lkTWFwJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG9ydENvZGVUb0lkTWFwID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVUb0lkSnNvbigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IENPTlNUQU5UUy5QUk9UT0NPTC5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5pcClcclxuICAgICAgLmNvbmNhdCgnOicpLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnBvcnQudG9TdHJpbmcoKSlcclxuICAgICAgLmNvbmNhdChDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQpLmNvbmNhdCgnP29wZXJhdGlvbj1nZXROb2RlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXROb2RlVG9JZE1hcCdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZVRvSWRNYXAgPSByZXNwLnN0YXR1c0NvZGUuQXBwRGF0YTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVqZWN0KHJlc3ApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Q2lyY2xlVG9JZEpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0Q2lyY2xlVG9JZE1hcCcpO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRDaXJjbGVUb0lkTWFwJ1xyXG4gICAgICB9KVxyXG4gICAgfTtcclxuICAgIGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgICAgIHN0YXR1c0NvZGU6IHtcclxuICAgICAgICBBcHBEYXRhOiBKU09OLFxyXG4gICAgICAgIHR5cGU6IHN0cmluZyxcclxuICAgICAgICBodHRwc3RhdHVzY29kZTogc3RyaW5nLFxyXG4gICAgICAgIG9wU3RhdHVzQ29kZTogc3RyaW5nXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PFJlc3BvbnNlPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzcC5zdGF0dXNDb2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5jaXJjbGVUb0lkTWFwID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZUpzb24oKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCB1cmwgPSBDT05TVEFOVFMuUFJPVE9DT0wuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuaXApXHJcbiAgICAgIC5jb25jYXQoJzonKS5jb25jYXQodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wb3J0LnRvU3RyaW5nKCkpXHJcbiAgICAgIC5jb25jYXQoQ09OU1RBTlRTLkFDQ0VTU19DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0T3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlJyk7XHJcbiAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgaGVhZGVyczogbmV3IEh0dHBIZWFkZXJzKHtcclxuICAgICAgICAncHJvamVjdCc6IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdCxcclxuICAgICAgICAnb3BlcmF0aW9uJzogJ2dldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZSdcclxuICAgICAgfSlcclxuICAgIH07XHJcbiAgICBpbnRlcmZhY2UgUmVzcG9uc2Uge1xyXG4gICAgICBzdGF0dXNDb2RlOiB7XHJcbiAgICAgICAgQXBwRGF0YTogSlNPTixcclxuICAgICAgICB0eXBlOiBzdHJpbmcsXHJcbiAgICAgICAgaHR0cHN0YXR1c2NvZGU6IHN0cmluZyxcclxuICAgICAgICBvcFN0YXR1c0NvZGU6IHN0cmluZ1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxSZXNwb25zZT4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3Auc3RhdHVzQ29kZS50eXBlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nID0gcmVzcC5zdGF0dXNDb2RlLkFwcERhdGE7XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXNwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICByZWplY3QoZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldFBhdGhOYW1lKCkge1xyXG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbiAmJiB3aW5kb3cubG9jYXRpb24uaGFzaCAmJiB3aW5kb3cubG9jYXRpb24uaGFzaC5zdWJzdHIoMSk7XHJcbn1cclxuICBvblN0YXJ0dXBSb3V0ZUNoYW5nZShldmVudCk6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscztcclxuICAgICAgaWYgKCF0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMpIHtcclxuICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB7fTtcclxuICAgICAgfVxyXG4gICAgICBpZiAodGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5sb2dpblBhZ2UgJiYgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5ub25SZXN0cmljdGVkUGFnZXNcclxuICAgICAgICAmJiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbikge1xyXG4gICAgICAgIGxldCBwYXRoTmFtZSA9IHRoaXMubG9jYXRpb24ucGF0aCgpO1xyXG4gICAgICAgIGlmKHBhdGhOYW1lLmluY2x1ZGVzKFwiP1wiKSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXRoTmFtZT1wYXRoTmFtZS5zcGxpdChcIj9cIilbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlc3RyaWN0ZWRQYWdlOiBib29sZWFuID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5ub25SZXN0cmljdGVkUGFnZXMuaW5kZXhPZihwYXRoTmFtZSk9PT0tMTtcclxuICAgICAgICBjb25zdCBsb2dnZWRJbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscy5jdXJyZW50VXNlcjtcclxuICAgICAgIGlmIChyZXN0cmljdGVkUGFnZSAmJiAhbG9nZ2VkSW4pIHtcclxuICAgICAgICAgIHRoaXMubG9jYXRpb24uZ28odGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5sb2dpblBhZ2UpO1xyXG4gICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobG9nZ2VkSW4pIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5zZXNzaW9uU2VydmljZS5tb2R1bGVSZXN0cmljdGlvbikge1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubW9kdWxlUmVzdHJpY3Rpb24gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhRm9yTW9kdWxlUmVzdHJpY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2Uuc3RydWN0dXJlZFJlc3RyaWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhRm9yU3RydWN0dXJlZFJlc3RyaWN0aW9uKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKCF0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5wYXJzZWROb2RlQ2lyY2xlSnNvbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGFGb3JOb2RlQ2lyY2xlUmVzdHJpY3Rpb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBsb2dpblBhZ2UgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlcy5pbmRleE9mKHBhdGhOYW1lKSE9LTE7XHJcbiAgICAgICAgICAgIGlmIChsb2dpblBhZ2UpIHtcclxuICAgICAgICAgICAgICB0aGlzLmxvY2F0aW9uLmdvKHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkuZGVmYXVsdFBhZ2VBZnRlckxvZ2luKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm9wZW5XZWJTb2NrZXRDaGFubmVsKG5ldyBXZWJTb2NrZXRDYWxsYmFja0NsYXNzKCkpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBjYWxsV2hlbkNvbmZpZ0xvYWRzKCkge1xyXG4gICAgY29uc3QgdXNlckRldGFpbHMgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHM7XHJcbiAgICBjb25zdCBhZXNLZXkgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuYWVzS2V5O1xyXG4gICAgdGhpcy5tZXNzYWdlTWFwcGluZy5sb2FkTWVzYWdlTWFwKCdhc3NldHMvY29uZmlndXJhdGlvbi9tZXNzYWdlbWFwcGluZy5qc29uJyk7XHJcbiAgICBpZiAoYWVzS2V5KSB7XHJcbiAgICAgIEFlc1V0aWxzLnNldEFlc0VuY3J5cHRpb25LZXkoYWVzS2V5KTtcclxuICAgIH1cclxuICAgIGlmICh1c2VyRGV0YWlscyAmJiB1c2VyRGV0YWlscy5jdXJyZW50VXNlciAmJiB1c2VyRGV0YWlscy5jdXJyZW50VXNlci51c2VybmFtZSAmJiAhdGhpcy5sb2dpblVzZXJJbWFnZSkge1xyXG4gICAgICBpbnRlcmZhY2UgVXNlckltYWdlUmVzcG9uc2Uge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGJvb2xlYW47XHJcbiAgICAgICAgQXBwRGF0YToge1xyXG4gICAgICAgICAgdXNlckluZm86IHtcclxuICAgICAgICAgICAgdXNlckltYWdlOiBzdHJpbmc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmdldFVzZXJJbWFnZTxVc2VySW1hZ2VSZXNwb25zZT4odXNlckRldGFpbHMuY3VycmVudFVzZXIudXNlcm5hbWUpLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgIHRoaXMubG9naW5Vc2VySW1hZ2UgPSByZXNwb25zZS5BcHBEYXRhLnVzZXJJbmZvLnVzZXJJbWFnZSA/IHJlc3BvbnNlLkFwcERhdGEudXNlckluZm8udXNlckltYWdlIDogJ25vSW1hZ2UnO1xyXG4gICAgICAgIH1cclxuICAgICAgfSwgZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuICBnZXRVc2VySW1hZ2U8VD4odXNlck5hbWU6IHN0cmluZyk6IFByb21pc2U8VD4ge1xyXG4gICAgY29uc3QgdXJsID0gQ09OU1RBTlRTLlBST1RPQ09MLmNvbmNhdCh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwKVxyXG4gICAgICAuY29uY2F0KCc6JykuY29uY2F0KHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydC50b1N0cmluZygpKVxyXG4gICAgICAuY29uY2F0KENPTlNUQU5UUy5JREVOVElUWV9DT05URVhUKS5jb25jYXQoJz9vcGVyYXRpb249Z2V0VXNlckltYWdlJnVzZXJOYW1lPScpLmNvbmNhdCh1c2VyTmFtZSk7XHJcbiAgICBjb25zdCB1c2VyVG9rZW4gPSBgJHt1c2VyTmFtZX0tdGhpcy5zZXNzaW9uU2VydmljZS5nZXRVc2VyVG9rZW5EYXRhKClgO1xyXG4gICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgIGhlYWRlcnM6IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgICAgJ3Byb2plY3QnOiB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3QsXHJcbiAgICAgICAgJ29wZXJhdGlvbic6ICdnZXRVc2VySW1hZ2UnLFxyXG4gICAgICAgICd1c2VyVG9rZW4nOiBgJHt1c2VyTmFtZX0tJHt0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFVzZXJUb2tlbkRhdGEoKX1gXHJcbiAgICAgIH0pXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxUPih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgIC5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgICByZXNvbHZlKHJlc3ApO1xyXG4gICAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICAgIHJlamVjdChlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgb3BlbldlYlNvY2tldENoYW5uZWwod2Vic29ja2V0Q2FsbGJhY2tzOiBXZWJTb2NrZXRDYWxsYmFja3MpOiBPYnNlcnZhYmxlPHZvaWQ+IHtcclxuICAgIGxldCByZXNwb25zZVNlc3Npb25EYXRhOiBSZXNwb25zZVNlc3Npb25EYXRhID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpO1xyXG4gICAgY29uc3QgcHJvdG9jb2wgPSBDT05TVEFOVFMuV0VCU09DS0VUX1BST1RPQ09MO1xyXG4gICAgY29uc3QgaXAgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmlwO1xyXG4gICAgY29uc3QgcG9ydCA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucG9ydDtcclxuICAgIGNvbnN0IHdlYnNvY2tldFBvcnQgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLndlYnNvY2tldFBvcnQ7XHJcbiAgICBjb25zdCBwcm9qZWN0ID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0O1xyXG4gICAgY29uc3QgdXNlck5hbWUgPSByZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWU7XHJcbiAgICBjb25zdCBiYXNlNjR0b2tlbiA9IGZvcmdlLnV0aWwuZW5jb2RlNjQoYCR7dXNlck5hbWV9LSR7dGhpcy5zZXNzaW9uU2VydmljZS5nZXRVc2VyVG9rZW5EYXRhKCl9YCk7XHJcbiAgICBjb25zdCBxdWVyeVN0cmluZyA9IGA/b3BlcmF0aW9uPWF1dGhlbnRpY2F0ZVdlYlNvY2tldCZwcm9qZWN0PSR7cHJvamVjdH0mdXNlclRva2VuPSR7YmFzZTY0dG9rZW59JnByb2plY3RVcmw9JHtpcH06JHtwb3J0fWA7XHJcbiAgICBjb25zdCB3ZWJTb2NrZXRVUkwgPSBgJHtwcm90b2NvbH0ke2lwfToke3dlYnNvY2tldFBvcnR9L3dlYnNvY2tldCR7cXVlcnlTdHJpbmd9YDtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTx2b2lkPihvYnNlcnZlID0+IHtcclxuICAgICAgbGV0IGZsYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB0aGlzLndlYnNvY2tldCA9IG5ldyBXZWJTb2NrZXQod2ViU29ja2V0VVJMKTtcclxuICAgICAgICBpZiAod2Vic29ja2V0Q2FsbGJhY2tzLm9uT3Blbikge1xyXG4gICAgICAgICAgdGhpcy53ZWJzb2NrZXQub25vcGVuID0gKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZWJzb2NrZXRDYWxsYmFja3Mub25PcGVuKCk7XHJcbiAgICAgICAgICAgIGNvbnN0IG1hcDogTWFwPHN0cmluZywgc3RyaW5nPiA9IHRoaXMuZ2V0Q29va2llcygpO1xyXG4gICAgICAgICAgICB0aGlzLlhfU09DS0VUX0FERFJFU1MgPSBtYXAuaGFzKCdYLVNPQ0tFVC1BRERSRVNTJykgPyBtYXAuZ2V0KCdYLVNPQ0tFVC1BRERSRVNTJykgOiBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLlhfVVNFUk5BTUUgPSBtYXAuaGFzKCdYLVVTRVJOQU1FJykgPyBtYXAuZ2V0KCdYLVVTRVJOQU1FJykgOiBudWxsO1xyXG4gICAgICAgICAgICB0aGlzLlNPQ0tFVF9JUCA9IG1hcC5oYXMoJ3NvY2tldElwJykgPyBtYXAuZ2V0KCdzb2NrZXRJcCcpIDogbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5yZXNvbHZlRm4oKTtcclxuICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgICAgICAgIGZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAod2Vic29ja2V0Q2FsbGJhY2tzLm9uQ2xvc2UpIHtcclxuICAgICAgICAgIHRoaXMud2Vic29ja2V0Lm9uY2xvc2UgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHdlYnNvY2tldENhbGxiYWNrcy5vbkNsb3NlKCk7XHJcbiAgICAgICAgICAgIFdlYlNvY2tldENhbGxiYWNrQ2xhc3MucmVJbml0aWFsaXplT2JzZXJ2YWJsZXMoKTtcclxuICAgICAgICAgICAgdGhpcy5yZUluaXRpYWxpemVXZWJzb2NrZXRPcGVuUHJvbWlzZSgpO1xyXG4gICAgICAgICAgICBjb25zdMOCwqBtYXA6w4LCoE1hcDxzdHJpbmcsw4LCoHN0cmluZz7DgsKgPcOCwqB0aGlzLmdldENvb2tpZXMoKTtcclxuICAgICAgICAgICAgIHJlc3BvbnNlU2Vzc2lvbkRhdGE9dGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpO1xyXG4gICAgICAgICAgICBpZihtYXAuaGFzKCdYLVVTRVJOQU1FJykgJiYgZmxhZyYmcmVzcG9uc2VTZXNzaW9uRGF0YS5nbG9iYWxzJiZyZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIpw4LCoHtcclxuICAgICAgICAgICAgICBjb25zdCBjYWxsYmFjayA9IG5ld8OCwqBXZWJTb2NrZXRDYWxsYmFja0NsYXNzKCk7XHJcbiAgICAgICAgICAgIMOCwqDDgsKgdGhpcy5vcGVuV2ViU29ja2V0Q2hhbm5lbChjYWxsYmFjaykuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sub25SZWNvbm5lY3QoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXNvbHZlRm4gPSB0aGlzLnJlc29sdmVGbjtcclxuICAgICAgICB0aGlzLndlYnNvY2tldC5vbmVycm9yID0gZnVuY3Rpb24oZXJyb3IpIHtcclxuICAgICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25FcnJvcikge1xyXG4gICAgICAgICAgICB3ZWJzb2NrZXRDYWxsYmFja3Mub25FcnJvcihlcnJvcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygncmUtY29ubmVjdGluZyB0byB3ZWJzb2NrZXQgc2VydmVyLi4uJyk7XHJcbiAgICAgICAgICByZXNvbHZlRm4oKTtcclxuICAgICAgICAgIG9ic2VydmUuZXJyb3IoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmICh3ZWJzb2NrZXRDYWxsYmFja3Mub25NZXNzYWdlKSB7XHJcbiAgICAgICAgICB0aGlzLndlYnNvY2tldC5vbm1lc3NhZ2UgPSB3ZWJzb2NrZXRDYWxsYmFja3Mub25NZXNzYWdlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICB0aGlzLnJlc29sdmVGbigpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfSkucGlwZShkZWxheSgyMDAwKSkucGlwZShyZXRyeSgxNSkpO1xyXG4gIH1cclxuICBwcml2YXRlIGdldENvb2tpZXMoKTogTWFwPHN0cmluZywgc3RyaW5nPiB7XHJcbiAgICBjb25zdCBjb29raWVTdHI6IHN0cmluZyA9IGRvY3VtZW50LmNvb2tpZTtcclxuICAgIGNvbnN0IGNvb2tpZXM6IHN0cmluZ1tdID0gY29va2llU3RyLnNwbGl0KCc7Jyk7XHJcbiAgICBjb25zdCBtYXA6IE1hcDxzdHJpbmcsIHN0cmluZz4gPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xyXG4gICAgY29va2llcy5mb3JFYWNoKGNvb2tpZSA9PiB7XHJcbiAgICAgIGlmIChjb29raWUpIHtcclxuICAgICAgICBjb25zdCBrZXlWYWwgPSBjb29raWUudHJpbSgpLnNwbGl0KCc9Jyk7XHJcbiAgICAgICAgbWFwLnNldChrZXlWYWxbMF0udHJpbSgpLCBrZXlWYWxbMV0udHJpbSgpKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gbWFwO1xyXG4gIH1cclxuICBwcml2YXRlIGhhbmRsZUVycm9yKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xyXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3JFdmVudCkge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihgQ291bGQgbm90IGNvbm5lY3QgdG8gc2VydmVyLlxcbjoke2Vycm9yfWApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRocm93RXJyb3IoYFNlcnZlciByZXR1cm5lZCBjb2RlICR7ZXJyb3Iuc3RhdHVzfSwgYm9keSB3YXM6ICR7ZXJyb3IuZXJyb3J9YCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHByaXZhdGUgcmVJbml0aWFsaXplV2Vic29ja2V0T3BlblByb21pc2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLndlYnNvY2tldE9wZW5Qcm9taXNlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB0aGlzLnJlc29sdmVGbiA9IHJlc29sdmU7XHJcbiAgICAgIHRoaXMucmVqZWN0Rm4gPSByZWplY3Q7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgQEhvc3RMaXN0ZW5lcignd2luZG93Om9uYmVmb3JldW5sb2FkJyxbJyRldmVudCddKVxyXG4gIG9uYmVmb3JldW5sb2FkSGFuZGxlcihldmVudDogRXZlbnQpIHtcclxuICAgIGNvbnN0IGxvZ2luUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKClcclxuICAgICAgICAgIC5ub25SZXN0cmljdGVkUGFnZXMuaW5jbHVkZXModGhpcy5sb2NhdGlvbi5wYXRoKCkpO1xyXG4gICAgaWYobG9naW5QYWdlKVxyXG4gICAge1xyXG4gICAgICB0aGlzLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwSGVhZGVycywgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBDT05TVEFOVFMgfSBmcm9tICcuL2NvbnN0YW50JztcclxuaW1wb3J0IHsgQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsIEFwcENvbmZpZ3VyYXRpb24gfSBmcm9tICcuL2FwcC1jb25maWd1cmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyB0aHJvd0Vycm9yLCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IHJldHJ5LCBjYXRjaEVycm9yIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTZXNzaW9uU2VydmljZSB9IGZyb20gJy4vc2Vzc2lvbi5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEh0dHBTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwQ2xpZW50OiBIdHRwQ2xpZW50LCBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLFxyXG4gIHByaXZhdGUgY2FjaGU6IENhY2hlTWFuYWdlclNlcnZpY2UsIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlKSB7IH1cclxuICBwcml2YXRlIHBhcnNlUXVlcnlTdHJpbmcocXVlcnlTdHJpbmc6IHN0cmluZywga2V5OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgbGV0IHRva2Vuczogc3RyaW5nW107XHJcbiAgICBpZiAocXVlcnlTdHJpbmcpIHtcclxuICAgICAgdG9rZW5zID0gcXVlcnlTdHJpbmcuc3BsaXQoJyYnKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgY29uc3QgbWFwOiBNYXA8c3RyaW5nLCBzdHJpbmc+ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcclxuICAgIGZvciAoY29uc3QgdG9rZW4gb2YgdG9rZW5zKSB7XHJcbiAgICAgIGNvbnN0IGtleVZhbHVlOiBzdHJpbmdbXSA9IHRva2VuLnNwbGl0KCc9Jyk7XHJcbiAgICAgIG1hcC5zZXQoa2V5VmFsdWVbMF0sIGtleVZhbHVlWzFdKTtcclxuICAgIH1cclxuICAgIHJldHVybiBtYXAuaGFzKGtleSkgPyBtYXAuZ2V0KGtleSkgOiBudWxsO1xyXG4gIH1cclxuICBwYXJzZVVybCh1cmw6IHN0cmluZyk6IE1hcDxzdHJpbmcsIHN0cmluZz4ge1xyXG4gICAgY29uc3QgcGFyc2VkUGFyYW1ldGVyczogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcbiAgICBjb25zdCBxdWVyeVN0cmluZzogc3RyaW5nID0gdXJsLnNwbGl0KCc/JylbMV07XHJcbiAgICBjb25zdCBwYXJhbWV0ZXJQYWlyTGlzdDogc3RyaW5nW10gPSBxdWVyeVN0cmluZy5zcGxpdCgnJicpO1xyXG4gICAgcGFyYW1ldGVyUGFpckxpc3QuZm9yRWFjaChwYXJhbWV0ZXJQYWlyID0+IHtcclxuICAgICAgY29uc3Qga2V5VmFsdWU6IHN0cmluZ1tdID0gcGFyYW1ldGVyUGFpci5zcGxpdCgnPScpO1xyXG4gICAgICBwYXJzZWRQYXJhbWV0ZXJzW2tleVZhbHVlWzBdXSA9IGtleVZhbHVlWzFdO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gcGFyc2VkUGFyYW1ldGVycztcclxuICB9XHJcbiAgcHJpdmF0ZSBjaGVja0F1dGhvcml6YXRpb24odXJsOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgIGlmICghdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5jbGllbnRTaWRlUmVxdWVzdEJhcnJpbmcpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbiAgICBjb25zdCAgcGFyc2VkUGFyYW1ldGVyczogTWFwPHN0cmluZywgc3RyaW5nPiA9IHRoaXMucGFyc2VVcmwodXJsKTtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHBhcnNlZFBhcmFtZXRlcnNbJ29wZXJhdGlvbiddO1xyXG4gICAgbGV0IGFjY2Vzc0dyYW50ZWRNb2R1bGUgPSBmYWxzZTtcclxuICAgIGxldCBhY2Nlc3NHcmFudGVkTm9kZSA9IGZhbHNlO1xyXG4gICAgbGV0IGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSBmYWxzZTtcclxuICAgIHN3aXRjaCAob3BlcmF0aW9uKSB7XHJcbiAgICBjYXNlICdkb0xvZ2luJzpcclxuICAgIGNhc2UgJ2xvZ291dFVzZXInOlxyXG4gICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gdHJ1ZTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBpZiAodGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXSAmJlxyXG4gICAgICAgICAgICB0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZSAhPT0gJ2ZyZWVBbGxvdycpIHtcclxuICAgICAgICBjb25zdCBhY2Nlc3NSZXF1aXJlZCA9IHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uYWNjZXNzO1xyXG4gICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLnN0cnVjdHVyZWRSZXN0cmljdGlvblt0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZV0pIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWRNb2R1bGUgPVxyXG4gICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb25bdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5tb2R1bGVdW2FjY2Vzc1JlcXVpcmVkXSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgYWNjZXNzR3JhbnRlZE1vZHVsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgICB0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm1vZHVsZSA9PT0gJ2ZyZWVBbGxvdycpIHtcclxuICAgICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gdHJ1ZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhY2Nlc3NHcmFudGVkTW9kdWxlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gICAgaWYgKCFhY2Nlc3NHcmFudGVkTW9kdWxlKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmIHRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uY2lyY2xlKSB7XHJcbiAgICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm5vZGUpIHtcclxuICAgICAgICBjb25zdCBjaXJjbGVBY2Nlc3NSZXF1aXJlZCA9IHBhcnNlZFBhcmFtZXRlcnNbJ2NpcmNsZU5hbWUnXTtcclxuICAgICAgICBjb25zdCBub2RlQWNjZXNzUmVxdWlyZWQgPSBwYXJzZWRQYXJhbWV0ZXJzWydub2RlTmFtZSddO1xyXG4gICAgICAgIGlmIChjaXJjbGVBY2Nlc3NSZXF1aXJlZCAmJiBub2RlQWNjZXNzUmVxdWlyZWQpIHtcclxuICAgICAgICAgIGlmIChub2RlQWNjZXNzUmVxdWlyZWQucGFyc2VkTm9kZUNpcmNsZUpzb25bbm9kZUFjY2Vzc1JlcXVpcmVkXSAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uW25vZGVBY2Nlc3NSZXF1aXJlZF1bY2lyY2xlQWNjZXNzUmVxdWlyZWRdKSB7XHJcbiAgICAgICAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSB0cnVlO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBhY2Nlc3NHcmFudGVkQ2lyY2xlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgIXRoaXMuY2FjaGUuT3BlcmF0aW9uVG9BY2Nlc3NNYXBwaW5nW29wZXJhdGlvbl0uY2lyY2xlKSB7XHJcbiAgICAgIGFjY2Vzc0dyYW50ZWRDaXJjbGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZENpcmNsZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgaWYgKCFhY2Nlc3NHcmFudGVkQ2lyY2xlKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGlmICh0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dICYmXHJcbiAgICAgICAgdGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXS5ub2RlKSB7XHJcbiAgICAgIGNvbnN0IG5vZGVBY2Nlc3NSZXF1aXJlZCA9IHBhcnNlZFBhcmFtZXRlcnNbJ25vZGVOYW1lJ107XHJcbiAgICAgIGlmIChub2RlQWNjZXNzUmVxdWlyZWQpIHtcclxuICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5wYXJzZWROb2RlQ2lyY2xlSnNvbltub2RlQWNjZXNzUmVxdWlyZWRdKSB7XHJcbiAgICAgICAgICBhY2Nlc3NHcmFudGVkTm9kZSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGFjY2Vzc0dyYW50ZWROb2RlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFjY2Vzc0dyYW50ZWROb2RlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodGhpcy5jYWNoZS5PcGVyYXRpb25Ub0FjY2Vzc01hcHBpbmdbb3BlcmF0aW9uXSAmJlxyXG4gICAgICAgICF0aGlzLmNhY2hlLk9wZXJhdGlvblRvQWNjZXNzTWFwcGluZ1tvcGVyYXRpb25dLm5vZGUpIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWNjZXNzR3JhbnRlZE5vZGUgPSBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiBhY2Nlc3NHcmFudGVkTm9kZTtcclxuICB9XHJcbiAgZ2V0RGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgY29uc29sZS5sb2codXJsKTtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBpZiAocmVxdWVzdC5yZXNwb25zZVR5cGUpIHtcclxuICAgICAgICAgIHJlcXVlc3QuaGVhZGVycy5zZXQoJ3Jlc3BvbnNlVHlwZScsIHJlcXVlc3QucmVzcG9uc2VUeXBlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIGlmKHJlcXVlc3QucmVzcG9uc2VUeXBlKSB7XHJcbiAgICAgICAgICBodHRwT3B0aW9uc1sncmVzcG9uc2VUeXBlJ10gPSByZXF1ZXN0LnJlc3BvbnNlVHlwZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LmdldDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcclxuICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0LmNhbGxiYWNrZnVuY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0LmNhbGxiYWNrZnVuY3Rpb24oe2JvZHk6IHJlc3BvbnNlLmJvZHksIGhlYWRlcnM6IHJlc3BvbnNlLmhlYWRlcnMsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzfSk7XHJcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuZ2V0PEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKHJlcXVlc3QuY2FsbGJhY2tmdW5jdGlvbikge1xyXG4gICAgICAgICAgICAgICAgcmVxdWVzdC5jYWxsYmFja2Z1bmN0aW9uKHtib2R5OiByZXNwb25zZS5ib2R5LCBoZWFkZXJzOiByZXNwb25zZS5oZWFkZXJzLCBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1c30pO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBOb3QgYXV0aG9yaXplZCBmb3IgYWNjZXNzaW5nICR7dXJsfTogNDAxYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcG9zdERhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGNvbnNvbGUubG9nKHVybCk7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wb3N0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucG9zdDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgcmVxdWVzdC5kYXRhLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwdXREYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzP3JlcXVlc3QuaGVhZGVyczp7fSBhcyBIdHRwSGVhZGVycyxcclxuICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICAgICAgfTtcclxuICAgICAgICBodHRwT3B0aW9ucy5oZWFkZXJzWydvcGVyYXRpb24nXSA9IG9wZXJhdGlvbjtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihzdWJzY3JpYmVyID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucHV0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucHV0PEh0dHBSZXNwb25zZTxUPj4odXJsLCByZXF1ZXN0LmRhdGEsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihgTm90IGF1dGhvcml6ZWQgZm9yIGFjY2Vzc2luZyAke3VybH06IDQwMWApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGRlbGV0ZURhdGE8VD4ocmVxdWVzdDogUmVxdWVzdCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PiB7XHJcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlUXVlcnlTdHJpbmcocmVxdWVzdC5xdWVyeVN0cmluZywgJ29wZXJhdGlvbicpO1xyXG4gICAgbGV0IHVybDogc3RyaW5nO1xyXG4gICAgY29uc3QgY29uZmlnOiBBcHBDb25maWd1cmF0aW9uID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgIGlmIChyZXF1ZXN0LnJlcVVybCkge1xyXG4gICAgICB1cmwgPSByZXF1ZXN0LnJlcVVybDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmICghcmVxdWVzdC5xdWVyeVN0cmluZykge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSAnJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gYD8ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgfVxyXG4gICAgICB1cmwgPSBgJHtDT05TVEFOVFMuUFJPVE9DT0x9JHtjb25maWcuaXB9OiR7Y29uZmlnLnBvcnR9JHtyZXF1ZXN0LmNvbnRleHR9JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIGlmICh0aGlzLmNoZWNrQXV0aG9yaXphdGlvbih1cmwpKSB7XHJcbiAgICAgICAgY29uc3QgaHR0cE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnM/cmVxdWVzdC5oZWFkZXJzOnt9IGFzIEh0dHBIZWFkZXJzLFxyXG4gICAgICAgICAgb2JzZXJ2ZTogJ3Jlc3BvbnNlJyBhcyAnYm9keSdcclxuICAgICAgICB9O1xyXG4gICAgICAgIGh0dHBPcHRpb25zLmhlYWRlcnNbJ29wZXJhdGlvbiddID0gb3BlcmF0aW9uO1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+KHN1YnNjcmliZXIgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXRPcGVuUHJvbWlzZS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5kZWxldGU8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuZGVsZXRlPEh0dHBSZXNwb25zZTxUPj4odXJsLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBoZWFkRGF0YTxUPihyZXF1ZXN0OiBSZXF1ZXN0KTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8VD4+IHtcclxuICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRoaXMucGFyc2VRdWVyeVN0cmluZyhyZXF1ZXN0LnF1ZXJ5U3RyaW5nLCAnb3BlcmF0aW9uJyk7XHJcbiAgICBsZXQgdXJsOiBzdHJpbmc7XHJcbiAgICBjb25zdCBjb25maWc6IEFwcENvbmZpZ3VyYXRpb24gPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgaWYgKHJlcXVlc3QucmVxVXJsKSB7XHJcbiAgICAgIHVybCA9IHJlcXVlc3QucmVxVXJsO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKCFyZXF1ZXN0LnF1ZXJ5U3RyaW5nKSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9ICcnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcXVlc3QucXVlcnlTdHJpbmcgPSBgPyR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICB9XHJcbiAgICAgIHVybCA9IGAke0NPTlNUQU5UUy5QUk9UT0NPTH0ke2NvbmZpZy5pcH06JHtjb25maWcucG9ydH0ke3JlcXVlc3QuY29udGV4dH0ke3JlcXVlc3QucXVlcnlTdHJpbmd9YDtcclxuICAgICAgaWYgKHRoaXMuY2hlY2tBdXRob3JpemF0aW9uKHVybCkpIHtcclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IHtcclxuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVycz9yZXF1ZXN0LmhlYWRlcnM6e30gYXMgSHR0cEhlYWRlcnMsXHJcbiAgICAgICAgICBvYnNlcnZlOiAncmVzcG9uc2UnIGFzICdib2R5J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgaHR0cE9wdGlvbnMuaGVhZGVyc1snb3BlcmF0aW9uJ10gPSBvcGVyYXRpb247XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4oc3Vic2NyaWJlciA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMgJiZcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHMuY3VycmVudFVzZXIpIHtcclxuICAgICAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldE9wZW5Qcm9taXNlLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5odHRwQ2xpZW50LmhlYWQ8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIGh0dHBPcHRpb25zKS5waXBlKHJldHJ5KDIpLCBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3IpKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQuaGVhZDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uc2UgPT4gc3Vic2NyaWJlci5uZXh0KHJlc3BvbnNlKSwgZXJyb3IgPT4gc3Vic2NyaWJlci5lcnJvcihlcnJvcikpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGBOb3QgYXV0aG9yaXplZCBmb3IgYWNjZXNzaW5nICR7dXJsfTogNDAxYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcGF0Y2hEYXRhPFQ+KHJlcXVlc3Q6IFJlcXVlc3QpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZVF1ZXJ5U3RyaW5nKHJlcXVlc3QucXVlcnlTdHJpbmcsICdvcGVyYXRpb24nKTtcclxuICAgIGxldCB1cmw6IHN0cmluZztcclxuICAgIGNvbnN0IGNvbmZpZzogQXBwQ29uZmlndXJhdGlvbiA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICBpZiAocmVxdWVzdC5yZXFVcmwpIHtcclxuICAgICAgdXJsID0gcmVxdWVzdC5yZXFVcmw7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpZiAoIXJlcXVlc3QucXVlcnlTdHJpbmcpIHtcclxuICAgICAgICByZXF1ZXN0LnF1ZXJ5U3RyaW5nID0gJyc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVxdWVzdC5xdWVyeVN0cmluZyA9IGA/JHtyZXF1ZXN0LnF1ZXJ5U3RyaW5nfWA7XHJcbiAgICAgIH1cclxuICAgICAgdXJsID0gYCR7Q09OU1RBTlRTLlBST1RPQ09MfSR7Y29uZmlnLmlwfToke2NvbmZpZy5wb3J0fSR7cmVxdWVzdC5jb250ZXh0fSR7cmVxdWVzdC5xdWVyeVN0cmluZ31gO1xyXG4gICAgICBpZiAodGhpcy5jaGVja0F1dGhvcml6YXRpb24odXJsKSkge1xyXG4gICAgICAgIGNvbnN0IGh0dHBPcHRpb25zID0ge1xyXG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzP3JlcXVlc3QuaGVhZGVyczp7fSBhcyBIdHRwSGVhZGVycyxcclxuICAgICAgICAgIG9ic2VydmU6ICdyZXNwb25zZScgYXMgJ2JvZHknXHJcbiAgICAgICAgfTtcclxuICAgICAgICBodHRwT3B0aW9ucy5oZWFkZXJzWydvcGVyYXRpb24nXSA9IG9wZXJhdGlvbjtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPFQ+PihzdWJzY3JpYmVyID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscyAmJlxyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCkuZ2xvYmFscy5jdXJyZW50VXNlcikge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0T3BlblByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmh0dHBDbGllbnQucGF0Y2g8SHR0cFJlc3BvbnNlPFQ+Pih1cmwsIHJlcXVlc3QuZGF0YSwgaHR0cE9wdGlvbnMpLnBpcGUocmV0cnkoMiksIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcikpXHJcbiAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHN1YnNjcmliZXIubmV4dChyZXNwb25zZSksIGVycm9yID0+IHN1YnNjcmliZXIuZXJyb3IoZXJyb3IpKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHR0cENsaWVudC5wYXRjaDxIdHRwUmVzcG9uc2U8VD4+KHVybCwgcmVxdWVzdC5kYXRhLCBodHRwT3B0aW9ucykucGlwZShyZXRyeSgyKSwgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9yKSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShyZXNwb25zZSA9PiBzdWJzY3JpYmVyLm5leHQocmVzcG9uc2UpLCBlcnJvciA9PiBzdWJzY3JpYmVyLmVycm9yKGVycm9yKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoYE5vdCBhdXRob3JpemVkIGZvciBhY2Nlc3NpbmcgJHt1cmx9OiA0MDFgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBwcml2YXRlIGhhbmRsZUVycm9yKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xyXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3JFdmVudCkge1xyXG4gICAgICByZXR1cm4gdGhyb3dFcnJvcihgQ291bGQgbm90IGNvbm5lY3QgdG8gc2VydmVyLlxcbjoke2Vycm9yfWApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVlc3Qge1xyXG4gIGNvbnRleHQ6IHN0cmluZztcclxuICBkYXRhPzogYW55O1xyXG4gIGhlYWRlcnM/OiBIdHRwSGVhZGVycztcclxuICBxdWVyeVN0cmluZz86IHN0cmluZztcclxuICByZXNwb25zZVR5cGU/OiBzdHJpbmc7XHJcbiAgcmVxVXJsPzogc3RyaW5nO1xyXG4gIGNhbGxiYWNrZnVuY3Rpb24/KC4uLmFyZ3MpOiBhbnk7XHJcbn1cclxuZXhwb3J0IGludGVyZmFjZSBSZXNwb25zZSB7XHJcbiAgYm9keT86IGFueTtcclxuICBoZWFkZXJzPzogYW55O1xyXG4gIHN0YXR1cz86IGFueTtcclxuICBxdWVyeVN0cmluZz86IGFueTtcclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkRlc3Ryb3ksIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwU2VydmljZSwgUmVxdWVzdCB9IGZyb20gJy4vaHR0cC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBmaWx0ZXIgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09OU1RBTlRTIH0gZnJvbSAnLi9jb25zdGFudCc7XHJcbmltcG9ydCB7IFNlc3Npb25TZXJ2aWNlLCBSZXNwb25zZVNlc3Npb25EYXRhLCBSZXF1ZXN0U2Vzc2lvbkRhdGEgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IFJzYVV0aWxzIH0gZnJvbSAnLi9yc2EtdXRpbHMnO1xyXG5pbXBvcnQgeyBBZXNVdGlscyB9IGZyb20gJy4vYWVzLXV0aWxzJztcclxuaW1wb3J0IHsgSHR0cEhlYWRlcnMsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgQ2FjaGVNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4vY2FjaGUtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBzYXZlQXMgfSBmcm9tICdmaWxlLXNhdmVyJztcclxuaW1wb3J0IHsgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcyB9IGZyb20gJy4vd2ViLXNvY2tldC1jYWxsYmFja3MtY2xhc3MnO1xyXG5pbXBvcnQgeyBoZWFkZXJzVG9TdHJpbmcgfSBmcm9tICdzZWxlbml1bS13ZWJkcml2ZXIvaHR0cCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJYW1TZXJ2aWNlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gIHByaXZhdGUgd2Vic29ja2V0OiBXZWJTb2NrZXQ7XHJcbiAgZXZlbnQ6IGFueTtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHBTZXJ2aWNlOiBIdHRwU2VydmljZSwgcHJpdmF0ZSBhcHBDb25maWd1cmF0aW9uOiBBcHBDb25maWd1cmF0aW9uU2VydmljZSxcclxuICAgIHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSwgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSBsb2NhdGlvbjogTG9jYXRpb24pIHtcclxuICAgIHRoaXMuc3RhcnRMaXN0ZW5pbmdUb1JvdXRlQ2hhbmdlKCkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3N0YXJ0ZWQgbGlzdGVuaW5nIGZvciByb3V0ZSBjaGFuZ2UnKTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICB9XHJcbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICB0aGlzLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gIH1cclxuICBwcml2YXRlIGRvTG9naW48VD4ocGF5bG9hZCwgcHJvamVjdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycygpLnNldCgncHJvamVjdCcsXHJcbiAgICAgICAgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKCkuc2V0KCdwcm9qZWN0JyxcclxuICAgICAgICBwcm9qZWN0KTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1kb0xvZ2luJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogcGF5bG9hZFxyXG4gICAgfTtcclxuICAgIHJldHVybiB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpO1xyXG4gIH1cclxuICBzdGFydExpc3RlbmluZ1RvUm91dGVDaGFuZ2UoKTogT2JzZXJ2YWJsZTx2b2lkPiB7XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMucm91dGVyLmV2ZW50cy5waXBlKFxyXG4gICAgICAgIGZpbHRlcihldmVudCA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpXHJcbiAgICAgICkuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICB0aGlzLm9uUm91dGVDaGFuZ2UoZXZlbnQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBhdXRoZW50aWNhdGVVc2VyPFQ+KHVzZXJOYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcsIHByb2plY3Q/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ge1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxUPj4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlU2Vzc2lvbkRhdGE6IFJlc3BvbnNlU2Vzc2lvbkRhdGEgPSB0aGlzLnNlc3Npb25TZXJ2aWNlLmdldFNlc3Npb25EYXRhKCk7XHJcbiAgICAgIGlmIChyZXNwb25zZVNlc3Npb25EYXRhICYmIHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscyAmJlxyXG4gICAgICAgIHJlc3BvbnNlU2Vzc2lvbkRhdGEuZ2xvYmFscy5jdXJyZW50VXNlciAmJiByZXNwb25zZVNlc3Npb25EYXRhLmdsb2JhbHMuY3VycmVudFVzZXIudXNlck5hbWUpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygndXNlciBhbHJlYWR5IGxvZ2dlZCBpbicpO1xyXG4gICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHJhbmRvbUFlc0tleSA9IEFlc1V0aWxzLmdlbmVyYXRlUmFuZG9tQWVzS2V5KCk7XHJcbiAgICAgICAgY29uc3QgY3JlZGVudGlhbHMgPSB7XHJcbiAgICAgICAgICB1c2VyTmFtZTogdXNlck5hbWUsXHJcbiAgICAgICAgICB1c2VyUGFzc3dvcmQ6IFJzYVV0aWxzLmVuY3J5cHQocGFzc3dvcmQpLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIEFwcERhdGE6IHtcclxuICAgICAgICAgICAgdXNlckluZm86IGNyZWRlbnRpYWxzLFxyXG4gICAgICAgICAgICBlbmNyeXB0aW9uS2V5OiBSc2FVdGlscy5lbmNyeXB0KHJhbmRvbUFlc0tleSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuZG9Mb2dpbjxUPihwYXlsb2FkLCBwcm9qZWN0KS5zdWJzY3JpYmUocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLmJvZHkgJiYgcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlICYmIHJlc3BvbnNlLmJvZHkuc3RhdHVzQ29kZS5BcHBEYXRhICYmIHJlc3BvbnNlLmJvZHkuc3RhdHVzQ29kZS5BcHBEYXRhLnVzZXJUb2tlbikge1xyXG4gICAgICAgICAgICBjb25zdCBzdWJUb2tlbnM6IHN0cmluZ1tdID0gcmVzcG9uc2UuYm9keS5zdGF0dXNDb2RlLkFwcERhdGEudXNlclRva2VuLnNwbGl0KCdAJyk7XHJcbiAgICAgICAgICAgIGxldCBtb2R1bGVSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICAgICAgICAgIGxldCBzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSBudWxsO1xyXG4gICAgICAgICAgICBsZXQgbm9kZU5hbWVDaXJjbGUgPSBudWxsO1xyXG4gICAgICAgICAgICBpZiAoc3ViVG9rZW5zWzFdICYmIHN1YlRva2Vuc1sxXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgbW9kdWxlUmVzdHJpY3Rpb24gPSB0aGlzLnBhcnNlVG9rZW4oQWVzVXRpbHMuZGVjcnlwdChzdWJUb2tlbnNbMV0sIHJhbmRvbUFlc0tleSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIG1vZHVsZVJlc3RyaWN0aW9uID0ge307XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3RydWN0dXJlZFJlc3RyaWN0aW9uID0gdGhpcy5yZXN0cnVjdHVyZUFjY2Vzc0pzb24obW9kdWxlUmVzdHJpY3Rpb24sIHt9KTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRTZXNzaW9uRGF0YUZvck1vZHVsZVJlc3RyaWN0aW9uKG1vZHVsZVJlc3RyaWN0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRTZXNzaW9uRGF0YUZvclN0cnVjdHVyZWRSZXN0cmljdGlvbihzdHJ1Y3R1cmVkUmVzdHJpY3Rpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFVzZXJUb2tlbkRhdGEoc3ViVG9rZW5zWzBdKTtcclxuICAgICAgICAgICAgaWYgKHN1YlRva2Vuc1syXSAmJiBzdWJUb2tlbnNbMl0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgIG5vZGVOYW1lQ2lyY2xlID0gQWVzVXRpbHMuZGVjcnlwdChzdWJUb2tlbnNbMl0sIHJhbmRvbUFlc0tleSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgbm9kZU5hbWVDaXJjbGUgPSAnJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBwYXJzZWROb2RlQ2lyY2xlSnNvbiA9IHRoaXMucGFyc2VOb2RlQ2lyY2xlVG9rZW4obm9kZU5hbWVDaXJjbGUpO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhRm9yTm9kZUNpcmNsZVJlc3RyaWN0aW9uKHBhcnNlZE5vZGVDaXJjbGVKc29uIGFzIEpTT04pO1xyXG4gICAgICAgICAgICBjb25zdCBuZU5hbWVzQ2lyY2xlTGlzdDogc3RyaW5nW10gPSBub2RlTmFtZUNpcmNsZS5zcGxpdCgnIycpO1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0KSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZSkge1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZSA9IHt9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAobGV0IGl0ciA9IDA7IGl0ciA8IG5lTmFtZXNDaXJjbGVMaXN0Lmxlbmd0aDsgaXRyKyspIHtcclxuICAgICAgICAgICAgICBjb25zdCBjaXJsZU5hbWVzRm9yTkUgPSBuZU5hbWVzQ2lyY2xlTGlzdFtpdHJdLnNwbGl0KCc6Jyk7XHJcbiAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QucHVzaChjaXJsZU5hbWVzRm9yTkVbMF0pO1xyXG4gICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UubWFwTmVOYW1lQ2lyY2xlTmFtZVtjaXJsZU5hbWVzRm9yTkVbMF1dID0gY2lybGVOYW1lc0Zvck5FWzFdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZVNob3J0TmFtZSA9IHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0WzBdO1xyXG4gICAgICAgICAgICB0aGlzLm5lU2hvcnROYW1lRnVsbE5hbWVNYXBwaW5nKCk7XHJcbiAgICAgICAgICAgIHRoaXMubmVDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZU1hcHBpbmcoKTtcclxuICAgICAgICAgICAgY29uc3QgbmVOYW1lQ2lyY2xlTmFtZTogSlNPTiA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgIHNlbGVjdGVkTmVOYW1lOiB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lLFxyXG4gICAgICAgICAgICAgIHNlbGVjdGVkQ2lyY2xlTmFtZTogdGhpcy5zZXNzaW9uU2VydmljZS5zZWxlY3RlZENpcmNsZU5hbWVcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0RGF0YTogUmVxdWVzdFNlc3Npb25EYXRhID0ge1xyXG4gICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyTmFtZSxcclxuICAgICAgICAgICAgICBhcHBEYXRhOiByZXNwb25zZS5ib2R5LnN0YXR1c0NvZGUuQXBwRGF0YSxcclxuICAgICAgICAgICAgICBub2RlTmFtZUNpcmNsZTogbm9kZU5hbWVDaXJjbGUsXHJcbiAgICAgICAgICAgICAgYWVzS2V5OiBBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1szXSwgcmFuZG9tQWVzS2V5KSxcclxuICAgICAgICAgICAgICBuZU5hbWVDaXJjbGVOYW1lOiBuZU5hbWVDaXJjbGVOYW1lXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UucHV0RGF0ZUZvckNvb2tpZUV4cGlyeSgpO1xyXG4gICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNldFNlc3Npb25EYXRhKHJlcXVlc3REYXRhKTtcclxuICAgICAgICAgICAgQWVzVXRpbHMuc2V0QWVzRW5jcnlwdGlvbktleShBZXNVdGlscy5kZWNyeXB0KHN1YlRva2Vuc1szXSwgcmFuZG9tQWVzS2V5KSk7XHJcbiAgICAgICAgICAgIGludGVyZmFjZSBVc2VySW1hZ2VSZXNwb25zZSB7XHJcbiAgICAgICAgICAgICAgc3VjY2VzczogYm9vbGVhbjtcclxuICAgICAgICAgICAgICBBcHBEYXRhOiB7XHJcbiAgICAgICAgICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICB1c2VySW1hZ2U6IHN0cmluZztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUuZ2V0VXNlckltYWdlPFVzZXJJbWFnZVJlc3BvbnNlPih1c2VyTmFtZSkudGhlbihmdW5jdGlvbiAocmVzcCkge1xyXG4gICAgICAgICAgICAgIGlmIChyZXNwLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FjaGUubG9naW5Vc2VySW1hZ2UgPSByZXNwLkFwcERhdGEudXNlckluZm8udXNlckltYWdlID8gcmVzcC5BcHBEYXRhLnVzZXJJbmZvLnVzZXJJbWFnZSA6ICdub0ltYWdlJztcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS5vcGVuV2ViU29ja2V0Q2hhbm5lbChuZXcgV2ViU29ja2V0Q2FsbGJhY2tDbGFzcygpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFt0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbl0pO1xyXG4gICAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5kZWZhdWx0UGFnZUFmdGVyTG9naW5dKTtcclxuICAgICAgICAgICAgICBvYnNlcnZlLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG9ic2VydmUubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICBkb0xvZ291dCh1c2VyTmFtZSk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgaWYgKCF1c2VyTmFtZSkge1xyXG4gICAgICB0aHJvd0Vycm9yKCd1c2VyTmFtZSBpcyB1bmRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogYG9wZXJhdGlvbj1sb2dvdXRVc2VyJnVzZXJOYW1lPSR7dXNlck5hbWV9YCxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8dm9pZD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTx7IHN1Y2Nlc3M6IGJvb2xlYW4gfT4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBsb2dvdXRVc2VyKCk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHZvaWQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICBjb25zdCBnbG9iYWxzID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHM7XHJcbiAgICAgIGlmIChnbG9iYWxzICYmIGdsb2JhbHMuY3VycmVudFVzZXIgJiYgZ2xvYmFscy5jdXJyZW50VXNlci51c2VyTmFtZSkge1xyXG4gICAgICAgIGNvbnN0IGluVXNlck5hbWUgPSBnbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lO1xyXG4gICAgICAgIHRoaXMuZG9Mb2dvdXQoaW5Vc2VyTmFtZSkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgICAgIHRoaXMucmVzZXRWYXJpYWJsZXMoKTtcclxuICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9Mb2dvdXRQYWdlKCk7XHJcbiAgICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQgJiYgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UoKTtcclxuICAgICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQgPSBudWxsO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb2JzZXJ2ZS5uZXh0KCk7XHJcbiAgICAgICAgfSwgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmNsZWFyU2Vzc2lvbkRhdGFBbmRHb3RvTG9nb3V0UGFnZSgpO1xyXG4gICAgICAgICAgaWYgKHRoaXMuY2FjaGUud2Vic29ja2V0ICYmIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0ID0gbnVsbDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9ic2VydmUuZXJyb3IoKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLnJlc2V0VmFyaWFibGVzKCk7XHJcbiAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5jbGVhclNlc3Npb25EYXRhQW5kR290b0xvZ291dFBhZ2UoKTtcclxuICAgICAgICBpZiAodGhpcy5jYWNoZS53ZWJzb2NrZXQgJiYgdGhpcy5jYWNoZS53ZWJzb2NrZXQuY2xvc2UpIHtcclxuICAgICAgICAgIHRoaXMuY2FjaGUud2Vic29ja2V0LmNsb3NlKCk7XHJcbiAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdubyB1c2VyIHRvIGxvZ291dCcpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0UGF0aE5hbWUoKSB7XHJcbiAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoICYmIHdpbmRvdy5sb2NhdGlvbi5oYXNoLnN1YnN0cigxKTtcclxufVxyXG4gIG9uUm91dGVDaGFuZ2UoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzID0gdGhpcy5zZXNzaW9uU2VydmljZS5nZXRTZXNzaW9uRGF0YSgpLmdsb2JhbHM7XHJcbiAgICBpZiAoIXRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscykge1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLmdsb2JhbHMgPSB7fTtcclxuICAgIH1cclxuICAgIGlmKCB0aGlzLnJvdXRlci51cmwgPT0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5zZXNzaW9uRXhwaXJlZFBhZ2UpXHJcbiAgICB7XHJcbiAgICAgIHRyeVxyXG4gICAgICB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUud2Vic29ja2V0KSB7XHJcbiAgICAgICAgICB0aGlzLmNhY2hlLndlYnNvY2tldC5jbG9zZSgpO1xyXG4gICAgICAgICAgdGhpcy5jYWNoZS53ZWJzb2NrZXQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjYXRjaChFcnJvckV2ZW50KVxyXG4gICAgICB7XHJcbiAgICAgICAgY29uc29sZS5sb2coRXJyb3JFdmVudCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmxvZ2luUGFnZSAmJlxyXG4gICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLm5vblJlc3RyaWN0ZWRQYWdlcyAmJlxyXG4gICAgICB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLmRlZmF1bHRQYWdlQWZ0ZXJMb2dpbikge1xyXG4gICAgICAgIGxldCBwYXRoTmFtZSA9IHRoaXMubG9jYXRpb24ucGF0aCgpO1xyXG4gICAgICAgIGlmKHBhdGhOYW1lLmluY2x1ZGVzKFwiP1wiKSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXRoTmFtZT1wYXRoTmFtZS5zcGxpdChcIj9cIilbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICBjb25zdCByZXN0cmljdGVkUGFnZSA9IHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubm9uUmVzdHJpY3RlZFBhZ2VzLmluZGV4T2YocGF0aE5hbWUpPT09LTE7XHJcbiAgICAgIGNvbnN0IGxvZ2dlZEluID0gdGhpcy5zZXNzaW9uU2VydmljZS5nbG9iYWxzLmN1cnJlbnRVc2VyO1xyXG4gICAgICBpZiAocmVzdHJpY3RlZFBhZ2UgJiYgIWxvZ2dlZEluKSB7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW3RoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkubG9naW5QYWdlXSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobG9nZ2VkSW4pIHtcclxuICAgICAgICBjb25zdCBsb2dpblBhZ2UgPSB0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpXHJcbiAgICAgICAgICAubm9uUmVzdHJpY3RlZFBhZ2VzLmluZGV4T2YocGF0aE5hbWUpIT0tMTtcclxuICAgICAgICBpZiAobG9naW5QYWdlKSB7XHJcbiAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5kZWZhdWx0UGFnZUFmdGVyTG9naW5dKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgZ2V0QWxscm9sZWlkPFQ+KHByb2plY3Q/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxSb2xlU2VsZWN0ZWRGaWxlZCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlU2luZ2xlVXNlcjxUPihjcmVhdGluZ1VzZXI6IHN0cmluZywgQXBwRGF0YTogYW55LHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBBcHBEYXRhLnVzZXJJbmZvLnVzZXJQYXNzd29yZCA9IEFlc1V0aWxzLmVuY3J5cHQoQXBwRGF0YS51c2VySW5mby51c2VyUGFzc3dvcmQpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiBgb3BlcmF0aW9uPWNyZWF0ZVNpbmdsZVVzZXImY3JlYXRpbmdVc2VyPSR7Y3JlYXRpbmdVc2VyfWAsXHJcbiAgICAgIGRhdGE6IHsgQXBwRGF0YSB9LFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNyZWF0ZUFjY291bnQ8VD4oIEFwcERhdGE6IGFueSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgQXBwRGF0YS51c2VySW5mby51c2VyUGFzc3dvcmQgPSBBZXNVdGlscy5lbmNyeXB0KEFwcERhdGEudXNlckluZm8udXNlclBhc3N3b3JkKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1jcmVhdGVBY2NvdW50JyxcclxuICAgICAgZGF0YToge0FwcERhdGF9LFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGNyZWF0ZUJ1bGtVc2VyPFQ+KGNyZWF0aW5nVXNlcjogc3RyaW5nLCBmaWxlOiBhbnkscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogYG9wZXJhdGlvbj1jcmVhdGVCdWxrVXNlciZjcmVhdGluZ1VzZXI9JHtjcmVhdGluZ1VzZXJ9YCxcclxuICAgICAgZGF0YTogZmlsZSxcclxuICAgICAgaGVhZGVyczpoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjcmVhdGVCdWxrUm9sZXNhbmRVc2VyczxUPihjcmVhdGluZ1VzZXI6IHN0cmluZywgZmlsZTogYW55LHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6IGBvcGVyYXRpb249Y3JlYXRlQnVsa1JvbGVzYW5kVXNlcnMmY3JlYXRpbmdVc2VyPSR7Y3JlYXRpbmdVc2VyfWAsXHJcbiAgICAgIGRhdGE6IGZpbGUsXHJcbiAgICAgIGhlYWRlcnM6aGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZG93bmxvYWRCdWxrVXNlcnMocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QXJyYXlCdWZmZXI+PiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRCdWxrVXNlcicsXHJcbiAgICAgIHJlc3BvbnNlVHlwZTogJ2FycmF5YnVmZmVyJyxcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxIdHRwUmVzcG9uc2U8QXJyYXlCdWZmZXI+PihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPEFycmF5QnVmZmVyPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCAgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcmVzcC5ib2R5XSwge1xyXG4gICAgICAgICAgdHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0LGFwcGxpY2F0aW9uL3ZuZC5tcy1leGNlbCdcclxuICAgICAgICB9KTtcclxuICAgICAgICB2YXIgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gICAgICBhLmhyZWYgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICBhLmRvd25sb2FkID0gXCJVc2VyTGlzdC54bHN4XCI7XHJcbiAgICAgIGEuY2xpY2soKTtcclxuICAgICAgICBvYnNlcnZlLm5leHQoKTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRvd25sb2FkVXNlclRlbXBsYXRlKHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8dm9pZD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VGVtcGxhdGUnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHZvaWQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGEocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIGxldCBkYXRhMSA9IHJlc3AuYm9keTtcclxuICAgICAgICBsZXQgZGF0YSA9IHJlc3AuYm9keVsnc3RhdHVzQ29kZSddWydBcHBEYXRhJ11bJ0Jhc2U2NFN0cmVhbSddO1xyXG4gICAgICAgIHZhciBiaW5kYXRhID0gd2luZG93LmF0b2IoZGF0YSk7XHJcbiAgICAgICAgdmFyIGxlbiA9IGJpbmRhdGEubGVuZ3RoO1xyXG4gICAgICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGxlbik7XHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICAgICAgYnl0ZXNbaV0gPSBiaW5kYXRhLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBmaWxlID0gbmV3IEJsb2IoW2J5dGVzLmJ1ZmZlcl0sIHtcclxuICAgICAgICAgIHR5cGU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldDsnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgd2luZG93LnNhdmVBcyhmaWxlLCBcInVzZXJ0ZW1wbGF0ZVwiICsgXCIueGxzeFwiKVxyXG4gICAgICAgIG9ic2VydmUubmV4dCgpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcigpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBkZWxldGVVc2VyPFQ+KHVzZXJOYW1lOiBzdHJpbmcscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1kZWxldGVVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5kZWxldGVEYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwLmJvZHkpO1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIG1vZGlmeVVzZXI8VD4odXNlck5hbWU6IHN0cmluZywgdXNlckluZm8scHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1tb2RpZnlVc2VyJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgICAgZGF0YTogeyAnQXBwRGF0YSc6IHVzZXJJbmZvIH1cclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHZpZXdVc2VyPFQ+KHVzZXJOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBpZiAoIXVzZXJOYW1lKSB7XHJcbiAgICAgIHRocm93RXJyb3IoJ3VzZXJOYW1lIGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1VzZXJMaXN0QWNjb3JkaW5ndG9Sb2xlPFQ+KHJvbGVJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaWYgKCFyb2xlSWQpIHtcclxuICAgICAgdGhyb3dFcnJvcigncm9sZUlkIGlzIG5vdCBkZWZpbmVkJyk7XHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VXNlcnNMaXN0JnJvbGVJZD0nICsgcm9sZUlkLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGJsb2NrVXNlcjxUPih1c2VySWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGlmICghdXNlcklkKSB7XHJcbiAgICAgIHRocm93RXJyb3IoJ3VzZXJJZCBpcyBub3QgZGVmaW5lZCcpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWJsb2NrVXNlciZ1c2VySWQ9JyArIHVzZXJJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBjaGVja1VzZXJFeGlzdGVuY2U8VD4odXNlck5hbWU6IHN0cmluZyxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghdXNlck5hbWUpIHtcclxuICAgICAgdGhyb3dFcnJvcigndXNlck5hbWUgaXMgbm90IGRlZmluZWQnKTtcclxuICAgIH1cclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoZWNrVXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0QWxsVXNlcjxUPihpbmRleDogbnVtYmVyLCBzaXplOiBudW1iZXIscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxVc2VyJmZyb209JyArIGluZGV4ICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOmhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0UmVzdHJpY3RlZFVzZXI8VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRBbGxVc2VyU2VsZWN0ZWRGaWVsZCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlUm9sZTxUPihyb2xlRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsnY3JlYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsnY3JlYXRlZEJ5J10gPSB0aGlzLmNhY2hlLlhfVVNFUk5BTUU7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Y3JlYXRlUm9sZScsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiByb2xlRGF0YSB9LFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLnBvc3REYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICByZXNldFZhcmlhYmxlcygpOiB2b2lkIHtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2xvYmFscyA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkQ2lyY2xlTmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uuc2VsZWN0ZWROZVNob3J0TmFtZSA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnBhcnNlZE5vZGVDaXJjbGVKc29uID0gbnVsbDtcclxuICAgIHRoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVDaXJjbGUgPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5zdHJ1Y3R1cmVkUmVzdHJpY3Rpb24gPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5tb2R1bGVSZXN0cmljdGlvbiA9IG51bGw7XHJcbiAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLm1hcE5lTmFtZUNpcmNsZU5hbWUgPSBudWxsO1xyXG4gICAgdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3QgPSBbXTtcclxuICB9XHJcbiAgZ2V0Q29va2llKGtleSk6IGFueSB7XHJcbiAgICBjb25zdCBjb29raWVTdHIgPSBkb2N1bWVudC5jb29raWU7XHJcbiAgICBjb25zdCBjb29raWVzOiBzdHJpbmdbXSA9IGNvb2tpZVN0ci5zcGxpdCgnOycpO1xyXG4gICAgY29uc3QgbWFwID0ge307XHJcbiAgICBjb29raWVzLmZvckVhY2goY29va2llID0+IHtcclxuICAgICAgaWYgKGNvb2tpZSkge1xyXG4gICAgICAgIGNvbnN0IGtleXZhbCA9IGNvb2tpZS50cmltKCkuc3BsaXQoJz0nKTtcclxuICAgICAgICBtYXBba2V5dmFsWzBdLnRyaW0oKV0gPSBrZXl2YWxbMV0udHJpbSgpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBtYXBba2V5XTtcclxuICB9XHJcbiAgcmVzdHJ1Y3R1cmVBY2Nlc3NKc29uKG1vZHVsZSwgc3RydWN0dXJlZEpzb24pIHtcclxuICAgIGZvciAoY29uc3Qga2V5IGluIG1vZHVsZSkge1xyXG4gICAgICBpZiAobW9kdWxlLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IG1vZHVsZVtrZXldO1xyXG4gICAgICAgIGlmICh2YWx1ZS5hY2Nlc3MpIHtcclxuICAgICAgICAgIGNvbnN0IGFjY2VzcyA9IHt9O1xyXG4gICAgICAgICAgZm9yIChjb25zdCBreSBpbiB2YWx1ZS5hY2Nlc3MpIHtcclxuICAgICAgICAgICAgaWYgKHZhbHVlLmFjY2Vzcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZWxlbWVudCA9IHZhbHVlLmFjY2Vzc1treV07XHJcbiAgICAgICAgICAgICAgc3dpdGNoIChreSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnUic6XHJcbiAgICAgICAgICAgICAgICAgIGFjY2Vzc1snUmVhZCddID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdXJzpcclxuICAgICAgICAgICAgICAgICAgYWNjZXNzWydXcml0ZSddID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdEJzpcclxuICAgICAgICAgICAgICAgICAgYWNjZXNzWydEZWxldGUnXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3RydWN0dXJlZEpzb25ba2V5XSA9IGFjY2VzcztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5yZXN0cnVjdHVyZUFjY2Vzc0pzb24odmFsdWUsIHN0cnVjdHVyZWRKc29uKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBzdHJ1Y3R1cmVkSnNvbjtcclxuICB9XHJcbiAgLy8gdmFyIGF1dGhUb2tlbj1cIlNDMS4xOlJEI1NDMS4yOlJXRCNTQzEuMzpSRCNTQzUuMTpSRCNTQzIuMTpSV0QjU0MzLjIuMTpSRFwiO1xyXG4gIHBhcnNlVG9rZW4oYXV0aFRva2VuOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGpzb24gPSB7fTtcclxuICAgIGlmICghYXV0aFRva2VuKSB7XHJcbiAgICAgIHJldHVybiBqc29uO1xyXG4gICAgfVxyXG4gICAgY29uc3QgdG9rZW5zOiBzdHJpbmdbXSA9IGF1dGhUb2tlbi5zcGxpdCgnIycpO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0b2tlbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3QgdG9rZW4gPSB0b2tlbnNbaV07XHJcbiAgICAgIGNvbnN0IHNob3J0Q29kZXMgPSB0b2tlbi5zcGxpdCgnLicpO1xyXG4gICAgICBsZXQgdGVtcE5hbWUgPSAnJztcclxuICAgICAgbGV0IHRlbXAgPSBqc29uO1xyXG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNob3J0Q29kZXMubGVuZ3RoIC0gMTsgaisrKSB7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRDb2RlID0gc2hvcnRDb2Rlc1tqXTtcclxuICAgICAgICBpZiAodGVtcE5hbWUgPT09ICcnKSB7XHJcbiAgICAgICAgICB0ZW1wTmFtZSA9IHNob3J0Q29kZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGVtcE5hbWUgPSBgJHt0ZW1wTmFtZX0uJHtzaG9ydENvZGV9YDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0ZW1wLmhhc093blByb3BlcnR5KHRlbXBOYW1lKSkge1xyXG4gICAgICAgICAgdGVtcFt0ZW1wTmFtZV0gPSB7fTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcCA9IHRlbXBbdGVtcE5hbWVdO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICh0ZW1wTmFtZSA9PT0gJycpIHtcclxuICAgICAgICB0ZW1wTmFtZSA9IHNob3J0Q29kZXNbc2hvcnRDb2Rlcy5sZW5ndGggLSAxXS5zcGxpdCgnOicpWzBdO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRlbXBOYW1lID0gYCR7dGVtcE5hbWV9LiR7c2hvcnRDb2Rlc1tzaG9ydENvZGVzLmxlbmd0aCAtIDFdLnNwbGl0KCc6JylbMF19YDtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIXRlbXAuaGFzT3duUHJvcGVydHkodGVtcE5hbWUpKSB7XHJcbiAgICAgICAgY29uc3QgcmVzdHJpY3RKc29uID0ge307XHJcbiAgICAgICAgY29uc3QgcmVzdHJpY3Rpb24gPSBzaG9ydENvZGVzW3Nob3J0Q29kZXMubGVuZ3RoIC0gMV0uc3BsaXQoJzonKVsxXS5zcGxpdCgnJyk7XHJcbiAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCByZXN0cmljdGlvbi5sZW5ndGg7IGsrKykge1xyXG4gICAgICAgICAgcmVzdHJpY3RKc29uW3Jlc3RyaWN0aW9uW2tdXSA9IHRydWU7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wW3RlbXBOYW1lXSA9IHsgYWNjZXNzOiByZXN0cmljdEpzb24gfTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGpzb247XHJcbiAgfVxyXG4gIHByaXZhdGUgcGFyc2VOb2RlQ2lyY2xlVG9rZW4odG9rZW4pIHtcclxuICAgIGNvbnN0IHBhcnNlZEpzb24gPSB7fTtcclxuICAgIGlmICghdG9rZW4gfHwgdG9rZW4gPT09ICcnKSB7XHJcbiAgICAgIHJldHVybiBwYXJzZWRKc29uO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgc2luZ2xlTm9kZUNpcmNsZUxpc3Q6IHN0cmluZ1tdID0gdG9rZW4uc3BsaXQoJyMnKTtcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2luZ2xlTm9kZUNpcmNsZUxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgY29uc3Qgc2luZ2xlTm9kZUNpcmNsZSA9IHNpbmdsZU5vZGVDaXJjbGVMaXN0W2ldO1xyXG4gICAgICBjb25zdCBub2RlID0gc2luZ2xlTm9kZUNpcmNsZS5zcGxpdCgnOicpWzBdO1xyXG4gICAgICBjb25zdCBjaXJjbGVzTGlzdCA9IHNpbmdsZU5vZGVDaXJjbGUuc3BsaXQoJzonKVsxXS5zcGxpdCgnLCcpO1xyXG4gICAgICBjb25zdCBjaXJjbGVKc29uID0ge307XHJcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgY2lyY2xlc0xpc3QubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICBjaXJjbGVKc29uW3RoaXMuY2FjaGUuY2lyY2xlRnVsbE5hbWVKc29uUmVzcG9uc2VbJ0NpcmNsZU5hbWUnXVtjaXJjbGVzTGlzdFtqXV1dID0gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBwYXJzZWRKc29uW25vZGVdID0gY2lyY2xlSnNvbjtcclxuICAgIH1cclxuICAgIHJldHVybiBwYXJzZWRKc29uO1xyXG4gIH1cclxuICBuZVNob3J0TmFtZUZ1bGxOYW1lTWFwcGluZygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5jYWNoZS5uZVNob3J0TmFtZUZ1bGxOYW1lSnNvbjtcclxuICAgIGNvbnN0IG5lU2hvcnROYW1lID0gdGhpcy5zZXNzaW9uU2VydmljZS5ub2RlTmFtZUxpc3RbMF07XHJcbiAgICBpZiAocmVzcG9uc2UuTm9kZU5hbWUpIHtcclxuICAgICAgY29uc3Qgbm9kZUZ1bGxOYW1lID0gcmVzcG9uc2UuTm9kZU5hbWVbbmVTaG9ydE5hbWVdO1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkTmVOYW1lID0gbm9kZUZ1bGxOYW1lO1xyXG4gICAgfVxyXG4gICAgaWYgKCF0aGlzLmNhY2hlLm1hcE5lU2hvcnROYW1lRnVsbE5hbWUpIHtcclxuICAgICAgdGhpcy5jYWNoZS5tYXBOZVNob3J0TmFtZUZ1bGxOYW1lID0ge307XHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBpdHIgPSAwOyBpdHIgPCByZXNwb25zZS5Ob2RlTmFtZSAmJiB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdC5sZW5ndGg7IGl0cisrKSB7XHJcbiAgICAgIHRoaXMuY2FjaGUubWFwTmVTaG9ydE5hbWVGdWxsTmFtZVtyZXNwb25zZS5Ob2RlTmFtZVt0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdFtpdHJdXV0gPSB0aGlzLnNlc3Npb25TZXJ2aWNlLm5vZGVOYW1lTGlzdFtpdHJdO1xyXG4gICAgfVxyXG4gIH1cclxuICBuZUNpcmNsZVNob3J0TmFtZUZ1bGxOYW1lTWFwcGluZygpOiB2b2lkIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5jYWNoZS5jaXJjbGVGdWxsTmFtZUpzb25SZXNwb25zZTtcclxuICAgIGNvbnN0IGNpcmNsZVNob3J0TmFtZXNMaXN0ID0gdGhpcy5zZXNzaW9uU2VydmljZS5tYXBOZU5hbWVDaXJjbGVOYW1lW3RoaXMuc2Vzc2lvblNlcnZpY2Uubm9kZU5hbWVMaXN0WzBdXTtcclxuICAgIGlmIChjaXJjbGVTaG9ydE5hbWVzTGlzdCkge1xyXG4gICAgICBjb25zdCBjaXJjbGUgPSBjaXJjbGVTaG9ydE5hbWVzTGlzdC5zcGxpdCgnLCcpO1xyXG4gICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnNlbGVjdGVkQ2lyY2xlTmFtZSA9IHJlc3BvbnNlLkNpcmNsZU5hbWVbY2lyY2xlWzBdXTtcclxuICAgIH1cclxuICB9XHJcbiAgZ2V0QWNjZXNzSnNvbjxUPihwcm9kdWN0SWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0TW9kdWxlU3ViTW9kdWxlRGF0YSZwcm9kdWN0SWQ9JyArIHByb2R1Y3RJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXROb2RlQ2lyY2xlSnNvbjxUPihwcm9kdWN0SWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Tm9kZUNpcmNsZURhdGEmcHJvZHVjdElkPScgKyBwcm9kdWN0SWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0TW9kdWxlVG9JZEpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0U2hvcnRDb2RlVG9JZE1hcCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Tm9kZVRvSWRKc29uPFQ+KHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldE5vZGVUb0lkTWFwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDaXJjbGVUb0lkSnNvbjxUPihwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1nZXRDaXJjbGVUb0lkTWFwJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZUpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Q2lyY2xlU2hvcnROYW1lRnVsbE5hbWUnLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZUpzb248VD4ocHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Tm9kZVNob3J0TmFtZUZ1bGxOYW1lJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBnZXRPcGVyYXRpb25Ub01vZHVsZU5vZGVDaXJjbGVKc29uPFQ+KHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZScsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZGVsZXRlUm9sZTxUPihyb2xlSWQscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBpZiAoIXJvbGVJZClcclxuICAgICAgdGhyb3cgXCJSb2xlIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249ZGVsZXRlUm9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5Um9sZTxUPihyb2xlSWQsIHJvbGVEYXRhLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlSWQpXHJcbiAgICAgIHRocm93IFwiUm9sZSBpZCBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICAgIH1cclxuICAgICAgZWxzZSB7XHJcbiAgICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgcm9sZURhdGEucm9sZUluZm8ucm9sZVsndXBkYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgICByb2xlRGF0YS5yb2xlSW5mby5yb2xlWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5BQ0NFU1NfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dXBkYXRlUm9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgZGF0YTogeyBcIkFwcERhdGFcIjogcm9sZURhdGEgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1JvbGU8VD4ocm9sZUlkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlSWQpXHJcbiAgICAgIHRocm93IFwiUm9sZSBpZCBpcyB1bmRlZmluZWRcIjtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLkFDQ0VTU19DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj12aWV3Um9sZSZyb2xlSWQ9JyArIHJvbGVJZCxcclxuICAgICAgaGVhZGVyczogaGVhZGVycyxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0QWxsUm9sZTxUPihmcm9tLCBzaXplLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdldEFsbFJvbGUmZnJvbT0nICsgZnJvbSArICcmc2l6ZT0nICsgc2l6ZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY2hlY2tSb2xlRXhpc3RlbmNlPFQ+KHJvbGVuYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFyb2xlbmFtZSlcclxuICAgICAgdGhyb3cgXCJyb2xlbmFtZSBpcyB1bmRlZmluZWRcIjtcclxuICAgICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuQUNDRVNTX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoZWNrUm9sZSZyb2xlTmFtZT0nICsgcm9sZW5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY3JlYXRlVXNlckdyb3VwPFQ+KGdyb3VwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1snY3JlYXRlZE9uJ10gPSBuZXcgRGF0ZShjdXJyZW50RGF0ZS5nZXRUaW1lKCkgKyB0aGlzLmNhY2hlLnRpbWVBZGp1c3RtZW50ICsgMTk4MDAwMDApO1xyXG4gICAgZ3JvdXBEYXRhLmdyb3VwSW5mb1snY3JlYXRlZEJ5J10gPSB0aGlzLmNhY2hlLlhfVVNFUk5BTUU7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWyd1cGRhdGVkT24nXSA9IG5ldyBEYXRlKGN1cnJlbnREYXRlLmdldFRpbWUoKSArIHRoaXMuY2FjaGUudGltZUFkanVzdG1lbnQgKyAxOTgwMDAwMCk7XHJcbiAgICBncm91cERhdGEuZ3JvdXBJbmZvWyd1cGRhdGVkQnknXSA9IHRoaXMuY2FjaGUuWF9VU0VSTkFNRTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1jcmVhdGVHcm91cCcsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiBncm91cERhdGEgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHZpZXdVc2VyR3JvdXA8VD4oZ3JvdXBJZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghZ3JvdXBJZClcclxuICAgICAgdGhyb3cgXCJncm91cElkIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj12aWV3R3JvdXAmZ3JvdXBJZD0nICsgZ3JvdXBJZCxcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdmlld1VzZXJHcm91cExpc3Q8VD4oZnJvbSwgc2l6ZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdHcm91cExpc3QmZnJvbT0nICsgZnJvbSArICcmc2l6ZT0nICsgc2l6ZSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICB2aWV3QWxsR3JvdXA8VD4oZnJvbSwgc2l6ZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXZpZXdBbGxHcm91cCZmcm9tPScgKyBmcm9tICsgJyZzaXplPScgKyBzaXplLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGRlbGV0ZVVzZXJHcm91cDxUPihncm91cElkLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgaWYgKCFncm91cElkKVxyXG4gICAgICB0aHJvdyBcImdyb3VwSWQgaWQgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWRlbGV0ZUdyb3VwJmdyb3VwSWQ9JyArIGdyb3VwSWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZGVsZXRlRGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbW9kaWZ5VXNlckdyb3VwPFQ+KGdyb3VwSWQsIGdyb3VwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghZ3JvdXBJZClcclxuICAgICAgdGhyb3cgXCJncm91cElkIGlkIGlzIHVuZGVmaW5lZFwiO1xyXG4gICAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRPbiddID0gbmV3IERhdGUoY3VycmVudERhdGUuZ2V0VGltZSgpICsgdGhpcy5jYWNoZS50aW1lQWRqdXN0bWVudCArIDE5ODAwMDAwKTtcclxuICAgIGdyb3VwRGF0YS5ncm91cEluZm9bJ3VwZGF0ZWRCeSddID0gdGhpcy5jYWNoZS5YX1VTRVJOQU1FO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPW1vZGlmeUdyb3VwJmdyb3VwSWQ9JyArIGdyb3VwSWQsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHsgJ0FwcERhdGEnOiBncm91cERhdGEgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgbG9ja1VzZXI8VD4odXNlck5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1sb2NrVXNlciZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdW5sb2NrVXNlcjxUPih1c2VyTmFtZSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPXVubG9ja1VzZXImdXNlck5hbWU9JyArIHVzZXJOYW1lLFxyXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFQ+KG9ic2VydmUgPT4ge1xyXG4gICAgICB0aGlzLmh0dHBTZXJ2aWNlLmdldERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGxvY2tHcm91cDxUPihncm91cE5hbWUscHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5JREVOVElUWV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1sb2NrR3JvdXAmZ3JvdXBOYW1lPScgKyBncm91cE5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgdW5sb2NrR3JvdXA8VD4oZ3JvdXBOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249dW5sb2NrR3JvdXAmZ3JvdXBOYW1lPScgKyBncm91cE5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UuZ2V0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2V0Q291bnRVc2VyczxUPihyb2xlSWRKc29uLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0Q291bnRVc2VycycsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6cm9sZUlkSnNvblxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgY2hhbmdlUGFzc3dvcmQ8VD4odXNlck5hbWUsIG9sZFBhc3N3b3JkLCBuZXdQYXNzd29yZCxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWNoYW5nZVBhc3N3b3JkJnVzZXJOYW1lPScgKyB1c2VyTmFtZSxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIFwidXNlckluZm9cIjoge1xyXG4gICAgICAgICAgXCJ1c2VyTmFtZVwiOiB1c2VyTmFtZSxcclxuICAgICAgICAgIFwib2xkVXNlclBhc3N3b3JkXCI6IEFlc1V0aWxzLmVuY3J5cHQob2xkUGFzc3dvcmQpLFxyXG4gICAgICAgICAgXCJuZXdVc2VyUGFzc3dvcmRcIjogQWVzVXRpbHMuZW5jcnlwdChuZXdQYXNzd29yZClcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGZvcmdvdFBhc3N3b3JkPFQ+KHVzZXJOYW1lLHByb2plY3Q/OnN0cmluZyk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IEh0dHBIZWFkZXJzO1xyXG4gICAgaWYgKCFwcm9qZWN0KSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzp0aGlzLmFwcENvbmZpZ3VyYXRpb24uZ2V0Q29uZmlndXJhdGlvbigpLnByb2plY3R9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6cHJvamVjdH0pXHJcbiAgICB9XHJcbiAgICBoZWFkZXJzPWhlYWRlcnMuYXBwZW5kKFwidXNlck5hbWVcIix1c2VyTmFtZSk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Zm9yZ290UGFzc293b3JkJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBpbnNlcnRUcmFjZURhdGE8VD4odXNlck5hbWUsb3BlcmF0aW9uOnN0cmluZyxyZXF1ZXN0UGFyYW1ldGVyczpzdHJpbmcscmVxdWVzdEhlYWRlcnM6c3RyaW5nLHByb2plY3Q/OnN0cmluZywpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgbGV0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKS5hcHBlbmQoXCJvcGVyYXRpb25cIixvcGVyYXRpb24pLmFwcGVuZChcInRpbWVzdGFtcFwiLGN1cnJlbnREYXRlLmdldFRpbWUoKS50b1N0cmluZygpKTtcclxuICAgIGNvbnN0IHJlcXVlc3Q6IFJlcXVlc3QgPSB7XHJcbiAgICAgIGNvbnRleHQ6IENPTlNUQU5UUy5UUkFDRV9DT05URVhULFxyXG4gICAgICBxdWVyeVN0cmluZzogJ29wZXJhdGlvbj1pbnNlcnRUcmFjZURhdGEnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgICBcInJlcXVlc3RQYXJhbWV0ZXJzXCI6IHtyZXF1ZXN0UGFyYW1ldGVyc30sXHJcbiAgICAgICAgICBcInJlcXVlc3RIZWFkZXJzXCI6IHtyZXF1ZXN0SGVhZGVyc30sXHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGdldFRyYWNlRGF0YTxUPih1c2VyTmFtZSxvcGVyYXRpb246c3RyaW5nLHRyYWNlTGV2ZWw6c3RyaW5nLGZyb21UaW1lU3RhbXA6c3RyaW5nLHRvVGltZVN0YW1wOnN0cmluZyxwcm9qZWN0PzpzdHJpbmcsKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKS5hcHBlbmQoXCJvcGVyYXRpb25cIixvcGVyYXRpb24pLmFwcGVuZChcInRyYWNlTGV2ZWxcIix0cmFjZUxldmVsKS5hcHBlbmQoXCJmcm9tVGltZVN0YW1wXCIsZnJvbVRpbWVTdGFtcCkuYXBwZW5kKFwidG9UaW1lU3RhbXBcIix0b1RpbWVTdGFtcCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuVFJBQ0VfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249Z2V0VHJhY2VEYXRhJyxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5nZXREYXRhPFQ+KHJlcXVlc3QpLnN1YnNjcmliZShyZXNwID0+IHtcclxuICAgICAgICBvYnNlcnZlLm5leHQocmVzcC5ib2R5KTtcclxuICAgICAgfSwgZXJyb3IgPT4ge1xyXG4gICAgICAgIG9ic2VydmUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuICByZXNldFBhc3N3b3JkPFQ+KHVzZXJOYW1lOiBzdHJpbmcsIG90cDogU3RyaW5nLCBuZXdQYXNzd29yZDogc3RyaW5nLGNvbmZpcm1QYXNzd29yZDogc3RyaW5nLCBwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgaGVhZGVycz1oZWFkZXJzLmFwcGVuZChcInVzZXJOYW1lXCIsdXNlck5hbWUpO1xyXG4gICAgbGV0IHBhc3N3b3JkOnN0cmluZyA9UnNhVXRpbHMuZW5jcnlwdChuZXdQYXNzd29yZCk7XHJcbiAgICBjb25zdCByZXF1ZXN0OiBSZXF1ZXN0ID0ge1xyXG4gICAgICBjb250ZXh0OiBDT05TVEFOVFMuSURFTlRJVFlfQ09OVEVYVCxcclxuICAgICAgcXVlcnlTdHJpbmc6ICdvcGVyYXRpb249cmVzZXRQYXNzd29yZCcsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBcInVzZXJJbmZvXCI6IHtcclxuICAgICAgICAgIFwidXNlck5hbWVcIjogdXNlck5hbWUsXHJcbiAgICAgICAgICBcIm5ld1Bhc3N3b3JkXCI6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgXCJjb25maXJtUGFzc3dvcmRcIjogcGFzc3dvcmQsXHJcbiAgICAgICAgICBcIm90cFwiOm90cFxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgZ2VuZXJhdGVQYXNzd29yZDxUPih1c2VyTmFtZTogc3RyaW5nLCBvdHA6IFN0cmluZywgbmV3UGFzc3dvcmQ6IHN0cmluZyxjb25maXJtUGFzc3dvcmQ6IHN0cmluZywgcHJvamVjdD86c3RyaW5nKTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICBsZXQgaGVhZGVyczogSHR0cEhlYWRlcnM7XHJcbiAgICBpZiAoIXByb2plY3QpIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkucHJvamVjdH0pO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoeydwcm9qZWN0Jzpwcm9qZWN0fSlcclxuICAgIH1cclxuICAgIGhlYWRlcnM9aGVhZGVycy5hcHBlbmQoXCJ1c2VyTmFtZVwiLHVzZXJOYW1lKTtcclxuICAgIGxldCBwYXNzd29yZDpzdHJpbmcgPVJzYVV0aWxzLmVuY3J5cHQobmV3UGFzc3dvcmQpO1xyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPWdlbmVyYXRlUGFzc3dvcmQnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgXCJ1c2VySW5mb1wiOiB7XHJcbiAgICAgICAgICBcInVzZXJOYW1lXCI6IHVzZXJOYW1lLFxyXG4gICAgICAgICAgXCJuZXdQYXNzd29yZFwiOiBwYXNzd29yZCxcclxuICAgICAgICAgIFwiY29uZmlybVBhc3N3b3JkXCI6IHBhc3N3b3JkLFxyXG4gICAgICAgICAgXCJvdHBcIjpvdHBcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgIH07XHJcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VD4ob2JzZXJ2ZSA9PiB7XHJcbiAgICAgIHRoaXMuaHR0cFNlcnZpY2UucG9zdERhdGE8VD4ocmVxdWVzdCkuc3Vic2NyaWJlKHJlc3AgPT4ge1xyXG4gICAgICAgIG9ic2VydmUubmV4dChyZXNwLmJvZHkpO1xyXG4gICAgICB9LCBlcnJvciA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4gIG1vZGlmeVVzZXJJbWFnZTxUPih1c2VyTmFtZSwgQXBwRGF0YSxwcm9qZWN0PzpzdHJpbmcpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgIGlmICghdXNlck5hbWUpXHJcbiAgICAgIHRocm93IFwidXNlck5hbWUgaXMgdW5kZWZpbmVkXCI7XHJcbiAgICAgIGxldCBoZWFkZXJzOiBIdHRwSGVhZGVycztcclxuICAgIGlmICghcHJvamVjdCkge1xyXG4gICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKHsncHJvamVjdCc6dGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0fSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7J3Byb2plY3QnOnByb2plY3R9KVxyXG4gICAgfVxyXG4gICAgY29uc3QgcmVxdWVzdDogUmVxdWVzdCA9IHtcclxuICAgICAgY29udGV4dDogQ09OU1RBTlRTLklERU5USVRZX0NPTlRFWFQsXHJcbiAgICAgIHF1ZXJ5U3RyaW5nOiAnb3BlcmF0aW9uPW1vZGlmeVVzZXJJbWFnZSZ1c2VyTmFtZT0nICsgdXNlck5hbWUsXHJcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICAnQXBwRGF0YSc6IEFwcERhdGFcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUPihvYnNlcnZlID0+IHtcclxuICAgICAgdGhpcy5odHRwU2VydmljZS5wb3N0RGF0YTxUPihyZXF1ZXN0KS5zdWJzY3JpYmUocmVzcCA9PiB7XHJcbiAgICAgICAgb2JzZXJ2ZS5uZXh0KHJlc3AuYm9keSk7XHJcbiAgICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgICBvYnNlcnZlLmVycm9yKGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgV2ViU29ja2V0Q2FsbGJhY2tzIHtcclxuICBvbk9wZW4/OiAoZXZlbnQ/OiBhbnksd2Vic29ja2V0PzogV2ViU29ja2V0KSA9PiB2b2lkO1xyXG4gIG9uQ2xvc2U/OiAoZXZlbnQ/OiBhbnkpID0+IHZvaWQ7XHJcbiAgb25FcnJvcj86IChldmVudD86IGFueSkgPT4gdm9pZDtcclxuICBvbk1lc3NhZ2U6IChldmVudD86IGFueSkgPT4gdm9pZDtcclxufVxyXG4iLCJpbXBvcnQgeyBIdHRwSW50ZXJjZXB0b3IsIEh0dHBSZXF1ZXN0LCBIdHRwSGFuZGxlciwgSHR0cFJlc3BvbnNlLCBIdHRwRXZlbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgU2Vzc2lvblNlcnZpY2UgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IENhY2hlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuL2NhY2hlLW1hbmFnZXIuc2VydmljZSc7XHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEh0dHBSZXNwb25zZUludGVyY2VwdG9yIGltcGxlbWVudHMgSHR0cEludGVyY2VwdG9yIHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc2Vzc2lvblNlcnZpY2U6IFNlc3Npb25TZXJ2aWNlLCBwcml2YXRlIGFwcENvbmZpZ3VyYXRpb246IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgY2FjaGU6IENhY2hlTWFuYWdlclNlcnZpY2UpIHsgfVxyXG4gICAgaW50ZXJjZXB0KHJlcTogSHR0cFJlcXVlc3Q8YW55PiwgbmV4dDogSHR0cEhhbmRsZXIpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUuWF9TT0NLRVRfQUREUkVTUykge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdYLVNPQ0tFVC1BRERSRVNTJzogdGhpcy5jYWNoZS5YX1NPQ0tFVF9BRERSRVNTXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jYWNoZS5YX1VTRVJOQU1FKSB7XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ1gtVVNFUk5BTUUnOiB0aGlzLmNhY2hlLlhfVVNFUk5BTUVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNhY2hlLlNPQ0tFVF9JUCkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdzb2NrZXRJcCc6IHRoaXMuY2FjaGUuU09DS0VUX0lQXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVxLmhlYWRlcnMuaGFzKCdYLUV2ZW50LU5hbWUnKSkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogcmVxLmhlYWRlcnMuZ2V0KCdYLUV2ZW50LU5hbWUnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAocmVxLmhlYWRlcnMuaGFzKCdFdmVudC1LZXknKSkge1xyXG4gICAgICAgICAgICByZXEgPSByZXEuY2xvbmUoe1xyXG4gICAgICAgICAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbjogcmVxLmhlYWRlcnMuZ2V0KCdFdmVudC1LZXknKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9ICBlbHNlIGlmIChyZXEucGFyYW1zLmhhcygnb3BlcmF0aW9uJykpIHtcclxuICAgICAgICAgICAgcmVxID0gcmVxLmNsb25lKHtcclxuICAgICAgICAgICAgICAgIHNldEhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBvcGVyYXRpb246IHJlcS5wYXJhbXMuZ2V0KCdvcGVyYXRpb24nKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzICYmIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyICYmXHJcbiAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lICYmXHJcbiAgICAgICAgICAgIHRoaXMuYXBwQ29uZmlndXJhdGlvbi5nZXRDb25maWd1cmF0aW9uKCkgJiYgdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0KSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJUb2tlbiA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0VXNlclRva2VuRGF0YSgpO1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHRoaXMuc2Vzc2lvblNlcnZpY2UuZ2V0U2Vzc2lvbkRhdGEoKS5nbG9iYWxzLmN1cnJlbnRVc2VyLnVzZXJOYW1lO1xyXG4gICAgICAgICAgICBsZXQgcHJvZHVjdDogc3RyaW5nO1xyXG4gICAgICAgICAgICBwcm9kdWN0ID0gcmVxLmhlYWRlcnMuZ2V0KFwicHJvamVjdFwiKTtcclxuICAgICAgICAgICAgaWYgKCFwcm9kdWN0KSB7XHJcbiAgICAgICAgICAgICAgICBwcm9kdWN0ID0gdGhpcy5hcHBDb25maWd1cmF0aW9uLmdldENvbmZpZ3VyYXRpb24oKS5wcm9qZWN0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlcSA9IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgICAgICAgICBzZXRIZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclRva2VuOiBgJHt1c2VyTmFtZX0tJHt1c2VyVG9rZW59YCxcclxuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0OiBwcm9kdWN0XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV4dC5oYW5kbGUocmVxKS5waXBlKHRhcChyZXNwb25zZSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcCA9IHJlc3BvbnNlIGFzIEh0dHBSZXNwb25zZTxhbnk+O1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3AuaGVhZGVycy5oYXMoJ3VzZXJUb2tlbicpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXNzaW9uU2VydmljZS5zZXRVc2VyVG9rZW5EYXRhKHJlc3AuaGVhZGVycy5nZXQoJ3VzZXJUb2tlbicpKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNlc3Npb25TZXJ2aWNlLnB1dERhdGVGb3JDb29raWVFeHBpcnkoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5ib2R5ICYmIHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXVsnaHR0cHN0YXR1c2NvZGUnXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5ib2R5WydzdGF0dXNDb2RlJ11bJ2h0dHBzdGF0dXNjb2RlJ10gPT09IDQwMSAmJiAocmVzcG9uc2UuYm9keVsnc3RhdHVzQ29kZSddWydvcFN0YXR1c0NvZGUnXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA9PT0gOTAzIHx8IHJlc3BvbnNlLmJvZHlbJ3N0YXR1c0NvZGUnXVsnb3BTdGF0dXNDb2RlJ10gPT09IDQwMzApKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vzc2lvblNlcnZpY2UuY2xlYXJTZXNzaW9uRGF0YUFuZEdvdG9TZXNzaW9uRXhwaXJlUGFnZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItaWFtJyxcclxuICB0ZW1wbGF0ZTogYFxyXG4gICAgPHA+XHJcbiAgICAgIGlhbSB3b3JrcyFcclxuICAgIDwvcD5cclxuICBgLFxyXG4gIHN0eWxlczogW11cclxufSlcclxuZXhwb3J0IGNsYXNzIElhbUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBDYWNoZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWNoZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBBcHBDb25maWd1cmF0aW9uU2VydmljZSB9IGZyb20gJy4vYXBwLWNvbmZpZ3VyYXRpb24uc2VydmljZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUFwcChhcHBDb25maWd1cmF0aW9uU2VydmljZTogQXBwQ29uZmlndXJhdGlvblNlcnZpY2UsXHJcbiAgICBjYWNoZTogQ2FjaGVNYW5hZ2VyU2VydmljZSkge1xyXG4gICAgcmV0dXJuICgpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgYXBwQ29uZmlndXJhdGlvblNlcnZpY2UubG9hZENvbmZpZ3VyYXRpb24oJ2Fzc2V0cy9jb25maWd1cmF0aW9uL2NvbmZpZy5qc29uJykudGhlbigoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZ2V0UnNhS2V5UHJvbWlzZSA9IGNhY2hlLmdldEF1dGhLZXkoKTtcclxuICAgICAgICBjb25zdCBzdGFydFVwUm91dGVDaGFuZ2VQcm9taXNlID0gY2FjaGUub25TdGFydHVwUm91dGVDaGFuZ2UoZXZlbnQpO1xyXG4gICAgICAgIFByb21pc2UuYWxsKFtnZXRSc2FLZXlQcm9taXNlLCBzdGFydFVwUm91dGVDaGFuZ2VQcm9taXNlXSkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBub2RlU2hvcnRGdWxsUHJvbWlzZSA9IGNhY2hlLmdldE5vZGVTaG9ydE5hbWVGdWxsTmFtZUpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IGNpcmNsZVNob3J0RnVsbFByb21pc2UgPSBjYWNoZS5nZXRDaXJjbGVTaG9ydE5hbWVGdWxsTmFtZUpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IG1vZHVsZVRvSWRQcm9taXNlID0gY2FjaGUuZ2V0TW9kdWxlVG9JZEpzb24oKTtcclxuICAgICAgICAgIGNvbnN0IG5vZGVUb0lkUHJvbWlzZSA9IGNhY2hlLmdldE5vZGVUb0lkSnNvbigpO1xyXG4gICAgICAgICAgY29uc3QgY2lyY2xlVG9JZFByb21pc2UgPSBjYWNoZS5nZXRDaXJjbGVUb0lkSnNvbigpO1xyXG4gICAgICAgICAgY29uc3Qgb3BlcmF0aW9uVG9Nb2R1bGVOb2RlQ2lyY2xlUHJvbWlzZSA9IGNhY2hlLmdldE9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZUpzb24oKTtcclxuICAgICAgICAgIFByb21pc2UuYWxsKFtub2RlU2hvcnRGdWxsUHJvbWlzZSwgY2lyY2xlU2hvcnRGdWxsUHJvbWlzZSwgbW9kdWxlVG9JZFByb21pc2UsXHJcbiAgICAgICAgICAgIG5vZGVUb0lkUHJvbWlzZSwgY2lyY2xlVG9JZFByb21pc2UsIG9wZXJhdGlvblRvTW9kdWxlTm9kZUNpcmNsZVByb21pc2VdKS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgIGNhY2hlLmNhbGxXaGVuQ29uZmlnTG9hZHMoKTtcclxuICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgIH0sIChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgIHJlamVjdCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgcmVqZWN0KCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG4iLCJpbXBvcnQgeyBOZ01vZHVsZSwgQVBQX0lOSVRJQUxJWkVSLCBNb2R1bGVXaXRoUHJvdmlkZXJzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElhbUNvbXBvbmVudCB9IGZyb20gJy4vaWFtLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9hcHAtY29uZmlndXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ2FjaGVNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4vY2FjaGUtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU2Vzc2lvblNlcnZpY2UgfSBmcm9tICcuL3Nlc3Npb24uc2VydmljZSc7XHJcbmltcG9ydCB7IElhbVNlcnZpY2UgfSBmcm9tICcuL2lhbS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29va2llU2VydmljZSB9IGZyb20gJ25neC1jb29raWUtc2VydmljZSc7XHJcbmltcG9ydCB7IEhUVFBfSU5URVJDRVBUT1JTIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBIdHRwUmVzcG9uc2VJbnRlcmNlcHRvciB9IGZyb20gJy4vaHR0cC1yZXNwb25zZS1pbnRlcmNlcHRvcic7XHJcbmltcG9ydCB7IGluaXRpYWxpemVBcHAgfSBmcm9tICcuL2NvbmZpZ3VyYXRpb24tZmFjdG9yeSc7XHJcblxyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtJYW1Db21wb25lbnRdLFxyXG4gIGV4cG9ydHM6IFtJYW1Db21wb25lbnRdLFxyXG4gIHByb3ZpZGVyczogWyBJYW1TZXJ2aWNlLCBDb29raWVTZXJ2aWNlICwgU2Vzc2lvblNlcnZpY2UsIEFwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLCBDYWNoZU1hbmFnZXJTZXJ2aWNlLCB7XHJcbiAgICBwcm92aWRlOiBBUFBfSU5JVElBTElaRVIsXHJcbiAgICB1c2VGYWN0b3J5OiBpbml0aWFsaXplQXBwLFxyXG4gICAgZGVwczogW0FwcENvbmZpZ3VyYXRpb25TZXJ2aWNlLCBDYWNoZU1hbmFnZXJTZXJ2aWNlXSxcclxuICAgIG11bHRpOiB0cnVlXHJcbiAgfSwge1xyXG4gICAgcHJvdmlkZTogSFRUUF9JTlRFUkNFUFRPUlMsXHJcbiAgICB1c2VDbGFzczogSHR0cFJlc3BvbnNlSW50ZXJjZXB0b3IsXHJcbiAgICBtdWx0aTogdHJ1ZVxyXG4gIH1dXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJYW1Nb2R1bGUge1xyXG4gIHB1YmxpYyBzdGF0aWMgZm9yUm9vdCgpOiBNb2R1bGVXaXRoUHJvdmlkZXJzIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIG5nTW9kdWxlOiBJYW1Nb2R1bGUsXHJcbiAgICAgIHByb3ZpZGVyczogW11cclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJhZXNqcy51dGlscyIsImFlc2pzLnBhZGRpbmciLCJhZXNqcy5Nb2RlT2ZPcGVyYXRpb24iLCJBcHBTZXR0aW5nIiwiZm9yZ2UudXRpbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7O0lBT0ksV0FBVztRQUNQLE9BQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQztLQUM1Qjs7cUJBUHlDLEdBQUcsUUFBUSxDQUFDLFFBQVEsSUFBSTsrQkFDZCxRQUFRLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsUUFBUSxHQUFHLE9BQU87NkJBQ3RFLGdCQUFnQjsyQkFDbEIsY0FBYzswQkFDZixhQUFhOzs7Ozs7QUNOaEU7Ozs7SUFRRSxZQUFvQixVQUFzQjtRQUF0QixlQUFVLEdBQVYsVUFBVSxDQUFZO0tBQUs7Ozs7O0lBQy9DLGlCQUFpQixDQUFDLFFBQWdCO1FBQ2hDLE9BQU8sSUFBSSxPQUFPLENBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBbUIsUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUTtnQkFDeEUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztnQkFDakMsT0FBTyxFQUFFLENBQUM7YUFDWCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBYTtnQkFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQ0FBK0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZGLE1BQU0sQ0FBQywrQ0FBK0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDckYsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDTSxnQkFBZ0I7UUFDckIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Ozs7WUFuQmhDLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7OztZQUpRLFVBQVU7Ozs7Ozs7OztBQ0RuQixNQUFPLEtBQUssR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDckM7SUFHSSxpQkFBZ0I7Ozs7O0lBQ1QsT0FBTyxpQkFBaUIsQ0FBQyxnQkFBd0I7UUFDcEQsUUFBUSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLENBQUM7Ozs7O0lBRWpFLE9BQU8sY0FBYztRQUN4QixPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQzs7Ozs7O0lBRWpELE9BQU8sZ0JBQWdCLENBQUMsZ0JBQXdCO1FBQ25ELFFBQVEsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzs7Ozs7O0lBRS9ELE9BQU8sT0FBTyxDQUFDLE9BQWUsRUFBRSxZQUFxQjtRQUN4RCxJQUFJLFlBQVksRUFBRTtZQUNkLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRTtnQkFDOUYsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDNUIsSUFBSSxFQUFFO29CQUNGLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7aUJBQzdCO2FBQ0osQ0FBQyxDQUFDLENBQUM7U0FDUDthQUFNLElBQUksUUFBUSxDQUFDLFNBQVMsRUFBRTtZQUMzQixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUU7Z0JBQ3ZFLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQzVCLElBQUksRUFBRTtvQkFDRixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2lCQUM3QjthQUNKLENBQUMsQ0FBQyxDQUFDO1NBQ1A7YUFBTTtZQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQztZQUN6QyxPQUFPLElBQUksQ0FBQztTQUNmOzs7Ozs7O0lBRUUsT0FBTyxPQUFPLENBQUMsVUFBa0IsRUFBRSxhQUFzQjtRQUM1RCxJQUFJLGFBQWEsRUFBRTtZQUNmLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUUsVUFBVSxFQUFFO2dCQUNuRyxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUM1QixJQUFJLEVBQUU7b0JBQ0YsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtpQkFDN0I7YUFDSixDQUFDLENBQUM7U0FDTjthQUFNLElBQUksUUFBUSxDQUFDLFVBQVUsRUFBRTtZQUM1QixPQUFPLFFBQVEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLFVBQVUsRUFBRTtnQkFDNUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDNUIsSUFBSSxFQUFFO29CQUNGLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7aUJBQzdCO2FBQ0osQ0FBQyxDQUFDO1NBQ047YUFBTTtZQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQztZQUMxQyxPQUFPLElBQUksQ0FBQztTQUNmOzs7OztJQUVMLGVBQWU7O1FBQ1gsTUFBTSxhQUFhLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7O1FBQ3RFLE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDbEUsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0tBQ3hEOztxQkF4RDBCLElBQUk7c0JBQ0gsSUFBSTs7Ozs7O0FDSHBDO0lBS0ksaUJBQWdCOzs7OztJQUNULE9BQU8sbUJBQW1CLENBQUMsTUFBYztRQUM1QyxRQUFRLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzs7Ozs7OztJQUV0QixPQUFPLE9BQU8sQ0FBQyxPQUFlLEVBQUUsTUFBZTtRQUNsRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1QsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7U0FDNUI7O1FBQ0QsTUFBTSxHQUFHLEdBQUdBLEtBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUM3QyxJQUFJLFNBQVMsR0FBR0EsS0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbEQsU0FBUyxHQUFHLElBQUlDLE9BQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDOztRQUNuRCxNQUFNLE1BQU0sR0FBRyxJQUFJQyxlQUFxQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7UUFDbEQsTUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRCxPQUFPRixLQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQzs7Ozs7OztJQUU5QyxPQUFPLE9BQU8sQ0FBQyxNQUFjLEVBQUUsTUFBZTtRQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1QsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7U0FDNUI7O1FBQ0QsTUFBTSxHQUFHLEdBQUdBLEtBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUM3QyxNQUFNLE1BQU0sR0FBRyxJQUFJRSxlQUFxQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7UUFDbEQsTUFBTSxjQUFjLEdBQUdGLEtBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOztRQUN2RCxJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3BELGNBQWMsR0FBR0MsT0FBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDM0QsT0FBUUQsS0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7OztJQUVoRCxPQUFPLG9CQUFvQixDQUFDLFNBQWdCLEVBQUU7O1FBQ2pELE1BQU0sR0FBRyxHQUF3QixJQUFJLEdBQUcsRUFBa0IsQ0FBQztRQUMzRCxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO1lBQzNFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQ3RGLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7WUFDaEUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7WUFDMUYsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7WUFDMUYsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7WUFDMUYsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUM7WUFDMUYsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7O1FBQzlFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUNiLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0IsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDN0Q7UUFDRCxPQUFPLEdBQUcsQ0FBQzs7Ozs7SUFFZixRQUFRO0tBQ1A7O2tCQTVDK0IsSUFBSTs7Ozs7O0FDSnhDOzs7O0lBUUUsWUFBb0IsTUFBYztRQUFkLFdBQU0sR0FBTixNQUFNLENBQVE7S0FBSzs7Ozs7SUFDdkMsUUFBUSxDQUFDLElBQWM7UUFDckIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDNUI7OztZQVJGLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7OztZQUpRLE1BQU07Ozs7Ozs7O0FDRGY7Ozs7OztnQkF5QjZCLGFBQTRCLEVBQVUsVUFBc0IsRUFBVSxlQUFnQztRQUF0RyxrQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUFVLGVBQVUsR0FBVixVQUFVLENBQVk7UUFBVSxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7dUJBWHZHLElBQUksWUFBWSxDQUFDLEVBQUMsY0FBYyxFQUFHLElBQUksRUFBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDOzs7Ozs7SUFlbEcsY0FBYyxDQUFDLE1BQWMsU0FBUzs7UUFFcEMsSUFBSSxJQUFJLENBQU87O1FBQ2YsTUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUNuQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUN6SDthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO1lBQ2hELElBQUkscUJBQUcsRUFBVSxDQUFBLENBQUM7U0FDbkI7UUFDRCx5QkFBTyxJQUEyQixFQUFDO0tBQ3BDOzs7OztJQUlELFNBQVMsQ0FBQyxNQUFjLFFBQVE7O1FBQzlCLE1BQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDM0c7UUFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7Ozs7SUFJRCxjQUFjLENBQUMsV0FBK0IsRUFBRSxHQUFHLEdBQUcsU0FBUzs7UUFDN0QsTUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDOztRQUNoQixNQUFNLGVBQWUsR0FBRztZQUNwQixXQUFXLEVBQUU7Z0JBQ1gsUUFBUSxFQUFFLFdBQVcsQ0FBQyxRQUFRO2dCQUM5QixPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU87Z0JBQzVCLGNBQWMsRUFBRSxXQUFXLENBQUMsY0FBYzthQUMzQztTQUNKLENBQUM7UUFDRixJQUFJLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRTtZQUNoQyxlQUFlLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsV0FBVyxDQUFDLGdCQUFnQixDQUFDO1NBQ2hGO1FBQ0QsSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFO1lBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO1NBQ3JDO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGVBQWUsQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQ25GOzs7OztJQUlELGdCQUFnQixDQUFDLEdBQUcsSUFBYztRQUNoQyxJQUFLLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BCLEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxFQUFFO2dCQUN0QixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNoQztTQUNGO2FBQU07WUFDTCxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQy9CLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUN0QjtLQUNGOzs7OztJQUlELHNCQUFzQixDQUFDLFNBQWtCOztRQUN2QyxJQUFJLFdBQVcsR0FBUSxNQUFNLENBQUM7UUFDOUIsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLEVBQ3JDO1lBQ0UsV0FBVyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxjQUFjLENBQUM7U0FDL0Q7UUFDRCxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxXQUFXLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUN2RjthQUFNO1lBQ0wsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQ2pEO0tBQ0Y7Ozs7SUFJRCxzQkFBc0I7O1FBQ3BCLElBQUksV0FBVyxHQUFRLE1BQU0sQ0FBQztRQUM5QixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFDckM7WUFDRSxXQUFXLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGNBQWMsQ0FBQztTQUMvRDtRQUNELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDM0MsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7U0FDN0Q7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLFdBQVcsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3RGLFFBQVEsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxXQUFXLEVBQUU7S0FDN0M7Ozs7O0lBSUQsZ0JBQWdCLENBQUMsU0FBaUI7UUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQ2hGOzs7O0lBSUQsZ0JBQWdCOztRQUNkLE1BQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDM0g7UUFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7Ozs7SUFJRCxrQ0FBa0MsQ0FBQyxpQkFBdUIsRUFBRSxNQUFjLG1CQUFtQjtRQUMzRixJQUFJLFFBQU8sT0FBTyxDQUFDLEVBQUU7WUFDbkIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7U0FDOUQ7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUM1QztLQUNGOzs7OztJQUlELGtDQUFrQyxDQUFDLE1BQWMsbUJBQW1COztRQUNsRSxNQUFNLFVBQVUsR0FBVyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUN6RCxJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDakY7UUFDRCxJQUFJLENBQUMsd0NBQXdDLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDekI7Ozs7OztJQUlELHNDQUFzQyxDQUFDLHFCQUEyQixFQUFFLE1BQWMsdUJBQXVCO1FBQ3ZHLElBQUksUUFBTyxPQUFPLENBQUMsRUFBRTtZQUNuQixZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztTQUNsRTthQUFNO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1NBQzVDO0tBQ0Y7Ozs7O0lBSUQsc0NBQXNDLENBQUMsTUFBYyx1QkFBdUI7O1FBQzFFLE1BQU0sVUFBVSxHQUFXLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNqRjtRQUNELElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO1FBQ2hELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN6Qjs7Ozs7O0lBSUQsc0NBQXNDLENBQUMscUJBQTJCLEVBQUUsTUFBYyx1QkFBdUI7UUFDdkcsSUFBSSxRQUFPLE9BQU8sQ0FBQyxFQUFFO1lBQ25CLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO1NBQ2xFO2FBQU07WUFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDNUM7S0FDRjs7Ozs7SUFJRCxzQ0FBc0MsQ0FBQyxNQUFjLHVCQUF1Qjs7UUFDMUUsTUFBTSxVQUFVLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDekQsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQ2pGO1FBQ0QsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLENBQUM7UUFDaEQsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3pCOzs7O0lBSUQsd0NBQXdDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFBRTtZQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztTQUN4RjtLQUNGOzs7O0lBSUQsaUNBQWlDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1NBQ2hGO0tBQ0Y7Ozs7SUFDTyxjQUFjO1FBQ3BCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7UUFDL0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDM0IsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztRQUNoQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFDbEMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztRQUM5QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDOzs7O1lBNU4xQixVQUFVLFNBQUM7Z0JBQ1YsVUFBVSxFQUFFLE1BQU07YUFDbkI7Ozs7WUFUUSxhQUFhO1lBR2NHLHVCQUFVO1lBRXJDLGVBQWU7Ozs7Ozs7O0FDTHhCOzs7O0lBUVcsT0FBTyxzQkFBc0I7UUFDaEMsT0FBTyxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7SUFFM0QsT0FBTyxtQkFBbUI7UUFDN0IsT0FBTyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLENBQUM7Ozs7O0lBRXhELE9BQU8sb0JBQW9CO1FBQzlCLE9BQU8sc0JBQXNCLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxDQUFDOzs7OztJQUV6RCxPQUFPLG9CQUFvQjtRQUM5QixPQUFPLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7SUFFekQsT0FBTyxpQ0FBaUM7UUFDM0MsT0FBTyxzQkFBc0IsQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7SUFFdEUsT0FBTyx1QkFBdUI7UUFDakMsc0JBQXNCLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxPQUFPLEVBQWdCLENBQUM7UUFDdEUsc0JBQXNCLENBQUMsYUFBYSxHQUFJLElBQUksT0FBTyxFQUFnQixDQUFDO1FBQ3BFLHNCQUFzQixDQUFDLGNBQWMsR0FBSSxJQUFJLE9BQU8sRUFBZ0IsQ0FBQztRQUNyRSxzQkFBc0IsQ0FBQyxjQUFjLEdBQUcsSUFBSSxPQUFPLEVBQWdCLENBQUM7Ozs7OztJQUV4RSxTQUFTLENBQUMsS0FBbUI7UUFDekIsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3ZEOzs7OztJQUNELE9BQU8sQ0FBQyxLQUFtQjtRQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDaEMsc0JBQXNCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUNyRDs7Ozs7SUFDRCxPQUFPLENBQUMsS0FBbUI7UUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuQixzQkFBc0IsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3JEOzs7Ozs7SUFDRCxNQUFNLENBQUMsS0FBbUIsRUFBRSxTQUFvQjtRQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDaEMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUNwRDs7OztJQUNELFdBQVc7UUFDUCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDdEMsc0JBQXNCLENBQUMsMkJBQTJCLENBQUMsSUFBSSxFQUFFLENBQUM7S0FDN0Q7OzBDQTdDK0MsSUFBSSxPQUFPLEVBQWdCO3VDQUM5QixJQUFJLE9BQU8sRUFBZ0I7d0NBQzFCLElBQUksT0FBTyxFQUFnQjt3Q0FDM0IsSUFBSSxPQUFPLEVBQWdCO3FEQUNiLElBQUksT0FBTyxFQUFROzs7Ozs7QUNQbkY7Ozs7SUFPRSxZQUFvQixVQUFzQjtRQUF0QixlQUFVLEdBQVYsVUFBVSxDQUFZO0tBQUs7Ozs7O0lBRXhDLE9BQU8sVUFBVSxDQUFDLElBQVk7UUFDakMsT0FBTyxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxjQUFjLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyw2QkFBNkIsQ0FBQzs7Ozs7O0lBRTlHLGFBQWEsQ0FBQyxRQUFlO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVE7WUFDMUQsSUFBSSxHQUFHLENBQWdCLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFhLEVBQUUsR0FBVztnQkFDbEYsY0FBYyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBQyxLQUFLLENBQUMsQ0FBQzthQUMzRCxDQUFDLENBQUM7U0FDSixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBYTtZQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0NBQStDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzFGLENBQUMsQ0FBQzs7OzRCQVp3QyxJQUFJLEdBQUcsRUFBa0I7O1lBTjNFLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7OztZQUhRLFVBQVU7Ozs7Ozs7O0FDRG5COzs7Ozs7OztJQXVDRSxZQUFvQixnQkFBeUMsRUFBVSxVQUFzQixFQUNuRixnQkFBd0MsUUFBa0IsRUFBUyxjQUE2QjtRQUR0RixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQXlCO1FBQVUsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUNuRixtQkFBYyxHQUFkLGNBQWM7UUFBMEIsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUFTLG1CQUFjLEdBQWQsY0FBYyxDQUFlO29DQUw3RCxJQUFJLE9BQU8sQ0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNO1lBQzdFLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO1NBQ3hCLENBQUM7S0FFNkc7Ozs7SUFDL0csUUFBUSxNQUFNOzs7O0lBQ2QsV0FBVztRQUNULElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3hCO0tBQ0Y7Ozs7SUFDRCxVQUFVOztRQUNSLE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLENBQUM7O1FBQ3RFLE1BQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxDQUFDO1lBQ3BILE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTtTQUM5QixDQUFDO1FBV0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUF5QixHQUFHLEVBQUUsV0FBVyxDQUFDO2lCQUMxRCxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDMUQsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7b0JBQzdCLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ2hFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOztvQkFDbEQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDOztvQkFDbEgsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDOztvQkFFOUMsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU07b0JBQ0wsTUFBTSxFQUFFLENBQUM7aUJBQ1Y7YUFDRixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLEVBQUUsQ0FBQzthQUNWLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsNEJBQTRCOztRQUMxQixNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMscUNBQXFDLENBQUMsQ0FBQzs7UUFDbEYsTUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTztnQkFDM0QsV0FBVyxFQUFFLDBCQUEwQjthQUN4QyxDQUFDO1NBQ0gsQ0FBQztRQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN6RixTQUFTLENBQUMsSUFBSTtnQkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUN4QixJQUFJLENBQUMsdUJBQXVCLEdBQUc7d0JBQzdCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU87cUJBQ3BDLENBQUM7b0JBQ0YsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU07b0JBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNkO2FBQ0YsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsOEJBQThCOztRQUM1QixNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsdUNBQXVDLENBQUMsQ0FBQzs7UUFDcEYsTUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTztnQkFDM0QsV0FBVyxFQUFFLDRCQUE0QjthQUMxQyxDQUFDO1NBQ0gsQ0FBQztRQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN6RixTQUFTLENBQUMsSUFBSTtnQkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUN4QixJQUFJLENBQUMsMEJBQTBCLEdBQUc7d0JBQ2hDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU87cUJBQ3BDLENBQUM7b0JBQ0YsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU07b0JBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNkO2FBQ0YsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsaUJBQWlCOztRQUNmLE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDOztRQUM3RSxNQUFNLFdBQVcsR0FBRztZQUNsQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUM7Z0JBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPO2dCQUMzRCxXQUFXLEVBQUUscUJBQXFCO2FBQ25DLENBQUM7U0FDSCxDQUFDO1FBU0YsT0FBTyxJQUFJLE9BQU8sQ0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFXLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3pGLFNBQVMsQ0FBQyxJQUFJO2dCQUNiLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUU7b0JBQ3hCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDaEQsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU07b0JBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNkO2FBQ0YsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsZUFBZTs7UUFDYixNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQzs7UUFDeEUsTUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTztnQkFDM0QsV0FBVyxFQUFFLGdCQUFnQjthQUM5QixDQUFDO1NBQ0gsQ0FBQztRQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN6RixTQUFTLENBQUMsSUFBSTtnQkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUMzQyxPQUFPLEVBQUUsQ0FBQztpQkFDWDtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Q7YUFDRixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ2YsQ0FBQyxDQUFDO1NBQ04sQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDRCxpQkFBaUI7O1FBQ2YsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO2FBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUM7O1FBQzFFLE1BQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQztnQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87Z0JBQzNELFdBQVcsRUFBRSxrQkFBa0I7YUFDaEMsQ0FBQztTQUNILENBQUM7UUFTRixPQUFPLElBQUksT0FBTyxDQUFPLENBQUMsT0FBTyxFQUFFLE1BQU07WUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQVcsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDekYsU0FBUyxDQUFDLElBQUk7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDN0MsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU07b0JBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNkO2FBQ0YsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNmLENBQUMsQ0FBQztTQUNOLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0Qsa0NBQWtDOztRQUNoQyxNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDL0UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsMkNBQTJDLENBQUMsQ0FBQzs7UUFDeEYsTUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTztnQkFDM0QsV0FBVyxFQUFFLGdDQUFnQzthQUM5QyxDQUFDO1NBQ0gsQ0FBQztRQVNGLE9BQU8sSUFBSSxPQUFPLENBQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTTtZQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBVyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN6RixTQUFTLENBQUMsSUFBSTtnQkFDYixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUN4QixJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQ3hELE9BQU8sRUFBRSxDQUFDO2lCQUNYO3FCQUFNO29CQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDZDthQUNGLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7OztJQUNELFdBQVc7UUFDVCxPQUFPLE1BQU0sQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3BGOzs7OztJQUNDLG9CQUFvQixDQUFDLEtBQUs7UUFFeEIsT0FBTyxJQUFJLE9BQU8sQ0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3ZDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRTtnQkFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO2FBQ2xDO1lBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsa0JBQWtCO21CQUNoSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTs7Z0JBQ25FLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BDLElBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFDekI7b0JBQ0UsUUFBUSxHQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2pDOztnQkFDRCxNQUFNLGNBQWMsR0FBWSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUM7O2dCQUNuSCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7Z0JBQzFELElBQUksY0FBYyxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDckUsT0FBTyxFQUFFLENBQUM7aUJBQ1g7cUJBQU0sSUFBSSxRQUFRLEVBQUU7b0JBQ25CLElBQUk7d0JBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEVBQUU7NEJBQzFDLElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDO3lCQUNsRzt3QkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsRUFBRTs0QkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLHNDQUFzQyxFQUFFLENBQUM7eUJBQzFHO3dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixFQUFFOzRCQUM3QyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsc0NBQXNDLEVBQUUsQ0FBQzt5QkFDekc7O3dCQUNELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDcEcsSUFBSSxTQUFTLEVBQUU7NEJBQ2IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDbEY7d0JBQ0QsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksc0JBQXNCLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJOzRCQUNwRSxPQUFPLEVBQUUsQ0FBQzt5QkFDWCxFQUFFLEtBQUs7NEJBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDbkIsT0FBTyxFQUFFLENBQUM7eUJBQ1gsQ0FBQyxDQUFDO3FCQUNKO29CQUFDLE9BQU8sQ0FBQyxFQUFFO3dCQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2hCO2lCQUNGO3FCQUFNO29CQUNMLE9BQU8sRUFBRSxDQUFDO2lCQUNYO2FBQ0Y7U0FDRixDQUFDLENBQUM7S0FDSjs7OztJQUNELG1CQUFtQjs7UUFDakIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7O1FBQ2hELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsTUFBTSxDQUFDO1FBQzNELElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDOUUsSUFBSSxNQUFNLEVBQUU7WUFDVixRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEM7UUFDRCxJQUFJLFdBQVcsSUFBSSxXQUFXLENBQUMsV0FBVyxJQUFJLFdBQVcsQ0FBQyxXQUFXLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQVN0RyxJQUFJLENBQUMsWUFBWSxDQUFvQixXQUFXLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLFFBQVE7Z0JBQzVGLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtvQkFDcEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztpQkFDN0c7YUFDRixFQUFFLFVBQVUsR0FBRztnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCLENBQUMsQ0FBQztTQUNKO0tBQ0Y7Ozs7OztJQUNELFlBQVksQ0FBSSxRQUFnQjs7UUFDOUIsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDO2FBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVFLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7O1FBRW5HLE1BQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQztnQkFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU87Z0JBQzNELFdBQVcsRUFBRSxjQUFjO2dCQUMzQixXQUFXLEVBQUUsR0FBRyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JFLENBQUM7U0FDSCxDQUFDO1FBQ0YsT0FBTyxJQUFJLE9BQU8sQ0FBSSxDQUFDLE9BQU8sRUFBRSxNQUFNO1lBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFJLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2xGLFNBQVMsQ0FBQyxJQUFJO2dCQUNiLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNmLEVBQUUsS0FBSztnQkFDTixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDZixDQUFDLENBQUM7U0FDTixDQUFDLENBQUM7S0FDSjs7Ozs7SUFDRCxvQkFBb0IsQ0FBQyxrQkFBc0M7O1FBQ3pELElBQUksbUJBQW1CLEdBQXdCLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7O1FBQ3BGLE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQzs7UUFDOUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsRUFBRSxDQUFDOztRQUN2RCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJLENBQUM7O1FBQzNELE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGFBQWEsQ0FBQzs7UUFDN0UsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxDQUFDOztRQUNqRSxNQUFNLFFBQVEsR0FBRyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQzs7UUFDbEUsTUFBTSxXQUFXLEdBQUdDLElBQVUsQ0FBQyxRQUFRLENBQUMsR0FBRyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQzs7UUFDakcsTUFBTSxXQUFXLEdBQUcsNENBQTRDLE9BQU8sY0FBYyxXQUFXLGVBQWUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDOztRQUM1SCxNQUFNLFlBQVksR0FBRyxHQUFHLFFBQVEsR0FBRyxFQUFFLElBQUksYUFBYSxhQUFhLFdBQVcsRUFBRSxDQUFDO1FBQ2pGLE9BQU8sSUFBSSxVQUFVLENBQU8sT0FBTzs7WUFDakMsSUFBSSxJQUFJLEdBQVksS0FBSyxDQUFDO1lBQzFCLElBQUk7Z0JBQ0YsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDN0MsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUU7b0JBQzdCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHO3dCQUN0QixrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7d0JBQzVCLE1BQU0sR0FBRyxHQUF3QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7d0JBQ25ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQzt3QkFDekYsSUFBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUN2RSxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUM7d0JBQ2xFLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzt3QkFDakIsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNmLElBQUksR0FBRyxJQUFJLENBQUM7cUJBQ2IsQ0FBQTtpQkFDRjtnQkFDRCxJQUFJLGtCQUFrQixDQUFDLE9BQU8sRUFBRTtvQkFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUc7d0JBQ3ZCLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUM3QixzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO3dCQUNqRCxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQzs7d0JBQ3hDLE1BQU0sR0FBRyxHQUF3QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7d0JBQ2xELG1CQUFtQixHQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7d0JBQzFELElBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUUsbUJBQW1CLENBQUMsT0FBTyxJQUFFLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7OzRCQUN0RyxNQUFNLFFBQVEsR0FBRyxJQUFJLHNCQUFzQixFQUFFLENBQUM7NEJBQzlDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQ0FDaEQsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDOzZCQUMxQixDQUFDLENBQUM7eUJBQ0Y7cUJBQ0YsQ0FBQztpQkFDSDs7Z0JBQ0QsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsVUFBUyxLQUFLO29CQUNyQyxJQUFJLGtCQUFrQixDQUFDLE9BQU8sRUFBRTt3QkFDOUIsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNuQztvQkFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7b0JBQ3BELFNBQVMsRUFBRSxDQUFDO29CQUNaLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDakIsQ0FBQztnQkFDRixJQUFJLGtCQUFrQixDQUFDLFNBQVMsRUFBRTtvQkFDaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcsa0JBQWtCLENBQUMsU0FBUyxDQUFDO2lCQUN6RDthQUNGO1lBQUMsT0FBTyxLQUFLLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDdEM7Ozs7SUFDTyxVQUFVOztRQUNoQixNQUFNLFNBQVMsR0FBVyxRQUFRLENBQUMsTUFBTSxDQUFDOztRQUMxQyxNQUFNLE9BQU8sR0FBYSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztRQUMvQyxNQUFNLEdBQUcsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7UUFDM0QsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNO1lBQ3BCLElBQUksTUFBTSxFQUFFOztnQkFDVixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4QyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUM3QztTQUNGLENBQUMsQ0FBQztRQUNILE9BQU8sR0FBRyxDQUFDOzs7Ozs7SUFFTCxXQUFXLENBQUMsS0FBd0I7UUFDMUMsSUFBSSxLQUFLLFlBQVksVUFBVSxFQUFFO1lBQy9CLE9BQU8sVUFBVSxDQUFDLGtDQUFrQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1NBQzlEO2FBQU07WUFDTCxPQUFPLFVBQVUsQ0FBQyx3QkFBd0IsS0FBSyxDQUFDLE1BQU0sZUFBZSxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztTQUNyRjs7Ozs7SUFFSyxnQ0FBZ0M7UUFDdEMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksT0FBTyxDQUFPLENBQUMsT0FBTyxFQUFFLE1BQU07WUFDNUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7WUFDekIsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7U0FDeEIsQ0FBQyxDQUFDOzs7Ozs7SUFHTCxxQkFBcUIsQ0FBQyxLQUFZOztRQUNoQyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUU7YUFDbkQsa0JBQWtCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUN6RCxJQUFHLFNBQVMsRUFDWjtZQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDeEI7S0FDRjs7O1lBamRGLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7OztZQWhCUSx1QkFBdUI7WUFFVixVQUFVO1lBSXZCLGNBQWM7WUFDZCxRQUFRO1lBSVIsY0FBYzs7O29DQTRjcEIsWUFBWSxTQUFDLHVCQUF1QixFQUFDLENBQUMsUUFBUSxDQUFDOzs7Ozs7OztBQ3hkbEQ7Ozs7Ozs7SUFjRSxZQUFvQixVQUFzQixFQUFVLGdCQUF5QyxFQUNyRixPQUFvQyxjQUE4QjtRQUR0RCxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtRQUNyRixVQUFLLEdBQUwsS0FBSztRQUErQixtQkFBYyxHQUFkLGNBQWMsQ0FBZ0I7S0FBSzs7Ozs7O0lBQ3ZFLGdCQUFnQixDQUFDLFdBQW1CLEVBQUUsR0FBVzs7UUFDdkQsSUFBSSxNQUFNLENBQVc7UUFDckIsSUFBSSxXQUFXLEVBQUU7WUFDZixNQUFNLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNqQzthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUM7U0FDYjs7UUFDRCxNQUFNLEdBQUcsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7UUFDM0QsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUU7O1lBQzFCLE1BQU0sUUFBUSxHQUFhLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDNUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbkM7UUFDRCxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7Ozs7OztJQUU1QyxRQUFRLENBQUMsR0FBVzs7UUFDbEIsTUFBTSxnQkFBZ0IsR0FBd0IsSUFBSSxHQUFHLEVBQWtCLENBQUM7O1FBQ3hFLE1BQU0sV0FBVyxHQUFXLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O1FBQzlDLE1BQU0saUJBQWlCLEdBQWEsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzRCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsYUFBYTs7WUFDckMsTUFBTSxRQUFRLEdBQWEsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwRCxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDN0MsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxnQkFBZ0IsQ0FBQztLQUN6Qjs7Ozs7SUFDTyxrQkFBa0IsQ0FBQyxHQUFXO1FBQ3BDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyx3QkFBd0IsRUFBRTtZQUN0RSxPQUFPLElBQUksQ0FBQztTQUNiOztRQUNELE1BQU8sZ0JBQWdCLEdBQXdCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7O1FBQ2xFLE1BQU0sU0FBUyxHQUFHLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDOztRQUNoRCxJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQzs7UUFDaEMsSUFBSSxpQkFBaUIsR0FBRyxLQUFLLENBQUM7O1FBQzlCLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1FBQ2hDLFFBQVEsU0FBUztZQUNqQixLQUFLLFNBQVMsQ0FBQztZQUNmLEtBQUssWUFBWTtnQkFDZixtQkFBbUIsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLE1BQU07WUFDUjtnQkFDRSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDO29CQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7O29CQUMzRSxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDN0UsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ3BHLG1CQUFtQjs0QkFDbkIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLLENBQUM7cUJBQ2pJO3lCQUFNO3dCQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztxQkFDN0I7aUJBQ0Y7cUJBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztvQkFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO29CQUN6RSxtQkFBbUIsR0FBRyxJQUFJLENBQUM7aUJBQzVCO3FCQUFNO29CQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztpQkFDN0I7Z0JBQ0gsTUFBTTtTQUNMO1FBQ0QsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3hCLE9BQU8sS0FBSyxDQUFDO1NBQ2Q7UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDM0csSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRTs7Z0JBQ3ZELE1BQU0sb0JBQW9CLEdBQUcsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUM7O2dCQUM1RCxNQUFNLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLG9CQUFvQixJQUFJLGtCQUFrQixFQUFFO29CQUM5QyxJQUFJLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDO3dCQUM3RCxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLENBQUMsb0JBQW9CLENBQUMsRUFBRTt3QkFDcEYsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO3FCQUM1Qjt5QkFBTTt3QkFDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7cUJBQzdCO2lCQUNGO3FCQUFNO29CQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztpQkFDN0I7YUFDRjtpQkFBTTtnQkFDTCxtQkFBbUIsR0FBRyxLQUFLLENBQUM7YUFDN0I7U0FDRjthQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUM7WUFDckQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtZQUMxRCxtQkFBbUIsR0FBRyxJQUFJLENBQUM7U0FDNUI7YUFBTTtZQUNMLG1CQUFtQixHQUFHLEtBQUssQ0FBQztTQUM3QjtRQUNELElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUN4QixPQUFPLEtBQUssQ0FBQztTQUNkO1FBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQztZQUM5QyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRTs7WUFDdkQsTUFBTSxrQkFBa0IsR0FBRyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN4RCxJQUFJLGtCQUFrQixFQUFFO2dCQUN0QixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDaEUsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2lCQUMxQjtxQkFBTTtvQkFDTCxpQkFBaUIsR0FBRyxLQUFLLENBQUM7aUJBQzNCO2FBQ0Y7aUJBQU07Z0JBQ0wsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO2FBQzNCO1NBQ0Y7YUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDO1lBQ3JELENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUU7WUFDeEQsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1NBQzFCO2FBQU07WUFDTCxpQkFBaUIsR0FBRyxLQUFLLENBQUM7U0FDM0I7UUFDRCxPQUFPLGlCQUFpQixDQUFDOzs7Ozs7O0lBRTNCLE9BQU8sQ0FBSSxPQUFnQjs7UUFDekIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O1FBQzFFLElBQUksR0FBRyxDQUFTOztRQUNoQixNQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQ3RCO2FBQU07WUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDMUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNqRDtZQUNELEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2pHLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2hDLElBQUksT0FBTyxDQUFDLFlBQVksRUFBRTtvQkFDeEIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDM0Q7O2dCQUNELE1BQU0sV0FBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsV0FBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLElBQUcsT0FBTyxDQUFDLFlBQVksRUFBRTtvQkFDdkIsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUM7aUJBQ3BEO2dCQUNELE9BQU8sSUFBSSxVQUFVLENBQWtCLE9BQU87b0JBQzVDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO3dCQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hELElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDOzRCQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBa0IsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDbEcsU0FBUyxDQUFDLFFBQVE7Z0NBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ3JCLElBQUksT0FBTyxDQUFDLGdCQUFnQixFQUFFO29DQUM1QixPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUM7aUNBQ3JHO3FDQUFNO29DQUNMLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUNBQ3hCOzZCQUNGLEVBQUUsS0FBSztnQ0FDSixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDOzZCQUN4QixDQUFDLENBQUM7eUJBQ0osQ0FBQyxDQUFDO3FCQUNOO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNsRyxTQUFTLENBQUMsUUFBUTs0QkFDakIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7Z0NBQzVCLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFDLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQzs2QkFDckc7aUNBQU07Z0NBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzs2QkFDeEI7eUJBQ0YsRUFBRSxLQUFLOzRCQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7eUJBQ3hCLENBQUMsQ0FBQztxQkFDSjtpQkFDRixDQUFDLENBQUM7YUFDSjtpQkFBTTtnQkFDTCxPQUFPLFVBQVUsQ0FBQyxnQ0FBZ0MsR0FBRyxPQUFPLENBQUMsQ0FBQzthQUMvRDtTQUNGO0tBQ0Y7Ozs7OztJQUNELFFBQVEsQ0FBSSxPQUFnQjs7UUFDMUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O1FBQzFFLElBQUksR0FBRyxDQUFTOztRQUNoQixNQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQ3RCO2FBQU07WUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDMUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNqRDtZQUNELEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2pHLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7O2dCQUNoQyxNQUFNLFdBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUMsT0FBTyxDQUFDLE9BQU8scUJBQUMsRUFBaUIsQ0FBQTtvQkFDMUQsT0FBTyxvQkFBRSxVQUFvQixDQUFBO2lCQUM5QixDQUFDO2dCQUNGLFdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUM3QyxPQUFPLElBQUksVUFBVSxDQUFrQixVQUFVO29CQUMvQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTzt3QkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO3dCQUN4RCxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQzs0QkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDakgsU0FBUyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7eUJBQ3JGLENBQUMsQ0FBQztxQkFDTjt5QkFBTTt3QkFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNqSCxTQUFTLENBQUMsUUFBUSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDckY7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxVQUFVLENBQUMsZ0NBQWdDLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDL0Q7U0FDRjtLQUNGOzs7Ozs7SUFDRCxPQUFPLENBQUksT0FBZ0I7O1FBQ3pCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztRQUMxRSxJQUFJLEdBQUcsQ0FBUzs7UUFDaEIsTUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUN0QjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzFCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDakQ7WUFDRCxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqRyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7Z0JBQ2hDLE1BQU0sV0FBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsV0FBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLE9BQU8sSUFBSSxVQUFVLENBQWtCLFVBQVU7b0JBQy9DLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO3dCQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hELElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDOzRCQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lDQUNoSCxTQUFTLENBQUMsUUFBUSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzt5QkFDckYsQ0FBQyxDQUFDO3FCQUNOO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFrQixHQUFHLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NkJBQ2hILFNBQVMsQ0FBQyxRQUFRLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxLQUFLLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUNyRjtpQkFDRixDQUFDLENBQUM7YUFDSjtpQkFBTTtnQkFDTCxPQUFPLFVBQVUsQ0FBQyxnQ0FBZ0MsR0FBRyxPQUFPLENBQUMsQ0FBQzthQUMvRDtTQUNGO0tBQ0Y7Ozs7OztJQUNELFVBQVUsQ0FBSSxPQUFnQjs7UUFDNUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7O1FBQzFFLElBQUksR0FBRyxDQUFTOztRQUNoQixNQUFNLE1BQU0sR0FBcUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ2xCLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQ3RCO2FBQU07WUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDMUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFdBQVcsR0FBRyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNqRDtZQUNELEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2pHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQkFDaEMsTUFBTSxXQUFXLEdBQUc7b0JBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFDLE9BQU8sQ0FBQyxPQUFPLHFCQUFDLEVBQWlCLENBQUE7b0JBQzFELE9BQU8sb0JBQUUsVUFBb0IsQ0FBQTtpQkFDOUIsQ0FBQztnQkFDRixXQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQztnQkFDN0MsT0FBTyxJQUFJLFVBQVUsQ0FBa0IsVUFBVTtvQkFDL0MsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU87d0JBQzlDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTt3QkFDeEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7NEJBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFrQixHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lDQUNyRyxTQUFTLENBQUMsUUFBUSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzt5QkFDckYsQ0FBQyxDQUFDO3FCQUNOO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFrQixHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNyRyxTQUFTLENBQUMsUUFBUSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDckY7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxVQUFVLENBQUMsZ0NBQWdDLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDL0Q7U0FDRjtLQUNGOzs7Ozs7SUFDRCxRQUFRLENBQUksT0FBZ0I7O1FBQzFCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztRQUMxRSxJQUFJLEdBQUcsQ0FBUzs7UUFDaEIsTUFBTSxNQUFNLEdBQXFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUN0QjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7Z0JBQ3hCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzFCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxXQUFXLEdBQUcsSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDakQ7WUFDRCxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqRyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7Z0JBQ2hDLE1BQU0sV0FBVyxHQUFHO29CQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sR0FBQyxPQUFPLENBQUMsT0FBTyxxQkFBQyxFQUFpQixDQUFBO29CQUMxRCxPQUFPLG9CQUFFLFVBQW9CLENBQUE7aUJBQzlCLENBQUM7Z0JBQ0YsV0FBVyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQzdDLE9BQU8sSUFBSSxVQUFVLENBQWtCLFVBQVU7b0JBQy9DLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPO3dCQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUU7d0JBQ3hELElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDOzRCQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBa0IsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDbkcsU0FBUyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7eUJBQ3JGLENBQUMsQ0FBQztxQkFDTjt5QkFBTTt3QkFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBa0IsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDbkcsU0FBUyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7cUJBQ3JGO2lCQUNGLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE9BQU8sVUFBVSxDQUFDLGdDQUFnQyxHQUFHLE9BQU8sQ0FBQyxDQUFDO2FBQy9EO1NBQ0Y7S0FDRjs7Ozs7O0lBQ0QsU0FBUyxDQUFJLE9BQWdCOztRQUMzQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7UUFDMUUsSUFBSSxHQUFHLENBQVM7O1FBQ2hCLE1BQU0sTUFBTSxHQUFxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUMxRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDbEIsR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7U0FDdEI7YUFBTTtZQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO2dCQUN4QixPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzthQUMxQjtpQkFBTTtnQkFDTCxPQUFPLENBQUMsV0FBVyxHQUFHLElBQUksT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ2pEO1lBQ0QsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDakcsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEVBQUU7O2dCQUNoQyxNQUFNLFdBQVcsR0FBRztvQkFDbEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUMsT0FBTyxDQUFDLE9BQU8scUJBQUMsRUFBaUIsQ0FBQTtvQkFDMUQsT0FBTyxvQkFBRSxVQUFvQixDQUFBO2lCQUM5QixDQUFDO2dCQUNGLFdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUM3QyxPQUFPLElBQUksVUFBVSxDQUFrQixVQUFVO29CQUMvQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTzt3QkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO3dCQUN4RCxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQzs0QkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQWtCLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQ0FDbEgsU0FBUyxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7eUJBQ3JGLENBQUMsQ0FBQztxQkFDTjt5QkFBTTt3QkFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBa0IsR0FBRyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNsSCxTQUFTLENBQUMsUUFBUSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDckY7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxVQUFVLENBQUMsZ0NBQWdDLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDL0Q7U0FDRjtLQUNGOzs7OztJQUNPLFdBQVcsQ0FBQyxLQUF3QjtRQUMxQyxJQUFJLEtBQUssWUFBWSxVQUFVLEVBQUU7WUFDL0IsT0FBTyxVQUFVLENBQUMsa0NBQWtDLEtBQUssRUFBRSxDQUFDLENBQUM7U0FDOUQ7YUFBTTtZQUNMLE9BQU8sVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFCOzs7O1lBdFdKLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7OztZQVZRLFVBQVU7WUFFVix1QkFBdUI7WUFHdkIsbUJBQW1CO1lBQ25CLGNBQWM7Ozs7Ozs7O0FDUHZCOzs7Ozs7Ozs7SUF1QkUsWUFBb0IsV0FBd0IsRUFBVSxnQkFBeUMsRUFDckYsZ0JBQ0EsT0FBb0MsTUFBYyxFQUFVLFFBQWtCO1FBRnBFLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUF5QjtRQUNyRixtQkFBYyxHQUFkLGNBQWM7UUFDZCxVQUFLLEdBQUwsS0FBSztRQUErQixXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUN0RixJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO1NBQ25ELENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsUUFBUTtLQUNQOzs7O0lBQ0QsV0FBVztRQUNULElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7S0FDeEI7Ozs7Ozs7SUFDTyxPQUFPLENBQUksT0FBTyxFQUFFLE9BQU87O1FBQ2pDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUN2QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNyRDthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFDdkMsT0FBTyxDQUFDLENBQUM7U0FDWjs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBRSxPQUFPO1NBQ2QsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUM7Ozs7O0lBRS9DLDJCQUEyQjtRQUN6QixPQUFPLElBQUksVUFBVSxDQUFPLE9BQU87WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUNyQixNQUFNLENBQUMsS0FBSyxJQUFJLEtBQUssWUFBWSxhQUFhLENBQUMsQ0FDaEQsQ0FBQyxTQUFTLENBQUMsS0FBSztnQkFDZixJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7b0JBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzNCO2FBQ0YsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ2hCLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUVELGdCQUFnQixDQUFJLFFBQWdCLEVBQUUsUUFBZ0IsRUFBRSxPQUFnQjtRQUN0RSxPQUFPLElBQUksVUFBVSxDQUFrQixPQUFPOztZQUM1QyxNQUFNLG1CQUFtQixHQUF3QixJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3RGLElBQUksbUJBQW1CLElBQUksbUJBQW1CLENBQUMsT0FBTztnQkFDcEQsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRTtnQkFDN0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztnQkFDdkYsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hCO2lCQUFNOztnQkFDTCxNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzs7Z0JBQ3JELE1BQU0sV0FBVyxHQUFHO29CQUNsQixRQUFRLEVBQUUsUUFBUTtvQkFDbEIsWUFBWSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO2lCQUN6QyxDQUFDOztnQkFDRixNQUFNLE9BQU8sR0FBRztvQkFDZCxPQUFPLEVBQUU7d0JBQ1AsUUFBUSxFQUFFLFdBQVc7d0JBQ3JCLGFBQWEsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztxQkFDOUM7aUJBQ0YsQ0FBQztnQkFDRixJQUFJLENBQUMsT0FBTyxDQUFJLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUTtvQkFDbEQsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFOzt3QkFDL0gsTUFBTSxTQUFTLEdBQWEsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O3dCQUNsRixJQUFJLGlCQUFpQixHQUFHLElBQUksQ0FBQzs7d0JBQzdCLElBQUkscUJBQXFCLEdBQUcsSUFBSSxDQUFDOzt3QkFDakMsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDO3dCQUMxQixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs0QkFDM0MsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO3lCQUNuRjs2QkFBTTs0QkFDTCxpQkFBaUIsR0FBRyxFQUFFLENBQUM7eUJBQ3hCO3dCQUNELHFCQUFxQixHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDMUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQ0FBa0MsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO3dCQUMxRSxJQUFJLENBQUMsY0FBYyxDQUFDLHNDQUFzQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7d0JBQ2xGLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ25ELElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOzRCQUMzQyxjQUFjLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQy9EOzZCQUFNOzRCQUNMLGNBQWMsR0FBRyxFQUFFLENBQUM7eUJBQ3JCOzt3QkFDRCxNQUFNLG9CQUFvQixHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQzt3QkFDdkUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQ0FBc0MsbUJBQUMsb0JBQTRCLEVBQUMsQ0FBQzs7d0JBQ3pGLE1BQU0saUJBQWlCLEdBQWEsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFOzRCQUNyQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7eUJBQ3ZDO3dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixFQUFFOzRCQUM1QyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQzt5QkFDOUM7d0JBQ0QsS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRTs7NEJBQ3ZELE1BQU0sZUFBZSxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDMUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMxRCxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDbEY7d0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDOUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7d0JBQ2xDLElBQUksQ0FBQyxnQ0FBZ0MsRUFBRSxDQUFDOzt3QkFDeEMsTUFBTSxnQkFBZ0IsR0FBUyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ3ZELGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWM7NEJBQ2xELGtCQUFrQixFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCO3lCQUMzRCxDQUFDLENBQUMsQ0FBQzs7d0JBQ0osTUFBTSxXQUFXLEdBQXVCOzRCQUN0QyxRQUFRLEVBQUUsUUFBUTs0QkFDbEIsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU87NEJBQ3pDLGNBQWMsRUFBRSxjQUFjOzRCQUM5QixNQUFNLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDOzRCQUNwRCxnQkFBZ0IsRUFBRSxnQkFBZ0I7eUJBQ25DLENBQUM7d0JBQ0YsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO3dCQUM3QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQzt3QkFDaEQsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7d0JBUzNFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFvQixRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJOzRCQUN0RSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0NBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDOzZCQUMzRzt5QkFDRixFQUFFLFVBQVUsR0FBRzs0QkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUNsQixDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLHNCQUFzQixFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7NEJBQ3RFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDOzRCQUN2RixPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUN4QixFQUFFOzRCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDOzRCQUN2RixPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUN4QixDQUFDLENBQUM7cUJBQ0o7eUJBQU07d0JBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDeEI7aUJBQ0YsRUFBRSxLQUFLO29CQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3RCLENBQUMsQ0FBQzthQUNKO1NBQ0YsQ0FBQyxDQUFDO0tBQ0o7Ozs7O0lBQ0QsUUFBUSxDQUFDLFFBQVE7UUFDZixJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDckM7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLGlDQUFpQyxRQUFRLEVBQUU7U0FDekQsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQU8sT0FBTztZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBdUIsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVE7Z0JBQzNFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7OztJQUNELFVBQVU7UUFDUixPQUFPLElBQUksVUFBVSxDQUFPLE9BQU87O1lBQ2pDLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQzdELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7O2dCQUNsRSxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQ0FBaUMsRUFBRSxDQUFDO29CQUN4RCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRTt3QkFDdEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztxQkFDN0I7b0JBQ0QsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2lCQUNoQixFQUFFLENBQUMsS0FBSztvQkFDUCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsaUNBQWlDLEVBQUUsQ0FBQztvQkFDeEQsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUU7d0JBQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7cUJBQzdCO29CQUNELE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDakIsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixJQUFJLENBQUMsY0FBYyxDQUFDLGlDQUFpQyxFQUFFLENBQUM7Z0JBQ3hELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFO29CQUN0RCxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjtnQkFDRCxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2FBQ2xDO1NBQ0YsQ0FBQyxDQUFDO0tBQ0o7Ozs7SUFDRCxXQUFXO1FBQ1QsT0FBTyxNQUFNLENBQUMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNwRjs7Ozs7SUFDQyxhQUFhLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQztRQUMzRSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7WUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxrQkFBa0IsRUFDbEY7WUFDRSxJQUNBO2dCQUNFLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUU7b0JBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7aUJBQzdCO2FBQ0Y7WUFDRCxPQUFNLFVBQVUsRUFDaEI7Z0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QjtTQUNGO1FBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTO1lBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQjtZQUMzRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTs7WUFDOUQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNwQyxJQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQ3pCO2dCQUNFLFFBQVEsR0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2pDOztZQUNILE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQzs7WUFDMUcsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO1lBQ3pELElBQUksY0FBYyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7YUFDNUU7aUJBQU0sSUFBSSxRQUFRLEVBQUU7O2dCQUNuQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUU7cUJBQ3ZELGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxTQUFTLEVBQUU7b0JBQ2IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7aUJBQ3hGO2FBQ0Y7U0FDRjtLQUNGOzs7Ozs7SUFDRCxZQUFZLENBQUksT0FBZ0I7O1FBQzlCLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSxtQ0FBbUM7WUFDaEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0QsZ0JBQWdCLENBQUksWUFBb0IsRUFBRSxPQUFZLEVBQUMsT0FBZTs7UUFDcEUsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7UUFDaEYsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLDJDQUEyQyxZQUFZLEVBQUU7WUFDdEUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFO1lBQ2pCLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsYUFBYSxDQUFLLE9BQVksRUFBQyxPQUFlOztRQUM1QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsT0FBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDOztRQUNoRixNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUseUJBQXlCO1lBQ3RDLElBQUksRUFBRSxFQUFDLE9BQU8sRUFBQztZQUNmLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUNELGNBQWMsQ0FBSSxZQUFvQixFQUFFLElBQVMsRUFBQyxPQUFlOztRQUMvRCxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSx5Q0FBeUMsWUFBWSxFQUFFO1lBQ3BFLElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFDLE9BQU87U0FDaEIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0QsdUJBQXVCLENBQUksWUFBb0IsRUFBRSxJQUFTLEVBQUMsT0FBZTs7UUFDeEUsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsa0RBQWtELFlBQVksRUFBRTtZQUM3RSxJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7OztJQUNELGlCQUFpQixDQUFDLE9BQWU7O1FBQy9CLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHVCQUF1QjtZQUNwQyxZQUFZLEVBQUUsYUFBYTtZQUMzQixPQUFPLEVBQUMsT0FBTztTQUNoQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBNEIsT0FBTztZQUN0RCxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBYyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTs7Z0JBQzNELE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNqQyxJQUFJLEVBQUUsNEZBQTRGO2lCQUNuRyxDQUFDLENBQUM7O2dCQUNILElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RDLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7Z0JBQzdCLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDUixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDaEIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNqQixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7SUFDRCxvQkFBb0IsQ0FBQyxPQUFlOztRQUNsQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSx1QkFBdUI7WUFDcEMsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQU8sT0FBTztZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTs7Z0JBQzlDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7O2dCQUN0QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDOztnQkFDOUQsSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs7Z0JBQ2hDLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7O2dCQUN6QixJQUFJLEtBQUssR0FBRyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDNUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2xDOztnQkFDRCxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDbEMsSUFBSSxFQUFFLG9FQUFvRTtpQkFDM0UsQ0FBQyxDQUFDO2dCQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsR0FBRyxPQUFPLENBQUMsQ0FBQTtnQkFDN0MsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDakIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxVQUFVLENBQUksUUFBZ0IsRUFBQyxPQUFlOztRQUM1QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQ3ZDOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxRQUFRO1lBQ3hELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxVQUFVLENBQUksUUFBZ0IsRUFBRSxRQUFRLEVBQUMsT0FBZTs7UUFDdEQsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDYixVQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQztTQUN2Qzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsUUFBUTtZQUN4RCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO1NBQzlCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsUUFBUSxDQUFJLFFBQVEsRUFBQyxPQUFlOztRQUNsQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQ3ZDOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw2QkFBNkIsR0FBRyxRQUFRO1lBQ3JELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBQ0QsMkJBQTJCLENBQUksTUFBTSxFQUFDLE9BQWU7O1FBQ25ELElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDckM7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLE1BQU07WUFDdEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxTQUFTLENBQUksTUFBTSxFQUFDLE9BQWU7O1FBQ2pDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsVUFBVSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDckM7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLDZCQUE2QixHQUFHLE1BQU07WUFDbkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxrQkFBa0IsQ0FBSSxRQUFnQixFQUFDLE9BQWU7UUFDcEQsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1NBQ3ZDOztRQUNELElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLCtCQUErQixHQUFHLFFBQVE7WUFDdkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7O0lBQ0QsVUFBVSxDQUFJLEtBQWEsRUFBRSxJQUFZLEVBQUMsT0FBZTs7UUFDdkQsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsS0FBSyxHQUFHLFFBQVEsR0FBRyxJQUFJO1lBQ25FLE9BQU8sRUFBQyxPQUFPO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7SUFDRCxpQkFBaUIsQ0FBSSxPQUFlOztRQUNsQyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSxtQ0FBbUM7WUFDaEQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxVQUFVLENBQUksUUFBUSxFQUFDLE9BQWU7O1FBQ3BDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUMvQixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDN0csUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDNUQsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBQzdHLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDOztRQUM1RCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLHNCQUFzQjtZQUNuQyxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO1lBQzdCLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7O0lBQ0QsY0FBYztRQUNaLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNuQyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDMUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFDL0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUM7UUFDaEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzFDLElBQUksQ0FBQyxjQUFjLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO1FBQ2pELElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1FBQzdDLElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQy9DLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztLQUN2Qzs7Ozs7SUFDRCxTQUFTLENBQUMsR0FBRzs7UUFDWCxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDOztRQUNsQyxNQUFNLE9BQU8sR0FBYSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOztRQUMvQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU07WUFDcEIsSUFBSSxNQUFNLEVBQUU7O2dCQUNWLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3hDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDMUM7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNqQjs7Ozs7O0lBQ0QscUJBQXFCLENBQUMsTUFBTSxFQUFFLGNBQWM7UUFDMUMsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUU7WUFDeEIsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQkFDOUIsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMxQixJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7O29CQUNoQixNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7b0JBQ2xCLEtBQUssTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTt3QkFDN0IsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTs7NEJBQ3BDLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7NEJBQ2pDLFFBQVEsRUFBRTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDdEIsTUFBTTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDdkIsTUFBTTtnQ0FDUixLQUFLLEdBQUc7b0NBQ04sTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQztvQ0FDeEIsTUFBTTs2QkFDVDt5QkFDRjtxQkFDRjtvQkFDRCxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUNuRDthQUNGO1NBQ0Y7UUFDRCxPQUFPLGNBQWMsQ0FBQztLQUN2Qjs7Ozs7SUFFRCxVQUFVLENBQUMsU0FBaUI7O1FBQzFCLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2QsT0FBTyxJQUFJLENBQUM7U0FDYjs7UUFDRCxNQUFNLE1BQU0sR0FBYSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOztZQUN0QyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7O1lBQ3hCLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O1lBQ3BDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQzs7WUFDbEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ2hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTs7Z0JBQzlDLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFO29CQUNuQixRQUFRLEdBQUcsU0FBUyxDQUFDO2lCQUN0QjtxQkFBTTtvQkFDTCxRQUFRLEdBQUcsR0FBRyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7aUJBQ3ZDO2dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUNyQjtnQkFDRCxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3ZCO1lBQ0QsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFO2dCQUNuQixRQUFRLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVEO2lCQUFNO2dCQUNMLFFBQVEsR0FBRyxHQUFHLFFBQVEsSUFBSSxVQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQzthQUM3RTtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFOztnQkFDbEMsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDOztnQkFDeEIsTUFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDOUUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzNDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBRXJDO2dCQUNELElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsQ0FBQzthQUMzQztTQUNGO1FBQ0QsT0FBTyxJQUFJLENBQUM7S0FDYjs7Ozs7SUFDTyxvQkFBb0IsQ0FBQyxLQUFLOztRQUNoQyxNQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLEtBQUssRUFBRSxFQUFFO1lBQzFCLE9BQU8sVUFBVSxDQUFDO1NBQ25COztRQUNELE1BQU0sb0JBQW9CLEdBQWEsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsb0JBQW9CLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOztZQUNwRCxNQUFNLGdCQUFnQixHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDOztZQUNqRCxNQUFNLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O1lBQzVDLE1BQU0sV0FBVyxHQUFHLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7O1lBQzlELE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztZQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0MsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7YUFDeEY7WUFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDO1NBQy9CO1FBQ0QsT0FBTyxVQUFVLENBQUM7Ozs7O0lBRXBCLDBCQUEwQjs7UUFDeEIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQzs7UUFDcEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEQsSUFBSSxRQUFRLENBQUMsUUFBUSxFQUFFOztZQUNyQixNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQztTQUNuRDtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHNCQUFzQixFQUFFO1lBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMsc0JBQXNCLEdBQUcsRUFBRSxDQUFDO1NBQ3hDO1FBQ0QsS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLFFBQVEsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQzNGLElBQUksQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDckk7S0FDRjs7OztJQUNELGdDQUFnQzs7UUFDOUIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQzs7UUFDdkQsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUcsSUFBSSxvQkFBb0IsRUFBRTs7WUFDeEIsTUFBTSxNQUFNLEdBQUcsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9DLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN6RTtLQUNGOzs7Ozs7O0lBQ0QsYUFBYSxDQUFJLFNBQVMsRUFBQyxPQUFlOztRQUN4QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsNkNBQTZDLEdBQUcsU0FBUztZQUN0RSxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGlCQUFpQixDQUFJLFNBQVMsRUFBQyxPQUFlOztRQUM1QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsd0NBQXdDLEdBQUcsU0FBUztZQUNqRSxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7O0lBQ0QsaUJBQWlCLENBQUksT0FBZTs7UUFDbEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGNBQWM7WUFDakMsV0FBVyxFQUFFLCtCQUErQjtZQUM1QyxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7O0lBQ0QsZUFBZSxDQUFJLE9BQWU7O1FBQ2hDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSwwQkFBMEI7WUFDdkMsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELGlCQUFpQixDQUFJLE9BQWU7O1FBQ2xDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSw0QkFBNEI7WUFDekMsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELDhCQUE4QixDQUFJLE9BQWU7O1FBQy9DLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSxzQ0FBc0M7WUFDbkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELDRCQUE0QixDQUFJLE9BQWU7O1FBQzdDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSxvQ0FBb0M7WUFDakQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7OztJQUNELGtDQUFrQyxDQUFJLE9BQWU7O1FBQ25ELElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSwwQ0FBMEM7WUFDdkQsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxVQUFVLENBQUksTUFBTSxFQUFDLE9BQWU7UUFDbEMsSUFBSSxDQUFDLE1BQU07WUFDVCxNQUFNLHNCQUFzQixDQUFDOztRQUM3QixJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsTUFBTTtZQUNwRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNwRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxVQUFVLENBQUksTUFBTSxFQUFFLFFBQVEsRUFBQyxPQUFlO1FBQzVDLElBQUksQ0FBQyxNQUFNO1lBQ1QsTUFBTSxzQkFBc0IsQ0FBQzs7UUFDN0IsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQy9CLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsQ0FBQztRQUM3RyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQzs7UUFDOUQsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxjQUFjO1lBQ2pDLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxNQUFNO1lBQ3BELElBQUksRUFBRSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUU7WUFDN0IsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxRQUFRLENBQUksTUFBTSxFQUFDLE9BQWU7UUFDaEMsSUFBSSxDQUFDLE1BQU07WUFDVCxNQUFNLHNCQUFzQixDQUFDOztRQUMvQixJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsTUFBTTtZQUNsRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxVQUFVLENBQUksSUFBSSxFQUFFLElBQUksRUFBQyxPQUFlOztRQUN0QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsNEJBQTRCLEdBQUcsSUFBSSxHQUFHLFFBQVEsR0FBRyxJQUFJO1lBQ2xFLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBRUQsa0JBQWtCLENBQUksUUFBUSxFQUFDLE9BQWU7UUFDNUMsSUFBSSxDQUFDLFFBQVE7WUFDWCxNQUFNLHVCQUF1QixDQUFDOztRQUM5QixJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsY0FBYztZQUNqQyxXQUFXLEVBQUUsK0JBQStCLEdBQUcsUUFBUTtZQUN2RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGVBQWUsQ0FBSSxTQUFTLEVBQUMsT0FBZTs7UUFDMUMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQy9CLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBQzFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDekQsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDMUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQzs7UUFDekQsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHVCQUF1QjtZQUNwQyxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFO1NBQy9CLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBRUQsYUFBYSxDQUFJLE9BQU8sRUFBQyxPQUFlO1FBQ3RDLElBQUksQ0FBQyxPQUFPO1lBQ1YsTUFBTSx5QkFBeUIsQ0FBQzs7UUFDaEMsSUFBSSxPQUFPLENBQWM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxPQUFPLEVBQUUsT0FBTztZQUNoQixXQUFXLEVBQUUsOEJBQThCLEdBQUcsT0FBTztTQUN0RCxDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxpQkFBaUIsQ0FBSSxJQUFJLEVBQUUsSUFBSSxFQUFDLE9BQWU7O1FBQzdDLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLCtCQUErQixHQUFHLElBQUksR0FBRyxRQUFRLEdBQUcsSUFBSTtZQUNyRSxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxZQUFZLENBQUksSUFBSSxFQUFFLElBQUksRUFBQyxPQUFlOztRQUN4QyxJQUFJLE9BQU8sQ0FBYztRQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsUUFBUSxHQUFHLElBQUk7WUFDcEUsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQztRQUNGLE9BQU8sSUFBSSxVQUFVLENBQUksT0FBTztZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsRUFBRSxLQUFLO2dCQUNOLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDO0tBQ0o7Ozs7Ozs7SUFDRCxlQUFlLENBQUksT0FBTyxFQUFDLE9BQWU7UUFDeEMsSUFBSSxDQUFDLE9BQU87WUFDVixNQUFNLHlCQUF5QixDQUFDOztRQUNoQyxJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSxnQ0FBZ0MsR0FBRyxPQUFPO1lBQ3ZELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ3BELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7OztJQUNELGVBQWUsQ0FBSSxPQUFPLEVBQUUsU0FBUyxFQUFDLE9BQWU7UUFDbkQsSUFBSSxDQUFDLE9BQU87WUFDVixNQUFNLHlCQUF5QixDQUFDOztRQUNoQyxJQUFJLE9BQU8sQ0FBYztRQUMzQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUM7U0FDekY7YUFDSTtZQUNILE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsQ0FBQyxDQUFBO1NBQy9DOztRQUNELE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDL0IsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUM7UUFDMUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQzs7UUFDekQsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLGdDQUFnQyxHQUFHLE9BQU87WUFDdkQsT0FBTyxFQUFFLE9BQU87WUFDaEIsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtTQUMvQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELFFBQVEsQ0FBSSxRQUFRLEVBQUMsT0FBZTs7UUFDbEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsUUFBUTtZQUN0RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELFVBQVUsQ0FBSSxRQUFRLEVBQUMsT0FBZTs7UUFDcEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsUUFBUTtZQUN4RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELFNBQVMsQ0FBSSxTQUFTLEVBQUMsT0FBZTs7UUFDcEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsZ0NBQWdDLEdBQUcsU0FBUztZQUN6RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELFdBQVcsQ0FBSSxTQUFTLEVBQUMsT0FBZTs7UUFDdEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsa0NBQWtDLEdBQUcsU0FBUztZQUMzRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGFBQWEsQ0FBSSxVQUFVLEVBQUMsT0FBZTs7UUFDekMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUseUJBQXlCO1lBQ3RDLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBQyxVQUFVO1NBQ2hCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7Ozs7SUFDRCxjQUFjLENBQUksUUFBUSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUMsT0FBZTs7UUFDbEUsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUsb0NBQW9DLEdBQUcsUUFBUTtZQUM1RCxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFO29CQUNWLFVBQVUsRUFBRSxRQUFRO29CQUNwQixpQkFBaUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztvQkFDaEQsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7aUJBQ2pEO2FBQ0Y7WUFDRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7OztJQUNELGNBQWMsQ0FBSSxRQUFRLEVBQUMsT0FBZTs7UUFDeEMsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQzs7UUFDNUMsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLDJCQUEyQjtZQUN4QyxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7OztJQUNELGVBQWUsQ0FBSSxRQUFRLEVBQUMsU0FBZ0IsRUFBQyxpQkFBd0IsRUFBQyxjQUFxQixFQUFDLE9BQWU7O1FBQ3pHLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7O1FBQ0QsSUFBSSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUM3QixPQUFPLEdBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDOztRQUMvSCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGFBQWE7WUFDaEMsV0FBVyxFQUFFLDJCQUEyQjtZQUN4QyxJQUFJLEVBQUU7Z0JBQ0YsbUJBQW1CLEVBQUUsRUFBQyxpQkFBaUIsRUFBQztnQkFDeEMsZ0JBQWdCLEVBQUUsRUFBQyxjQUFjLEVBQUM7YUFDckM7WUFDRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7Ozs7SUFDRCxZQUFZLENBQUksUUFBUSxFQUFDLFNBQWdCLEVBQUMsVUFBaUIsRUFBQyxhQUFvQixFQUFDLFdBQWtCLEVBQUMsT0FBZTs7UUFDakgsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFDLFdBQVcsQ0FBQyxDQUFDOztRQUNsTCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGFBQWE7WUFDaEMsV0FBVyxFQUFFLHdCQUF3QjtZQUNyQyxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7OztJQUNELGFBQWEsQ0FBSSxRQUFnQixFQUFFLEdBQVcsRUFBRSxXQUFtQixFQUFDLGVBQXVCLEVBQUUsT0FBZTs7UUFDMUcsSUFBSSxPQUFPLENBQWM7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQztRQUNELE9BQU8sR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQzs7UUFDNUMsSUFBSSxRQUFRLEdBQVMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQzs7UUFDbkQsTUFBTSxPQUFPLEdBQVk7WUFDdkIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7WUFDbkMsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFO29CQUNWLFVBQVUsRUFBRSxRQUFRO29CQUNwQixhQUFhLEVBQUUsUUFBUTtvQkFDdkIsaUJBQWlCLEVBQUUsUUFBUTtvQkFDM0IsS0FBSyxFQUFDLEdBQUc7aUJBQ1Y7YUFDRjtZQUNELE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFDRixPQUFPLElBQUksVUFBVSxDQUFJLE9BQU87WUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2xELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCLEVBQUUsS0FBSztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQztLQUNKOzs7Ozs7Ozs7O0lBQ0QsZ0JBQWdCLENBQUksUUFBZ0IsRUFBRSxHQUFXLEVBQUUsV0FBbUIsRUFBQyxlQUF1QixFQUFFLE9BQWU7O1FBQzdHLElBQUksT0FBTyxDQUFjO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztTQUN6RjthQUNJO1lBQ0gsT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBQyxDQUFDLENBQUE7U0FDL0M7UUFDRCxPQUFPLEdBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLENBQUM7O1FBQzVDLElBQUksUUFBUSxHQUFTLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7O1FBQ25ELE1BQU0sT0FBTyxHQUFZO1lBQ3ZCLE9BQU8sRUFBRSxTQUFTLENBQUMsZ0JBQWdCO1lBQ25DLFdBQVcsRUFBRSw0QkFBNEI7WUFDekMsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRTtvQkFDVixVQUFVLEVBQUUsUUFBUTtvQkFDcEIsYUFBYSxFQUFFLFFBQVE7b0JBQ3ZCLGlCQUFpQixFQUFFLFFBQVE7b0JBQzNCLEtBQUssRUFBQyxHQUFHO2lCQUNWO2FBQ0Y7WUFDRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7Ozs7Ozs7SUFDRCxlQUFlLENBQUksUUFBUSxFQUFFLE9BQU8sRUFBQyxPQUFlO1FBQ2xELElBQUksQ0FBQyxRQUFRO1lBQ1gsTUFBTSx1QkFBdUIsQ0FBQzs7UUFDOUIsSUFBSSxPQUFPLENBQWM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0k7WUFDSCxPQUFPLEdBQUcsSUFBSSxXQUFXLENBQUMsRUFBQyxTQUFTLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtTQUMvQzs7UUFDRCxNQUFNLE9BQU8sR0FBWTtZQUN2QixPQUFPLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtZQUNuQyxXQUFXLEVBQUUscUNBQXFDLEdBQUcsUUFBUTtZQUM3RCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUU7Z0JBQ0osU0FBUyxFQUFFLE9BQU87YUFDbkI7U0FDRixDQUFDO1FBQ0YsT0FBTyxJQUFJLFVBQVUsQ0FBSSxPQUFPO1lBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFJLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QixFQUFFLEtBQUs7Z0JBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDSjs7O1lBbDlDRixVQUFVLFNBQUM7Z0JBQ1YsVUFBVSxFQUFFLE1BQU07YUFDbkI7Ozs7WUFsQlEsV0FBVztZQUdYLHVCQUF1QjtZQUV2QixjQUFjO1lBSWQsbUJBQW1CO1lBQ25CLE1BQU07WUFDTixRQUFROzs7Ozs7OztBQ1pqQjs7Ozs7O0lBU0ksWUFBb0IsY0FBOEIsRUFBVSxnQkFBeUMsRUFDekY7UUFEUSxtQkFBYyxHQUFkLGNBQWMsQ0FBZ0I7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQXlCO1FBQ3pGLFVBQUssR0FBTCxLQUFLO0tBQTBCOzs7Ozs7SUFDM0MsU0FBUyxDQUFDLEdBQXFCLEVBQUUsSUFBaUI7UUFDOUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFO1lBQzdCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixrQkFBa0IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQjtpQkFDbEQ7YUFDSixDQUFDLENBQUM7U0FDTjtRQUNELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7WUFDdkIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVU7aUJBQ3RDO2FBQ0osQ0FBQyxDQUFDO1NBQ047UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ3RCLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTO2lCQUNuQzthQUNKLENBQUMsQ0FBQztTQUNOO1FBQ0QsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNqQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQztnQkFDWixVQUFVLEVBQUU7b0JBQ1IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQztpQkFDN0M7YUFDSixDQUFDLENBQUM7U0FDTjthQUNJLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbkMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7aUJBQzFDO2FBQ0osQ0FBQyxDQUFDO1NBQ047YUFBTyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNaLFVBQVUsRUFBRTtvQkFDUixTQUFTLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2lCQUN6QzthQUNKLENBQUMsQ0FBQztTQUNOO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3hHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRO1lBQ2pFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sRUFBRTs7WUFDOUYsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDOztZQUN6RCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDOztZQUNuRixJQUFJLE9BQU8sQ0FBUztZQUNwQixPQUFPLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDVixPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLENBQUMsT0FBTyxDQUFDO2FBQzlEO1lBQ0QsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osVUFBVSxFQUFFO29CQUNSLFNBQVMsRUFBRSxHQUFHLFFBQVEsSUFBSSxTQUFTLEVBQUU7b0JBQ3JDLE9BQU8sRUFBRSxPQUFPO2lCQUNuQjthQUNKLENBQUMsQ0FBQztTQUNOO1FBQ0QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUTtZQUNyQyxJQUFJLFFBQVEsWUFBWSxZQUFZLEVBQUU7O2dCQUNsQyxNQUFNLElBQUkscUJBQUcsUUFBNkIsRUFBQztnQkFDM0MsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtvQkFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO29CQUNwRSxJQUFJLENBQUMsY0FBYyxDQUFDLHNCQUFzQixFQUFFLENBQUM7aUJBQ2hEO2dCQUNELElBQUksUUFBUSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztvQkFDNUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO29CQUMvQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxHQUFHLEtBQUssUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxjQUFjLENBQUM7NEJBQ2pHLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO3dCQUNsRSxJQUFJLENBQUMsY0FBYyxDQUFDLHdDQUF3QyxFQUFFLENBQUM7cUJBQ2xFO2lCQUNKO2FBQ0o7U0FDSixDQUFDLENBQUMsQ0FBQztLQUNQOzs7WUEvRUosVUFBVTs7OztZQUxGLGNBQWM7WUFHZCx1QkFBdUI7WUFDdkIsbUJBQW1COzs7Ozs7O0FDTjVCO0lBYUUsaUJBQWlCOzs7O0lBRWpCLFFBQVE7S0FDUDs7O1lBZEYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxTQUFTO2dCQUNuQixRQUFRLEVBQUU7Ozs7R0FJVDtnQkFDRCxNQUFNLEVBQUUsRUFBRTthQUNYOzs7Ozs7Ozs7Ozs7OztBQ1BELHVCQUE4Qix1QkFBZ0QsRUFDMUUsS0FBMEI7SUFDMUIsT0FBTyxNQUFNLElBQUksT0FBTyxDQUFPLENBQUMsT0FBTyxFQUFFLE1BQU07UUFDN0MsdUJBQXVCLENBQUMsaUJBQWlCLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxJQUFJLENBQUM7O1lBQ2pGLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDOztZQUM1QyxNQUFNLHlCQUF5QixHQUFHLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUseUJBQXlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7Z0JBQzlELE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxDQUFDLDRCQUE0QixFQUFFLENBQUM7O2dCQUNsRSxNQUFNLHNCQUFzQixHQUFHLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxDQUFDOztnQkFDdEUsTUFBTSxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs7Z0JBQ3BELE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQzs7Z0JBQ2hELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7O2dCQUNwRCxNQUFNLGtDQUFrQyxHQUFHLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDO2dCQUN0RixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsb0JBQW9CLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCO29CQUMxRSxlQUFlLEVBQUUsaUJBQWlCLEVBQUUsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDN0UsS0FBSyxDQUFDLG1CQUFtQixFQUFFLENBQUM7b0JBQzVCLE9BQU8sRUFBRSxDQUFDO2lCQUNaLEVBQUUsQ0FBQyxLQUFLO29CQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ25CLE1BQU0sRUFBRSxDQUFDO2lCQUNkLENBQUMsQ0FBQzthQUNKLEVBQUUsQ0FBQyxLQUFLO2dCQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sRUFBRSxDQUFDO2FBQ1YsQ0FBQyxDQUFDO1NBQ0osRUFBRSxDQUFDLEtBQUs7WUFDUCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25CLE1BQU0sRUFBRSxDQUFDO1NBQ1YsQ0FBQyxDQUFDO0tBQ0osQ0FBQyxDQUFDO0NBQ0o7Ozs7OztBQ2pDSCxXQW1CZ0IsYUFBYTtBQVM3Qjs7OztJQUNTLE9BQU8sT0FBTztRQUNuQixPQUFPO1lBQ0wsUUFBUSxFQUFFLFNBQVM7WUFDbkIsU0FBUyxFQUFFLEVBQUU7U0FDZCxDQUFDOzs7O1lBckJMLFFBQVEsU0FBQztnQkFDUixPQUFPLEVBQUUsRUFDUjtnQkFDRCxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUM7Z0JBQzVCLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQztnQkFDdkIsU0FBUyxFQUFFLENBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRyxjQUFjLEVBQUUsdUJBQXVCLEVBQUUsbUJBQW1CLEVBQUU7d0JBQ3JHLE9BQU8sRUFBRSxlQUFlO3dCQUN4QixVQUFVLElBQWU7d0JBQ3pCLElBQUksRUFBRSxDQUFDLHVCQUF1QixFQUFFLG1CQUFtQixDQUFDO3dCQUNwRCxLQUFLLEVBQUUsSUFBSTtxQkFDWixFQUFFO3dCQUNELE9BQU8sRUFBRSxpQkFBaUI7d0JBQzFCLFFBQVEsRUFBRSx1QkFBdUI7d0JBQ2pDLEtBQUssRUFBRSxJQUFJO3FCQUNaLENBQUM7YUFDSDs7Ozs7Ozs7Ozs7Ozs7OyJ9