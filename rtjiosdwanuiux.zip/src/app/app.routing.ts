import { Routes } from '@angular/router';
import { NavigationComponent } from './Operations/Navigation/navigation.component';
import { DashboardComponent } from './Operations/Dashboard/dashboard.component';
import { ModuleActivateGuard } from './SharedFolder/services/moduleActivate.guard';

export const AppRoutes: Routes = [
  {
    path: 'layout',
    component: NavigationComponent,
    children: [
      {
        path: 'underlayService',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Underlay Management' },
        loadChildren: './Operations/Modules/UnderlayService/service-module.module#ServiceModuleModule'
      },
      {
        path: 'opticalTransport',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Optical Transport' },
        loadChildren: './Operations/Modules/OpticalTransport/opticalTransport.module#OpticalTransportModule'
      },
      {
        path: 'CPE_Management',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'CPE Management' },
        loadChildren: './Operations/Modules/CPE_Management/cpeManagement.module#CPEManagementModule'
      },
      {
        path: 'userManagement',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'User Management' },
        loadChildren: './Operations/Modules/User_Management/user-management.module#UserManagementModule'
      },
      {
        path: 'Dashboard',
        component: DashboardComponent
      },
      { path: '**', redirectTo: 'Dashboard' }
    ]
  }
];
