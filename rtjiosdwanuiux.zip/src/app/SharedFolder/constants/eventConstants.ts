export class EventConstants {

  //underlayService Events
  public static readonly ADD_CUSTOMER: string = 'addcustomerrequest';
  public static readonly COMPLETE_DELETE: string = 'deletesingleservice';
  public static readonly MODIFY_SERVICE: string = 'modifyservicerequest ';
  public static readonly PARTIAL_DELETE: string = 'deletesingleservicepartial';
  public static readonly DEVICE_DETAILS_REQUEST: string = 'devicedetailsrequest';
  public static readonly DEVICE_PORT_DETAILS_REQUEST: string = 'deviceportdetailsrequest';
  public static readonly PROVISION_SERVICE_REQUEST: string = 'provisionservicerequest';
  public static readonly ALD = 'Adl';
  public static readonly GET_SERVICE_STATUS = 'getServiceStatus';
  public static readonly GET_SERVICE_ORDER_INFO = 'getServiceOrderInfo';
  public static readonly GET_ALL_CUSTOMER_DETAILS = 'GetAllCustomerDetails';

  //opticalTransport Events
  public static readonly CIENA_BOD_SNC_MR: string = 'bod';
  public static readonly CIENA_BOD_SNCP_MR: string = 'bodProtected';
  public static readonly NOKIA_BOD_AEND_ZEND: string = 'getNodesRequest';
  public static readonly NOKIA_BOD: string = 'BoD';
  public static readonly CIENA_BOD_AEND_ZEND: string = 'getnodelistrequest';
  public static readonly CIENA_BOD: string = 'bod';
  public static readonly CIENA_BOD_PROTECTED = 'bodProtected';
  public static readonly CIENA_BOD_EXPLICIT: string = 'bodExplicit';
  public static readonly CIENA_BOD_PROTECTED_EXPLICIT: string = 'bodExplicitProtected';
  public static readonly CIENA_EXPLICIT_BULK_TEMPLATE = 'explicitBulkTemplate';
  public static readonly CIENA_IMPLICIT_BULK_TEMPLATE = 'implicitBulkTemplate';
  public static readonly CIENA_IMPLICIT_BULK_VALIDATION = 'ImplicitValidation';
  public static readonly CIENA_EXPLICIT_BULK_VALIDATION = 'ExplicitValidation';
  public static readonly CIENA_VALIDATION_PORTS = 'validateAendZendPort';
  public static readonly CIENA_BULK_BOD = 'BulkBoD';
  public static readonly CIENA_EXPLICIT_BULK_BOD = 'BulkBoDExplicit';
  public static readonly CIENA_GET_BOD_DETAILS = 'getservicedetailsrequest';
  public static readonly CIENA_GET_GCT_LIST = 'getNeidList';
  public static readonly CIENA_DELETE_GCT_DETAILS = 'deleteGctReport';
  public static readonly CIENA_MULTINODE_HEALTHCHECK = 'multiNodeHealthCheck';
  public static readonly CIENA_BULK_HEALTHCHECK = 'bulkhcrequest';
  public static readonly CIENA_GET_HC_TEMPLATE = 'getHctemplate';
  public static readonly CIENA_SERVICE_HC_ASSESMENT = 'servicehc';
  public static readonly CIENA_MODIFY_HC_TEMPLATE = 'modifyHctemplate';
  public static readonly CIENA_SERVICE_NMAP_ASSESMENT = 'nmapassessment';


  public static readonly CIENA_ALARM_CONTEXT = '/PEAG/CIENA/AAnbHandler';
  public static readonly CIENA_ALARM_SUMMARY = 'getAlarmSummary';
  public static readonly CIENA_ALARM_TREND = 'getAlarmTrends';
  public static readonly CIENA_ALARM_TREND_AFFECTED_NODE = 'getTrendsOfAffectedNodes';
  public static readonly CIENA_ALARM_TREND_ZONE = 'getAlarmTrendsOfState';
  public static readonly CIENA_ALARM_TREND_AFFECTED_NODE_ZONE = 'getTrendOfAffectedNodesState';
  public static readonly CIENA_ALARM_GET_CRITICAL_MODAL = 'getCriticalAlarmSummary';

  public static readonly CIENA_ALARM_GET_MODAL = 'getAlarmTemplate';
  public static readonly CIENA_ALARM_DEMAND_UNAVAILABILITY = 'getDemandDetails';
  public static readonly CIENA_ALARM_DUMP = 'getAlarmDump';
  public static readonly CIENA_DEMAND_DUMP = 'getDemandDump';


  public static readonly CIENA_ALARM_DELETE_MODAL = 'deleteAlarm';
  public static readonly CIENA_ALARM_ADD_MODAL = 'addAlarms';
  public static readonly CIENA_ALARM_EDIT_MODAL = 'modifyAlarm';
  public static readonly CIENA_ALARM_DOWNLOAD_MODAL = 'downloadAlarmTemplate';
  public static readonly CIENA_ALARM_DOWNLOAD_TEMPLATE = 'downloadSampleAlarmTemplate';
  public static readonly CIENA_ALARM_UPLOAD_MODAL = 'uploadAlarmTemplate';


  public static readonly CIENA_BACKUP_CONTEXT = '/PEAG/CIENA/BRnbHandler';
  public static readonly CIENA_GET_NODEDATA_BACKUP_CONTEXT = 'getNodeDataForBR';
  public static readonly CIENA_GET_NODEDATA_FOR_NMAP_BACKUP_CONTEXT = 'nmapBackup';
  public static readonly CIENA_GET_NODEDATA_FOR_SCHEDULED_NMAP_BACKUP_CONTEXT = 'scheduleNamapBackup';
  public static readonly CIENA_GET_MULTI_NODEDATA_BACKUP_CONTEXT = 'multipleNodeBackup';
  public static readonly CIENA_GET_ALL_NODEDATA_BACKUP_CONTEXT = 'allNodeBackup';
  public static readonly CIENA_GET_MULTI_SCHEDULE_NODEDATA_BACKUP_CONTEXT = 'scheduleMultiNodeBackup';
  public static readonly CIENA_GET_ALL_SCHEDULE_NODEDATA_BACKUP_CONTEXT = 'scheduleAllNodeBackup';
  public static readonly CIENA_CHECK_BACKUP_CONTEXT = 'checkBackUp';
  public static readonly CIENA_ALLCHECK_BACKUP_CONTEXT = 'checkAllBackUp';
  public static readonly CIENA_RESTORE_BACKUP_PATH_CONTEXT = 'onDemandNodeImages';
  public static readonly CIENA_RESTORE_ON_DEMAND_CONTEXT = 'onDemandRestoration';
  public static readonly CIENA_GET_LOG_RESTORE_CONTEXT = 'getBackupAndRestoreLogDetails';
  public static readonly CIENA_GET_ALL_CIRCLE_CONTEXT = 'getAllCircles';
  public static readonly CIENA_GET_ALL_NETWORK_CONTEXT = 'getAllNetworks';
  public static readonly CIENA_GET_FILTERED_DATA_CONTEXT = 'getFilteredDataForBR';
  public static readonly CIENA_GET_ALLDATA_CONTEXT = 'getAllNodes';

  public static readonly CIENA_PM_MANAGEMENT = '/PEAG/CIENA/PMnbHandler';
  public static readonly CIENA_GET_NODEDATA_RESOURCE_TYPE = 'getNodeDataForResourceType';
  public static readonly CIENA_PORT_LEVEL_PM_MULTINODE = 'portLevelPmMultinode';
  public static readonly CIENA_PORT_LEVEL_VIEW_PM_MULTINODE = 'viewPmNodeDetails'
  public static readonly CIENA_PORT_COUNTERS_ALL_CATEGORY = 'getAllCountersForCategory';
  public static readonly CIENA_PORT_VIEW_PM_TREND_FOR_COUNTER = 'viewPmTrendForCounter'
  public static readonly CIENA_DOWNLOAD_PORT_LEVEL_PM_REPORT = 'downloadPortLevelPmReport'
  public static readonly CIENA_GET_DEMANDS = 'getDemandsForNode';
  public static readonly CIENA_GET_PM_Counters = 'getAllCountersForDemand';

  public static readonly CIENA_GET_DEMAND_PM = 'demandPm';
  public static readonly CIENA_GET_DEMAND_TREND = 'viewPmDemandTrendForCounter';
  //public static readonly CIENA_GET_PORT_LEVEL_PM_MULTINODE = 'portLevelPmMultinode';
  public static readonly CIENA_GET_PMDEMANDPM = 'demandPm';
  public static readonly CIENA_DOWNLOAD_DEMAND = 'downloadDemandPmReport'

  public static readonly CIENA_INVENTORY_MANAGEMENT = '/PEAG/CIENA/INVMnbHandler';
  public static readonly CIENA_DOWNLOAD_REPORT = 'downloadReport';
  public static readonly CIENA_GET_REPORT_LIST = 'getReportList';


  public static readonly CIENA_INVENTORY_NODELIST_TYPE = 'getNodesList';
  public static readonly CIENA_INVENTORY_LINKSLIST_TYPE = 'getLinksList';
  public static readonly CIENA_FETCH_INVENTORY_TYPE = 'fetchInventoryDetails'
  public static readonly CIENA_INVENTORY_SCHEDULE_REPORT = 'scheduleInvm';
  public static readonly CIENA_INVENTORY_GET_SCHEDULED_REPORTS = 'getSchedulerList';
  public static readonly CIENA_INVENTORY_CANCEL_SCHEDULED_REPORT = 'cancelINVMScheduler';


  public static readonly NOKIA_BULK_BOD = 'BulkBoD';
  public static readonly NOKIA_GET_BOD_DETAILS = 'getservicedetailsrequest'
  public static readonly DOWNLOAD_TEMPLATE = 'downloadtemplate'
  public static readonly NOKIA_GCT = 'GCT';
  public static readonly CIENA_GCT = 'GCT';
  public static readonly NOKIA_BULK_GCT = 'BulkGCT';
  public static readonly NOKIA_GCT_GET_NEID_LIST = 'getNeidList';
  public static readonly NOKIA_DELETE_GCT_DETAILS = 'deleteGctReport';
  public static readonly CIENA_DELETE_BOD_DETAILS = 'deleteservice';
  public static readonly NOKIA_GET_GCT_TEMPLATE = "getGCTTemplate";
  public static readonly NOKIA_MODIFY_GCT_TEMPLATE = "modifyGCTTemplate";
  public static readonly NOKIA_GET_HC_TEMPLATE = "getHctemplate"
  public static readonly NOKIA_MODIFY_HC_TEMPLATE = "modifyHctemplate"
  public static readonly NOKLA_NSP_INFRA_CONTEXT = "/PEAG/nbHandlerNokiaInfra";
  public static readonly NOKIA_NSP_INFRA_PROVISION = "provInfra";
  public static readonly NOKIA_BULK_INFRA_PROVISIONING = "bulkProvInfra";
  public static readonly NOKIA_INFRA_DOWNLOAD_TEMPLATE = "downloadtemplate";
  public static readonly NOKIA_INFRA_TRAIL_DETAIL = "gettrailsdetailsrequest";
  public static readonly NOKIA_INFRA_DELETE_TRAIL = "deleteTrails";
  public static readonly NOKIA_INFRA_EXPORT_DETAIL = "exportTrailDetails";
  //CPE Events

  //DomainServer Events
  public static readonly CPE_DOMAINSERVER_CREATE: string = "createDomainServer";
  public static readonly CPE_DOMAINSERVER_GETALLSERVER: string = "getAllDomainServer";
  public static readonly CPE_DOMAINSERVER_DELETESERVER: string = "deleteDomainServer";
  // **CPE_Management Events**



  //ZTP
  public static readonly CREATE_ZTP = "ztp"
  public static readonly UPDATE_ZTP = "updateDomainServer"
  public static readonly GET_DUID_MAPPING = "getduidmapping"
  public static readonly DELETE_DUID_MAPPING = "deprovision"
  public static readonly GET_CUSTOMER_DETAILS_LIST = "getAllCustomerNames"
  public static readonly ZTPContextHandler = "/PEAG/RAD/nbHandler"

  //VIEW DETAIL CONTEXT 
  public static readonly VIEW_DETAILS_CONTEXT = '/oms1350/data/npr/node';


  //CustomParameters

  public static readonly CREATE_CUSTOM_PARAMETERS = 'createTargetedConfigurationParameter';
  public static readonly GET_ALL_TARGET_CONFIG_PARAMETERS = 'getAllTargetedConfigurationParameters';
  public static readonly GET_PARAMETER_BY_CUSTOM = 'getTargetedConfigurationParametersByName';
  public static readonly DELETE_PARAMETER_BY_CUSTOM = 'deleteTargetedConfigurationParameter';
  public static readonly CustomParametersContextHandler = '/PEAG/RAD/GUIHandler';

  //Template Management

  public static readonly CREATE_TEMPLATE = 'createTemplate';
  public static readonly GET_ALL_TEMPLATE = 'getAllTemplate';
  public static readonly DELETE_TEMPLATE = 'deleteTemplate';
  public static readonly TemplateContextHanlder = '/PEAG/RAD/GUIHandler';

  //getZTPDetails

  public static readonly GET_ZTP_DETAILS = 'getZTPDetailsRequest';
  public static readonly GET_ZTP_STATUS = 'getZTPDetailsByFilter';
  public static readonly ZTP_DOWNLOAD_FILE = 'downloadFile';
  public static readonly ZTP_DOWNLOAD_FILE_TABLE = 'downloadZTPDetailsByFilter';
  public static readonly GET_ZTP_ORDER_STATUS = 'getZTPOrderStatus';
  public static readonly GetZTPStatusContextHandler = '/PEAG/RAD/GUIHandler'
  public static readonly GetZTPDetailsContextHandler = '/PEAG/RAD/nbHandler';

  //customerDetails

  public static readonly GET_CUSTOMER_DETAILS = 'getCustomerDetails';
  public static readonly GET_ALL_CUSTOMERSITE_LIST = 'getAllCustomerSiteList';
  public static readonly ROW_TABLE_LIST = 'downloadCustomerSiteDetails';
  public static readonly MAIN_TABLE_LIST = 'downloadAllCustomerSites';
  public static readonly CustomerDetailsContextHandler = '/PEAG/RAD/GUIHandler';

  //getDOmainByCircle
  public static readonly GET_DOMAINSERVER_CIRCLEWISE = 'getCirclesList';
  public static readonly GET_DOMAIN_BY_CIRCLENAME = 'getDomainServerByCircleName';
  public static readonly getDomainServerCircleWise = '/PEAG/RAD/GUIHandler';

  //getDomainByDUID

  public static readonly GET_DOMAIN_BY_DUID = 'getDomainServerByDUID';

  //IAM

  public static readonly ACCESS_CONTEXT = '/IAM/access';
  public static readonly IDENTITY_CONTEXT = '/IAM/identity';

  //Spinner

  public static readonly SPINNER_TIMER = 60000;

  // constant for gct-scheduler
  public static readonly SCHEDULE_GCT = 'scheduleGCT';
  public static readonly SCHEDULE_PM = 'schedulePMCorrelation';
  public static readonly GET_SCHEDULE_GCT = 'getSchedulerList';
  public static readonly DELETE_SCHEDULE_GCT = 'cancelScheduler';
  public static readonly DELETE_PM_SCHEDULER = 'cancelSchedulerPM'
  public static readonly GCT_SCHEDULER_NAME = 'GCT-Schedular';
  public static readonly GCT_PM_SCHEDULER_NAME = 'PM-Schedular'
  public static readonly GET_PM_SCHEDULE_LIST = 'getSchedulerListPM';
  public static readonly HEALTH_CHECK_SCHEDULER_NAME = 'Health-Check-Schedular';
  //Constants for Nokia NSP / Health-Check Module

  public static readonly POST_MULT_NODE_HC = 'multinodehc';
  public static readonly POST_BULK_HC_REQUEST = 'bulkhcrequest';
  public static readonly GET_HC_REPORT_REQUEST = 'getHCReportList';
  public static readonly DOWNLOAD_HC_REPORT = 'getHCReport';
  public static readonly DELETE_HC_REPORT = 'deleteHcReport';
  public static readonly POST_SERVICE_HC = 'servicehc';
  public static readonly POST_SCHEDULE_HC = 'scheduleHC';
  public static readonly GET_SCHEDULE_HC_LIST = 'getSchedulerListHC';
  public static readonly DELETE_SCHEDULE_HC = 'cancelSchedulerHC';
  public static readonly GET_NODE_BULK_LIST = 'getbulkhcparameter'
  public static readonly GET_VIEW_DETAIL_API = 'getApiCall';
}
