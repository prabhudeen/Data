import { Component, OnInit, OnDestroy, Output, EventEmitter, HostListener } from '@angular/core';
import { NotificationMessageService } from '../services/notificationMessage.service';
import { SessionService } from '../services/sessionService.service';
import { Observable, Subscription } from 'rxjs';
import { ObserveOnSubscriber } from 'rxjs/internal/operators/observeOn';
import { SubscribeOnObservable } from 'rxjs/internal-compatibility';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit, OnDestroy {

  closed = new EventEmitter<any>();
  NOTIFICATION: string = "notification";

  let
  loading = false;
  // loader           = cfg.loader || angular.noop,
  loaded = [];
  readProperty = 'read';
  autoLoad = true;
  totalItems = 0;
  totalUnreadItems = 0;
  unreadNotification: any[] = [];
  badgeVisible: boolean = false;
  userName: string = '';
  notificationObservable: Subscription;
  constructor(private notificationMessage: NotificationMessageService,
    private sessionService: SessionService) { }

  ngOnInit() {
    this.userName = this.sessionService.get("userName");
    console.log(this.userName);
    if (this.sessionService.get(this.userName + '_' + this.NOTIFICATION)) {
      this.loaded = this.sessionService.get(this.userName + '_' + this.NOTIFICATION)
    }
    else {
      this.loaded = [];
    }
    console.log('loaded Data = ', this.loaded);
    this.totalItems = this.loaded.length;
    this.loaded.forEach(data => {
      if (data['read'] === false) this.totalUnreadItems = this.totalUnreadItems + 1;
    })

    if (this.totalUnreadItems > 0) {
      this.badgeVisible = true;
    }
    this.notificationObservable = this.notificationMessage.getObservable()
      .subscribe(data => {
        console.log(data['state']);
        this.loaded.unshift({ data: data['state'] || data['status'], read: false });
        this.totalUnreadItems = this.totalUnreadItems + 1;
        if (this.loaded.length > 50) this.loaded = this.loaded.slice(0, 50);
        this.sessionService.set(this.userName + '_' + this.NOTIFICATION, this.loaded);

        if (this.totalUnreadItems > 0) {
          this.badgeVisible = true;
        }
      });

  }


  markReadNotification($event) {
    this.badgeVisible = false;
    // this.loaded=[];
    this.unreadNotification = [];
    this.loaded.forEach(data => data['read'] = true);
    this.totalUnreadItems = 0;

    this.sessionService.set(this.userName + '_' + this.NOTIFICATION, this.loaded);
  }


  removeAllNotification($event) {
    console.log('removeAllNotificaton Data ', $event);
    this.loaded = [];
    this.totalUnreadItems = 0;
    this.badgeVisible = false;
    this.sessionService.set(this.userName + '_' + this.NOTIFICATION, this.loaded);
    $event.stopPropagation();
  }

  showDropDrown() {

  }


  isLoading() {
    return this.loading;
  };

  getTotalItems() {
    return this.totalItems;
  };

  getUnreadItems() {
    return this.totalUnreadItems;
  };

  getLoadedData() {
    return this.loaded;
  };
  hasItems() {
    return this.totalItems > 0;
  };
  hasUnreadItems() {
    return this.totalUnreadItems > 0;
  };

  allItemsUnread() {
    return this.totalUnreadItems === this.totalItems;
  };

  @HostListener('window:beforeunload')
  doSomething() {
    console.log('ngDestroy in notification ..')
    this.notificationObservable.unsubscribe();
  }

  ngOnDestroy(): void {
    console.log('ngDestroy in notification ..')
    this.notificationObservable.unsubscribe();
  }

}
