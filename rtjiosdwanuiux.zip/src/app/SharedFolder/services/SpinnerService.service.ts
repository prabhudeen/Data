import { Injectable } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationService } from './notification.service';

@Injectable({
    providedIn: 'root'
})

export class SpinnerService {
    private clearSetTimeout;
    private timer = 60000 * 2; // time in milliseconds 

    constructor(private ngxSpinner: NgxSpinnerService,
        private notificationService: NotificationService) {
    }

    gotoTop() {
        const element = document.querySelector('#matsidenavscroll');
        element.scrollTo(0,0)
    }

    start(timerValue = this.timer) {
        this.gotoTop();
        this.ngxSpinner.show();
        this.clearSetTimeout = setTimeout(() => {
            this.stop();
            this.notificationService.notificationMessage('Response not received', 'danger');
        }, timerValue);
    }

    stop() {
        this.ngxSpinner.hide();
        clearTimeout(this.clearSetTimeout);
    }

}