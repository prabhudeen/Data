import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AccessService } from './access.service';
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class ModuleActivateGuard implements CanActivate {

    constructor(private accessModuleService: AccessService) {
        this.accessModuleService._setModulesRestriction();
    }

    canActivate(router: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {

        let level = router.data.level;
        let moduleName = router.data.moduleName;

        if (level === 'Module') {
            let moduleShortCode = this.accessModuleService.getShortCode(moduleName);
            return this.accessModuleService.modulesRestriction[moduleShortCode] ? true : false;
        }

        if (level === 'SubModule') {

            let subModuleName = router.data.subModuleName;
            let accessType = router.data.accessType;
            let moduleShortCode = this.accessModuleService.getShortCode(moduleName);
            let subModuleShortCode = this.accessModuleService.getShortCode(subModuleName);


            if (this.accessModuleService.modulesRestriction[moduleShortCode]) {

                let subModuleAccess = this.accessModuleService.modulesRestriction[moduleShortCode][subModuleShortCode];

                if (accessType === undefined) {
                    return subModuleAccess ? true : false;
                } else {
                    if (subModuleAccess) {
                        return this.accessModuleService.modulesRestriction[moduleShortCode][subModuleShortCode]['access'][accessType];
                    } else {
                        return false;
                    }
                }

            } else {
                return false;
            }
        }
    }
}