import { Injectable } from '@angular/core';
import { SessionService } from 'iam';

@Injectable({
    providedIn: "root"
})
export class AccessService {

    modulesRestriction: any = null;

    constructor(private sessionService: SessionService) { }

    _setModulesRestriction() {
        this.modulesRestriction = this.sessionService.getSessionDataForModuleRestriction();
    }

    _getModuleRestriction(name) {

        if (!this.modulesRestriction) {
            this._setModulesRestriction();
        }

        let shortCodeForModule = this.getShortCode(name);
        return this.modulesRestriction[shortCodeForModule];
    }

    clearModulesRestriction() {
        this.modulesRestriction = null;
    }

    getAccessForSideBar(list: any[]) {

        let result;

        if (!this.modulesRestriction) {
            this._setModulesRestriction();
        }

        result = JSON.parse(JSON.stringify(list));


        result.forEach(moduleType => {

            let shortCodeForModule = this.getShortCode(moduleType.value);

            if (this.modulesRestriction[shortCodeForModule]) {
                moduleType.access = true;

                if (moduleType.title !== 'User Management') {

                    let moduleRestriction = this.modulesRestriction[shortCodeForModule];

                    if (moduleType.type === 'SubLink') {
                        // as of now only for Optical Transport
                        moduleType.subLink.forEach(subModuleType => {
                            let flag = false;
                            subModuleType.subChildren.forEach(subChildrenType => {
                                let subChildrenShortCode = this.getShortCode(subChildrenType.value);
                                if (moduleRestriction[subChildrenShortCode]) {
                                    subChildrenType.access = true;
                                    flag = true;
                                } else {
                                    subChildrenType.access = false;
                                }
                            });
                            subModuleType.access = flag;
                        });

                    } else if (moduleType.type === 'SubList') {

                        moduleType.subList.forEach(subModuleType => {
                            let subModuleShortCode = this.getShortCode(subModuleType.value);
                            if (moduleRestriction[subModuleShortCode]) {
                                subModuleType.access = true;
                            } else {
                                subModuleType.access = false;
                            }
                        });

                    } else if (moduleType.type = 'SubLinkAndList') {

                        moduleType.subList.forEach(subModuleType => {
                            let subModuleShortCode = this.getShortCode(subModuleType.value);
                            if (moduleRestriction[subModuleShortCode]) {
                                subModuleType.access = true;
                            } else {
                                subModuleType.access = false;
                            }
                        });

                        moduleType.subLink.forEach(subModuleType => {
                            let subModuleShortCode = this.getShortCode(subModuleType.value);
                            if (moduleRestriction[subModuleShortCode]) {
                                subModuleType.access = true;
                                subModuleType.subChildren.forEach((subChildModuleType, index) => {
                                    if (index == 0) {
                                        subChildModuleType.access = this.getAccessForSubModule(moduleType.value, subModuleType.value, 'W');
                                    }
                                    else {
                                        subChildModuleType.access = this.getAccessForSubModule(moduleType.value, subModuleType.value, 'R');
                                    }
                                })
                            } else {
                                subModuleType.access = false;
                            }
                        })
                    }
                }
            } else {
                moduleType.access = false;
            }
        });
        return result;
    }

    getAccessForSubModule(moduleName, subModuleName, method) {
        let restriction;

        if (!this.modulesRestriction) {
            this._setModulesRestriction();
        }

        let shortCodeForModule = this.getShortCode(moduleName);
        let shortCodeForSubModule = this.getShortCode(subModuleName);

        if (this.modulesRestriction[shortCodeForModule][shortCodeForSubModule]) {
            return this.modulesRestriction[shortCodeForModule][shortCodeForSubModule]['access'][method] ? true : false;
        } else {
            return false;
        }

    }

    getListWithModuleRestrictionAccess(list: any[], moduleName: string, isOptical?: boolean) {

        let restriction;

        if (moduleName === 'ModuleLevel') {

            if (!this.modulesRestriction) {
                this._setModulesRestriction();
            }
            restriction = this.modulesRestriction;

        } else {
            restriction = this._getModuleRestriction(moduleName);
        }

        let result = JSON.parse(JSON.stringify(list));

        if (isOptical) {
            result.forEach(item => {
                let flag = false;
                item.childList.forEach(childItemName => {
                    let subModuleShortCode = this.getShortCode(childItemName);
                    if (restriction[subModuleShortCode]) {
                        flag = true;
                    }
                });
                item.access = flag;
            });
        } else {
            result.forEach(item => {
                let subModulename = item.value;
                let subModuleShortCode = this.getShortCode(subModulename);

                if (subModuleShortCode && restriction[subModuleShortCode]) {
                    item.access = true;
                } else {
                    item.access = false;
                }
            });
        }

        return result;
    }

    getShortCode(name) {

        switch (name) {
            case "Optical Transport": return "sc1";
            case "Ciena MCP Bandwidth on Demand Module": return "sc1.1";
            case "Ciena MCP GCT Module": return "sc1.2";
            case "Nokia NSP Bandwidth on Demand Module": return "sc1.3";
            case "Nokia NSP GCT Module": return "sc1.4";
            case "Nokia NSP Health Check Module": return "sc1.5";
            case "Nokia NSP Node Module": return "sc1.6";
            case "Nokia NSP Service Module": return "sc1.7";
            case "Nokia NSP Health Schedule Module": return "sc1.8";
            case "Nokia NSP Get Data Module": return "sc1.9";
            case "Nokia NSP Health Check Template Module": return "sc1.10"
            case "Nokia Infra trails Module": return "sc1.13";
            case "Ciena MCP Health Check Module": return "sc1.11";
            case "Ciena MCP Get Data Module": return "sc1.12";
            case "Ciena MCP Alarm Analysis Module": return "sc1.14";
            case "Ciena MCP Backup and Restore Module": return "sc1.15";
            case "Ciena MCP PM Management Module": return "sc1.16";
            case "Ciena MCP Inventory Management Module": return "sc1.17";


            case "CPE Management": return "sc2"
            case "Circle": return "sc2.1"
            case "Domain Server": return "sc2.2"
            case "ZTP": return "sc2.3"
            case "Custom Parameters": return "sc2.4"
            case "Template Management": return "sc2.5"
            case "Customer Details": return "sc2.6"
            case "BootStrap Server Details": return "sc2.7"

            case "Underlay Management": return "sc3"
            case "Add Customer": return "sc3.1"
            case "Provision Service": return "sc3.2"
            case "Modify Service": return "sc3.3"
            case "Delete Service": return "sc3.4"
            case "Partial Delete": return "sc3.5"
            case "Service Status": return "sc3.6"

            case "User Management": return "sc4"

            default: return null;
        }
    }

}