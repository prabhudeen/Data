import { Injectable, OnDestroy } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { SdWanServiceService } from './sd-wan-service.service';


@Injectable({
  providedIn: 'root'
})
export class NotificationMessageService{
 
  private notificationSubject = new Subject<any>();
  constructor() { }

  getNotification(response,callbacks): any{
          //  console.log(callbacks);
           this.notificationSubject.next(response);
    }

    getObservable():Observable<any>{
      return this.notificationSubject.asObservable();
    }
}
