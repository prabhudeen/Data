import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { HttpService, WebSocketCallbackClass, Request, AppConfigurationService } from 'iam';
import { UUID } from 'angular2-uuid';
import { NotificationService } from './notification.service';
import { SessionService } from './sessionService.service';
import { SpinnerService } from './SpinnerService.service';
import { NotificationMessageService } from './notificationMessage.service';
declare const $: any;
@Injectable({
  providedIn: 'root'
})
export class SdWanServiceService {

  callbacks: any = {};

  constructor(private httpService: HttpService,
    private notificationService: NotificationService,
    private _sessionService: SessionService,
    private notificationMessage: NotificationMessageService,
    private spinnerService: SpinnerService,
    private appConfigurationService: AppConfigurationService) {
    this.restartWebsocket();

    WebSocketCallbackClass.getOnWebsocketReconnectObservable().subscribe(() => {
      this.restartWebsocket();
    });

  }

  restartWebsocket() {

    if (this.appConfigurationService.getConfiguration()['production']) {
      this.disableLogger();
    }

    WebSocketCallbackClass.reInitializeObservables();

    WebSocketCallbackClass.getOnMessageObservable().subscribe(
      (resp) => {
        const response = JSON.parse(resp.data);
        console.log(response);
        if (response['headers']['X-Message-Type'] === 'eventACK') {
          if (this.callbacks[response['headers']['X-Flow-Id']]) {
            this.callbacks[response['headers']['X-Flow-Id']].subscribe.next(response);
            delete this.callbacks[response['headers']['X-Flow-Id']];
            let toasterType;
            let toasterMsg;
            let errorMsg;
            if (response['status_code'] === 400 || response['status_code'] === 5002 || response['status_code'] === 404) {
              if (response['status']) {
                toasterMsg = `Error Ack : ` + response['status'];
              } else if (response['reason']) {
                toasterMsg = `Error Ack : ` + response['reason'];
              } else if (response['message']) {
                toasterMsg = `Error Ack : ` + response['message'];
              } else if (response['errorMessage']) {
                toasterMsg = `Error Ack : ` + response['errorMessage'];
              }
              errorMsg = toasterMsg;
              toasterType = 'danger';
              console.log(`Error Message : Event Name = `
                + ` | Flow Id = `
                + response['headers']['X-Flow-Id']
                + ` | Message = `
                + JSON.stringify(errorMsg));
              this.notificationService.notificationMessage(toasterMsg, toasterType);
            }
            if (response['status_code'] == 500) {
              toasterType = 'danger';
              if (response['state']) {
                toasterMsg = `Error Ack : ` + response['state'];
              } else if (response['reason']) {
                toasterMsg = `Error Ack : ` + response['reason'];
              }
              console.log(`Error Message : Event Name = `
                + ` | Flow Id = `
                + response['headers']['X-Flow-Id']
                + ` | Message = `
                + JSON.stringify(response['state']));

              this.notificationService.notificationMessage(toasterMsg, toasterType);
            }
          }
        }
        else if (response['headers']['X-Message-Type'] === 'notification') {
          this.notificationMessage.getNotification(response, this.callbacks);
        }
      });
  }

  disableLogger() {
    console.log = function () { }
  }

  sendRequest(requestType: string, context: string,
    reqBody: any, headers: HttpHeaders, queryString: string, eventKey: string) {

    console.log(`Sending Request : Type = `, requestType,
      `| context = `, context, `| request body = `, JSON.stringify(reqBody),
      `| query string = `, queryString + `| event key =`, eventKey);

    const callBackId = UUID.UUID();

    console.log('callbackId:' + callBackId);

    if (headers === null) {
      headers = new HttpHeaders()
        .append('X-Flow-Id', callBackId)
        .append('X-Message-Type', 'event')
        .append('Event-Key', eventKey)
        .append('UserName', this._sessionService.get('userName'))
    } else {
      console.log(`request headers = `);
      for (const header of headers.keys()) {
        console.log(header + ' : ' + headers.get(header));
      }
      headers = headers.append('X-Flow-Id', callBackId)
        .append('X-Message-Type', 'event')
        .append('Event-Key', eventKey)
        .append('UserName', this._sessionService.get('userName'))
    }

    const request: Request = {
      data: reqBody,
      headers: headers,
      queryString: queryString,
      context: context
    };
    console.log('Headers', headers);

    switch (requestType.toUpperCase()) {

      case 'POST':
        return new Observable<any>(observe => {
          this.updateCallbacks(observe, callBackId);
          console.log('called post function...');
          this.updateCallbacks(observe, callBackId);
          this.httpService.postData(request).subscribe(
            (data) => {
              console.log("ERM Response", JSON.stringify(data));
            },
            (error) => {
              console.log('error case');
              console.log(error);
              if (error.error.statusCode.httpstatuscode == 404 || error.error.statusCode.httpstatuscode == 401) {
                this.notificationService.notificationMessage(error.error.log, 'danger');
              }
              this.spinnerService.stop();
              delete this.callbacks[callBackId];
            }
          );
        });

      case 'GET':
        return new Observable<any>(observe => {
          this.updateCallbacks(observe, callBackId);
          this.httpService.getData(request).subscribe(
            (data) => {
              console.log("ERM Response", JSON.stringify(data));
            },
            (error) => {
              console.log('error case');
              console.log(error);
              if (error.error.statusCode.httpstatuscode == 404 || error.error.statusCode.httpstatuscode == 401) {
                this.notificationService.notificationMessage(error.error.log, 'danger');
              }
              this.spinnerService.stop();
              delete this.callbacks[callBackId];
            }
          );
        });

      case 'PUT':
        return new Observable<any>(observe => {
          this.updateCallbacks(observe, callBackId);
          this.httpService.putData(request).subscribe(
            (data) => {
              console.log("ERM Response", JSON.stringify(data));
            },
            (error) => {
              console.log('error case');
              console.log(error);
              if (error.error.statusCode.httpstatuscode == 404 || error.error.statusCode.httpstatuscode == 401) {
                this.notificationService.notificationMessage(error.error.log, 'danger');
              }
              this.spinnerService.stop();
              delete this.callbacks[callBackId];
            }
          );
        });

      case 'DELETE':
        return new Observable<any>(observe => {
          this.updateCallbacks(observe, callBackId);
          this.httpService.deleteData(request).subscribe(
            (data) => {
              console.log("ERM Response", JSON.stringify(data));
            },
            (error) => {
              console.log('error case');
              console.log(error);
              if (error.error.statusCode.httpstatuscode == 404 || error.error.statusCode.httpstatuscode == 401) {
                this.notificationService.notificationMessage(error.error.log, 'danger');
              }
              this.spinnerService.stop();
              delete this.callbacks[callBackId];
            }
          );
        });
      case 'PATCH':
        return new Observable<any>(observe => {
          this.updateCallbacks(observe, callBackId);
          this.httpService.patchData(request).subscribe(
            (data) => {
              console.log("ERM Response", JSON.stringify(data));
            },
            (error) => {
              console.log(error);
              if (error.error.statusCode.httpstatuscode == 404 || error.error.statusCode.httpstatuscode == 401) {
                this.notificationService.notificationMessage(error.error.log, 'danger');
              }
              this.spinnerService.stop();
              delete this.callbacks[callBackId];
            }
          );
        });
    }
  }

  updateCallbacks(observe, callBackId) {
    this.callbacks[callBackId] = {
      time: new Date(),
      subscribe: observe
    };
  }
}
