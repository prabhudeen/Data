import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NameFilterPipe } from '../../Operations/Modules/User_Management/Utility/name-filter.pipe';
import { PasswordValidationDirective } from '../../Operations/Modules/User_Management/Utility/password-validation.directive';

@NgModule({
    declarations: [
        NameFilterPipe,
        PasswordValidationDirective
    ],
    imports: [
        MaterialModule,
        FormsModule,
        CommonModule,
        ReactiveFormsModule,
    ],
    exports: [
        CommonModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule,
        NameFilterPipe,
        PasswordValidationDirective
    ]
})
export class SharedModule { }