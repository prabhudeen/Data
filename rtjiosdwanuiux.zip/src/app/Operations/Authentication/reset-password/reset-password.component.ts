import { Component, ViewChild, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionService } from '../../../SharedFolder/services/sessionService.service';
import { IamService, AppConfigurationService, MessageMapping } from 'iam';
import { NotificationService } from '../../../SharedFolder/services/notification.service';
import { UIConfigurationService } from '../../../SharedFolder/services/UIConfig.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  @ViewChild('resetPassword') resetPassword: NgForm;
  usernameIAM;
  uiConfiguration;
  otp: any;
  seen = false;
  seen1 = false;
  constructor(private customSessionService: SessionService,
    private _iamService: IamService,
    private appConfigService: AppConfigurationService,
    private router: Router,
    private notificationService: NotificationService,
    private uiConfigurationService: UIConfigurationService) { }

  ngOnInit() {
    this.usernameIAM = this.customSessionService.get("userName");
    this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
    if (!this.usernameIAM)
      this.router.navigate(['/login']);
    this.customSessionService.remove("userName");
  }

  onArrow() {
    this.router.navigate(['/forgotPassword']);
  }

  onSubmit() {
    this._iamService.resetPassword(this.usernameIAM, this.resetPassword.value["otp"], this.resetPassword.value["newPassword"], this.resetPassword.value["confirmPasswordControl"], this.appConfigService.getConfiguration().project).subscribe(
      response => {
        let message = MessageMapping.getMessage(+response['statusCode']['opStatusCode']);
        if (response["statusCode"]["httpstatuscode"] == 200) {
          this.notificationService.notificationMessage(message, "success");
          this.router.navigate(['/login']);
        }
        else {
          this.notificationService.notificationMessage(message, 'danger');
        }
      }
    );

    // this.router.navigate(['/login']);
  }



}
