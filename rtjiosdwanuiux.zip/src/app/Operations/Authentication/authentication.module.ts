import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LoginUserComponent } from './login-user/login-user.component';
import { LogoutUserComponent } from './logout-user/logout-user.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { authenticationRoutes } from './authentication.routing';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SharedModule } from '../../SharedFolder/modules/shared.module';

@NgModule({
    declarations: [
        LoginUserComponent,
        LogoutUserComponent,
        SessionExpiredComponent,
        ForgotPasswordComponent,
        ResetPasswordComponent
    ],
    imports: [
        RouterModule.forChild(authenticationRoutes),
        SharedModule
    ],
    providers: []
})
export class AuthenticationModule { }
