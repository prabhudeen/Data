import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { IamService, MessageMapping } from 'iam';
import { NotificationService } from '../../../SharedFolder/services/notification.service';
import { SessionService } from '../../../SharedFolder/services/sessionService.service';
import { SdWanServiceService } from '../../../SharedFolder/services/sd-wan-service.service';
import { UIConfigurationService } from '../../../SharedFolder/services/UIConfig.service';
import { AccessService } from '../../../SharedFolder/services/access.service';
declare const $: any;


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.scss']
})
export class LoginUserComponent implements OnInit {

  @ViewChild('form') form: NgForm;
  login: FormGroup;
  displayLogin = false;
  validuserNameLogin = false;
  validPasswordLogin = false;
  email: string;
  password: string;
  uiConfiguration;
  seen = false;
  spinnerValue = false;

  constructor(
    private _notificationService: NotificationService,
    private _iamService: IamService,
    private _sessionService: SessionService,
    private sdWanService: SdWanServiceService,
    private uiConfigurationService: UIConfigurationService,
    private accessService: AccessService
  ) { }

  ngOnInit() {
    this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
  }

  onSubmit() {

    this.accessService.clearModulesRestriction();
    this.spinnerValue = true;
    this._iamService.authenticateUser(this.email, this.password).subscribe(
      (resJson) => {
        this.spinnerValue = false;
        const resBody = resJson['body']['statusCode']['AppData'];

        if (resJson['body']['statusCode']['httpstatuscode'] == 400) {
          let message = MessageMapping.getMessage(+resJson['body']['statusCode']['opStatusCode']);
          if (+resJson['body']['statusCode']['opStatusCode'] == 4006) {
            message = message + `,Please contact Administrator`
          } else {
            message = message + ` \n Attempts Remaining : ${resJson['body']['statusCode']['AppData']['totalLoginAttemptRemaining']}`
          }
          this._notificationService.notificationMessage(message, 'danger');
        }
        if (resBody.roleName) {
          this._sessionService.set('roleName', resBody.roleName);
          this._sessionService.set('userName', this.email);
          this.sdWanService.restartWebsocket();
          // this._iamService.getAccessJson(this.appConfigurationService.getConfiguration().project).subscribe(
          //   response => {
          //     console.log('response for getAccessJSON:', response);
          //   }
          // )
        }
      }
    );
  }
}
