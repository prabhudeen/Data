import { Routes } from '@angular/router';
import { LogoutUserComponent } from './logout-user/logout-user.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

export const authenticationRoutes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginUserComponent
    },
    {
        path: 'logout',
        component: LogoutUserComponent
    },
    {
        path: 'sessionExpired',
        component: SessionExpiredComponent
    },
    {
        path: 'forgotPassword',
        component: ForgotPasswordComponent
    },
    {
        path: 'resetPassword',
        component: ResetPasswordComponent
    }
]
