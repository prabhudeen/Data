import { Component, ViewChild, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { IamService, AppConfigurationService, MessageMapping } from 'iam';
import { SessionService } from '../../../SharedFolder/services/sessionService.service';
import { NotificationService } from '../../../SharedFolder/services/notification.service';
import { UIConfigurationService } from '../../../SharedFolder/services/UIConfig.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  @ViewChild('forgotForm') forgotPasswordForm: NgForm;
  userName: string;
  uiConfiguration;

  constructor(private router: Router,
    private _iamService: IamService,
    private appConfigService: AppConfigurationService,
    private customSessionService: SessionService,
    private notificationService: NotificationService,
    private uiConfigurationService: UIConfigurationService) { }

  ngOnInit() {
    this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
  }

  onSubmit() {
    this.customSessionService.set('userName', this.userName);
    this._iamService.forgotPassword(this.userName, this.appConfigService.getConfiguration().project).subscribe(
      response => {
        let message = MessageMapping.getMessage(+response['statusCode']['opStatusCode']);
        if (response["statusCode"]["httpstatuscode"] == 200) {
          this.router.navigate([`/resetPassword`]);
          this.notificationService.notificationMessage(message, "success");
        }
        else {
          this.notificationService.notificationMessage(message, 'danger');
        }
      }
    );
  }

  onArrow() {
    this.router.navigate([`/login`]);
  }

}
