import { Component, OnInit, ViewChild } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { IamService, MessageMapping } from 'iam';
import { AccessService } from '../../SharedFolder/services/access.service';
import { SessionService } from '../../SharedFolder/services/sessionService.service';
import { NgForm } from '@angular/forms';
import { NotificationService } from '../../SharedFolder/services/notification.service';
import { UIConfigurationService } from '../../SharedFolder/services/UIConfig.service';

// import { MatExpansionPanel } from '@angular/material';


@Component({
  selector: 'navigation-layout',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'],
})
export class NavigationComponent implements OnInit {

  // @ViewChildren(MatExpansionPanel) viewPanels: QueryList<MatExpansionPanel>;
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  userName: string;

  list: any[] = [
    {
      title: 'Optical Transport',
      icon: 'assets/img/opticalTransportIcon.svg',
      type: 'SubLink',
      access: true,
      value: 'Optical Transport',
      subLink: [
        {
          title: 'Ciena MCP',
          access: true,
          value: 'Ciena MCP',
          subChildren: [
            { title: 'BOD', link: '/layout/opticalTransport/cienaMCP/BOD', access: true, value: 'Ciena MCP Bandwidth on Demand Module' },
            { title: 'GCT', link: '/layout/opticalTransport/cienaMCP/GCT', access: true, value: 'Ciena MCP GCT Module' },
            { title: 'Health Check', link: '/layout/opticalTransport/cienaMCP/HealthCheck', access: true, value: 'Ciena MCP Health Check Module' },
            { title: 'Alarm Analysis', link: '/layout/opticalTransport/cienaMCP/AlarmAnalysis', access: true, value: 'Ciena MCP Alarm Analysis Module' },
            { title: 'Backup and Restore', link: '/layout/opticalTransport/cienaMCP/BackupRestore', access: true, value: 'Ciena MCP Backup and Restore Module' },
            { title: 'PM Management', link: '/layout/opticalTransport/cienaMCP/PmManagement', access: true, value: 'Ciena MCP PM Management Module' },
            { title: 'Inventory Management', link: '/layout/opticalTransport/cienaMCP/inventoryManagement', access: true, value: 'Ciena MCP Inventory Management Module' },
            { title: 'Get Data', link: '/layout/opticalTransport/cienaMCP/GetData', access: true, value: 'Ciena MCP Get Data Module' },
          ]
        },
        {
          title: 'Nokia NSP',
          access: true,
          value: 'Nokia NSP',
          subChildren: [
            { title: 'BOD', link: '/layout/opticalTransport/nokiaNSP/BOD', access: true, value: 'Nokia NSP Bandwidth on Demand Module' },
            { title: 'GCT', link: '/layout/opticalTransport/nokiaNSP/GCT', access: true, value: 'Nokia NSP GCT Module' },
            { title: 'Health Check', link: '/layout/opticalTransport/nokiaNSP/Health-Check', access: true, value: 'Nokia NSP Health Check Module' },
            { title: 'Get Data', link: '/layout/opticalTransport/nokiaNSP/view-details', access: true, value: 'Nokia NSP Get Data Module' },
            { title: 'Infra Provisioning', link: '/layout/opticalTransport/nokiaNSP/infra-trails', access: true, value: 'Nokia Infra trails Module' }
          ]
        }
      ]
    },
    {
      title: 'Underlay Service',
      icon: 'assets/img/underlayServiceIcon.svg',
      type: 'SubList',
      access: true,
      value: 'Underlay Management',
      subList: [
        { title: 'Add Customer', link: '/layout/underlayService/addCustomer', access: true, value: 'Add Customer' },
        { title: 'Provison Service', link: '/layout/underlayService/provisionService', access: true, value: 'Provision Service' },
        { title: 'Modify Service', link: '/layout/underlayService/modifyService', access: true, value: 'Modify Service' },
        { title: 'Delete Service', link: '/layout/underlayService/deleteService', access: true, value: 'Delete Service' },
        { title: 'Partial Delete', link: '/layout/underlayService/partialDeleteService', access: true, value: 'Partial Delete' },
        { title: 'Service Status', link: '/layout/underlayService/serviceStatus', access: true, value: 'Service Status' }
      ]
    },
    {
      title: 'vCPE Management',
      icon: 'assets/img/cpeManagementIcon.svg',
      type: 'SubLinkAndList',
      access: true,
      value: 'CPE Management',
      subList: [
        { title: 'Bootstrap Server Details', link: '/layout/CPE_Management/bootstrapServerDetails', access: true, value: 'BootStrap Server Details' },
        { title: 'Customer Details', link: '/layout/CPE_Management/customerDetails', access: true, value: 'Customer Details' },
      ],
      subLink: [
        {
          title: 'Circle',
          access: true,
          value: 'Circle',
          subChildren: [
            { title: 'Create', link: '/layout/CPE_Management/circle/create', access: true },
            { title: 'View All', link: '/layout/CPE_Management/circle/getAll', access: true }
          ]
        },
        {
          title: 'RV Domain Server',
          access: true,
          value: 'Domain Server',
          subChildren: [
            { title: 'Create', link: '/layout/CPE_Management/domainServer/create', access: true },
            { title: 'View All', link: '/layout/CPE_Management/domainServer/getAll', access: true },
            { title: 'View DUID Wise', link: '/layout/CPE_Management/domainServer/getByDuid', access: true },
            { title: 'View Circle Wise', link: '/layout/CPE_Management/domainServer/getByCircle', access: true }
          ]
        },
        {
          title: 'ZTP',
          access: true,
          value: 'ZTP',
          subChildren: [
            { title: 'Create ZTP', link: '/layout/CPE_Management/ztp/create', access: true },
            { title: 'View ZTP Status', link: '/layout/CPE_Management/ztp/getZtpStatus', access: true },
            { title: 'Order Status', link: '/layout/CPE_Management/ztp/orderStatus', access: true }
          ]
        },
        {
          title: 'Custom Parameters',
          access: true,
          value: 'Custom Parameters',
          subChildren: [
            { title: 'Create', link: '/layout/CPE_Management/customParameters/createCustomParameters', access: true },
            { title: 'View All', link: '/layout/CPE_Management/customParameters/getAllTargetedParameters', access: true },
            { title: 'View By Name', link: '/layout/CPE_Management/customParameters/getParametersByCustom', access: true }
          ]
        },
        {
          title: 'Template Management',
          access: true,
          value: 'Template Management',
          subChildren: [
            { title: 'Create', link: '/layout/CPE_Management/templateManagement/createTemplate', access: true },
            { title: 'View All', link: '/layout/CPE_Management/templateManagement/getAllTemplate', access: true }
          ]
        }
      ]
    },
    {
      title: 'User Management',
      icon: 'assets/img/user_Management.svg',
      type: 'SubList',
      access: true,
      value: 'User Management',
      subList: [
        { title: 'User List', link: '/layout/userManagement/userList', access: true },
        { title: 'Create User', link: '/layout/userManagement/createUser', access: true },
      ]
    }
  ]

  @ViewChild('form') form: NgForm;
  isAdmin: boolean = false;
  uiConfiguration;
  seen = false;
  seen1 = false;
  seen2 = false;


  constructor(private breakpointObserver: BreakpointObserver,
    private router: Router,
    private _iamService: IamService,
    private accessService: AccessService,
    private _sessionService: SessionService,
    private notificationService: NotificationService,
    private uiConfigurationService: UIConfigurationService) { }

  ngOnInit() {
    this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
    this.userName = this._sessionService.get('userName');
    if (this.userName === 'admin') {
      this.isAdmin = true;
    }
    this.list = this.accessService.getAccessForSideBar(this.list);
    // this.list[0]['subLink'][0]['subChildren'][6]['access'] = true;
    console.log('this.list :>> ', this.list);
    let roleName = this._sessionService.get('roleName');
    if (roleName && roleName === 'TelcoRole') {
      this.list[3].access = true;
    }

    //order status module should be shown for the users which has admin role and telco role.uk-padding-vertical-remove
    if (roleName && (roleName.includes('admin') || roleName === 'TelcoRole')) {
      this.list[2].subLink[2].subChildren[2].access = true;
    } else {
      this.list[2].subLink[2].subChildren[2].access = false;
    }
  }

  onUpdate() {
    let oldPassword = this.form.value.oldPassword;
    let newPassword = this.form.value.password;
    this._iamService.changePassword(this.userName, oldPassword, newPassword).subscribe(
      (res) => {
        console.log(res);
        this.form.reset();
        let message = MessageMapping.getMessage(+res['statusCode']['opStatusCode']);
        if (res['statusCode']['httpstatuscode'] == 200) {
          this.notificationService.notificationMessage(message, 'success');
        } else {
          this.notificationService.notificationMessage(message, 'danger');

        }
      }
    )
  }

  logout() {
    this._iamService.logoutUser().subscribe(response => {
      this._sessionService.remove('roleName');
    });
  }

  onlogoIcon() {
    this.router.navigate(['layout', 'Dashboard']);
  }

  // togglePanels() {
  //   this.viewPanels.forEach(p => p.close());
  // }

}
