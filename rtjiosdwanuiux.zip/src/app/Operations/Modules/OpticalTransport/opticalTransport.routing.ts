import { Routes } from '@angular/router';
import { OpticalTransportComponent } from './optical-transport.component';
import { CienaBodComponent } from './cienaMCP/ciena-bod/ciena-bod.component';
import { CienaMCPComponent } from './cienaMCP/ciena-mcp.component';
import { NokiaNspComponent } from './nokiaNSP/nokia-nsp.component';
import { NokiaBodComponent } from './nokiaNSP/nokia-bod/nokia-bod.component';
import { CienaGCTComponent } from './cienaMCP/ciena-gct/ciena-gct.component';
import { NokiaGCTComponent } from './nokiaNSP/nokia-gct/nokia-gct.component';
import { NokiaGctTemplateComponent } from './nokiaNSP/nokia-gct-template/nokia-gct-template.component';
import { HealthCheckComponent } from './nokiaNSP/health-check/health-check.component';
import { NokiaNodeComponent } from './nokiaNSP/health-check/nokia-node/nokia-node.component';
import { NokiaServiceComponent } from './nokiaNSP/health-check/nokia-service/nokia-service.component';
import { NokiaScheduleComponent } from './nokiaNSP/health-check/nokia-schedule/nokia-schedule.component';
import { ViewDetailsComponent } from './nokiaNSP/view-details/view-details.component';
import { CienaHealthCheckComponent } from './cienaMCP/ciena-health-check/ciena-health-check.component';
import { CienaScheduleComponent } from './cienaMCP/ciena-health-check/ciena-schedule/ciena-schedule.component';
import { CienaHealthTemplateComponent } from './cienaMCP/ciena-health-check/ciena-health-template/ciena-health-template.component';
import { CienaNmapComponent } from './cienaMCP/ciena-health-check/ciena-nmap/ciena-nmap.component';
import { CienaServiceComponent } from './cienaMCP/ciena-health-check/ciena-service/ciena-service.component';
import { CienaNodeComponent } from './cienaMCP/ciena-health-check/ciena-node/ciena-node.component';
import { CienaViewDetailsComponent } from './cienaMCP/ciena-view-details/ciena-view-details.component';
import { HcTemplateComponent } from './nokiaNSP/health-check/hc-template/hc-template.component';
import { NokiaInfraComponent } from './nokiaNSP/nokia-infra/nokia-infra.component';
import { AlarmAnalysisComponent } from './cienaMCP/alarm-analysis/alarm-analysis.component';
import { ModuleActivateGuard } from '../../../SharedFolder/services/moduleActivate.guard';
import { BackupRestoreComponent } from './cienaMCP/backup-restore/backup-restore.component';
import { PMManagementComponent } from './cienaMCP/pm-management/pm-management.component';
import { InventoryManagementComponent } from './cienaMCP/inventory-management/inventory-management.component';

export const opticalTransportRoutes: Routes = [
    {
        path: '',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Optical Transport' },
        component: OpticalTransportComponent
    },
    {
        path: 'cienaMCP',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Optical Transport' },
        component: CienaMCPComponent
    },
    {
        path: 'cienaMCP/BOD',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Bandwidth on Demand Module' },
        component: CienaBodComponent
    },
    {
        path: 'cienaMCP/GCT',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP GCT Module' },
        component: CienaGCTComponent
    },
    {
        path: 'cienaMCP/AlarmAnalysis',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Alarm Analysis Module' },
        component: AlarmAnalysisComponent
    },
    {
        path: 'cienaMCP/BackupRestore',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Backup and Restore Module' },
        component: BackupRestoreComponent
    },
    {
        path: 'cienaMCP/PmManagement',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP PM Management Module' },
        component: PMManagementComponent
    },
    {
        path: 'cienaMCP/inventoryManagement',
        // canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Inventory Management Module' },
        component: InventoryManagementComponent
    },
    {
        path: 'cienaMCP/GetData',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Get Data Module' },
        component: CienaViewDetailsComponent
    },
    {
        path: 'cienaMCP/HealthCheck',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaHealthCheckComponent
    },
    {
        path: 'cienaMCP/HealthCheck/node',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaNodeComponent
    },
    {
        path: 'cienaMCP/HealthCheck/service',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaServiceComponent
    },
    {
        path: 'cienaMCP/HealthCheck/nmap',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaNmapComponent
    },
    {
        path: 'cienaMCP/HealthCheck/healthCheckTemplate',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaHealthTemplateComponent
    },
    {
        path: 'cienaMCP/HealthCheck/schedule',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Ciena MCP Health Check Module' },
        component: CienaScheduleComponent
    },
    {
        path: 'nokiaNSP',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Optical Transport' },
        component: NokiaNspComponent,
    },
    {
        path: 'nokiaNSP/BOD',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Bandwidth on Demand Module' },
        component: NokiaBodComponent
    },
    {
        path: 'nokiaNSP/GCT',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP GCT Module' },
        component: NokiaGCTComponent
    },
    {
        path: 'nokiaNSP/get-GCT-template',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP GCT Module' },
        component: NokiaGctTemplateComponent
    },
    {
        path: 'nokiaNSP/Health-Check',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Health Check Module' },
        component: HealthCheckComponent
    },
    {
        path: 'nokiaNSP/Health-Check/node',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Health Check Module' },
        component: NokiaNodeComponent
    },
    {
        path: 'nokiaNSP/Health-Check/service',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Health Check Module' },
        component: NokiaServiceComponent
    },
    {
        path: 'nokiaNSP/Health-Check/schedule',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Health Check Module' },
        component: NokiaScheduleComponent
    },
    {
        path: 'nokiaNSP/Health-Check/template',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Health Check Module' },
        component: HcTemplateComponent
    },
    {
        path: 'nokiaNSP/view-details',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia NSP Get Data Module' },
        component: ViewDetailsComponent
    },
    {
        path: 'nokiaNSP/infra-trails',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Optical Transport', subModuleName: 'Nokia Infra trails Module' },
        component: NokiaInfraComponent
    }

]
