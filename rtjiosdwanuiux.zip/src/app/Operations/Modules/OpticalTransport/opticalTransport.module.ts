import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { opticalTransportRoutes } from './opticalTransport.routing';
import { OpticalTransportComponent } from './optical-transport.component';
import { CienaMCPComponent } from './cienaMCP/ciena-mcp.component';
import { NokiaNspComponent } from './nokiaNSP/nokia-nsp.component';
import { NokiaBodComponent } from './nokiaNSP/nokia-bod/nokia-bod.component';
import { CienaBodComponent } from './cienaMCP/ciena-bod/ciena-bod.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { CienaGCTComponent } from './cienaMCP/ciena-gct/ciena-gct.component';
import { NokiaGCTComponent } from './nokiaNSP/nokia-gct/nokia-gct.component';
import { opticalModuleAPIService } from './opticalTransportModule_API.service';
import { NokiaGctTemplateComponent } from './nokiaNSP/nokia-gct-template/nokia-gct-template.component';
import { GctSchedulerComponent } from './nokiaNSP/nokia-gct/gct-scheduler/gct-scheduler.component';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { HealthCheckComponent } from './nokiaNSP/health-check/health-check.component';
import { NokiaServiceComponent } from './nokiaNSP/health-check/nokia-service/nokia-service.component';
import { NokiaNodeComponent } from './nokiaNSP/health-check/nokia-node/nokia-node.component';
import { SelectAutocompleteModule } from 'mat-select-autocomplete';
import { NokiaScheduleComponent } from './nokiaNSP/health-check/nokia-schedule/nokia-schedule.component';
import { ViewDetailsComponent } from '../../../Operations/Modules/OpticalTransport/nokiaNSP/view-details/view-details.component';
import { CienaHealthCheckComponent } from './cienaMCP/ciena-health-check/ciena-health-check.component';
import { CienaNodeComponent } from './cienaMCP/ciena-health-check/ciena-node/ciena-node.component';
import { CienaServiceComponent } from './cienaMCP/ciena-health-check/ciena-service/ciena-service.component';
import { CienaNmapComponent } from './cienaMCP/ciena-health-check/ciena-nmap/ciena-nmap.component';
import { CienaHealthTemplateComponent } from './cienaMCP/ciena-health-check/ciena-health-template/ciena-health-template.component';
import { CienaScheduleComponent } from './cienaMCP/ciena-health-check/ciena-schedule/ciena-schedule.component';
import { CienaViewDetailsComponent } from './cienaMCP/ciena-view-details/ciena-view-details.component';
import { HcTemplateComponent } from './nokiaNSP/health-check/hc-template/hc-template.component';
import { NokiaInfraComponent } from './nokiaNSP/nokia-infra/nokia-infra.component';
import { AlarmAnalysisComponent } from './cienaMCP/alarm-analysis/alarm-analysis.component';
import { SharedModule } from '../../../SharedFolder/modules/shared.module';
import { DialogBoxxComponent } from './nokiaNSP/dialog-boxx/dialog-boxx.component';
import { BackupRestoreComponent } from './cienaMCP/backup-restore/backup-restore.component';
import { PMManagementComponent } from './cienaMCP/pm-management/pm-management.component';
import { InventoryManagementComponent } from './cienaMCP/inventory-management/inventory-management.component';
@NgModule({
    declarations: [
        CienaMCPComponent,
        CienaBodComponent,
        OpticalTransportComponent,
        NokiaNspComponent,
        NokiaBodComponent,
        CienaGCTComponent,
        DialogBoxxComponent,
        NokiaGCTComponent,
        NokiaGctTemplateComponent,
        GctSchedulerComponent,
        HealthCheckComponent,
        NokiaServiceComponent,
        NokiaNodeComponent,
        NokiaScheduleComponent,
        ViewDetailsComponent,
        CienaHealthCheckComponent,
        CienaNodeComponent,
        CienaServiceComponent,
        CienaNmapComponent,
        CienaHealthTemplateComponent,
        CienaScheduleComponent,
        CienaViewDetailsComponent,
        HcTemplateComponent,
        NokiaInfraComponent,
        AlarmAnalysisComponent,
        BackupRestoreComponent,
        PMManagementComponent,
        InventoryManagementComponent
    ],
    imports: [
        RouterModule.forChild(opticalTransportRoutes),
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        NgxMaterialTimepickerModule,
        SelectAutocompleteModule,
        SharedModule
    ],
    providers: [
        DatePipe,
        opticalModuleAPIService
    ],
    entryComponents: [
        DialogBoxxComponent
    ],
    exports: [NgxMaterialTimepickerModule]
})
export class OpticalTransportModule { }
