import { Injectable } from '@angular/core';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';

@Injectable({
    providedIn: 'root'
})
export class NokiaTrailsService {

    constructor(private commonService: SdWanServiceService) { }


    infraProvisioning(requerstJSON): Observable<any> {
        return new Observable<any>(observe => {
            console.log('inside  infra Provisioning..');
            this.commonService.sendRequest('POST', EventConstants.NOKLA_NSP_INFRA_CONTEXT, requerstJSON, null, null, EventConstants.NOKIA_NSP_INFRA_PROVISION).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    uploadBulkFile(file: any): Observable<any> {
        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            this.commonService.sendRequest('POST', EventConstants.NOKLA_NSP_INFRA_CONTEXT, { 'file': file }, null, null, EventConstants.NOKIA_BULK_INFRA_PROVISIONING).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log('File Uploaded Successfully...');
                }
            );
        });
    }


    getServiceDetailsRequest(header: HttpHeaders, isExport: boolean) {
        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            this.commonService.sendRequest('GET', EventConstants.NOKLA_NSP_INFRA_CONTEXT, null, header, null,
                isExport ? EventConstants.NOKIA_INFRA_EXPORT_DETAIL : EventConstants.NOKIA_INFRA_TRAIL_DETAIL).subscribe(
                    (response) => {
                        console.log(JSON.stringify(response));
                        observe.next(response);
                        console.log('response Successfully...');
                    }
                );
        });
    }

    downloadTemplate() {

        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            this.commonService.sendRequest('GET', EventConstants.NOKLA_NSP_INFRA_CONTEXT, null, null, null, EventConstants.NOKIA_INFRA_DOWNLOAD_TEMPLATE).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    nokiaGCTRequest(type, mode, label?) {

        let header = new HttpHeaders()
            .append('Type', type);
        console.log(header, "header");
        let eventKey = mode == 'Single' ? EventConstants.NOKIA_GCT : EventConstants.NOKIA_BULK_GCT;
        if (eventKey === EventConstants.NOKIA_GCT) {
            header = header.set('guiLabel', label);
        }
        return new Observable<any>(observe => {
            console.log('inside nokia GCT..');
            this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', null, header, null, eventKey).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log('File Uploaded Successfully...');
                }
            );
        });
    }


    nokiaGetListType(type) {
        let headers = new HttpHeaders().append('Type', type);
        console.log(headers, "headers in getList");

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.NOKIA_GCT_GET_NEID_LIST).subscribe(
                (response) => {
                    // console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log('successful type submission');
                }
            );
        })
    }

    downloadGCTTemplate(type, label) {
        let header = new HttpHeaders();
        header = header.set('guiLabel', label);
        header = header.set('Type', type);
        console.log(header);

        return new Observable<any>(observe => {
            console.log("inside Observable");
            console.log(header, "headers");

            this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, header, null, EventConstants.NOKIA_GCT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }


    deleteTrailDetails(connectionName) {
        let headers = new HttpHeaders().append('Connection-Name', connectionName);
        return new Observable<any>(observe => {
            console.log("inside delete Observable");
            this.commonService.sendRequest('DELETE', EventConstants.NOKLA_NSP_INFRA_CONTEXT, null, headers, null, EventConstants.NOKIA_INFRA_DELETE_TRAIL).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));

                    observe.next(response);

                }
            );
        });
    }

    deleteBODDetails(deleteJSON) {
        let headers = new HttpHeaders()
            .append('timeStamp', deleteJSON['timeStamp'])
            .append('siteNameA', deleteJSON['siteNameA'])
            .append('siteNameZ', deleteJSON['siteNameZ'])
            .append('servicerate', deleteJSON['servicerate']);
        console.log("headers are:", headers);

        return new Observable<any>(observe => {
            console.log("inside delete");
            this.commonService.sendRequest('DELETE', '/PEAG/nokianbHandler', null, headers, null, EventConstants.CIENA_DELETE_BOD_DETAILS).subscribe(
                (response) => {
                    observe.next(response);
                }
            )

        })
    }

    getGCTTemplate(type) {
        let headers = new HttpHeaders()
            .append('Type', type);
        return new Observable<any>(observer => {
            this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.NOKIA_GET_GCT_TEMPLATE)
                .subscribe(response => {
                    console.log(response.body);
                    observer.next(JSON.parse(response.body));
                })
        })
    }


    updateGCTTemplateData(type, requerstJSON) {
        let headers = new HttpHeaders()
            .append('Type', type);
        return new Observable<any>(observer => {
            this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', requerstJSON, headers, null, EventConstants.NOKIA_MODIFY_GCT_TEMPLATE)
                .subscribe(response => {
                    console.log(response);
                    observer.next(response);
                })
        })
    }

    getGCTSchedulesList(type, module) {

        let query;
        if (EventConstants.GCT_PM_SCHEDULER_NAME === type)
            query = EventConstants.GET_PM_SCHEDULE_LIST
        else if (EventConstants.GCT_SCHEDULER_NAME == type)
            query = EventConstants.GET_SCHEDULE_GCT
        else if (EventConstants.HEALTH_CHECK_SCHEDULER_NAME == type)
            query = EventConstants.GET_SCHEDULE_HC_LIST;
        if (module == "nokia") {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, null, null, query)
                    .subscribe(response => {
                        observer.next(JSON.parse(response['body']));
                    })
            })
        }

        else {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, null, null, query)
                    .subscribe(response => {
                        observer.next(JSON.parse(response['body']));
                    })
            });
        }
    }

    CancelGCTSchedule(scheduleName, type, module) {
        let query;
        if (EventConstants.GCT_PM_SCHEDULER_NAME === type)
            query = EventConstants.DELETE_PM_SCHEDULER
        else if (EventConstants.GCT_SCHEDULER_NAME == type)
            query = EventConstants.DELETE_SCHEDULE_GCT
        else if (EventConstants.HEALTH_CHECK_SCHEDULER_NAME == type)
            query = EventConstants.DELETE_SCHEDULE_HC;

        let headers = new HttpHeaders()
            .append('Scheduler-Name', scheduleName);
        if (module == "nokia") {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('DELETE', '/PEAG/nokianbHandler', null, headers, null, query)
                    .subscribe(response => {
                        console.log(response);
                        observer.next(response);
                    })
            });
        }

        else {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('DELETE', '/PEAG/nbHandlerCiena', null, headers, null, query)
                    .subscribe(response => {
                        console.log(response);
                        observer.next(response);
                    })
            });
        }
    }


    scheduleGCTPost(requestJSON, type, module) {
        let query;
        if (EventConstants.GCT_PM_SCHEDULER_NAME === type)
            query = EventConstants.SCHEDULE_PM
        else if (EventConstants.GCT_SCHEDULER_NAME == type)
            query = EventConstants.SCHEDULE_GCT
        else if (EventConstants.HEALTH_CHECK_SCHEDULER_NAME == type)
            query = EventConstants.POST_SCHEDULE_HC;

        if (module == "nokia") {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', requestJSON, null, null, query)
                    .subscribe(response => {
                        console.log(response);
                        observer.next(response);
                    });
            });
        }

        else {
            return new Observable<any>(observer => {
                this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', requestJSON, null, null, query)
                    .subscribe(response => {
                        console.log(response);
                        observer.next(response);
                    });
            });
        }

    }

    getViewDetails(getApi) {
        let headers = new HttpHeaders()
            .append('Context', getApi);
        return new Observable<any>(observer => {
            this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.GET_VIEW_DETAIL_API)
                .subscribe(response => {
                    console.log(response);
                    if (response['body'] && JSON.parse(response['body'])[0])
                        observer.next(JSON.parse(response['body'])[0]);
                    else observer.next([]);
                })
        });
    }

}
