import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NokiaService } from '../nokia.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { ExcelService } from '../../../../../SharedFolder/services/excel.service';
import { DatePipe } from '@angular/common';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { NgForm } from '@angular/forms';
import { MatPaginator, TooltipPosition } from '@angular/material';
import swal from 'sweetalert2';
import { HttpHeaders } from '@angular/common/http';
import { NokiaTrailsService } from './nokia-trails.service';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';
declare var $: any;

@Component({
  selector: 'app-nokia-infra',
  templateUrl: './nokia-infra.component.html',
  styleUrls: ['./nokia-infra.component.css']
})
export class NokiaInfraComponent implements OnInit, OnDestroy {

  @ViewChild('form') form: NgForm;
  @ViewChild('nokiaTrailForm') nokiaTrailForm: NgForm;
  @ViewChild('paginator') paginator: MatPaginator;
  networkType = ['Control Plane Enabled', 'Non Control Plane'];
  rate = ['ODU2', 'ODU2E', 'OTU2', 'OTU2E', 'ODU4'];
  wavekey = ['Keyed', 'Unkeyed'];
  protection = ['Linear', 'SBR'];
  frequency: string = '';
  pageSize: number;
  displayDelete: string;
  index: number;
  offset: number;
  siteNameA: string;
  siteNameZ: string;
  timeStamp: number;
  servicerate: string;
  serviceOrderId: number;
  deleteStatus: boolean = false;
  public min: Date = new Date();
  public curDate: Date = new Date();
  public maxDate: Date = new Date();
  toolTipPostion: TooltipPosition = "above";
  matTabIndex: number = 0;
  exceltrailDetails = [];
  filteredTimeStamp: string;
  deleteTrailName: string = '';
  read: boolean;
  write: boolean;
  delete: boolean;
  aendArray = [];
  zendArray = [];
  aendNE = '';
  zendNE = '';
  responseTime = '';
  aendCardName;
  aendShelf;
  zendCardName;
  zendShelf;
  zendPort;
  roleName: string = '';
  constructor(private router: Router,
    private route: ActivatedRoute,
    private service: NokiaTrailsService,
    private ngxService: SpinnerService,
    private accessService: AccessService,
    private excelService: ExcelService,
    private datePipe: DatePipe,
    private optService: opticalModuleAPIService,
    private sessionService: SessionService) { }


  ngOnInit() {

    this.roleName = this.sessionService.get('userName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    this.pageSize = 5;
    this.offset = 0;
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia Infra trails Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia Infra trails Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia Infra trails Module', 'D');
    if (this.write) {
      this.matTabIndex = 0;
    } else {
      this.matTabIndex = 1;
    }

  }

  setDateAndTime() {
    this.min = this.from;
    this.maxDate = new Date(new Date(this.min).setDate(new Date(this.min).getDate() + 30));
    this.maxDate = new Date(Math.min(new Date().getTime(), this.maxDate.getTime()));
    console.log(this.min, " | ", this.maxDate);
  }

  backToNSP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onSubmitTrails() {

    const requestJSON = {
      "networktype": this.form.value['networkType'],
      "trailrate": this.form.value['rate'],
      "frequency": this.form.value['frequency'],
      "provisionwavekey": this.form.value['wavekey'],
      "preferredRestorationMode": this.form.value['protection'],
      "a1NeName": this.form.value['aendNE'],
      "z1NeName": this.form.value['zendNE'],
      "a1CardName": this.form.value['aendCardName'],
      "z1CardName": this.form.value['zendCardName'],
      "a1ShelfName": this.form.value['aendShelf'],
      "z1ShelfName": this.form.value['zendShelf'],
      "a1SlotName": this.form.value['aendSlot'],
      "z1SlotName": this.form.value['zendSlot'],
      "a1PortName": this.form.value['aendPort'],
      "z1PortName": this.form.value['zendPort'],
      "routingDetails": this.form.value['routingDetails']
    }


    console.log(this.form, JSON.stringify(requestJSON));
    this.ngxService.start();
    this.service.infraProvisioning(requestJSON).
      subscribe(response => {
        if (response['status_code'] == 200) {
          console.log(JSON.stringify(response));
          console.log('onSubmit success...');
          this.form.reset();
          this.showSwal(this.NOKIA_TRAIL_SUCCESS, response.state);
          this.ngxService.stop();
        }
        else {
          console.log("status is :", response.status);
          this.showDangerSwal(this.NOKIA_TRAIL_FAILURE, response.state);
          this.ngxService.stop();
        }
      });

  }
  cienaSCNMRequestJson: {};
  recilencyType = ['MESH_RESTORABLE', 'PERMANENT'];
  aendZendShelf = ['A', 'C'];
  aendZendSlot = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '15', '13', '14', '15'];
  retainList = [];

  fileName = '';
  file: any;
  from: any = '';
  to: any = '';
  NOKIA_TRAIL_SUCCESS = 'NOKIA TRAIL SUCCESS';
  NOKIA_TRAIL_FAILURE = 'NOKIA TRAIL FAILED';
  trailDetailsFlag = false;
  length: number;

  pageSizeOptions = [5, 10, 25, 100];
  trailDetails = [];
  trailDetailTemp = [];
  fileByteArray = [];
  onPageChanged(e) {
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.trailDetailTemp = this.trailDetails.slice(firstCut, secondCut);
  }
  onTabChanged(event) {


  }
  getServiceDetailsRequest(isExport) {
    console.log('export value | ', isExport);
    let oldtimestamp = Date.parse(this.from).toString();
    let latesttimestamp = Date.parse(this.to).toString();
    let headers = new HttpHeaders()
      .append('Old-Timestamp', oldtimestamp)
      .append('Latest-Timestamp', latesttimestamp);
    const startTimeStamp: number = new Date().getTime();
    // if(isExport) this.ngxService.start()
    this.service.getServiceDetailsRequest(headers, isExport).
      subscribe(res => {
        if (isExport) {
          this.ngxService.stop();
          console.log(res);
          this.downloadFile(res);

        } else {
          this.trailDetails = JSON.parse(res.body);
          console.log("parsed JSON:", this.trailDetails);
          this.exceltrailDetails = JSON.parse(res.body);
          this.length = this.trailDetails.length;
          this.exceltrailDetails.forEach(element => {
            element['timeStamp'] = this.datePipe.transform(element['timeStamp'], 'medium');
            console.log("filtered stamp", element['timeStamp']);
          });
          this.trailDetailTemp = this.trailDetails.slice(0, 5);
          if (this.trailDetails.length > 0) {
            this.trailDetailsFlag = false;
          }
          else this.trailDetailsFlag = true;
          const endTimeStamp: number = new Date().getTime();
          this.responseTime = Number(((endTimeStamp - startTimeStamp) / 1000.0)).toString();
        }

      });
  }

  uploadFile() {
    console.log("file is:", this.fileByteArray);
    this.ngxService.start(20000);
    this.service.uploadBulkFile(this.fileByteArray).
      subscribe(res => {
        if (res['status_code'] == 200) {
          this.ngxService.stop();
          this.showSwal('NOKIA BULK INFRA TRAIL', this.fileName + " " + res.state);
          this.fileName = '';
          this.file = undefined;
          this.nokiaTrailForm.reset();
        }
      })
  }


  public onFileChange(event) {
    var fileByteArray = [];
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      this.fileName = event.target.files[0].name;
      this.file = event.target.files[0];
      const [file] = event.target.files;
      reader.readAsArrayBuffer(this.file);

      reader.onload = () => {
        var arrayBuffer = reader.result;
        var bytes = new Uint8Array(<ArrayBuffer>arrayBuffer);

        this.fileByteArray = [].concat(bytes);
        this.fileByteArray = Object.values(this.fileByteArray[0]);
      }

    }
  }

  downloadTemplate() {
    this.service.downloadTemplate().
      subscribe(res => {
        console.log(res)
        this.downloadFile(res);
      });
  }

  downloadFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response.fileData);
    console.log(response);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    linkElement.download = response['fileName'];
    document.body.appendChild(linkElement);
    linkElement.click();
  }


  backToMCP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  showSwal(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-success",
      type: "success"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop)

  }

  showDangerSwal(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-danger",
      type: "warning"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop)

  }

  beforeDelete(bodItem, index) {
    this.deleteTrailName = bodItem['connectionName'];
    console.log("index", index);
    this.index = this.offset + index;
    console.log("offset index", this.index);
    $('#deleteGCTModal').modal('show');
  }

  deleteTrailDetails() {
    console.log("inside on delete");
    this.ngxService.start();
    this.service.deleteTrailDetails(this.deleteTrailName).subscribe(
      (response) => {
        this.ngxService.stop();
        console.log("res inside", response);
        this.displayDelete = response['state'];
        if (response['status_code'] == 200) {
          this.deleteStatus = true;
          $('#afterdeleteGCTModal').modal('show');
          this.trailDetails.splice(this.index, 1);
          this.exceltrailDetails.splice(this.index, 1);
          this.length = this.trailDetails.length;
          console.log("trailDetails", this.trailDetails);
          this.trailDetailTemp = this.trailDetails.slice(0, 5);
          if (this.paginator)
            this.paginator.firstPage();
        }
        else {
          this.deleteStatus = false;
          $('#afterdeleteGCTModal').modal('show');
          // setTimeout(() => this.getServiceDetailsRequest(), 1000);
        }
      }
    );
  }


  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  ngOnDestroy(): void {
    this.ngxService.stop();
  }

}
