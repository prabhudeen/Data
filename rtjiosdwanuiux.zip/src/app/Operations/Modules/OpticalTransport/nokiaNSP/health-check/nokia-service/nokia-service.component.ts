import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../../../../../../SharedFolder/services/SpinnerService.service';
import { NokiaHealthService } from '../nokia-health.service';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';
import { MatPaginator } from '@angular/material';

@Component({
  selector: 'app-nokia-service',
  templateUrl: './nokia-service.component.html',
  styleUrls: ['./nokia-service.component.css']
})
export class NokiaServiceComponent implements OnInit {
  @ViewChild('paginator') paginator: MatPaginator;
  matTabIndex: number = 0;
  serviceList: any[] = [];
  displaySuccess: string = '';
  tickEnable: boolean = true;
  serviceModal: boolean = false;
  pageSize: number;
  offset: number;
  length: number;
  read: boolean;
  write: boolean;
  delete: boolean;
  roleName: string = '';
  displayDelete: string = '';
  deleteGCTModal: boolean = false;
  selectedGUILabel: string = '';
  deleteStatus: boolean = false;
  pageSizeOptions = [5, 10, 25, 100];
  healthReportList: any[] = [];
  healthReporstListTemp: any[] = [];
  callPagination: boolean = false;
  selectedIndex: any = '';
  nodeDetail: any[] = [
    {
      display: 'Switchover Events',
      value: 'Switchover Events'
    },
    {
      display: 'PM Enabled Status',
      value: 'PM Enabled Status'
    }
  ];

  secondTable: any[] = [
    'InfraConn_OTU',
    'InfraConn_ODU',
    'DSR'
  ];
  secondTableTemp: any[] = [];
  @ViewChild('serviceForm') serviceForm: NgForm;
  nodeList: any;
  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private ngxService: SpinnerService,
    private healtService: NokiaHealthService,
    private accessService: AccessService) {
    this.nodeList = new FormGroup({
      firstSelected: new FormControl([]),
      secondSelected: new FormControl([])
    });
  }

  ngOnInit() {
    this.pageSize = 5;
    this.nodeList.get('firstSelected').valueChanges.subscribe(data => {
      console.log('onChangeNodeName value >>> ', data)
      if (data == 'PM Enabled Status') {
        this.nodeList.get('secondSelected').setValue('');
        this.nodeList.get('secondSelected').markAsPristine();
        this.secondTable.forEach(element => {
          this.secondTableTemp.push({
            display: element,
            value: element
          });
        });
      } else {
        this.secondTableTemp = [];
      }
    });
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'D');
    if (!this.write) {
      this.matTabIndex = 1;
      this.getHCReport();
    }
  }

  onSubmit() {
    let requestJson = {
      'type': this.nodeList.value['secondSelected']
    };
    this.ngxService.start();
    this.healtService.postSeriveHCRequest(requestJson).
      subscribe(response => {
        this.ngxService.stop();
        this.displaySuccess = response['state'];
        if (response['status_code'] == 200) {
          this.tickEnable = true;
          this.serviceModal = true;
          // this.nodeList.markAsPristine();
          this.serviceForm.reset();
          this.nodeList.controls['firstSelected'].setValue('');
          this.nodeList.controls['secondSelected'].setValue('');

        } else {
          this.tickEnable = true;
          this.serviceModal = true;
        }
      });

  }

  getHCReport() {
    let headers = new HttpHeaders()
      .append('Type', 'Service');
    this.healtService.getHCReportList(headers)
      .subscribe(response => {
        if (response['status_Code'] == 200) {
          this.healthReportList = response['guiLabels'];
          this.healthReporstListTemp = this.healthReportList;
          this.healthReportList = this.healthReportList.map(data => {
            let time = data.filename.substring(data.filename.lastIndexOf('_') + 1, data.filename.indexOf('.'));
            return {
              time: new Date(time),
              value: data.filename,
              username: data.username
            };
          })
          this.healthReportList.sort((a, b) => {
            return b.time - a.time;
          })
          console.log(this.healthReportList);
          if (this.healthReportList.length > 0) {
            // this.gctDetailsFlag = false;
            this.length = this.healthReportList.length;
            if (this.healthReportList.length > this.pageSize) {
              if (this.callPagination)
                this.onPageChanged(this.paginator);
              else
                this.healthReporstListTemp = this.healthReportList.slice(0, this.pageSize);

            }
            else
              this.healthReporstListTemp = this.healthReportList;
          }
          // else this.gctDetailsFlag = true;
        }
        // else this.gctDetailsFlag = true;
      });
  }

  beforeDelete(label, index) {
    console.log(label, 'onClick');
    this.selectedGUILabel = label;
    this.selectedIndex = this.offset + index;
    this.deleteGCTModal = true;
  }

  onDeleteHCReport() {
    let headers = new HttpHeaders()
      .append('guiLabel', this.selectedGUILabel)
      .append('Type', 'Service');
    this.healtService.deleteTemplate(headers).subscribe(res => {
      // this.ngxService.stop();
      console.log("delete", res);
      this.displaySuccess = res['state'];
      if (res['status_code'] == 202) {
        this.serviceModal = true;
        this.tickEnable = true;
        this.callPagination = true;
        this.getHCReport();
      }
      else {
        this.tickEnable = false;
      }
      this.serviceModal = true;
      console.log(this.deleteStatus, "deleteStatus");
      // setTimeout(() => this.getHCReport(), 500);

    });

  }

  onDownload(item) {
    let headers = new HttpHeaders()
      .append('Type', 'Service').
      append('guiLabel', item.value)
      .append('User-Name', item.username);

    this.healtService.downloadTemplate(headers).subscribe(res => {
      // console.log(res)
      this.downloadFile(res);
    });
  }

  downloadFile(data) {
    if (data['status_code'] == 202) {
      var linkElement = document.createElement('a');
      var byteArray = new Uint8Array(data['fileData']);
      linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      linkElement.download = data['fileName'];
      document.body.appendChild(linkElement);
      linkElement.click();
    }
  }

  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.healthReporstListTemp = this.healthReportList.slice(firstCut, secondCut);
  }


  onTabChanged(event) {
    this.matTabIndex = event.index;
    if (this.matTabIndex == 1) {
      this.getHCReport();
    }
  }
  backToHelthCheck() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

}
