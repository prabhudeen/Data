import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { NgForm, FormGroup, FormControl } from '@angular/forms';
import { SpinnerService } from '../../../../../../SharedFolder/services/SpinnerService.service';
import { NokiaService } from '../../nokia.service';
import { NokiaHealthService } from '../nokia-health.service';
import { HttpHeaders } from '@angular/common/http';
import { SessionService } from '../../../../../../SharedFolder/services/sessionService.service';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatPaginator } from '@angular/material';

@Component({
  selector: 'app-nokia-node',
  templateUrl: './nokia-node.component.html',
  styleUrls: ['./nokia-node.component.css']
})
export class NokiaNodeComponent implements OnInit, AfterViewInit {
  @ViewChild('nokiaNodeForm') nokiaNodeForm: NgForm;
  @ViewChild('bulkHCRequest') bulkHCRequest: NgForm;
  @ViewChild('nokiaHealthReport') nokiaHealthReport: NgForm;
  @ViewChild('paginator') paginator: MatPaginator;
  matTabIndex: number = 0;
  nodeDetail: any[] = [];
  nodeName: string = '';
  pageSize: number;
  offset: number;
  length: number;
  read: boolean;
  write: boolean;
  delete: boolean;
  roleName: string = '';
  displayDelete: string = '';
  deleteGCTModal: boolean = false;
  selectedGUILabel: any = {};
  deleteStatus: boolean = false;
  pageSizeOptions = [5, 10, 25, 100];
  healthCheckTypeList: any[] = []
  nokiaNodeModal: boolean = false;
  tickEnable: boolean = false;
  displaySuccess: string = '';
  healthReportList: any[] = [];
  healthReporstListTemp: any[] = [];
  nodeList = new FormGroup({
    selected: new FormControl([])
  });
  selectedIndex: any = '';
  callPagination: boolean = false;

  nodeBulkList = new FormGroup({
    selected: new FormControl([])
  });
  constructor(private optService: opticalModuleAPIService,
    private ngxService: SpinnerService,
    private healtService: NokiaHealthService,
    private service: NokiaService,
    private accessService: AccessService,
    private sessionService: SessionService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.pageSize = 5;
    this.nodeBulkList.get('selected').valueChanges.subscribe(data => {
      this.nodeName = data;
    })
    setTimeout(() => {
      this.roleName = this.sessionService.get('roleName');
      if (this.roleName && this.roleName.includes('admin'))
        this.roleName = 'TelcoRole';
    }, 2000)
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'D');
    if (!this.write) {
      this.matTabIndex = 2;
      this.getHCReport();
    } else {
      this.getNodeDetail();
    }

  }

  ngAfterViewInit(): void {
    // this.paginator.pageIndex = 0;
  }

  getSelectedOptions($event) {
    if ($event && $event.length >= 10) {
      console.log('inside case ..')
      this.nodeDetail.forEach(data => {
        if ($event.findIndex(d => d == data.value) === -1) {
          data.disabled = true;
        } else {
          data.disabled = false;
        }
      });

    } else if ($event.length < 10 && $event.length > 8) {
      this.nodeDetail.forEach(data => {
        data.disabled = false;
      });
    }

  }

  getNodeDetail() {
    this.ngxService.start(60000 * 2);
    this.service.getAendZend()
      .subscribe(res => {
        this.ngxService.stop();
        if (res['status_code'] === 410) {
          this.tickEnable = false;
          this.displaySuccess = res['state'];
          this.nokiaNodeModal = true;

        } else {
          this.nodeDetail = [];
          JSON.parse(res['body']).forEach(element => {
            this.nodeDetail.push({
              display: element['siteName'],
              value: element['siteName'],
              disabled: false
            })
          });
        }
      });
  }

  postMultiNodeHC() {
    let request = {
      "guilabels": this.nodeList.value['selected']
    }
    this.ngxService.start();
    this.healtService.postMultiNodeHC(request).
      subscribe(response => {
        this.ngxService.stop();
        this.displaySuccess = response['state'];
        if (response['status_code'] == 200) {
          this.tickEnable = true;
          this.nokiaNodeModal = true;
          this.nokiaNodeForm.reset();
          this.nodeList.controls['selected'].setValue([]);

        } else {
          this.tickEnable = false;
          this.nokiaNodeModal = true;
        }
      });

  }
  postBulkHCRequest() {
    let request = {
      "type": this.nodeBulkList.value['selected']
    }
    this.ngxService.start();
    this.healtService.postBulkHCRequest(request)
      .subscribe(response => {
        this.ngxService.stop();
        if (response['status_code'] == 200) {
          this.displaySuccess = response['state'];
          this.tickEnable = true;
          this.nokiaNodeModal = true;
          this.bulkHCRequest.reset();
          this.nodeBulkList.controls['selected'].setValue('');

        } else {
          this.displaySuccess = response['state'];
          this.tickEnable = false;
          this.nokiaNodeModal = true;
        }
      })
  }

  getHCReport() {
    let headers = new HttpHeaders()
      .append('Type', 'Nodes');
    this.healtService.getHCReportList(headers)
      .subscribe(response => {
        if (response['status_Code'] == 200) {
          this.healthReportList = response['guiLabels'];
          this.healthReporstListTemp = this.healthReportList;
          this.healthReportList = this.healthReportList.map(data => {
            return {
              timeStamp: data.timeStamp,
              time: new Date(data.timeStamp),
              testtype: data.testtype,
              testname: data.testname,
              username: data.username
            };
          })
          this.healthReportList.sort((a, b) => {
            return b.time - a.time;
          })
          console.log(this.healthReportList);
          if (this.healthReportList.length > 0) {
            this.length = this.healthReportList.length;
            if (this.healthReportList.length > this.pageSize) {
              if (this.callPagination)
                this.onPageChanged(this.paginator);
              else
                this.healthReporstListTemp = this.healthReportList.slice(0, this.pageSize);
            }
            else
              this.healthReporstListTemp = this.healthReportList;

          }
        }
      });
  }

  onDownload(item) {
    console.log('headers | ', item.testname, item.timeStamp, item.username, item.testtype);
    let headers = new HttpHeaders()
      .append('Type', 'Nodes')
      .append('Test-Name', item.testname)
      .append('Time-Stamp', item.timeStamp)
      .append('User-Name', item.username)
      .append('Test-Type', item.testtype);

    this.healtService.downloadTemplate(headers).subscribe(res => {
      this.downloadFile(res);
    });
  }

  downloadFile(data) {
    if (data['status_code'] == 202) {
      var linkElement = document.createElement('a');
      var byteArray = new Uint8Array(data['fileData']);
      linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      linkElement.download = data['fileName'];
      document.body.appendChild(linkElement);
      linkElement.click();
    }
  }

  beforeDelete(item, index) {
    this.selectedGUILabel = item;
    this.selectedIndex = this.offset + index;
    this.deleteGCTModal = true;

  }

  onDeleteHCReport() {
    let headers = new HttpHeaders()
      .append('Type', 'Nodes')
      .append('Test-Name', this.selectedGUILabel.testname)
      .append('Time-Stamp', this.selectedGUILabel.timeStamp)
      .append('User-Name', this.selectedGUILabel.username)
      .append('Test-Type', this.selectedGUILabel.testtype);
    // console.log('headers | ', headers);
    this.healtService.deleteTemplate(headers).subscribe(res => {
      console.log("delete", res);
      this.displaySuccess = res['state'];
      if (res['status_code'] == 202) {
        this.nokiaNodeModal = true;
        this.tickEnable = true;
        this.callPagination = true;
      }
      else {
        this.tickEnable = false;
      }
      this.nokiaNodeModal = true;
      console.log(this.deleteStatus, "deleteStatus");

    });

  }


  onTabChanged(event) {

    this.matTabIndex = event.index;
    console.log('matTabIndex >> ', this.matTabIndex);
    if (this.matTabIndex == 0) {
      this.getNodeDetail();
    }
    if (this.matTabIndex == 2) {
      this.getHCReport();
    }

    if (this.matTabIndex == 1) {
      this.getBulkHcNodeList();
    }
  }

  getBulkHcNodeList() {
    this.healtService.getBulkHcNodeRequest()
      .subscribe(response => {
        if (response['status_Code'] == 200) {
          this.healthCheckTypeList = [];
          response['type'].forEach(element => {
            this.healthCheckTypeList.push({
              display: element,
              value: element
            });
          })
        } else {
          this.healthCheckTypeList = [];
        }
      })
  }

  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.healthReporstListTemp = this.healthReportList.slice(firstCut, secondCut);
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

}
