import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NokiaService } from '../../nokia.service';
import { HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { NokiaHealthService } from '../nokia-health.service';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';
import { SessionService } from '../../../../../../SharedFolder/services/sessionService.service';

@Component({
  selector: 'app-hc-template',
  templateUrl: './hc-template.component.html',
  styleUrls: ['./hc-template.component.css']
})
export class HcTemplateComponent implements OnInit {

  @ViewChild('templateHCForm') templateHCForm: NgForm;
  @ViewChild('addForm') addForm: NgForm;
  nodes: any = [];
  nodeValue;
  showAddButton: boolean = false;
  nodeType: any;
  templateList: any = [];
  modifiedTempList: any = [];
  dataJSON;
  actionType: string = '';
  arrayI;
  arrayJ;
  innerDeleteParam: any;
  finalList: any;
  cienaNodeModal: boolean = false;
  displaySuccess: any;
  tickEnable: boolean = false;
  showGetButton: boolean = true;
  modifyObject: any = {};
  hcTypeIndex: number;
  hcParameterIndex: number;
  showUpdateButton: boolean = false;
  deleteGCTModal: boolean = false;
  addHCTemplate: boolean = false;
  typeNodeFlag: boolean = false;
  read: boolean;
  write: boolean;
  delete: boolean; ks
  roleName: string = "";


  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private healthService: NokiaHealthService,
    private accessService: AccessService,
    private session: SessionService) { }

  ngOnInit() {
    this.roleName = this.session.get('roleName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    this.nodes = ['Nodes', 'Service'];
    this.resetData();
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'D');
  }

  resetData() {
    this.dataJSON = {
      "HC_Type": "",
      "HC_Parameter": "",
      "Expected_Values_MCN": [],
      "Expected_Values_NLC": [],
      "Expected_Values_MAC": [],
      "Expected_Values": []
    };
  }

  templateHC() {
    this.showGetButton = true;
    this.showUpdateButton = false;
    console.log('this.nodeType :', this.nodeType);
    this.showAddButton = true;
    this.nodeValue = this.nodeType;
    this.typeNodeFlag = (this.nodeType === 'Nodes') ? true : false;
    console.log("this.typenodeFlag", this.typeNodeFlag);
    console.log('nodeValue :', this.nodeValue);
    let headers = new HttpHeaders().append('Type', this.nodeValue);
    this.healthService.healthTemplateGet(headers).subscribe(
      response => {
        console.log('response :', response);
        this.templateList = JSON.parse(response['body']);
      }
    );


  }

  action(type, hc_type_index, hc_parameter_index) {
    this.actionType = type;
    this.hcTypeIndex = hc_type_index;
    this.hcParameterIndex = hc_parameter_index;
    console.log('hc_type ', hc_type_index, 'hc_parameter_indx', hc_parameter_index);
    switch (type) {

      case 'edit':

        this.dataJSON['HC_Type'] = this.templateList[hc_type_index]['HC_Type'];
        if (this.typeNodeFlag) {
          console.log("inside nodes")
          this.dataJSON['HC_Parameter'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['HC_Parameter'];
          this.dataJSON['Expected_Values_MCN'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['Expected_Values_MCN'].join(',');
          this.dataJSON['Expected_Values_NLC'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['Expected_Values_NLC'].join(',');
          this.dataJSON['Expected_Values_MAC'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['Expected_Values_MAC'].join(',');
        }
        if (!this.typeNodeFlag) {
          console.log("inside Service")
          this.dataJSON['HC_Parameter'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['HC_Parameter'];
          this.dataJSON['Expected_Values'] = this.templateList[hc_type_index]['parameters'][hc_parameter_index]['Expected_Values'].join(',');
        }
        console.log(this.dataJSON);
        break;

      case 'delete':
        // this.innerDeleteParam = this.modifiedTempList[i]['list'][j]['name'];
        break;

      case 'add':
        this.dataJSON['HC_Type'] = this.templateList[hc_type_index]['HC_Type'];
        this.dataJSON['HC_Parameter'] = null;
        if (this.typeNodeFlag) {
          this.dataJSON['Expected_Values_MCN'] = [];
          this.dataJSON['Expected_Values_NLC'] = [];
          this.dataJSON['Expected_Values_MAC'] = [];
        }
        if (!this.typeNodeFlag) {
          this.dataJSON['Expected_Values'] = [];
        }
        break;

      case 'deleteWhole':
        // this.innerDeleteParam = this.modifiedTempList[i]['HC_Type'];
        break;

      case 'addNew':
        this.resetData();
        break;
    }

  }

  submitAction() {

    switch (this.actionType) {

      case 'edit':
        this.templateList[this.hcTypeIndex]['parameters'][this.hcParameterIndex]['HC_Parameter'] = this.dataJSON['HC_Parameter'];
        if (this.typeNodeFlag) {
          this.templateList[this.hcTypeIndex]['parameters'][this.hcParameterIndex]['Expected_Values_MCN'] = this.dataJSON['Expected_Values_MCN'].split(',');
          this.templateList[this.hcTypeIndex]['parameters'][this.hcParameterIndex]['Expected_Values_NLC'] = this.dataJSON['Expected_Values_NLC'].split(',');
          this.templateList[this.hcTypeIndex]['parameters'][this.hcParameterIndex]['Expected_Values_MAC'] = this.dataJSON['Expected_Values_MAC'].split(',');
        }
        if (!this.typeNodeFlag) {
          this.templateList[this.hcTypeIndex]['parameters'][this.hcParameterIndex]['Expected_Values'] = this.dataJSON['Expected_Values'].split(',');
        }
        this.showUpdateButton = true;
        break;

      case 'delete':
        this.templateList[this.hcTypeIndex]['parameters'].splice(this.hcParameterIndex, 1);
        this.showUpdateButton = true;
        break;

      case 'add':

        let json = {};
        if (this.typeNodeFlag) {
          json = {
            "HC_Parameter": this.dataJSON['HC_Parameter'],
            "Expected_Values_MCN": this.dataJSON['Expected_Values_MCN'].split(','),
            "Expected_Values_NLC": this.dataJSON['Expected_Values_NLC'].split(','),
            "Expected_Values_MAC": this.dataJSON['Expected_Values_MAC'].split(',')
          };
        }
        if (!this.typeNodeFlag) {
          json = {
            "HC_Parameter": this.dataJSON['HC_Parameter'],
            "Expected_Values": this.dataJSON['Expected_Values'].split(',')
          }
        }
        this.templateList[this.hcTypeIndex]['parameters'].push(json);
        this.showUpdateButton = true;
        break;

      case 'deleteWhole':
        this.templateList.splice(this.hcTypeIndex, 1);
        this.showUpdateButton = true;
        break;

      case 'addNew':
        let addJson = {};
        addJson['parameters'] = [];
        addJson['HC_Type'] = this.dataJSON['HC_Type']
        if (this.typeNodeFlag) {
          addJson['parameters'].push({
            "HC_Parameter": this.dataJSON['HC_Parameter'],
            "Expected_Values_MCN": this.dataJSON['Expected_Values_MCN'].split(','),
            "Expected_Values_NLC": this.dataJSON['Expected_Values_NLC'].split(','),
            "Expected_Values_MAC": this.dataJSON['Expected_Values_MAC'].split(',')
          });
        }
        if (!this.typeNodeFlag) {
          addJson['parameters'].push({
            "HC_Parameter": this.dataJSON['HC_Parameter'],
            "Expected_Values": this.dataJSON['Expected_Values'].split(','),
          });
        }

        this.templateList.unshift(addJson);
        this.showUpdateButton = true;
        break;
    }
  }


  modifyHCTemplate() {
    console.log('this.finalList :', this.templateList);
    let headers = new HttpHeaders()
      .append('Type', this.nodeValue);
    this.healthService.modifyHCTemplate(this.templateList, headers).subscribe(
      response => {
        console.log('response :', response);
        this.cienaNodeModal = true;
        this.displaySuccess = response['state'];
        this.tickEnable = response['status_code'] === 200;
        if (this.tickEnable) {
          this.showUpdateButton = false;
          this.templateHC();
        }
      }
    )
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

}
