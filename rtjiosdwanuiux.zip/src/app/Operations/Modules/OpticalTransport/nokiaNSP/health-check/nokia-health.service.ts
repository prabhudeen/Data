import { Injectable } from '@angular/core';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';

@Injectable({
  providedIn: 'root'
})
export class NokiaHealthService {

  constructor(private commonService: SdWanServiceService) { }
   
  postMultiNodeHC(request: any): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', request, null, null, EventConstants.POST_MULT_NODE_HC).subscribe(
        (response) => {
          console.log(JSON.stringify(response));
          observe.next(response);

        }
      );
    });

  }

  postBulkHCRequest(request) {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', request, null, null, EventConstants.POST_BULK_HC_REQUEST).subscribe(
        (response) => {
          console.log(JSON.stringify(response));
          observe.next(response);

          }
        );
      });
   }

   getBulkHcNodeRequest() {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, null, null, EventConstants.GET_NODE_BULK_LIST).subscribe(
        (response) => {
          console.log(JSON.stringify(response));
          observe.next(response);

          }
        );
      });
   }

   getHCReportList(headers){
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.GET_HC_REPORT_REQUEST).subscribe(
        (response) => {
          console.log(JSON.stringify(response));
          observe.next(response);

          }
        );
      });
   }

   downloadTemplate(headers) {

    return new Observable<any>(observe => {
        this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.DOWNLOAD_HC_REPORT).subscribe(
            (response) => {
                observe.next(response);
            }
        );
    });
   }

   deleteTemplate(headers) {
    
    return new Observable<any>(observe => {
        this.commonService.sendRequest('DELETE', '/PEAG/nokianbHandler', null, headers, null, EventConstants.DELETE_HC_REPORT).subscribe(
            (response) => {
                console.log(JSON.stringify(response));

                observe.next(response);

            }
        );
    });
  }

  postSeriveHCRequest(request) {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', request, null, null, EventConstants.POST_SERVICE_HC).subscribe(
        (response) => {
          console.log(JSON.stringify(response));
          observe.next(response);

          }
        );
      });
   }

   healthTemplateGet(headers) {
    return new Observable<any>(observe => {
        this.commonService.sendRequest('GET', '/PEAG/nokianbHandler', null, headers, null, EventConstants.NOKIA_GET_HC_TEMPLATE).subscribe(
            (response) => {
                console.log(response);
                observe.next(response);
            }
        );
    });
}

healthServiceAssesment(json) {
    return new Observable<any>(observe => {
        this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', json, null, null, EventConstants.CIENA_SERVICE_HC_ASSESMENT).subscribe(
            (response) => {
                console.log(JSON.stringify(response));
                observe.next(response);
            }
        );
    });
}
NMAPAssesment() {
    return new Observable<any>(observe => {
        this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', null, null, null, EventConstants.CIENA_SERVICE_NMAP_ASSESMENT).subscribe(
            (response) => {
                console.log(JSON.stringify(response));
                observe.next(response);
            }
        );
    });
}

modifyHCTemplate(json, header) {
    return new Observable<any>(observe => {
        this.commonService.sendRequest('POST', '/PEAG/nokianbHandler', json, header, null, EventConstants.NOKIA_MODIFY_HC_TEMPLATE).subscribe(
            (response) => {
                console.log(response);
                observe.next(response);
            }
        );
    });
}

}
