import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';

@Component({
  selector: 'app-health-check',
  templateUrl: './health-check.component.html',
  styleUrls: ['./health-check.component.css']
})
export class HealthCheckComponent implements OnInit {

  list: any[] = [
    {
      title: "Node",
      value: "Nokia NSP Node Module",
      access: true,
    },
    {
      title: "Service",
      value: "Nokia NSP Service Module",
      access: true,
    },
    {
      title: "Schedule Health Check",
      value: "Nokia NSP Health Schedule Module",
      access: true,
    },
    {
      title: "Health Check Template",
      value: "Nokia NSP Health Check Template Module",
      access: true,
    }
  ]


  constructor(private router: Router,
    private route: ActivatedRoute,
    private accessService: AccessService,
    private optService: opticalModuleAPIService) { }

  ngOnInit() {
    this.list[0]['access'] = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R');
    this.list[1]['access'] = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R')
    this.list[2]['access'] = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Health Check Module', 'R');
  }

  onClick(action) {
    switch (action) {
      case "Nokia NSP Node Module":
        this.router.navigate(['node'], { relativeTo: this.route });
        break;
      case "Nokia NSP Service Module":
        this.router.navigate(['service'], { relativeTo: this.route });
        break;
      case "Nokia NSP Health Schedule Module":
        this.router.navigate(['schedule'], { relativeTo: this.route });
        break;
        case "Nokia NSP Health Check Template Module":
        this.router.navigate(['template'], { relativeTo: this.route });
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

}
