import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { GctSchedulerComponent } from '../../nokia-gct/gct-scheduler/gct-scheduler.component';
import { SpinnerService } from '../../../../../../SharedFolder/services/SpinnerService.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-nokia-schedule',
  templateUrl: './nokia-schedule.component.html',
  styleUrls: ['./nokia-schedule.component.css']
})
export class NokiaScheduleComponent implements OnInit {
  @ViewChild(GctSchedulerComponent) hcScheduler: GctSchedulerComponent
  constructor(private optService: opticalModuleAPIService,
    private ngxServie: SpinnerService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    // this.ngxServie.start(1000)
    setTimeout(() => {
      this.hcScheduler.callGCTScheduler("nokia");
      // this.ngxServie.stop();
    }, 200);
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToHC() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

}
