import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { NokiaService } from '../nokia.service';
import { TooltipPosition, MatPaginator } from '@angular/material';
import swal from 'sweetalert2';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { ExcelService } from '../../../../../SharedFolder/services/excel.service';
import { DatePipe } from '@angular/common';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { Workbook, WorkbookSheetColumn, WorkbookSheetRow, WorkbookSheetRowCell, WorkbookSheet } from '@progress/kendo-angular-excel-export';
import { saveAs } from '@progress/kendo-file-saver';
declare var $: any;

@Component({
  selector: 'app-nokia-bod',
  templateUrl: './nokia-bod.component.html',
  styleUrls: ['./nokia-bod.component.css']
})
export class NokiaBodComponent implements OnInit, OnDestroy {

  @ViewChild('form') form: NgForm;
  @ViewChild('nokiaBulkForm') nokiaBulkForm: NgForm;
  @ViewChild('paginator') paginator: MatPaginator;
  demandType = ['DPT_UN_PROTECTED', 'DPT_SERVER_PROTECTED', 'DPT_YCABLE', 'DPT_ESNCP'];
  demandRate = ['100GbE', '10GbE', '1GbE', 'ODU4', 'ODU2', 'ODU2e', 'ODU1', 'ODU0', 'STM64', 'STM16', 'STM4', 'STM1'];
  pageSize: number;
  displayDelete: string;
  index: number;
  offset: number;
  siteNameA: string;
  siteNameZ: string;
  timeStamp: number;
  servicerate: string;
  serviceOrderId: number;
  deleteStatus: boolean = false;
  public min = new Date();
  toolTipPostion: TooltipPosition = "above";
  matTabIndex: number = 0;
  excelBodDetails = [];
  filteredTimeStamp: string;
  deleteJson: any = {};
  read: boolean;
  write: boolean;
  delete: boolean;
  aendArray = [];
  zendArray = [];
  aendNE = '';
  zendNE = '';
  responseTime = '';
  constructor(private router: Router,
    private route: ActivatedRoute,
    private service: NokiaService,
    private ngxService: SpinnerService,
    private accessService: AccessService,
    private excelService: ExcelService,
    private datePipe: DatePipe,
    private optService: opticalModuleAPIService) { }


  ngOnInit() {

    this.ngxService.start();
    this.service.getAendZend()
      .subscribe(res => {
        this.aendArray = JSON.parse(res['body']);
        this.zendArray = JSON.parse(JSON.stringify(res['body']));
        this.ngxService.stop();

      });
    this.pageSize = 5;
    this.offset = 0;


    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Bandwidth on Demand Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Bandwidth on Demand Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Bandwidth on Demand Module', 'D');
    if (this.write) {
      this.matTabIndex = 0;
    } else {
      this.matTabIndex = 1;
    }

  }

  setDateAndTime() {
    this.min = this.from;
  }

  backToNSP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onSubmitNokia() {

    const requestJSON = {
      "siteNameA": this.form.value.aendNE,
      "siteNameZ": this.form.value.zendNE,
      "servicerate": this.form.value.demandRate,
      "signalType": this.form.value.demandRate,
      "demandName": this.form.value.demandName
    }


    console.log(JSON.stringify(requestJSON));
    this.ngxService.start();
    this.service.singleProvisioning(requestJSON).
      subscribe(response => {
        if (response['status_code'] == 202) {
          console.log(JSON.stringify(response));
          console.log('onSubmit success...');
          this.form.reset();
          this.showSwal(this.NOKIA_BOD_SUCCESS, response.status);
          this.ngxService.stop();
        }
        else {
          console.log("status is :", response.status);
          this.showDangerSwal(this.NOKIA_BOD_FAILURE, response.status);
          this.ngxService.stop();
        }
      });

  }
  cienaSCNMRequestJson: {};
  recilencyType = ['MESH_RESTORABLE', 'PERMANENT'];
  aendZendShelf = ['A', 'C'];
  aendZendSlot = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '15', '13', '14', '15'];
  retainList = [];

  // demandType = ['SNC-MR', 'SNCP-MR'];
  fileName = '';
  file: any;
  from: any = '';
  to: any = '';
  CIENA_BOD = 'CIENA BOD';
  NOKIA_BOD_SUCCESS = 'NOKIA BOD SUCCESS';
  NOKIA_BOD_FAILURE = 'NOKIA BOD FAILED';
  bodDetailsFlag = false;
  length: number;

  pageSizeOptions = [5, 10, 25, 100];
  bodDetails = [];
  bodDetailsTemp = [];
  fileByteArray = [];
  onPageChanged(e) {
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.bodDetailsTemp = this.bodDetails.slice(firstCut, secondCut);
  }
  onTabChanged(event) {


  }
  getServiceDetailsRequest() {
    let oldtimestamp = Date.parse(this.from).toString();
    let latesttimestamp = Date.parse(this.to).toString();
    let headers = new HttpHeaders()
      .append('Old-Timestamp', oldtimestamp)
      .append('Latest-Timestamp', latesttimestamp);
    const startTimeStamp: number = new Date().getTime();
    this.service.getServiceDetailsRequest(headers).
      subscribe(res => {
        this.bodDetails = JSON.parse(res);
        console.log("parsed JSON:", this.bodDetails);
        this.excelBodDetails = JSON.parse(res);
        this.length = this.bodDetails.length;
        this.excelBodDetails.forEach(element => {
          element['timeStamp'] = this.datePipe.transform(element['timeStamp'], 'medium');
          console.log("filtered stamp", element['timeStamp']);
        });
        this.bodDetailsTemp = this.bodDetails.slice(0, 5);
        if (this.bodDetails.length > 0) {
          this.bodDetailsFlag = false;
        }
        else this.bodDetailsFlag = true;
        // this.from = '';
        // this.to = '';
        const endTimeStamp: number = new Date().getTime();
        this.responseTime = Number(((endTimeStamp - startTimeStamp) / 1000.0)).toString();
      });
  }

  uploadFile() {
    console.log("file is:", this.fileByteArray);
    this.ngxService.start(20000);
    this.service.uploadBulkFile(this.fileByteArray).
      subscribe(res => {
        if (res['status_code'] == 200) {
          this.ngxService.stop();
          this.showSwal('NOKIA BULK BOD', this.fileName + " " + res.state);
          this.fileName = '';
          this.file = undefined;
          this.nokiaBulkForm.reset();
        }
      })
  }


  public onFileChange(event) {
    var fileByteArray = [];
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      this.fileName = event.target.files[0].name;
      this.file = event.target.files[0];
      const [file] = event.target.files;
      reader.readAsArrayBuffer(this.file);

      reader.onload = () => {
        var arrayBuffer = reader.result;
        var bytes = new Uint8Array(<ArrayBuffer>arrayBuffer);
        this.fileByteArray = [].concat(bytes);
        this.fileByteArray = Object.values(this.fileByteArray[0]);
      }

    }
  }


  downloadTemplate() {
    this.service.downloadTemplate().
      subscribe(res => {
        console.log(res)
        this.downloadFile(res);
      });
  }

  downloadFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response.fileData);
    console.log('byteArray | ', byteArray);

    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    // linkElement.target = '_blank';
    linkElement.download = response['fileName'];
    document.body.appendChild(linkElement);
    linkElement.click();
  }


  backToMCP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  showSwal(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-success",
      type: "success"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop)

  }

  showDangerSwal(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-danger",
      type: "warning"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop)

  }

  beforeDelete(bodItem, index) {
    this.deleteJson = {
      "siteNameA": bodItem['siteNameA'],
      "siteNameZ": bodItem['siteNameZ'],
      "timeStamp": bodItem['timeStamp'],
      "servicerate": bodItem['servicerate'],
    }
    console.log("index", index);
    this.index = this.offset + index;
    console.log("offset index", this.index);
    $('#deleteGCTModal').modal('show');
  }

  onDeleteBOD(toDeleteJson) {
    console.log("inside on delete");
    this.service.deleteBODDetails(toDeleteJson).subscribe(
      (response) => {
        console.log("res inside", response);
        this.displayDelete = response['state'];
        if (response['status_code'] == 202) {
          this.deleteStatus = true;
          $('#afterdeleteGCTModal').modal('show');
          this.bodDetails.splice(this.index, 1);
          this.excelBodDetails.splice(this.index, 1);
          this.length = this.bodDetails.length;
          console.log("bodDetails", this.bodDetails);
          this.bodDetailsTemp = this.bodDetails.slice(0, 5);
          if (this.paginator)
            this.paginator.firstPage();
        }
        else {
          this.deleteStatus = false;
          $('#afterdeleteGCTModal').modal('show');
          setTimeout(() => this.getServiceDetailsRequest(), 1000);
        }
      }
    );
  }

  exportAsXLSX() {
    // this.excelService.exportAsExcelFile(this.excelBodDetails, 'BOD Details');
    this.exportNewWorkbook();
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }


  //functon which export excel
  list: any[] = [];
  public exportNewWorkbook() {
    this.list.push({
      cells: <WorkbookSheetRowCell[]>[
        // First cell
        { value: 'siteNameA' },
        // Second cell
        { value: 'siteNameZ' },
        { value: 'servicerate' },
        { value: 'username' },
        { value: 'demandName' },
        { value: 'Source Port' },
        { value: 'Destination Port' },
        { value: 'isServiceCreated' },
        { value: 'timeStamp' },
        { value: 'Failure Reason' }


      ]
    });
    // this.bodDetails = JSON.parse(JSON.stringify(this.bodDetails));
    console.log(this.bodDetails);
    this.bodDetails.forEach(item => {

      this.list.push({
        cells: <WorkbookSheetRowCell[]>[
          // First cell
          { value: item["siteNameA"] },
          // Second cell
          { value: item["siteNameZ"] },
          { value: item["servicerate"] },
          { value: item["username"] },
          { value: item["demandName"] },
          { value: item["fromport1"] },
          { value: item["toport1"] },
          { value: item["isServiceCreated"] == true ? "True" : "False" },
          { value: this.datePipe.transform(item['timeStamp'], 'medium') },
          { value: item["Failure Reason"] ? item["Failure Reason"] : "" }

        ]
      })
    });
    console.log(this.list);
    const workbook = new Workbook({
      sheets: <WorkbookSheet[]>[
        {
          // Column settings (width)
          columns: <WorkbookSheetColumn[]>[
            { autoWidth: true },
            { autoWidth: true }
          ],
          // Title of the sheet
          name: 'Customers',
          // Rows of the sheet
          rows: <WorkbookSheetRow[]>
            // First row (header)

            // Second row (data)
            [].concat(this.list)

        }
      ]
    });
    workbook.toDataURL().then(dataUrl => {
      saveAs(dataUrl, 'BOD-LOG-Details.xlsx');
    });
  }

  ngOnDestroy(): void {
    this.ngxService.stop();
  }

}
