import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { NokiaService } from '../nokia.service';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {
  @ViewChild('viewForm') viewForm: NgForm;
  viewDetailsResult: string = '';
  afterSuccessViewModal: boolean = false;
  tickEnable: boolean = false;
  displaySuccess: boolean = false;
  getApi = '';
  read;
  write;
  delete;
  roleName: string = '';
  constructor(private optService: opticalModuleAPIService
    , private nokiaService: NokiaService
    , private router: Router,
    private route: ActivatedRoute,
    private ngxService: SpinnerService,
    private accessService: AccessService,
    private sessionService: SessionService) { }

  ngOnInit() {
    this.roleName = this.sessionService.get('userName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Get Data Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Get Data Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP Get Data Module', 'D');

  }

  getViewDetails() {
    this.viewDetailsResult = '';
    this.ngxService.start(60000 * 2);
    this.nokiaService.getViewDetails(this.viewForm.value['getApi'])
      .subscribe(res => {
        this.ngxService.stop();
        if (res['status_code'] === 410) {
          this.tickEnable = false;
          this.displaySuccess = res['state'];
          this.afterSuccessViewModal = true;

        } else {
          this.viewDetailsResult = JSON.stringify(JSON.parse(res['body'])[0], null, 4);

        }

      })
  }

  async downloadJSONFile() {

    this.ngxService.start();
    const filename = 'viewDetails.json';
    const jsonStr = this.viewDetailsResult;
    let element = document.createElement('a');
    this.ngxService.start();
    let encodeMessage = await encodeURIComponent(jsonStr);
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeMessage);
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    this.ngxService.stop();
    document.body.removeChild(element);
    this.ngxService.stop();

  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  backToNSP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

}
