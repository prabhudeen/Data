import { Component, OnInit, ViewChild, ElementRef, EventEmitter, Output, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NokiaService } from '../nokia.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { MatTable, MatDialog } from '@angular/material';
import { DialogBoxxComponent } from '../dialog-boxx/dialog-boxx.component';
import { element } from '@angular/core/src/render3';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';

export interface GctData {
  name: string;
  id: number;
  editable: boolean;
}

@Component({
  selector: 'app-nokia-gct-template',
  templateUrl: './nokia-gct-template.component.html',
  styleUrls: ['./nokia-gct-template.component.css']
})



export class NokiaGctTemplateComponent implements OnInit {
  @Output() valueChange = new EventEmitter<any[]>();
  @Output() assignRoleName = new EventEmitter<string>();
  gctTemplateListType: any = {

    'Nodes': 'Nodes',
    'OTS': 'Phy Conn_OTS',
    'OPS': 'Phy Conn_OPS',
    'OMS': 'Trails_OMS',
    'OTU': 'Trails_OTU',
    'ODU': 'Trails_ODU',
    'DSR': 'DSR',
    'ASON_TRAILS': 'ASON_TRAILS',
    'ASON_LINKS': 'ASON_LINKS'


  }
  roleName: string = ''
  GCT_TEMPLATE_DATA: any = {};
  templateListArray = Object.keys(this.gctTemplateListType);
  gctTemplateData = [];
  gctParameter = [];
  expectedValues = ['Expected_Values_MCN', 'Expected_Values_NLC', 'Expected_Values_MAC'];
  gctModalDialoge: boolean = false;
  gctType: string = '';
  afterSuccessGCTModal: boolean = false;
  displaySuccess: string = '';
  tickEnable: boolean = true;
  afterdeleteGCTModal: boolean = false;
  deleteStatus: boolean = false;
  read: boolean;
  write: boolean;
  delete: boolean;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private nokiaService: NokiaService,
    private ngxService: SpinnerService,
    private accessService: AccessService,
    private optService: opticalModuleAPIService,
    public dialog: MatDialog,
    private session: SessionService) { }


  ngOnInit() {
    this.gctType = '';
    this.roleName = this.session.get('roleName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'D');

    console.log(this.read, this.write, this.delete);
  }

  getGCTTemplate(gctType) {
    console.log(gctType);
    this.gctType = gctType;
    this.nokiaService.getGCTTemplate(gctType)
      .subscribe(res => {
        // this.gctTemplateData=res;
        this.GCT_TEMPLATE_DATA = {};
        this.gctParameter = [];
        res.forEach(element => {
          this.gctParameter.push(element['GCT_Parameter']);

          this.GCT_TEMPLATE_DATA[element['GCT_Parameter']] = {};
          this.GCT_TEMPLATE_DATA[element['GCT_Parameter']]['Expected_Values_MCN'] = element['Expected_Values_MCN'];
          this.GCT_TEMPLATE_DATA[element['GCT_Parameter']]['Expected_Values_NLC'] = element['Expected_Values_NLC'];
          this.GCT_TEMPLATE_DATA[element['GCT_Parameter']]['Expected_Values_MAC'] = element['Expected_Values_MAC'];
        });
        // this.valueChange.emit(this.gctParameter);
        console.log(this.GCT_TEMPLATE_DATA);
      })
  }

  displayedColumns: string[] = ['id', 'name', 'action'];
  dataSource: GctData[] = [];
  exptectedValueName: string = '';
  currentGctParam: string = '';
  currentGctValue: string = '';
  @ViewChild(MatTable) table: MatTable<any>;

  gctExpecteValue(array, expecteValueName, paramValue) {
    console.log(array);
    this.dataSource = [];
    this.currentGctValue = expecteValueName;
    this.currentGctParam = paramValue;
    array.forEach((data, ind) => {
      this.dataSource.push({
        id: ind,
        name: data,
        editable: false
      });
    })
    this.exptectedValueName = expecteValueName;
    this.gctModalDialoge = true;
  }

  openDialog(action, obj) {
    if (action == 'Update') {
      obj.editable = true;
      console.log('openDialog', obj);
    }

  }

  addRowData(row_obj) {
    if (row_obj) {
      row_obj.name = '';
      row_obj.editable = true;
      console.log(row_obj, this.GCT_TEMPLATE_DATA)
      this.dataSource.unshift(row_obj);
      this.dataSource = this.dataSource.map((element, index) => {
        element.id = index;
        return element;
      })
      setTimeout(() => {
        let myInput: HTMLElement;
        myInput = document.getElementById("table-0");
        myInput.focus();
        console.log(myInput);
      }, 500);

    }
    console.log(this.GCT_TEMPLATE_DATA);
    // this.table.renderRows();

  }
  deleteGctRow(row_obj) {

    this.dataSource = this.dataSource.filter((element, index) => {
      if (index !== row_obj.id) {
        element.id = index - 1;
        return element;
      }
    });
    console.log('DeleteRowData', row_obj, this.GCT_TEMPLATE_DATA);
  }
  updateGCTtemplateData(row_obj) {
    let index = -1;
    if ((index = this.dataSource.findIndex(element => element.name === '')) == -1) {
      this.GCT_TEMPLATE_DATA[this.currentGctParam][this.currentGctValue] = this.dataSource.map((element) => {
        return element.name;
      });
      this.gctModalDialoge = false;
      this.valueChange.emit(this.GCT_TEMPLATE_DATA);
    } else {
      let obj = { name: '', action: 'Add Property' };
      obj.name = "Please Add the property at index " + index;
      const dialogRef = this.dialog.open(DialogBoxxComponent, {
        width: '350px',
        data: obj
      });

      dialogRef.afterClosed().subscribe(result => {
        let myInput: HTMLElement;
        myInput = document.getElementById("table-" + index);
        myInput.focus();
      });


    }
    console.log(this.GCT_TEMPLATE_DATA);
  }



  updateGctTemplate() {
    let gctTemplateFinalJson = [];
    this.gctParameter.forEach(param => {
      let arraysObj = this.GCT_TEMPLATE_DATA[param];
      let obj = {};
      obj['GCT_Parameter'] = param;
      obj['Expected_Values_MCN'] = arraysObj['Expected_Values_MCN'];
      obj['Expected_Values_NLC'] = arraysObj['Expected_Values_NLC'];
      obj['Expected_Values_MAC'] = arraysObj['Expected_Values_MAC'];
      gctTemplateFinalJson.push(obj);
    });
    // this.valueChange.emit(this.gctParameter);
    console.log(JSON.stringify(gctTemplateFinalJson));

    this.nokiaService.updateGCTTemplateData(this.gctType, gctTemplateFinalJson)
      .subscribe(res => {
        if (res.status_code == 200) {
          this.displaySuccess = res.state;
          this.afterSuccessGCTModal = true;
          this.tickEnable = true;
        }
        else {
          this.afterSuccessGCTModal = true;
          this.tickEnable = false;
        }
      });
  }


  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }


}
