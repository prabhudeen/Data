export interface NokiaBOD {
    siteNameA: string;
    siteNameZ: string;
    servicerate: string;
    containerrate: string;
    signalType: string;
}

