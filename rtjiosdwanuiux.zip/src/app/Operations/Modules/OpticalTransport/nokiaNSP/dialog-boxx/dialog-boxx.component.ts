import { Component, OnInit, Optional, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GctData } from '../nokia-gct-template/nokia-gct-template.component';

export interface GctData {
  name: string;
  id: number;
}
 

@Component({
  selector: 'app-dialog-boxx',
  templateUrl: './dialog-boxx.component.html',
  styleUrls: ['./dialog-boxx.component.css']
})
export class DialogBoxxComponent implements OnInit {

  action:string;
  local_data:any;
 
  constructor(
    public dialogRef: MatDialogRef<DialogBoxxComponent>,
    //@Optional() is used to prevent error if no data is passed
    @Optional() @Inject(MAT_DIALOG_DATA) public data: GctData) {
    console.log(data);
    this.local_data = {...data};
    this.action = this.local_data.action;
    console.log(this.local_data);
  }
 
  doAction(){
    // delete this.local_data.action;
    this.dialogRef.close({event:this.action,data:this.local_data});
  }
 
  closeDialog(){
    this.dialogRef.close({event:'Cancel'});
  }

  ngOnInit() {
  }

}
