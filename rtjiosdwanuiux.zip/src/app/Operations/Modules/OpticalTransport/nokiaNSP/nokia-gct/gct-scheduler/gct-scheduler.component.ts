import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { NokiaService } from '../../nokia.service';
import { NgForm } from '@angular/forms';
import { SessionService } from '../../../../../../SharedFolder/services/sessionService.service';
import { EventConstants } from '../../../../../../SharedFolder/constants/eventConstants';
import { SpinnerService } from './../../../../../../SharedFolder/services/SpinnerService.service';
import { NgxMaterialTimepickerComponent } from 'ngx-material-timepicker';
import { AccessService } from './../../../../../../SharedFolder/services/access.service';

@Component({
  selector: 'app-gct-scheduler',
  templateUrl: './gct-scheduler.component.html',
  styleUrls: ['./gct-scheduler.component.css']
})
export class GctSchedulerComponent implements OnInit {

  @Input() gctSchedularType: string = '';
  @Input() ModuleLevel: string = 'nokia';
  @Input() SubModuleLevel: string = '';
  @ViewChild('fullTime') fullTime: NgxMaterialTimepickerComponent;

  pmMIN: Boolean = false;
  pmHR: Boolean = false;
  scheduleList: any[] = [];
  scheduleListTemp: any[] = [];
  scheduleDay: Number[] = [1, 2, 3, 4, 5, 6, 7];
  scheduleDayTemp: Number[] = [1, 2, 3, 4, 5, 6, 7];
  scheduleGctModal: boolean = false;
  scheduleGctModalSuccess: boolean = false;
  displaySuccess: string = '';
  tickEnable: boolean = false;
  allDaysToggleBtn: boolean = true;
  selectedTime: string = '';
  roleName: string = '';
  pageSize: number;
  offset: number;
  length: number;
  read: boolean;
  write: boolean;
  delete: boolean;
  displayDelete: string = '';
  deleteGCTModal: boolean = false;
  selectedGUILabel: string = '';
  deleteStatus: boolean = false;
  toggleAllDays: number = 0;
  opticalModule: any;
  pageSizeOptions = [5, 10, 25, 100];
  @ViewChild('gctSchedulerForm') gctSchedulerForm: NgForm;
  constructor(private nokiaService: NokiaService,
    private session: SessionService,
    private ngxService: SpinnerService,
    private accessService: AccessService) {
  }

  ngOnInit() {
    this.pageSize = 5
    // this.roleName = this.session.get('roleName');
    // console.log('this.roleName :>> ', this.roleName);
    this.roleName = this.session.get('roleName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    console.log(this.roleName, this.gctSchedularType);

    if (this.ModuleLevel === 'ciena') {
      this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');
      this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'W');
      this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'D');
    }
    if (this.ModuleLevel === 'nokia') {
      console.log(this.SubModuleLevel);
      this.read = this.accessService.getAccessForSubModule('Optical Transport', this.SubModuleLevel, 'R');
      this.write = this.accessService.getAccessForSubModule('Optical Transport', this.SubModuleLevel, 'W');
      this.delete = this.accessService.getAccessForSubModule('Optical Transport', this.SubModuleLevel, 'D');
    }


  }

  callGCTScheduler(modelName) {
    console.log('callGCTScheduler>>> ', this.gctSchedularType);
    this.nokiaService.getGCTSchedulesList(this.gctSchedularType, modelName)
      .subscribe(resp => {
        console.log(resp);
        this.scheduleList = resp.map(element => {
          const curElement = element['data'];
          const time = this.timeformat(curElement['hour'], curElement['minute']);
          const newWeekOfDay = new Array(7).fill(-1);
          this.scheduleDay.forEach((day, index) => {
            if (curElement['daysOfWeek'].findIndex(curDay => curDay === day) !== -1)
              newWeekOfDay[index] = index + 1;
          })
          const obj = {
            scheduleTime: time,
            scheduleDays: newWeekOfDay,
            schedulerName: element['schedulerName']
          };

          if (this.gctSchedularType == EventConstants.GCT_PM_SCHEDULER_NAME) {
            obj['granularity'] = curElement['granularity'];
          }
          return obj;
        });
        this.scheduleListTemp = [];
        if (this.scheduleList.length > 0) {
          // this.gctDetailsFlag = false;
          this.length = this.scheduleList.length;
          if (this.scheduleList.length > this.pageSize)
            this.scheduleListTemp = this.scheduleList.slice(0, this.pageSize);
          else
            this.scheduleListTemp = this.scheduleList;
        }

        console.log('schedule List>>>> ', this.scheduleListTemp);
      })
  }


  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.scheduleListTemp = this.scheduleList.slice(firstCut, secondCut);
  }

  timeformat(hour = 0, min = '0') {
    const x = hour >= 12 ? 'pm' : 'am';
    hour = hour % 12;
    hour = hour ? hour : 12;
    min = Number(min) < 10 ? '0' + min : min;
    const mytime = hour + ':' + min + ' ' + x;
    return mytime;
  }

  dayOfCurrentNum(num) {
    switch (num) {
      case 1: return 'Sun'
      case 2: return 'Mon'
      case 3: return 'Tue'
      case 4: return 'Wed'
      case 5: return 'Thu'
      case 6: return 'Fri'
      case 7: return 'Sat'

    }
  }

  showSeletedTime() {
    console.log(this.selectedTime);
  }

  CancelGCTSchedule(scheduleName, index) {
    let modelName = this.ModuleLevel;
    console.log('CancelGCTSchedule >>>> ', scheduleName);
    this.ngxService.start();
    this.nokiaService.CancelGCTSchedule(scheduleName, this.gctSchedularType, modelName)
      .subscribe(res => {
        this.ngxService.stop();
        console.log(res);
        if (res['status_code'] === 200) {
          this.tickEnable = true;
          if (modelName === "nokia") {
            this.displaySuccess = res['state'];
          }
          else {
            this.displaySuccess = res['status'];
          }
          console.log('this.displaySuccess :', this.displaySuccess);
          this.scheduleGctModalSuccess = true;
          this.callGCTScheduler(modelName);
        }
        else {
          this.tickEnable = false;
          if (modelName === "nokia") {
            this.displaySuccess = res['state'] ? res['state'] : 'Unknow Error';
          }

          else {
            this.displaySuccess = res['status'] ? res['status'] : 'Unknow Error';
          }
          this.scheduleGctModalSuccess = true;
        }
      })


  }

  scheduleGCT() {
    this.opticalModule = this.ModuleLevel;
    console.log("schedule gct >>> ", this.pmHR, this.pmMIN)
    const filterDay = this.scheduleDayTemp.filter(day => day !== -1);
    let hour = this.selectedTime.split(':')[0];
    let min = this.selectedTime.split(':')[1];

    hour = hour[0] == '0' ? hour[1] : hour;
    min = min[0] == '0' ? min[1] : min;
    console.log(this.selectedTime, 'hour>>>', hour, 'and minute >>>> ', min);
    const requestJson = {
      'hour': hour,
      'minute': min,
      'daysOfWeek': filterDay
    }
    if (this.gctSchedularType === EventConstants.GCT_PM_SCHEDULER_NAME)
      requestJson['granularity'] = (this.pmMIN == true && this.pmHR == true) ? 'both' : this.pmMIN ? '15min' : '24hr';

    console.log('requestJson >>>>', requestJson);
    this.ngxService.start();
    this.nokiaService.scheduleGCTPost(requestJson, this.gctSchedularType, this.opticalModule)
      .subscribe(res => {
        this.ngxService.stop();
        console.log(res);
        if (res['status_code'] === 200) {
          if (this.opticalModule === 'nokia')
            this.displaySuccess = res['state'];
          else
            this.displaySuccess = res['status'];
          this.tickEnable = true;
          this.scheduleGctModalSuccess = true;
          this.callGCTScheduler(this.opticalModule);
          this.pmHR = false;
          this.pmMIN = false;
        }
        else {
          if (this.opticalModule === "nokia") {
            this.displaySuccess = res['state'];
          }
          else {
            this.displaySuccess = res['status'];
          }
          this.tickEnable = false;
          this.scheduleGctModalSuccess = true;
        }
      })
  }

  toggleMatChip(day, i) {
    if (day == -1) this.toggleAllDays++;
    else this.toggleAllDays--;

    this.scheduleDayTemp[i] = day == -1 ? i + 1 : -1;
  }

  resetAllDays() {
    if (this.allDaysToggleBtn == false) {
      this.toggleAllDays = 0;
      this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => -1);
    }
    else {
      this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => i + 1);
    }

    console.log('callled reset function called ', this.scheduleDayTemp)
  }

  resetScheduleModalData() {
    this.pmMIN = false;
    this.pmHR = false;
    this.selectedTime = '';
    this.allDaysToggleBtn = true;
    this.toggleAllDays = 0;
    this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => i + 1);


  }
}
