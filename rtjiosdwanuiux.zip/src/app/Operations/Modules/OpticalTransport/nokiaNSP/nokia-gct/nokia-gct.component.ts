import { Component, ViewChild, OnInit, OnDestroy, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { NokiaService } from '../nokia.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import swal from 'sweetalert2';
import { GctSchedulerComponent } from './gct-scheduler/gct-scheduler.component';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
import { ThrowStmt } from '@angular/compiler';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';
declare var $: any;

@Component({
    selector: 'app-nokia-gct',
    templateUrl: './nokia-gct.component.html',
    styleUrls: ['./nokia-gct.component.css']
})

export class NokiaGCTComponent implements OnDestroy, AfterViewInit {


    @ViewChild('paginator') paginator: MatPaginator;

    roleName: string = '';
    schedularType: string = '';
    gctParameter: any[] = [];
    toolTipPostion: TooltipPosition = "above";
    selectedGUILabel: any = {};
    selectedIndex;
    tickEnable: boolean = false;
    deleteStatus: boolean = false;
    ListType: string;
    gctDetailsFlag = false;
    displayDelete;
    displaySuccess;
    length: number;
    gctTypeList = ['Nodes',
        'PhyConn_OPS',
        'PhyConn_OTS',
        'InfraConn_OMS',
        'InfraConn_OTU',
        'InfraConn_ODU',
        'DSR',
        'ASON_TRAILS',
        'ASON_LINKS'
    ];

    gctDeviationList = ['Nodes',
        'PhyConn_OPS',
        'PhyConn_OTS',
        'InfraConn_OMS',
        'InfraConn_OTU',
        'InfraConn_ODU',
        'DSR',
        'ASON_TRAILS',
        'ASON_LINKS',
        'PM'
    ];

    pageSizeOptions = [5, 10, 25, 100];
    gctDetails = [];
    gctDetailsTemp = [];
    guiArray = [];
    pageSize: number;
    offset: number;
    matTabIndex: number = 0;
    read: boolean;
    write: boolean;
    delete: boolean;
    gctModeList: any[] = ['Single', 'All'];
    filterGui: string = '';
    gctListType: string = '';
    afterdeleteGCTModal: boolean = false;
    deleteGCTModal: boolean = false;
    afterSuccessGCTModal: boolean = false;
    callPagination: boolean = false;

    @ViewChild('nokiaGCTForm') nokiaGCTForm: NgForm;
    @ViewChild('nokiaGCTListForm') nokiaGCTListForm: NgForm;
    @ViewChild('gctType') gctType: string;
    @ViewChild('gctMode') gctMode: string;
    @ViewChild(GctSchedulerComponent) gctSchedulerComponent: GctSchedulerComponent;
    @ViewChild('pmScheduler') pmSchedulerComponent: GctSchedulerComponent;


    constructor(private router: Router,
        private route: ActivatedRoute,
        private nokiaService: NokiaService,
        private ngxService: SpinnerService,
        private accessService: AccessService,
        private optService: opticalModuleAPIService,
        private sessionService: SessionService

    ) { }

    ngOnInit() {

        this.assignRoleName(null);
        this.pageSize = 5;
        this.offset = 0;
        this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'R');
        this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'W');
        this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Nokia NSP GCT Module', 'D');
        if (this.write) {
            this.matTabIndex = 0;
        }
        else {
            this.matTabIndex = 1;
        }

    }

    ngAfterViewInit(): void {
        this.paginator.pageIndex = 0;
    }

    assignRoleName(roleName) {

        this.roleName = this.sessionService.get('userName');
        if (this.roleName && this.roleName.includes('admin'))
            this.roleName = 'TelcoRole';
        console.log('roleName | ', this.roleName);
    }

    onTabChanged(event) {
        console.log(event.index);
        if (event.index == 3) {
            this.schedularType = EventConstants.GCT_SCHEDULER_NAME;
            this.gctSchedulerComponent.callGCTScheduler("nokia");
        } else if (event.index === 4) {
            this.schedularType = EventConstants.GCT_PM_SCHEDULER_NAME;
            this.pmSchedulerComponent.callGCTScheduler("nokia");
        }
    }

    changeGCTparameter(gctParameter) {
        console.log('changegctParmanet', gctParameter);
        this.gctParameter = gctParameter;
    }

    getGUILableList(mode) {
        if (this.nokiaGCTForm.value['gctType'] == 'Nodes' && mode == 'Single') {
            this.ngxService.start()
            this.nokiaService.getAendZend()
                .subscribe(res => {
                    this.ngxService.stop();
                    if (res['status_code'] === 410) {
                        this.tickEnable = false;
                        this.displaySuccess = res['state'];
                        this.afterSuccessGCTModal = true;
                    } else {
                        this.guiArray = JSON.parse(res['body']);
                    }


                });
        }
    }


    onPageChanged(e) {
        this.offset = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.gctDetailsTemp = this.gctDetails.slice(firstCut, secondCut);
    }

    backToNSP() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onSubmit() {
        this.ngxService.start(60000 * 2);
        console.log(this.nokiaGCTForm.value['guiLabel'], "gui Value");
        console.log(this.nokiaGCTForm.value['gctType'], "gctType");
        const startTimeStamp: number = new Date().getTime();
        this.nokiaService.nokiaGCTRequest(this.nokiaGCTForm.value['gctType'], this.nokiaGCTForm.value['gctMode'], this.nokiaGCTForm.value['guiLabel']).subscribe(
            (response) => {
                this.ngxService.stop();
                this.gctDetailsTemp = [];
                this.gctListType = this.nokiaGCTForm.value['gctType'];
                console.log(this.gctListType);
                console.log(response, "check response");
                this.displaySuccess = response['state'];
                if (response['status_code'] === 200) {
                    this.tickEnable = true;
                    this.afterSuccessGCTModal = true;
                    this.nokiaGCTForm.value['gctType'] = '';
                    this.nokiaGCTForm.resetForm();
                }
                else {
                    this.tickEnable = false;
                    this.afterSuccessGCTModal = true;
                }


            }
        );
    }


    getGCTTypeList() {
        console.log(this.nokiaGCTListForm);

        this.ListType = this.nokiaGCTListForm.value['gctListType'];
        console.log(this.ListType, "listType Value");
        this.nokiaService.nokiaGetListType(this.ListType).subscribe(
            (response) => {
                console.log(response);
                if (response['status_Code'] == 200) {
                    this.gctDetails = response['guiLabels'];
                    this.gctDetailsTemp = this.gctDetails;
                    this.gctDetails = this.gctDetails.map(data => {
                        let time = data.filename.substring(data.filename.lastIndexOf('_') + 1, data.filename.lastIndexOf('.')).replace('IST ', '');
                        let d = new Date(time);
                        return {
                            year: d.getFullYear(),
                            time: d,
                            value: data.filename,
                            username: data.username
                        };
                    })
                    // this.gctDetails.sort((a, b) => {
                    //     return (b.year - a.year) > 0 ? 1 : (b.time - a.time);
                    // })

                    console.log(this.gctDetails);


                    if (this.gctDetails.length > 0) {
                        this.gctDetailsFlag = false;
                        this.length = this.gctDetails.length;
                        if (this.gctDetails.length > this.pageSize) {
                            if (this.callPagination)
                                this.onPageChanged(this.paginator);
                            else
                                this.gctDetailsTemp = this.gctDetails.slice(0, this.pageSize);

                        }
                        else
                            this.gctDetailsTemp = this.gctDetails;


                    }
                    else this.gctDetailsFlag = true;
                }
                else this.gctDetailsFlag = true;
            }
        )
    }

    onDownload(label) {
        this.nokiaService.downloadGCTTemplate(this.ListType, label).subscribe(res => {
            this.downloadFile(res);
        });
    }

    downloadFile(data) {
        if (data['status_code'] == 202) {
            var linkElement = document.createElement('a');
            var byteArray = new Uint8Array(data['fileData']);
            linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
            linkElement.download = data['fileName'];
            document.body.appendChild(linkElement);
            linkElement.click();
        }
        else {
            this.displayDelete = data['state'];
            this.afterdeleteGCTModal = true;
            setTimeout(() => this.getGCTTypeList(), 1000);
        }
    }

    beforeDelete(item, index) {
        this.selectedGUILabel = item
        console.log('selected GUI Lable | ', this.selectedGUILabel)
        this.selectedIndex = this.offset + index;
        console.log('selectedIndex | ', this.selectedIndex, ' | ', index);
        this.deleteGCTModal = true;

    }

    onDeleteGCT(item) {
        this.nokiaService.deleteGCTDetails(item, this.ListType).subscribe(res => {
            this.displayDelete = res['state'];
            if (res['status_code'] == 202) {
                this.deleteStatus = true;
                this.callPagination = true;
                this.getGCTTypeList();
            }
            else {
                this.deleteStatus = false;
            }
            this.afterdeleteGCTModal = true;
        });

    }

    breadcrumbNavigation(path: string) {
        this.optService.breadcrumbNavigation(path);
    }

    ngOnDestroy(): void {
        this.ngxService.stop();
    }
}
