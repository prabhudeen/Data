import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { opticalModuleAPIService } from '../opticalTransportModule_API.service';

@Component({
  selector: 'app-nokia-nsp',
  templateUrl: './nokia-nsp.component.html',
  styleUrls: ['./nokia-nsp.component.css']
})
export class NokiaNspComponent implements OnInit {

  list: any[] = [
    {
      title: "Bandwidth On Demand",
      value: "Nokia NSP Bandwidth on Demand Module",
      access: true,
    },
    {
      title: "Golden Configuration Template (GCT) Audit",
      value: "Nokia NSP GCT Module",
      access: true,
    },
    {
      title: "Health Check",
      value: "Nokia NSP Health Check Module",
      access: true
    },
    {
      title: "Infrastructure Provisioning",
      value: "Nokia Infra trails Module",
      access: true
    },
    {
      title: "Get Data",
      value: "Nokia NSP Get Data Module",
      access: true
    }
  ]

  constructor(private router: Router,
    private route: ActivatedRoute,
    private accessService: AccessService,
    private optService: opticalModuleAPIService) { }

  ngOnInit() {
    this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'Optical Transport');
  }

  onClick(action) {
    switch (action) {
      case "Nokia NSP Bandwidth on Demand Module":
        this.router.navigate(['BOD'], { relativeTo: this.route });
        break;
      case "Nokia NSP GCT Module":
        this.router.navigate(['GCT'], { relativeTo: this.route });
        break;
      case "Nokia NSP Health Check Module":
        this.router.navigate(['Health-Check'], { relativeTo: this.route });

        break;
      case "Nokia NSP Get Data Module":
        this.router.navigate(['view-details'], { relativeTo: this.route });
        break;
      case "Nokia Infra trails Module":
        this.router.navigate(['infra-trails'], { relativeTo: this.route });
    }
  }

  backToOpticalTransport() {
    this.router.navigateByUrl("layout/opticalTransport");
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }


}
