import { SdWanServiceService } from '../../../SharedFolder/services/sd-wan-service.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../SharedFolder/constants/eventConstants';
import { ActivatedRoute, Router } from '@angular/router';



@Injectable({
    providedIn: "root"
})

export class opticalModuleAPIService {

    constructor(private commonService: SdWanServiceService,
        private route: ActivatedRoute,
        private router: Router) { }


    cienaSCNMR(cienaSCNMRJson) {

        return new Observable<any>(observe => {
            this.commonService.sendRequest("POST", "/PEAG/nbHandlerCiena", cienaSCNMRJson, null, null, EventConstants.CIENA_BOD_SNC_MR).subscribe(
                (response) => {
                    if (response["status_code"] = 200) {
                        observe.next(response['body']);
                    }
                    else {
                        observe.next(response['body']);
                    }
                }
            );
        }
        );
    }

    breadcrumbNavigation(path: string) {
        switch (path) {
            case 'dashboard': return this.router.navigate(['/layout/Dashboard']);
            case 'opticalTrasport': return this.router.navigate(['/layout/opticalTransport']);
            case 'nokiaMCP': return this.router.navigate(['/layout/opticalTransport/nokiaNSP']);
            case 'cienaMCP': return this.router.navigate(['/layout/opticalTransport/cienaMCP']);
            case 'cienaHealthCheck': return this.router.navigate(['/layout/opticalTransport/cienaMCP/HealthCheck']);
            case 'Health-Check': return this.router.navigate(['/layout/opticalTransport/nokiaNSP/Health-Check']);
        }
    }

}