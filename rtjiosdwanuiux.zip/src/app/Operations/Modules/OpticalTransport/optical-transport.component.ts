import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../SharedFolder/services/access.service';
import { opticalModuleAPIService } from './opticalTransportModule_API.service';

@Component({
  selector: 'app-optical-transport',
  templateUrl: './optical-transport.component.html',
  styleUrls: ['./optical-transport.component.css']
})
export class OpticalTransportComponent implements OnInit {

  list: any[] = [
    {
      title: "Ciena MCP",
      value: "cienaMCP",
      access: true,
      childList: ['Ciena MCP Bandwidth on Demand Module', 'Ciena MCP GCT Module', 'Ciena MCP Health Check Module', 'Ciena MCP Get Data Module', 'Ciena MCP Alarm Analysis Module', 'Ciena MCP Backup and Restore Module', 'Ciena MCP PM Management Module', 'Ciena MCP Inventory Management Module']
    },
    {
      title: "Nokia NSP",
      value: "nokiaNSP",
      access: true,
      childList: ['Nokia NSP Bandwidth on Demand Module', 'Nokia NSP GCT Module', 'Nokia NSP Health Check Module', 'Nokia NSP Get Data Module', 'Nokia Infra trails Module']
    }
  ]

  constructor(private router: Router,
    private accessService: AccessService,
    private optService: opticalModuleAPIService) { }

  ngOnInit() {
    this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'Optical Transport', true);
  }

  onClick(action) {
    switch (action) {
      case "cienaMCP":
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP");
        break;
      case "nokiaNSP":
        this.router.navigateByUrl("layout/opticalTransport/nokiaNSP");
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
}
