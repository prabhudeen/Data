import { Injectable } from '@angular/core';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class AlarmAnalysisService {
    constructor(private commonService: SdWanServiceService) { }


    // ---------    Prashant    ----------------------- //

    alarmSummary(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_SUMMARY).subscribe(
                (response) => {
                    // console.log("string response is:", JSON.stringify(response));
                    // console.log('parsed response is :', JSON.parse(JSON.stringify(response)));
                    console.log(response);
                    observe.next(JSON.parse(response['body']));
                    console.log("modified response", JSON.parse(response['body']));
                }
            );
        });

    }

    getAlarmTrend(node) {
        console.log('node :', node);
        let headers = new HttpHeaders().append('Type', node);
        console.log('headers in service are :', headers);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, headers, null, EventConstants.CIENA_ALARM_TREND).subscribe(
                (response) => {
                    console.log(response);
                    // console.log('response.body :', response['body']);
                    observe.next(response);
                    //console.log("modified response", JSON.parse(response['body']));
                }
            );
        });
    }

    getAlarmTrendOfAffectedNodes(node) {
        console.log('node getAlarmTrendOfAffectedNodes :', node);
        let headers = new HttpHeaders().append('Type', node);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, headers, null, EventConstants.CIENA_ALARM_TREND_AFFECTED_NODE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                    // console.log("modified response", JSON.parse(response['body']));
                }
            );
        });
    }

    getAlarmTrendOfZone(node) {
        let headers = new HttpHeaders().append('Type', node);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, headers, null, EventConstants.CIENA_ALARM_TREND_ZONE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                    // console.log("modified response", JSON.parse(response['body']));
                }
            );
        });
    }

    getAlarmTrendOfAffectedNodesZone(node) {
        let headers = new HttpHeaders().append('Type', node);
        console.log('node in affected zone :', node);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, headers, null, EventConstants.CIENA_ALARM_TREND_AFFECTED_NODE_ZONE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                    //  console.log("modified response", JSON.parse(response['body']));
                }
            );
        });
    }


    demandUnavailability(): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_DEMAND_UNAVAILABILITY).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                    //console.log("modified response", JSON.parse(response['data']));
                }
            );
        });
    }

    getAlarmsDump(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_DUMP).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });

    }

    getDemandDump(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_DEMAND_DUMP).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });

    }


    // ----------- Prashant End ----------------//
    deleteModal(headers): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('DELETE', EventConstants.CIENA_ALARM_CONTEXT, null, headers, null, EventConstants.CIENA_ALARM_DELETE_MODAL).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        });
    }
    addAlarmModal(json): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_ALARM_CONTEXT, json, null, null, EventConstants.CIENA_ALARM_ADD_MODAL).subscribe(
                (response) => {

                    console.log(response);
                    observe.next(response);
                }
            );
        });
    }
    editModal(json): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_ALARM_CONTEXT, json, null, null, EventConstants.CIENA_ALARM_EDIT_MODAL).subscribe(
                (response) => {

                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }
    getModal(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_GET_MODAL).subscribe(
                (response) => {

                    console.log(response);
                    console.log('JSON.parse(response) :', JSON.parse(response['body']));
                    observe.next(JSON.parse(response['body']));
                }
            );
        });
    }
    getCriticalAlarmModal(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_GET_CRITICAL_MODAL).subscribe(
                (response) => {

                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    // downLoadTemplate(): any {
    //     return new Observable((observe) => {
    //         this.commonService.downloadUserTemplate().subscribe(
    //             (data) => {
    //                 console.log('data :', data);
    //                 observe.next("data");
    //             }
    //         )
    //     })
    // }
    downLoadTemplate(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_DOWNLOAD_MODAL).subscribe(
                (response) => {

                    console.log(response);
                    observe.next(response);
                }
            );
        });
    }
    alarmDownloadTemplate(): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_ALARM_CONTEXT, null, null, null, EventConstants.CIENA_ALARM_DOWNLOAD_TEMPLATE).subscribe(
                (response) => {

                    console.log(response);
                    observe.next(response);
                }
            );
        });
    }

    uploadTemplate(uploadFile): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_ALARM_CONTEXT, uploadFile, null, null, EventConstants.CIENA_ALARM_UPLOAD_MODAL).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

}