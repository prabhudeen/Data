import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AlarmAnalysisService } from './alarm-analysis.service';
import { ValueTransformer } from '@angular/compiler/src/util';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { TooltipPosition } from '@angular/material';

declare var Highcharts: any;
@Component({
  selector: 'app-alarm-analysis',
  templateUrl: './alarm-analysis.component.html',
  styleUrls: ['./alarm-analysis.component.css']
})
export class AlarmAnalysisComponent implements OnInit, OnDestroy {
  @ViewChild('cienaNodeForm') cienaNodeForm: NgForm;
  @ViewChild('addAlarmForm') addAlarmForm: NgForm;
  toolTipPostion: TooltipPosition = "above";
  toolTipPostion1: TooltipPosition = "below";

  // stateMapping = {
  //   'Bihar': 'bihar',
  //   'Madhya Pradesh': 'madhya pradesh',
  //   'Uttar Pradesh - East': 'uttar pradesh',
  //   'Karnataka': 'karnataka',
  //   'Nagaland': 'nagaland',
  //   'Assam': 'assam',
  //   'West Bengal': 'west bengal',
  //   'Puducherry': 'puducherry',
  //   'Daman and Diu': 'daman and diu',
  //   'Gujarat': 'gujarat',
  //   'Rajasthan': 'rajasthan',
  //   'Dadara and Nagar Havelli': 'dadara and nagar havelli',
  //   'Chhattisgarh': 'chhattisgarh',
  //   'Delhi': 'nct of delhi',
  //   'Tamil Nadu': 'tamil nadu',
  //   'Uttar Pradesh - West': 'uttarakhand',
  //   'Andhra Pradesh': 'andhra pradesh',
  //   'Jammu and Kashmir': 'jammu and kashmir',
  //   'Odisha': 'odisha',
  //   'Maharashtra': 'maharashtra',
  //   'Kerala': 'kerala',
  //   'Punjab': 'punjab',
  //   'Haryana': 'haryana',
  //   'Chandigarh': 'chandigarh',
  //   'Himachal Pradesh': 'himachal pradesh',
  //   'Meghalaya': 'meghalaya',
  //   'Telangana': 'telangana',
  //   'Mizoram': 'mizoram',
  //   'Tripura': 'tripura',
  //   'Manipur': 'manipur',
  //   'Arunanchal Pradesh': 'arunanchal pradesh',
  //   'Jharkhand': 'jharkhand',
  //   'Goa': 'goa',
  //   'Sikkim': 'sikkim'
  // }

  //data: any[]
  xyz: any = "hello";
  AlarmSummaryData: any = [];
  temp: any[]
  dataList: any = []
  demandTotal: any = {}
  demandSeries: any = [];
  circleList: any = [];
  jsondata: JSON;
  nodetypeAlarmTemplate: string;
  NodeType: string;
  AlarmName: string;
  AlarmCategory: string;
  AddAlarmModal: boolean = false;
  deleteModal: boolean = false;
  editModal: boolean = false;
  afterdeleteModal: any;
  isSuccess: boolean = false;
  matTabIndex;
  dataList1: any = [];
  zoneType: any;
  slider: boolean = false;
  nodeList = new FormGroup({
    selected: new FormControl([])
  });
  selectZone = new FormControl();
  zoneList = ['Pan India', 'North Zone', 'South Zone', 'East Zone', 'West Zone']
  nodes: { 'name': string; 'value': string; }[];
  showAlarmGraph: boolean;
  //carousal settings
  arrowIndex: number = 0;
  colorJsonData: any;
  blackJSonData: any;
  totalNodesData: any;
  tableDataIndex: any = [];
  stateName: String;
  arrayList: any = [];
  index;
  blackArray: any = [];
  colorArray: any = [];
  selectedIndex: any;
  panData: any = [];
  totalPanIndia: any = [];
  totalNodes: any = [];
  zoneData: any = [];
  dataJson: any = {};
  outputArray1: any;
  grandTotal: any = {};
  status: any;
  validatedFileName: any = '';
  validatedFile: any;
  read: boolean;
  write: boolean;
  userDelete: boolean;
  dates: any;
  datesTotal: any = {};
  demandDates: any = {};
  criticalDates: any = {};
  isZoneSelected: boolean = false;
  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private alarmService: AlarmAnalysisService,
    private ngxService: SpinnerService,
    private accessService: AccessService) { }

  ngOnInit() {
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Alarm Analysis Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Alarm Analysis Module', 'W');
    this.userDelete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Alarm Analysis Module', 'D');
    console.log('read :', this.read);
    console.log('this.write :', this.write);
    console.log('this.userDelete :', this.userDelete);
    // this.transformDataOfDUT();
    this.transformAlarmSummary();
    this.nodes = [
      { 'name': 'Pan India', 'value': 'panIndia' },
      { 'name': 'South Zone', 'value': 'southZone' },
      { 'name': 'North Zone', 'value': 'northZone' },
      { 'name': 'East Zone', 'value': 'eastZone' },
      { 'name': 'West Zone', 'value': 'westZone' }
    ];
  }

  // afterResponseAlarmSummary(): void {
  //   //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
  //   //Add 'implements AfterViewInit' to the class.
  //   // let data = this.outputArray1;
  //   // Highcharts.mapChart('container-indian-map', {
  //   //   chart: {
  //   //     map: 'countries/in/custom/in-all-disputed',
  //   //     borderWidth: 1,
  //   //     backgroundColor: '#FAFAFA',
  //   //     borderColor: '#e5e5e5'
  //   //   },
  //   //   title: {
  //   //     text: undefined
  //   //   },
  //   //   mapNavigation: {
  //   //     enabled: true,
  //   //     buttonOptions: {
  //   //       verticalAlign: 'bottom'
  //   //     }
  //   //   },
  //   //   legend: {
  //   //     enabled: true,
  //   //     title: {
  //   //       text: 'Colour Gradient',
  //   //       style: {
  //   //         color: 'white',
  //   //         fontSize: '8px'
  //   //       }
  //   //     }
  //   //   },
  //   //   colorAxis: {
  //   //     minColor: '#ffcba0',
  //   //     maxColor: '#f96807'
  //   //   },
  //   //   credits: {
  //   //     enabled: false
  //   //   },
  //   //   series: [{
  //   //     data: this.outputArray1,
  //   //     name: 'Map',
  //   //     enableMouseTracking: true,
  //   //     states: {
  //   //       hover: {
  //   //         color: '#FAFAFA'
  //   //       }
  //   //     },
  //   //     dataLabels: {
  //   //       enabled: true,
  //   //       format: '{point.name}',
  //   //       style: {
  //   //         fontSize: "8px"
  //   //       }
  //   //     }
  //   //   }]
  //   // }
  //   );

  //   console.log('element existed:', document.getElementById('container-table'));
  // }

  tabChanged(index) {
    this.selectedIndex = index;
    console.log('index :', index);
    if (index === 0) {
      this.transformAlarmSummary();
    }
    if (index === 3) {

      this.demandTranform();

    }
    if (index === 1) {

    }

    if (index === 2) {
      this.alarmService.getCriticalAlarmModal().subscribe(
        response => {
          console.log('response :', response);
          this.dataList1 = response['data'];
          this.grandTotal = response['Grand Total'];
          this.criticalDates = response['dates'];
        }
      )
    }
    if (index === 4) {
      this.getDataForAlarmTemplate();
    }
  }

  getDataForAlarmTemplate() {
    this.alarmService.getModal().subscribe(
      Response => {
        console.log('Response :', Response);
        this.arrayList = Response;
      }
    )
  }

  //alarm trends

  // alarmTrendCharts() {
  //   this.arrowIndex = 0;
  //   setTimeout(() => {
  //     this.updateDataForCarousal();
  //   }, 1000)
  // }

  onSelectChangeAlarmTrends() {
    console.log('this.zoneType :', this.zoneType);
    this.showAlarmGraph = false;
  }

  onSubmitAlarmTrends() {
    this.colorArray = [];
    this.blackArray = [];
    this.zoneData = [];
    this.totalNodes = [];
    this.panData = [];
    this.totalPanIndia = [];
    this.showAlarmGraph = true;
    this.arrowIndex = 0;
    this.dates = [];
    this.datesTotal = [];
    this.demandDates = [];
    if (this.zoneType['value'] === 'panIndia') {
      this.slider = false;

      this.panIndiaResponse();
    }
    else {
      this.slider = true;
      // this.zoneResponse();
      this.zoneResponse();
    }
    console.log('this.slider :', this.slider);
    //this.alarmTrendCharts();
    this.isZoneSelected = false;
  }


  transformAlarmSummary() {
    //  this.spinner.start();
    this.ngxService.start();
    this.outputArray1 = [];
    this.alarmService.alarmSummary().subscribe(
      Response => {
        //  this.spinner.stop();
        this.ngxService.stop();
        this.circleList = Response;
        console.log('this.circleList :', this.circleList);
        this.circleList.forEach(element => {
          let temp = [];
          // temp.push(this.stateMapping[element['Circle']]);
          temp.push(parseInt((element['value']['Total Alarms']), 10));
          this.outputArray1.push(temp);
        });
        //this.afterResponseAlarmSummary();
        console.log('outputArray:', this.outputArray1);
      }
    );
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onNextArrow() {
    this.arrowIndex += 1;
    this.updateDataForCarousal();
  }

  onBackArrow() {
    this.arrowIndex -= 1;
    this.updateDataForCarousal();
  }


  //panIndiaTransform

  panIndiaResponse() {
    this.ngxService.start();
    this.alarmService.getAlarmTrend(this.zoneType['name']).subscribe(
      response => {
        this.panData = response;
        if (response) {
          this.alarmService.getAlarmTrendOfAffectedNodes(this.zoneType['name']).subscribe(
            BlackResp => {
              this.ngxService.stop();
              this.totalPanIndia = BlackResp;
              setTimeout(() => {
                this.updateDataForCarousal();
              }, 1000);

            }
          );
        }
      }
    );
  }

  getTrendsOfAffectedNodes() {
    //let 
    // console.log("..................", this.panData);

    this.tableDataIndex = this.panData['data'];
    this.dates = this.panData['dates'];
    this.totalNodesData = this.totalPanIndia['data'][0];
    this.datesTotal = this.totalPanIndia['dates'];

    //-----------//

    let totalNodesArray = [];
    totalNodesArray.push(parseInt((this.totalNodesData['Week1']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week2']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week3']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week4']), 10));

    this.blackArray = totalNodesArray;

    //----------------------//

    let json = {};
    this.colorArray = [];
    for (let i = 0; i < (this.tableDataIndex).length; i++) {
      let tempArray = [];

      tempArray.push(parseInt((this.tableDataIndex[i]['Week1']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week2']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week3']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week4']), 10));
      json[this.tableDataIndex[i]['name']] = tempArray;
    }
    this.colorArray.push(json);
  }

  // zone transformation

  zoneResponse() {
    console.log("zone Response function called...");
    this.ngxService.start();
    this.alarmService.getAlarmTrendOfZone(this.zoneType['name']).subscribe(
      response => {
        this.zoneData = response;
        console.log("zone response | ", this.zoneData);
        if (response) {
          console.log("reached in second zone fucntion...")
          this.alarmService.getAlarmTrendOfAffectedNodesZone(this.zoneType['name']).subscribe(
            BlackResp => {
              this.ngxService.stop();
              this.totalNodes = BlackResp;
              setTimeout(() => {
                this.updateDataForCarousal();
              }, 1000);
            }
          );
        }
      }
    );
  }

  transformAlarmTrend() {
    // Total nodes

    this.totalNodesData = this.totalNodes['data'][this.arrowIndex];
    this.tableDataIndex = this.zoneData['zoneData'][this.arrowIndex]['data'];
    this.stateName = this.zoneData['zoneData'][this.arrowIndex]['Circle'];
    this.dates = this.zoneData['dates'];
    this.datesTotal = this.totalNodes['dates'];
    console.log(this.totalNodesData);
    let totalNodesArray = [];

    totalNodesArray.push(parseInt((this.totalNodesData['Week1']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week2']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week3']), 10));
    totalNodesArray.push(parseInt((this.totalNodesData['Week4']), 10));


    this.blackArray = totalNodesArray;
    //-------------//
    //console.log("arrowIndex" + this.arrowIndex);
    this.tableDataIndex = this.zoneData['zoneData'][this.arrowIndex]['data'];
    let json = {};
    //this.colorArray = [];
    for (let i = 0; i < (this.tableDataIndex).length; i++) {
      let tempArray = [];
      console.log('arrowIndex :', this.arrowIndex);
      tempArray.push(parseInt((this.tableDataIndex[i]['Week1']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week2']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week3']), 10));
      tempArray.push(parseInt((this.tableDataIndex[i]['Week4']), 10));
      json[this.tableDataIndex[i]['name']] = tempArray;

    }
    this.colorArray.push(json);
    console.log('this.colorArray in Zones :', this.colorArray);
  }

  // Demand Unavailability Transformation
  demandTranform() {
    this.ngxService.start();
    this.alarmService.demandUnavailability().subscribe(
      Response => {
        this.ngxService.stop();
        console.log(" Demand Details Response " + Response);
        this.dataJson = Response;
        this.demandSeries = [];
        this.demandDates = [];
        this.dataList = this.dataJson['data'];
        this.demandTotal = this.dataJson['total'];
        this.demandDates = this.dataJson['dates'];
        for (let i = 0; i < this.dataList.length; i++) {
          let tempArray = [];
          let tempJson = [];
          tempJson['name'] = this.dataList[i]['demandType'] + "( " + this.dataList[i]['rate'] + " )";
          tempJson['stack'] = this.dataList[i]['rate'];

          tempArray.push(parseInt((this.dataList[i]['alarmCount-Week1']), 10));
          tempArray.push(parseInt((this.dataList[i]['alarmCount-Week2']), 10));
          tempArray.push(parseInt((this.dataList[i]['alarmCount-Week3']), 10));
          tempArray.push(parseInt((this.dataList[i]['alarmCount-Week4']), 10));
          tempJson['data'] = tempArray;
          this.demandSeries.push(tempJson);
          this.demandUnavailabilityChart();
        }
      }
    );
  }


  demandUnavailabilityChart() {
    Highcharts.chart('container-table', {
      chart: {
        type: 'column',
      },
      title: {
        text: undefined
      },
      xAxis: {
        categories: ['Week 1', 'Week 2', 'Week 3', 'Week 4']
      },
      yAxis: {
        min: 0,
        title: {
          text: undefined
        },
        labels: {
          left: 'a'
        },
        minRange: undefined,
        minorTickInterval: null

      },
      legend: {
        reversed: true
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        formatter: function () {
          return '<b>' + 'Rate: ' + this.series.options.stack + '</b><br/>' +
            'Demand Type : ' + this.series.name + '<br/>' + 'Value : ' + this.y + '<br/>' +
            'Total: ' + this.point.stackTotal;
        }
      },
      // colors: ['lightgreen', 'skyblue', 'red', '#f2bb66', 'lightgreen', 'skyblue', 'red', '#f2bb66'],
      colors: ['lightgreen', 'lightgreen', '#f2bb66', '#f2bb66', 'red', 'red', 'skyblue', 'skyblue',],


      plotOptions: {
        series: {
          stacking: 'normal',
          pointWidth: 20
        }
      },
      series: this.demandSeries
    });

  }

  updateDataForCarousal() {
    if (this.zoneType['value'] === 'panIndia') {
      console.log('this.blackArray :', this.blackArray);
      this.getTrendsOfAffectedNodes();
      this.stateName = "Pan India";
    }
    else {
      console.log('this.blackArray :', this.blackArray);
      this.transformAlarmTrend();
    }

    Highcharts.chart('container-pan-india-two', {
      chart: {
        type: 'column',
      },
      title: {
        text: undefined
      },
      xAxis: {
        categories: ['Week 1', 'Week 2', 'Week 3', 'Week 4']
      },
      yAxis: {
        min: 0,
        title: {
          text: undefined
        },
        labels: {
          left: 'a'
        },
        minRange: undefined,
        minorTickInterval: null

      },
      legend: {
        reversed: true
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        formatter: function () {
          return 'Value : ' + this.y + '<br/>';
        }
      },
      // colors: ['lightgreen', 'skyblue', 'red', '#f2bb66', 'lightgreen', 'skyblue', 'red', '#f2bb66'],
      colors: ['grey'],
      plotOptions: {
        series: {
          stacking: 'normal',
          pointWidth: 15,
          // groupPadding: 20
        }
      },
      series: [{
        name: 'Total Nodes',
        data: this.blackArray
      }]
    });

    Highcharts.chart('container-pan-india', {
      chart: {
        type: 'column',
      },
      title: {
        text: undefined
      },
      xAxis: {
        categories: ['Week 1', 'Week 2', 'Week 3', 'Week 4']
      },
      yAxis: {
        min: 0,
        title: {
          text: undefined
        },
        labels: {
          left: 'a'
        },
        minRange: undefined,
        minorTickInterval: null
      },
      legend: {
        reversed: true
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        formatter: function () {
          return 'Alarm: ' + this.series.name + '<br/>' + 'Value : ' + this.y + '<br/>' +
            'Total: ' + this.point.stackTotal;
        }
      },
      // colors: ['lightgreen', 'skyblue', 'red', '#f2bb66', 'lightgreen', 'skyblue', 'red', '#f2bb66'],
      colors: ['skyblue', 'red', 'yellow'],
      plotOptions: {
        series: {
          stacking: 'normal',
          pointWidth: 15,
          stack: 'Week 1'
          // groupPadding: 20
        }
      },
      series: [{
        name: 'Minor',
        data: this.colorArray[this.arrowIndex]['Minor'],
        stack: 'Week 1'
      },
      {
        name: 'Critical',
        data: this.colorArray[this.arrowIndex]['Critical'],
        stack: 'Week 1'
      },
      {
        name: 'Major',
        data: this.colorArray[this.arrowIndex]['Major'],
        stack: 'Week 1'
      }]
    });
  }

  downloadDemand() {
    this.ngxService.start();
    this.alarmService.getDemandDump().
      subscribe(res => {
        this.ngxService.stop();
        console.log(res);
        this.downloadFile(res);
      });
  }

  // downloadFileDemandUnavailability(response) {
  //   var linkElement = document.createElement('a');
  //   var byteArray = new Uint8Array(response['fileData']);
  //   linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
  //   // linkElement.target = '_blank';
  //   linkElement.download = response['filename'];
  //   console.log(response);
  //   document.body.appendChild(linkElement);
  //   linkElement.click();
  // }

  downloadAlarmSummary() {
    this.ngxService.start();
    this.alarmService.getAlarmsDump().
      subscribe(res => {
        this.ngxService.stop();
        console.log(res)
        this.downloadFile(res);
      });
  }


  //----------************-------------Nageshwar---------*************---------------------//

  onEdit(jsondata, i) {
    this.index = i;
    this.NodeType = jsondata['Node Type'];
    this.AlarmName = jsondata['Alarm Name'];
    this.AlarmCategory = jsondata['Alarm Category']
  }

  onDeleteModal(jsondata, i) {
    this.index = i;
    this.NodeType = jsondata['Node Type'];
    this.AlarmName = jsondata['Alarm Name'];
    this.AlarmCategory = jsondata['Alarm Category'];

    // $('#afterdeleteModal').modal('show');
    //this.afterdeleteModal = true;
  }
  onEditdata() {
    // this.arrayList[this.index]['nodetypeAlarmTemplate'] = this.NodeType;
    // this.arrayList[this.index]['alarmName'] = this.AlarmName;
    // this.arrayList[this.index]['alarmCategory'] = this.AlarmCategory;

    // let headers = new HttpHeaders().append('Alarm Name', this.AlarmName).append('Node Type', this.NodeType).append('Alarm Category', this.AlarmCategory);
    let editJson = {
      "Node Type": this.NodeType,
      "Alarm Name": this.AlarmName,
      "Alarm Category": this.AlarmCategory
    };
    this.ngxService.start();

    this.alarmService.editModal(editJson).subscribe(
      Response => {
        this.ngxService.stop();
        this.afterdeleteModal = true;
        this.status = Response['status'];
        if (Response['status_code'] == 200) {
          this.isSuccess = true;
          this.getDataForAlarmTemplate();

          // $('#afterdeleteModal').modal('show');
        }
        else if (Response['status_code'] == 410) {
          this.isSuccess = false;
        }
        console.log('Response :', Response);

      }
    )

  }
  onDelete() {
    let headers = new HttpHeaders().append('Alarm-Name', this.AlarmName)
      .append('Node-Type', this.NodeType)
      .append('Alarm-Category', this.AlarmCategory);
    this.ngxService.start();
    this.alarmService.deleteModal(headers).subscribe(
      Response => {
        this.ngxService.stop();
        this.afterdeleteModal = true;
        this.status = Response['status'];
        if (Response['status_code'] == 200) {
          this.isSuccess = true;
          this.getDataForAlarmTemplate();
          //  $('#afterdeleteModal').modal('show');
        }
        else if (Response['status_code'] == 410) {
          this.isSuccess = false;
        }
        console.log('Response :', Response);

      }
    )
    // this.arrayList.splice(this.index, 1);
  }

  onAdddata() {
    let json = {
      "Node Type": this.addAlarmForm.value.NodeType,
      "Alarm Name": this.addAlarmForm.value.alarmName,
      "Alarm Category": this.addAlarmForm.value.alarmCategory
    };
    let headers = new HttpHeaders().append('Alarm Name', this.addAlarmForm.value.alarmName).append('Node Type', this.addAlarmForm.value.NodeType).append('Alarm Category', this.addAlarmForm.value.alarmCategory)
    this.ngxService.start();
    this.alarmService.addAlarmModal(json).subscribe(
      Response => {
        this.ngxService.stop();
        this.afterdeleteModal = true;
        this.status = Response['status'];
        this.getDataForAlarmTemplate();
        if (Response['status_code'] == 200) {
          this.isSuccess = true;
          this.getDataForAlarmTemplate();
        }

        console.log('response :', Response);
      }
    )
    // this.arrayList.push(json);

  }


  downLoadTemplate() {
    this.ngxService.start();
    this.alarmService.downLoadTemplate().
      subscribe(res => {
        this.ngxService.stop();
        console.log(res)
        this.downloadFile(res);
      });

  }
  alarmDownloadTemplate() {
    this.ngxService.start();
    this.alarmService.alarmDownloadTemplate().
      subscribe(res => {
        this.ngxService.stop();
        console.log(res)
        this.downloadFile(res);
      });

  }

  downloadFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response['fileData']);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    // linkElement.target = '_blank';
    linkElement.download = response['filename'];
    console.log(response);
    document.body.appendChild(linkElement);
    linkElement.click();
  }


  onUploadFile(event) {
    let file: File = event.target.files[0];
    let fileName = file.name;
    console.log(fileName);
    this.ngxService.start();

    this.alarmService.uploadTemplate(file).subscribe(
      (data) => {
        this.ngxService.stop();
        this.afterdeleteModal = true;
        this.status = data['status'];
        if (data['status_code'] == 200) {
          this.isSuccess = true;
          this.getDataForAlarmTemplate();

        }
        console.log(data);
      }
    );
  }

  ngOnDestroy() {
    this.ngxService.stop();
  }
  onCheck(name) {
    if (name == 'total-alarms') {
      return 'Total Alarms';
    }
    else {
      return name;
    }
  }
  zoneSelection() {
    this.isZoneSelected = true;
  }

}



















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































