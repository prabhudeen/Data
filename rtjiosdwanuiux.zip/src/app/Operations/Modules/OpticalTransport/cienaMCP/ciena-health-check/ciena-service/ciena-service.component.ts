import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { OpticalTransportModule } from '../../../opticalTransport.module';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CienaHealthService } from '../ciena-health.service';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';

@Component({
  selector: 'app-ciena-service',
  templateUrl: './ciena-service.component.html',
  styleUrls: ['./ciena-service.component.css']
})
export class CienaServiceComponent implements OnInit {

  @ViewChild('cienaServiceForm') cienaServiceForm: NgForm;
  matTabIndex: number = 0;
  healthCheckType: any = [];
  serviceType: any;
  length: number = 0;
  pageSize: number;
  pageSizeOptions = [5, 10, 15, 20, 30, 50, 100];
  offset: number;
  selectedGUILabel: string = '';
  deleteGCTModal: boolean = false;
  nodeDetail: any = [];
  parameterHCList: any = [];
  healthReportList: any = [];
  healthReportListTemp: any = [];
  tickEnable: boolean = false;
  cienaServiceModal: boolean = false;
  displaySuccess;
  read: boolean;
  write: boolean;
  delete: boolean;

  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private healthService: CienaHealthService,
    private accessService: AccessService) { }

  ngOnInit() {
    this.healthCheckType = ['Service Uptime'];
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'D');
    this.pageSize = 5;
    console.log('this.write :', this.write);
    if (this.write) {
      this.matTabIndex = 0;
    }
    else {
      this.matTabIndex = 1;
      this.getHCReport();
    }
  }


  serviceHC() {
    console.log('this.serviceType :', this.serviceType);
    let json = {
      'type': this.serviceType
    };
    this.healthService.healthServiceAssesment(json).subscribe(
      response => {
        console.log('response :', response);
        this.cienaServiceModal = true;
        if (response['status_code'] == 200) {
          this.tickEnable = true;
          this.displaySuccess = response['status'];
        }
        else {
          this.tickEnable = false;
          this.displaySuccess = response['status'];
        }
      }
    )
  }

  getHCReport() {
    let headers = new HttpHeaders()
      .append('Type', 'Service');
    //  this.ngxService.start();
    this.healthService.getHCReportList(headers)
      .subscribe(response => {
        // this.ngxService.stop();
        if (response['status_Code'] == 200) {
          this.healthReportList = response['Ne-Ids'];
          this.healthReportListTemp = this.healthReportList;
          this.healthReportList = this.healthReportList.map(data => {
            let time = data.filename.substring(data.filename.lastIndexOf('_') + 1, data.filename.indexOf('.'));
            return {
              time: new Date(time),
              value: data.filename,
              username: data.username
            };
          })
          this.healthReportList.sort((a, b) => {
            return b.time - a.time;
          })
          console.log(this.healthReportList);
          if (this.healthReportList.length > 0) {
            // this.gctDetailsFlag = false;
            this.length = this.healthReportList.length;
            if (this.healthReportList.length > this.pageSize)
              this.healthReportListTemp = this.healthReportList.slice(0, this.pageSize);
            else
              this.healthReportListTemp = this.healthReportList;
          }
          // else this.gctDetailsFlag = true;
        }
        // else this.gctDetailsFlag = true;
      });
  }


  onDownload(label) {
    let headers = new HttpHeaders()
      .append('Type', 'Service').
      append('Ne-Id', label)
    this.healthService.downloadTemplate(headers).subscribe(res => {
      // console.log(res)
      this.downloadFile(res);
    });
  }

  downloadFile(data) {
    if (data['status_code'] == 200) {
      var linkElement = document.createElement('a');
      var byteArray = new Uint8Array(data['fileData']);
      linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      linkElement.download = data['fileName'];
      document.body.appendChild(linkElement);
      linkElement.click();
    }
  }

  beforeDelete(label, index) {
    this.selectedGUILabel = label;
    // this.selectedIndex = index;
    // $('#deleteGCTModal').modal('show');
    this.deleteGCTModal = true;

  }

  onDeleteHCReport() {
    let headers = new HttpHeaders()
      .append('Ne-Id', this.selectedGUILabel)
      .append('Type', 'Service');
    this.healthService.deleteTemplate(headers).subscribe(res => {
      // this.ngxService.stop();
      console.log("delete", res);
      this.displaySuccess = res['status'];
      if (res['status_code'] == 200) {
        this.cienaServiceModal = true;
        this.tickEnable = true;
      }
      else {
        this.tickEnable = false;
      }
      this.cienaServiceModal = true;
      // $('#afterdeleteGCTModal').modal('show');
      // this.afterdeleteGCTModal=true;
      setTimeout(() => this.getHCReport(), 500);

    });

  }

  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.healthReportListTemp = this.healthReportList.slice(firstCut, secondCut);
  }


  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onTabChanged(event) {
    this.matTabIndex = event.index;
    console.log('matTabIndex >> ', this.matTabIndex);
    if (this.matTabIndex == 0) {
      //   this.getNodeDetail();
    }
    if (this.matTabIndex == 1) {
      this.getHCReport();
    }
  }

}
