import { Injectable } from '@angular/core';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class CienaHealthService {
    constructor(private commonService: SdWanServiceService) { }

    multiNodeHC(request: any): Observable<any> {

        //  let headers = new HttpHeaders().append('Event-Key', request);

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', request, null, null, EventConstants.CIENA_MULTINODE_HEALTHCHECK).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });

    }


    parameterNodeHC(request: any): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', request, null, null, EventConstants.CIENA_BULK_HEALTHCHECK).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    getHCReportList(headers) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.GET_HC_REPORT_REQUEST).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);

                }
            );
        });
    }

    downloadTemplate(headers) {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.DOWNLOAD_HC_REPORT).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    deleteTemplate(headers) {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('DELETE', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.DELETE_HC_REPORT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));

                    observe.next(response);

                }
            );
        });
    }

    healthTemplateGet(headers) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.CIENA_GET_HC_TEMPLATE).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    healthServiceAssesment(json) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', json, null, null, EventConstants.CIENA_SERVICE_HC_ASSESMENT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }
    NMAPAssesment() {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', null, null, null, EventConstants.CIENA_SERVICE_NMAP_ASSESMENT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    modifyHCTemplate(json, header) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', json, header, null, EventConstants.CIENA_MODIFY_HC_TEMPLATE).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

}