import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { CienaHealthService } from '../ciena-health.service';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';
import { SessionService } from '../../../../../../SharedFolder/services/sessionService.service';

@Component({
  selector: 'app-ciena-health-template',
  templateUrl: './ciena-health-template.component.html',
  styleUrls: ['./ciena-health-template.component.css']
})
export class CienaHealthTemplateComponent implements OnInit {

  @ViewChild('templateHCForm') templateHCForm: NgForm;
  nodes: any = [];
  nodeValue;
  showAddButton: boolean = false;
  nodeType: any;
  templateList: any = [];
  modifiedTempList: any = [];
  dataJSON;
  actionType;
  arrayI;
  arrayJ;
  innerDeleteParam: any;
  finalList: any;
  cienaNodeModal: boolean = false;
  displaySuccess: any;
  tickEnable: boolean = false;
  showGetButton: boolean = true;
  deleteGCTModal: boolean = false;
  addHCTemplate: boolean = false;
  read: boolean;
  write: boolean;
  delete: boolean;
  roleName: string;
  userName: string;

  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private healthService: CienaHealthService,
    private accessService: AccessService,
    private sessionService: SessionService) { }

  ngOnInit() {
    this.nodes = [{ 'name': 'Node 5430', 'value': '5430' },
    { 'name': 'Node 6500', 'value': '6500' }];

    setTimeout(() => {
      this.roleName = this.sessionService.get('roleName');
      this.userName = this.sessionService.get('userName');
      console.log('this.userName inside timeout :', this.userName);
      if (this.roleName.includes('admin') || this.roleName.includes('TelcoRole')) {
        console.log('this.userName inside if loop :', this.userName);
        // this.roleName = 'TelcoRole';
        this.userName = 'admin';
      }
    }, 2000);
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'D');
    this.resetData();
  }

  resetData() {
    this.dataJSON = {
      "healthCheckParameter": "",
      "apiParameter": "",
      "apiValueExpected": ""
    };
  }

  showGetButtonChange() {
    this.showGetButton = true;
    console.log('this.showGetButton :', this.showGetButton);
  }

  templateHC() {
    this.showGetButton = false;
    console.log('this.nodeType :', this.nodeType);
    this.showAddButton = true;
    this.nodeValue = this.nodeType['value'];
    console.log('nodeValue :', this.nodeValue);
    let headers = new HttpHeaders().append('Type', this.nodeValue);
    this.healthService.healthTemplateGet(headers).subscribe(
      response => {
        console.log('response :', response);
        this.templateList = JSON.parse(response['body']);
        console.log('this.templateList :', this.templateList);
        this.modifiedTempList = this.templateList.map(element => {
          let ele = {};
          ele['HC_Type'] = element['HC_Type'];
          let list = [];
          let temp = Object.entries(element);
          let indexOfHCType = temp.findIndex(item => {
            return item[0] === 'HC_Type'
          });
          temp.splice(indexOfHCType, 1);
          temp.forEach(item => {
            let result = {};
            result['name'] = item[0];
            result['value'] = item[1];
            list.push(result);
          });
          ele['list'] = list;
          return ele;
        });

        console.log('this.modifiedTempList :', this.modifiedTempList);
      }
    );

    // this.templateList = [
    //   {
    //     "HC_Type": "NE Software release",
    //     "softwareVersion": [
    //       "4.5.0.0",
    //       "4.4.0.0"
    //     ]
    //   },
    //   {
    //     "HC_Type": "Switch Matrix",
    //     "ProceduralState": [
    //       "PROVIDING_SERVICE",
    //       "HOT_STANDBY"
    //     ]
    //   },
    //   {
    //     "HC_Type": "Power Filter card status",
    //     "ProceduralState": [
    //       "PROVIDING_SERVICE",
    //       "SYNCHRONIZED"
    //     ]
    //   },
    //   {
    //     "HC_Type": "Controller Card Status",
    //     "ProceduralState": [
    //       "PROVIDING_SERVICE",
    //       "SYNCHRONIZED"
    //     ]
    //   },
    //   {
    //     "HC_Type": "NE Management Status",
    //     "state": ["synchronized"]
    //   },
    //   {
    //     "HC_Type": "FAN Module",
    //     "operState": ["Enabled"],
    //     "AlarmStatus": ["NO_ALARM"]
    //   }
    // ];


  }

  action(type, i, j) {
    this.actionType = type;
    this.arrayI = i;
    this.arrayJ = j;

    switch (type) {

      case 'edit':

        this.dataJSON['healthCheckParameter'] = this.modifiedTempList[i]['HC_Type'];
        this.dataJSON['apiParameter'] = this.modifiedTempList[i]['list'][j]['name'];
        this.dataJSON['apiValueExpected'] = this.modifiedTempList[i]['list'][j]['value'];

        break;

      case 'delete':
        this.innerDeleteParam = this.modifiedTempList[i]['list'][j]['name'];
        break;

      case 'add':
        this.dataJSON['healthCheckParameter'] = this.modifiedTempList[i]['HC_Type'];
        this.dataJSON['apiParameter'] = '';
        this.dataJSON['apiValueExpected'] = '';
        break;

      case 'deleteWhole':
        this.innerDeleteParam = this.modifiedTempList[i]['HC_Type'];
        break;

      case 'addNew':
        this.resetData();
        break;
    }

  }

  submitAction() {

    switch (this.actionType) {

      case 'edit':

        this.modifiedTempList[this.arrayI]['list'][this.arrayJ]['name'] = this.dataJSON['apiParameter'];
        this.modifiedTempList[this.arrayI]['list'][this.arrayJ]['value'] = this.dataJSON['apiValueExpected'];
        this.modifyHCTemplate();
        //this.templateHC();
        break;

      case 'delete':
        this.modifiedTempList[this.arrayI]['list'].splice(this.arrayJ, 1);
        if (this.modifiedTempList[this.arrayI]['list'].length === 0) {
          this.modifiedTempList.splice(this.arrayI, 1);
        }
        this.modifyHCTemplate();
        // this.templateHC();
        break;

      case 'add':

        let json = {
          "name": this.dataJSON['apiParameter'],
          "value": this.dataJSON['apiValueExpected']
        };
        this.modifiedTempList[this.arrayI]['list'].push(json);
        this.modifyHCTemplate();
        // this.templateHC();
        break;

      case 'deleteWhole':
        this.modifiedTempList.splice(this.arrayI, 1);
        this.modifyHCTemplate();
        // this.templateHC();
        break;

      case 'addNew':
        this.modifiedTempList.push({
          "HC_Type": this.dataJSON['healthCheckParameter'],
          "list": [
            {
              "name": this.dataJSON['apiParameter'],
              "value": this.dataJSON['apiValueExpected']
            }
          ]
        });
        this.modifyHCTemplate();
        // this.templateHC();
        break;
    }
  }


  modifyHCTemplate() {
    this.finalList = this.modifiedTempList.map(element => {
      let json = {};
      json['HC_Type'] = element['HC_Type'];
      element['list'].forEach(subElement => {
        if (typeof subElement['value'] === 'string') {
          json[subElement['name']] = subElement['value'].split(',');
        } else {
          json[subElement['name']] = subElement['value'];
        }
      });
      return json;
    });
    console.log('this.finalList :', this.finalList);
    let headers = new HttpHeaders()
      .append('Type', this.nodeValue);
    this.healthService.modifyHCTemplate(this.finalList, headers).subscribe(
      response => {
        console.log('response :', response);
        this.cienaNodeModal = true;
        this.displaySuccess = response['status'];
        this.tickEnable = response['status_code'] === 200;
      }
    )
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

}
