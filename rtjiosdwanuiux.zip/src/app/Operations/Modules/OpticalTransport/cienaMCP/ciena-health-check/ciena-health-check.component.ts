import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';

@Component({
  selector: 'app-ciena-health-check',
  templateUrl: './ciena-health-check.component.html',
  styleUrls: ['./ciena-health-check.component.css']
})
export class CienaHealthCheckComponent implements OnInit {
  list: any[] = [
    {
      title: "Node",
      value: "CienaMCP Node Module",
      access: false,
    },
    {
      title: "Service",
      value: "CienaMCP Service Module",
      access: false,
    },
    {
      title: "NMAP",
      value: "CienaMCP NMAP Module",
      access: false,
    },
    {
      title: "Health Check Template",
      value: "CienaMCP Health Check Module",
      access: false,
    },
    {
      title: "Health Check Schedule",
      value: "CienaMCP Schedule Module",
      access: false,
    }
  ]


  constructor(private router: Router,
    private route: ActivatedRoute,
    private optService: opticalModuleAPIService,
    private accessService: AccessService) { }

  ngOnInit() {
    let readAccess = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');

    if (readAccess) {
      this.list[0]['access'] = true;
      this.list[1]['access'] = true;
      this.list[2]['access'] = true;
      this.list[3]['access'] = true;
      this.list[4]['access'] = true;
    }

  }

  onClick(action) {
    switch (action) {
      case "CienaMCP Node Module":
        this.router.navigate(['node'], { relativeTo: this.route });
        break;
      case "CienaMCP Service Module":
        this.router.navigate(['service'], { relativeTo: this.route });
        break;
      case "CienaMCP NMAP Module":
        this.router.navigate(['nmap'], { relativeTo: this.route });
        break;
      case "CienaMCP Health Check Module":
        this.router.navigate(['healthCheckTemplate'], { relativeTo: this.route });
        break;
      case "CienaMCP Schedule Module":
        this.router.navigate(['schedule'], { relativeTo: this.route });
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

}
