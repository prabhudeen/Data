import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { CienaHealthService } from '../ciena-health.service';
import { SpinnerService } from '../../../../../../SharedFolder/services/SpinnerService.service';
import { CienaService } from '../../ciena.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';

@Component({
  selector: 'app-ciena-node',
  templateUrl: './ciena-node.component.html',
  styleUrls: ['./ciena-node.component.css']
})
export class CienaNodeComponent implements OnInit {

  @ViewChild('cienaNodeForm') cienaNodeForm: NgForm;
  @ViewChild('parameterHCRequest') parameterHCRequest: NgForm;
  matTabIndex: number = 0;
  length: number = 0;
  pageSize: number;
  pageSizeOptions = [5, 10, 15, 20, 30, 50, 100];
  offset: number;
  selectedGUILabel: string = '';
  deleteGCTModal: boolean = false;
  nodeDetail: any = [];
  parameterHCList: any = [];
  healthReportList: any = [];
  healthReporstListTemp: any = [];
  tickEnable: boolean = false;
  cienaNodeModal: boolean = false;
  displaySuccess;
  nodeList = new FormGroup({
    selected: new FormControl([])
  });

  nodeParameterList = new FormGroup({
    selected: new FormControl([])
  });
  read: boolean;
  write: boolean;
  delete: boolean;

  constructor(private optService: opticalModuleAPIService,
    private healthService: CienaHealthService,
    private ngxService: SpinnerService,
    private cienaService: CienaService,
    private accessService: AccessService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.pageSize = 5;
    //this.getNodeDetail();
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'D');
    this.getParameterDetail();
    if (this.write) {
      this.matTabIndex = 0;
    } else {
      this.matTabIndex = 2;
      this.getHCReport();
    }

  }

  getNodeDetail() {
    console.log("inside fn");
    this.cienaService.getAendZend()
      .subscribe(res => {
        console.log('res :>> ', res);
        if (res['status_code'] == 410) {
          this.displaySuccess = res['status'];
          this.tickEnable = false;
          this.cienaNodeModal = true;
        } else {
          this.nodeDetail = [];
          console.log('response is :', res);
          console.log(this.nodeDetail);
          res['data'].forEach(element => {
            this.nodeDetail.push({
              display: element['name'],
              value: element['name']
            })
          });
        }
      });
  }

  multiNodeHC() {
    let request = {
      "neids": this.nodeList.value['selected']
    }
    // this.ngxService.start();
    console.log('request :', request);
    this.healthService.multiNodeHC(request).
      subscribe(response => {
        //  this.ngxService.stop();
        this.displaySuccess = response['status'];
        this.cienaNodeForm.reset();
        if (response['status_code'] == 200) {
          this.tickEnable = true;
          this.cienaNodeModal = true;
          this.nodeList.controls['selected'].setValue([]);
        } else {
          this.tickEnable = false;
          this.cienaNodeModal = true;
          this.nodeList.controls['selected'].setValue([]);
        }
      });
    // this.cienaNodeForm.resetForm();
  }

  getParameterDetail() {
    // this.ngxService.start();
    console.log("inside fn");
    let res = '[{"name": "NE Software release"},{"name": "NE Management Status"},{"name": "Alarm summary"},{"name": "Controller Card Status"},{"name": "FAN Module"},{"name": "Power Filter card status"},{"name": "Switch Matrix"},{"name": "NE Uptime"},{"name": "NTP synchronization status"}]';
    console.log("parsed response is:", JSON.parse(res));

    JSON.parse(res).forEach(element => {
      this.parameterHCList.push({
        display: element['name'],
        value: element['name']
      });
      console.log('this.parameterHCList after adding is:', this.parameterHCList);
    });
  }

  parameterNodeHC() {
    console.log("inside 2nd function");

    let request = {
      "type": this.nodeParameterList.value['selected']
    }
    // this.ngxService.start();
    console.log('request :', request);
    this.healthService.parameterNodeHC(request).
      subscribe(response => {
        //  this.ngxService.stop();
        this.displaySuccess = response['status'];
        if (response['status_code'] == 200) {
          this.tickEnable = true;
          this.cienaNodeModal = true;
          this.parameterHCRequest.reset();
          this.nodeParameterList.controls['selected'].setValue([]);
        } else {
          this.tickEnable = false;
          this.cienaNodeModal = true;
        }
      });

  }

  getHCReport() {
    let headers = new HttpHeaders()
      .append('Type', 'Nodes');
    //  this.ngxService.start();
    this.healthService.getHCReportList(headers)
      .subscribe(response => {
        // this.ngxService.stop();
        if (response['status_Code'] == 200) {
          this.healthReportList = response['Ne-Ids'];
          this.healthReporstListTemp = this.healthReportList;
          this.healthReportList = this.healthReportList.map(data => {
            let time = data.filename.substring(data.filename.lastIndexOf('_') + 1, data.filename.indexOf('.'));
            return {
              time: new Date(time),
              value: data.filename,
              username: data.username
            };
          })
          this.healthReportList.sort((a, b) => {
            return b.time - a.time;
          })
          console.log(this.healthReportList);
          if (this.healthReportList.length > 0) {
            // this.gctDetailsFlag = false;
            this.length = this.healthReportList.length;
            if (this.healthReportList.length > this.pageSize)
              this.healthReporstListTemp = this.healthReportList.slice(0, this.pageSize);
            else
              this.healthReporstListTemp = this.healthReportList;
          }
          // else this.gctDetailsFlag = true;
        }
        // else this.gctDetailsFlag = true;
      });
  }


  onDownload(label) {
    let headers = new HttpHeaders()
      .append('Type', 'Nodes').
      append('Ne-Id', label)
    this.healthService.downloadTemplate(headers).subscribe(res => {
      // console.log(res)
      this.downloadFile(res);
    });
  }

  downloadFile(data) {
    if (data['status_code'] == 200) {
      var linkElement = document.createElement('a');
      var byteArray = new Uint8Array(data['fileData']);
      linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      linkElement.download = data['fileName'];
      document.body.appendChild(linkElement);
      linkElement.click();
    }
  }

  beforeDelete(label, index) {
    this.selectedGUILabel = label;
    // this.selectedIndex = index;
    // $('#deleteGCTModal').modal('show');
    this.deleteGCTModal = true;

  }

  onDeleteHCReport() {
    let headers = new HttpHeaders()
      .append('Ne-Id', this.selectedGUILabel)
      .append('Type', 'Nodes');
    this.healthService.deleteTemplate(headers).subscribe(res => {
      // this.ngxService.stop();
      console.log("delete", res);
      this.displaySuccess = res['status'];
      if (res['status_code'] == 200) {
        this.cienaNodeModal = true;
        this.tickEnable = true;
      }
      else {
        this.tickEnable = false;
      }
      this.cienaNodeModal = true;
      // $('#afterdeleteGCTModal').modal('show');
      // this.afterdeleteGCTModal=true;
      setTimeout(() => this.getHCReport(), 500);

    });

  }

  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.healthReporstListTemp = this.healthReportList.slice(firstCut, secondCut);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onTabChanged(event) {
    this.matTabIndex = event.index;
    console.log('matTabIndex >> ', this.matTabIndex);
    if (this.matTabIndex == 0) {
      // this.getNodeDetail();
    }
    if (this.matTabIndex == 1) {
      //   this.getHCReport();
    }

    if (this.matTabIndex == 2) {
      this.getHCReport();
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

}
