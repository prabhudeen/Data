import { Component, OnInit, ViewChild } from '@angular/core';
import { opticalModuleAPIService } from '../../../opticalTransportModule_API.service';
import { CienaHealthService } from '../ciena-health.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { OpticalTransportModule } from '../../../opticalTransport.module';

import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../../SharedFolder/services/access.service';

@Component({
  selector: 'app-ciena-nmap',
  templateUrl: './ciena-nmap.component.html',
  styleUrls: ['./ciena-nmap.component.css']
})
export class CienaNmapComponent implements OnInit {

  @ViewChild('cienaServiceForm') cienaServiceForm: NgForm;
  matTabIndex: number = 0;
  healthCheckType: any = [];
  serviceType: any;
  length: number = 0;
  pageSize: number;
  pageSizeOptions = [5, 10, 15, 20, 30, 50, 100];
  offset: number;
  selectedGUILabel: string = '';
  deleteGCTModal: boolean = false;
  nodeDetail: any = [];
  parameterHCList: any = [];
  healthReportList: any = [];
  healthReporstListTemp: any = [];
  tickEnable: boolean = false;
  cienaServiceModal: boolean = false;
  displaySuccess;
  showTable: boolean = false;
  read: boolean;
  write: boolean;
  delete: boolean;

  constructor(private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private healthService: CienaHealthService,
    private accessService: AccessService) { }

  ngOnInit() {
    this.pageSize = 5;
    this.healthCheckType = ['Service Uptime'];
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Health Check Module', 'D');
    this.getHCReport();
  }


  serviceHC() {
    console.log('this.serviceType :', this.serviceType);
    this.healthService.healthServiceAssesment(this.serviceType).subscribe(
      response => {
        console.log('response :', response);
      }
    )
  }
  onNMAP() {

    this.healthService.NMAPAssesment()
      .subscribe(response => {
        // this.ngxService.stop();
        this.cienaServiceModal = true;
        this.displaySuccess = response['status'];
        this.tickEnable = (response['status_code'] == 200) ? true : false;
      });
  }

  getHCReport() {
    this.showTable = true;
    let headers = new HttpHeaders()
      .append('Type', 'Nmap');
    //  this.ngxService.start();
    this.healthService.getHCReportList(headers)
      .subscribe(response => {
        // this.ngxService.stop();
        if (response['status_Code'] == 200) {
          this.healthReportList = response['Ne-Ids'];
          this.healthReporstListTemp = this.healthReportList;
          this.healthReportList = this.healthReportList.map(data => {
            let time = data.filename.substring(data.filename.lastIndexOf('_') + 1, data.filename.indexOf('.'));
            return {
              time: new Date(time),
              value: data.filename,
              username: data.username
            };
          })
          this.healthReportList.sort((a, b) => {
            return b.time - a.time;
          })
          console.log(this.healthReportList);
          if (this.healthReportList.length > 0) {
            // this.gctDetailsFlag = false;
            this.length = this.healthReportList.length;
            if (this.healthReportList.length > this.pageSize)
              this.healthReporstListTemp = this.healthReportList.slice(0, this.pageSize);
            else
              this.healthReporstListTemp = this.healthReportList;
          }
          // else this.gctDetailsFlag = true;
        }
        // else this.gctDetailsFlag = true;
      });
  }


  onDownload(label) {
    let headers = new HttpHeaders()
      .append('Type', 'Nmap').
      append('Ne-Id', label)
    this.healthService.downloadTemplate(headers).subscribe(res => {
      // console.log(res)
      this.downloadFile(res);
    });
  }

  downloadFile(data) {
    if (data['status_code'] == 200) {
      var linkElement = document.createElement('a');
      var byteArray = new Uint8Array(data['fileData']);
      linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      linkElement.download = data['fileName'];
      document.body.appendChild(linkElement);
      linkElement.click();
    }
  }

  beforeDelete(label, index) {
    this.selectedGUILabel = label;
    // this.selectedIndex = index;
    // $('#deleteGCTModal').modal('show');
    this.deleteGCTModal = true;

  }

  onDeleteHCReport() {
    let headers = new HttpHeaders()
      .append('Ne-Id', this.selectedGUILabel)
      .append('Type', 'Nmap');
    this.healthService.deleteTemplate(headers).subscribe(res => {
      // this.ngxService.stop();
      console.log("delete", res);
      this.displaySuccess = res['status'];
      if (res['status_code'] == 200) {
        this.cienaServiceModal = true;
        this.tickEnable = true;
      }
      else {
        this.tickEnable = false;
      }
      setTimeout(() => this.getHCReport(), 500);

    });

  }

  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.healthReporstListTemp = this.healthReportList.slice(firstCut, secondCut);
  }


  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  // onTabChanged(event) {
  //   this.matTabIndex = event.index;
  //   console.log('matTabIndex >> ', this.matTabIndex);
  //   if (this.matTabIndex == 0) {
  //     //   this.getNodeDetail();
  //   }
  //   if (this.matTabIndex == 1) {
  //     this.getHCReport();
  //   }
  // }

}
