import { Injectable } from '@angular/core';
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';

@Injectable({
    providedIn: 'root'
})
export class CienaService {
    constructor(private commonService: SdWanServiceService) {
    }

    getAendZend(): Observable<any> {
        return new Observable<any>(observe => {
            console.log('inside getAendZend');
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, null, null, EventConstants.CIENA_BOD_AEND_ZEND).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log("inside health node module");


                }
            );
        });
    }

    singleProvisioning(requerstJSON, boolean): Observable<any> {
        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            let eventKey;
            if (requerstJSON['circuit_type'] === 'SNCP-MR' && boolean === false) {
                eventKey = EventConstants.CIENA_BOD_PROTECTED;
            }
            else if (requerstJSON['circuit_type'] === 'SNC-MR' && boolean === false) {
                eventKey = EventConstants.CIENA_BOD;
            }
            else if (requerstJSON['circuit_type'] === 'SNC-MR' && boolean === true) {
                eventKey = EventConstants.CIENA_BOD_EXPLICIT;
            }
            else if (requerstJSON['circuit_type'] === 'SNCP-MR' && boolean === true) {
                eventKey = EventConstants.CIENA_BOD_PROTECTED_EXPLICIT;
            }
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', requerstJSON, null, null, eventKey).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log('CIENA BOD Created Successfully...');
                }
            );
        });
    }



    uploadBulkFile(file: File, toggle): Observable<any> {
        return new Observable<any>(observe => {
            console.log('inside bulk Provisioning..');
            let eventKey;
            if (toggle === false) {
                eventKey = EventConstants.CIENA_BULK_BOD;
            }
            else {
                eventKey = EventConstants.CIENA_EXPLICIT_BULK_BOD;
            }
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', file, null, null, eventKey).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                    console.log('File Uploaded Successfully...');
                }
            );
        });
    }

    getServiceDetailsRequest(header: HttpHeaders) {
        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, header, null, EventConstants.CIENA_GET_BOD_DETAILS).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response.body);
                    console.log('File Uploaded Successfully...');
                }
            );
        });
    }

    cienaGCTRequest(neid) {
        // let header = new HttpHeaders({
        //     "Ne-Id" : neid
        // });
        let header = new HttpHeaders();
        header = header.set('Ne-Id', neid);
        console.log(header);

        return new Observable<any>(observe => {
            console.log("inside Observable");
            console.log(EventConstants.CIENA_GCT, "gct");
            console.log(header, "headers");

            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', null, header, null, EventConstants.CIENA_GCT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    downloadTemplate(bulkCheck) {
        let header;
        if (bulkCheck == false) {
            header = new HttpHeaders()
                .append("Type", EventConstants.CIENA_IMPLICIT_BULK_TEMPLATE);
        }

        else {
            header = new HttpHeaders()
                .append("Type", EventConstants.CIENA_EXPLICIT_BULK_TEMPLATE);
        }

        return new Observable<any>(observe => {
            console.log('inside singleProvisioning..');
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, header, null, EventConstants.DOWNLOAD_TEMPLATE).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    downloadGCTTemplate(neid) {
        // let header = new HttpHeaders({
        //     "Ne-Id" : neid
        // });
        let header = new HttpHeaders();
        header = header.set('Ne-Id', neid);
        console.log(header);

        return new Observable<any>(observe => {
            console.log("inside Observable");
            console.log(EventConstants.CIENA_GCT, "gct");
            console.log(header, "headers");

            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, header, null, EventConstants.CIENA_GCT).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        });
    }

    validatePorts(bulkCheck, file: File) {
        let header;
        console.log('file in service is :', file);
        if (bulkCheck == false) {
            header = new HttpHeaders()
                .append("Type", EventConstants.CIENA_IMPLICIT_BULK_VALIDATION);
        }

        else {
            header = new HttpHeaders()
                .append("Type", EventConstants.CIENA_EXPLICIT_BULK_VALIDATION);
        }
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/nbHandlerCiena', file, header, null, EventConstants.CIENA_VALIDATION_PORTS).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    observe.next(response);
                }
            );
        })
    }


    getGCTListDetails() {
        return new Observable<any>(observe => {
            console.log("inside Observable");
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, null, null, EventConstants.CIENA_GET_GCT_LIST).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));
                    if (response['status_Code'] === 200) {
                        observe.next(response['Ne-Ids']);
                    }
                }
            );
        });
    }

    deleteGCTDetails(neid) {
        let headers = new HttpHeaders().append('Ne-Id', neid);
        return new Observable<any>(observe => {
            console.log("inside delete Observable");
            this.commonService.sendRequest('DELETE', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.CIENA_DELETE_GCT_DETAILS).subscribe(
                (response) => {
                    console.log(JSON.stringify(response));

                    observe.next(response);

                }
            );
        });
    }

    deleteBODDetails(deleteJson) {
        let headers = new HttpHeaders()
            .append("source", deleteJson['source'])
            .append("destination", deleteJson['destination'])
            .append("ZendNE", deleteJson['ZendNE'])
            .append("layerRate", deleteJson['layerRate'])
            .append("AendNE", deleteJson['AendNE']);
        console.log("headers are:", headers);

        return new Observable<any>(observe => {
            console.log("inside delete");
            this.commonService.sendRequest('DELETE', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.CIENA_DELETE_BOD_DETAILS).subscribe(
                (response) => {
                    observe.next(response);
                }
            )

        })
    }

    getViewDetails(getApi) {
        let headers = new HttpHeaders()
            .append('Context', getApi);
        return new Observable<any>(observer => {
            this.commonService.sendRequest('GET', '/PEAG/nbHandlerCiena', null, headers, null, EventConstants.GET_VIEW_DETAIL_API)
                .subscribe(response => {
                    console.log(response);
                    let modifiedResponse = {};
                    modifiedResponse = JSON.parse(JSON.stringify(response));
                    delete modifiedResponse['headers'];
                    console.log('modifiedResponse :', modifiedResponse);
                    console.log('response after modifying :', response);
                    observer.next(modifiedResponse);
                });
        });
    }

}
