import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
@Injectable({
  providedIn: 'root'
})
export class BackuprestoreService {
  constructor(private commonService: SdWanServiceService) {

  }

  getDataBackuprestore(header): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, header, null, EventConstants.CIENA_GET_NODEDATA_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );

  }
  getMultiNodeBackup(json): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, null, null, EventConstants.CIENA_GET_MULTI_NODEDATA_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );


  }
  getAllNodeBackup(headers): Observable<any> {

    // let headers = new HttpHeaders().append('Event-Key', EventConstants.CIENA_GET_ALL_NODEDATA_BACKUP_CONTEXT);
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, null, headers, null, EventConstants.CIENA_GET_ALL_NODEDATA_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getmultischeduleDataBackup(json): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, null, null, EventConstants.CIENA_GET_MULTI_SCHEDULE_NODEDATA_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getAllscheduleDataBackup(json, headers): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, headers, null, EventConstants.CIENA_GET_ALL_SCHEDULE_NODEDATA_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getCheckup(json): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, null, null, EventConstants.CIENA_CHECK_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getALLCheckup(headers): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, null, headers, null, EventConstants.CIENA_ALLCHECK_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getBackupPath(json): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, null, null, EventConstants.CIENA_RESTORE_BACKUP_PATH_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getOnDemandRestoration(headers, json): Observable<any> {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, headers, null, EventConstants.CIENA_RESTORE_ON_DEMAND_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }

  getNmapBackUp(): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, null, null, null, EventConstants.CIENA_GET_NODEDATA_FOR_NMAP_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }

  getNmapScheduled(json): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('POST', EventConstants.CIENA_BACKUP_CONTEXT, json, null, null, EventConstants.CIENA_GET_NODEDATA_FOR_SCHEDULED_NMAP_BACKUP_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getAllCircle(): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, null, null, EventConstants.CIENA_GET_ALL_CIRCLE_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getAllNetwork(): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, null, null, EventConstants.CIENA_GET_ALL_NETWORK_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getFilteredData(header): Observable<any> {
    console.log('headers inside service', header);
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, header, null, EventConstants.CIENA_GET_FILTERED_DATA_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }
  getAllNodes(headers): Observable<any> {

    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, headers, null, EventConstants.CIENA_GET_ALLDATA_CONTEXT).subscribe(
        (response) => {
          console.log(response);
          observe.next(response);
        }
      );
    }
    );
  }

  getBackupRestoreLog(headers): Observable<any> {


    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.CIENA_BACKUP_CONTEXT, null, headers, null, EventConstants.CIENA_GET_LOG_RESTORE_CONTEXT).subscribe(
        (response) => {

          //console.log(" the response from db" + response.body);
          console.log(response);

          observe.next(response);
        }
      );
    }
    );
  }
}

