import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material';
import { Observable, Subscription } from 'rxjs';
import { NotificationService } from '../../../../../SharedFolder/services/notification.service';
import { BackuprestoreService } from './backuprestore.service';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';


@Component({
  selector: 'app-backup-restore',
  templateUrl: './backup-restore.component.html',
  styleUrls: ['./backup-restore.component.css']
})
export class BackupRestoreComponent implements OnInit, OnDestroy {

  @ViewChild('paginatorBackup1') paginator1: MatPaginator;
  @ViewChild('paginatorBackup2') paginator2: MatPaginator;
  @ViewChild('paginatorBackup3') paginator3: MatPaginator;
  @ViewChild('paginatorBackup4') paginator4: MatPaginator;
  matTabIndex: number = 0;
  showAlarmGraph: boolean = false;
  from: any = '';
  scheduleFrom: any = '';
  to: any = '';
  showTable: boolean = false;
  public min = new Date();
  public minDate = new Date();
  public maxDate = new Date();
  nodes: string[];
  types: string[];
  types1: string[];
  selectType1: any;
  selectType2: any;
  selectType3: any;
  scheduleType: any;
  nodeType1: any;
  nodeType2: any;
  nodeType3: any;
  selectedIndex: any = 0;
  statesList1 = new FormGroup({
    selected: new FormControl([])
  });
  networksList1 = new FormGroup({
    selected: new FormControl([])
  });
  nodeIdsList1 = new FormGroup({
    selected: new FormControl([])
  });
  statesList2 = new FormGroup({
    selected: new FormControl([])
  });
  networksList2 = new FormGroup({
    selected: new FormControl([])
  });
  nodeIdsList2 = new FormGroup({
    selected: new FormControl([])
  });
  statesList3 = new FormGroup({
    selected: new FormControl([])
  });
  networksList3 = new FormGroup({
    selected: new FormControl([])
  });
  nodeIdsList3 = new FormGroup({
    selected: new FormControl([])
  });
  stateList1: any[];
  networkList1: any[];
  nodeIdList1: any[];
  stateList2: any[];
  networkList2: any[];
  nodeIdList2: any[];
  stateList3: any[];
  networkList3: any[];
  nodeIdList3: any[];
  show: boolean = false;
  tableShow1: boolean = false;
  tableShow2: boolean = false;
  tableShow3: boolean = false;
  pageSize1: number;
  pageSizeOptions = [5, 10];
  bodDetails = [];
  bodDetailsTemp = [];
  bodDetailsFlag = false;
  length1: number;
  cienaServiceModal: boolean = false;
  schedules: string[];
  allNodes: boolean = false;
  filterState1: string;
  filterNetwork1: string;
  filterNode1: string;
  initialFlag1: boolean = false;
  filterState2: string;
  filterNetwork2: string;
  filterNode2: string;
  initialFlag2: boolean = false;
  filterState3: string;
  filterNetwork3: string;
  filterNode3: string;
  initialFlag3: boolean = false;
  footer: boolean = false;
  nodeList1: any[];
  nodeList2: any[];
  nodeList3: any[];
  checkAll: boolean = false;
  read: boolean;
  write: boolean;
  delete: boolean;

  /* Restore constants ................*/
  @ViewChild('scheduleRestoreForm') scheduleRestoreForm: NgForm;
  startIndex = 0;
  batchSize = 100;
  FetchFileData: any;
  fileRestoreModal: boolean = false;
  locationPath: string;
  tableTab1 = [];
  tableTab2 = [];
  tableTab3 = [];
  tableTab1Temp = [];
  tableTab2Temp = [];
  tableTab3Temp = [];
  table1DetailsFlag: boolean = false;
  table2DetailsFlag: boolean = false;
  table3DetailsFlag: boolean = false;
  status: string;
  statusCode: string;
  multiNodeBackUpJson: {};
  scheduleBackUpJson: {};
  multiCheckBackUpJson: {};
  fetchFileJson: {};
  fetchFileDataArray: any;
  nmap: boolean = false;
  states: any;
  network: any;
  nodeId: any;
  confirmRestoreModal: boolean = false;
  changeNode1: boolean = false;
  changeNode2: boolean = false;
  changeNode3: boolean = false;
  stateSubscription1: Subscription;
  networkSubscription1: Subscription;
  nodeSubscription1: Subscription;
  stateSubscription2: Subscription;
  networkSubscription2: Subscription;
  nodeSubscription2: Subscription;
  stateSubscription3: Subscription;
  networkSubscription3: Subscription;
  nodeSubscription3: Subscription;
  resetFilterValue1;
  resetFilterValue2;
  resetFilterValue3;
  length2: number;
  pageSize2: number;
  length3: number;
  pageSize3: number;

  /*............. Logs Constants...............*/
  backupLogData: any[];
  backupLogData1: any[];
  public maxFrom = new Date(new Date().getTime());
  public minFrom = new Date(new Date().getTime() - 155520000000000);
  public maxTo = new Date(new Date().getTime());
  public minTo = new Date(new Date().getTime() - 155520000000000);
  length4: number;
  pageSize4: number;
  LogDetailsFlag: boolean = false;
  offset1: number;
  offset2: number;
  offset3: number;
  offset4: number;
  tab3Footer: boolean = true;

  constructor(
    private optService: opticalModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private backupservice: BackuprestoreService,
    private accessService: AccessService,
    private spinner: SpinnerService
  ) { }

  onPageChanged1(e) {
    this.offset1 = e.pageIndex * e.pageSize;
    this.pageSize1 = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    //this.checkAll = false;


    if (firstCut >= (this.startIndex + this.batchSize)) {
      this.startIndex = this.startIndex + this.batchSize;
      this.onGetTable1();
    }
    else if (firstCut < (this.startIndex)) {
      this.startIndex = this.startIndex - this.batchSize;
      this.onGetTable1();
    } else {
      this.tableTab1Temp = this.tableTab1.slice(firstCut - this.startIndex, secondCut - this.startIndex);
    }
    this.getCheckedNodes();
  }

  onPageChanged2(e) {
    this.offset2 = e.pageIndex * e.pageSize;
    this.pageSize2 = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.checkAll = false;

    if (firstCut >= (this.startIndex + this.batchSize)) {
      this.startIndex = this.startIndex + this.batchSize;
      this.onGetTable2();
    }
    else if (firstCut < (this.startIndex)) {
      this.startIndex = this.startIndex - this.batchSize;
      this.onGetTable2();
    } else {
      this.tableTab2Temp = this.tableTab2.slice(firstCut - this.startIndex, secondCut - this.startIndex);
    }
    this.getCheckedNodes();


  }

  onPageChanged3(e) {
    this.offset3 = e.pageIndex * e.pageSize;
    this.pageSize3 = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.checkAll = false;

    if (firstCut >= (this.startIndex + this.batchSize)) {
      this.startIndex = this.startIndex + this.batchSize;
      this.onGetTable3();
    }
    else if (firstCut < (this.startIndex)) {
      this.startIndex = this.startIndex - this.batchSize;
      this.onGetTable3();
    } else {
      this.tableTab3Temp = this.tableTab3.slice(firstCut - this.startIndex, secondCut - this.startIndex);

    }
    this.getCheckedNodes();


  }

  onPageChanged4(e) {
    this.offset4 = e.pageIndex * e.pageSize;
    this.pageSize4 = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.backupLogData = this.backupLogData1.slice(firstCut, secondCut);
  }

  ngOnInit() {
    this.offset1 = 0;
    this.offset2 = 0;
    this.offset3 = 0;
    this.offset4 = 0;
    this.pageSize1 = 10;
    this.pageSize2 = 10;
    this.pageSize3 = 10;
    this.pageSize4 = 10;
    this.types = ['Node Type', 'NMAP'];
    this.types1 = ['Node Type'];
    this.schedules = ['DAILY', 'ONCE', 'WEEKLY', 'MONTHLY'];
    this.nodes = ['5430', '6500-2', '6500-7', '6500-14', '6500-32'];
    this.selectedIndex = 0;
    this.resetFilterValue1 = {
      'node': false,
      'network': false,
      'state': false
    };
    this.resetFilterValue2 = {
      'node': false,
      'network': false,
      'state': false
    };
    this.resetFilterValue3 = {
      'node': false,
      'network': false,
      'state': false
    };
    this.getCheckedNodes();
    this.checkAll = false;
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Backup and Restore Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Backup and Restore Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Backup and Restore Module', 'D');
    console.log('this.write :', this.write);
    console.log('this.read :', this.read);
    console.log('this.delete :', this.delete);
  }

  tabChanged(index) {
    this.selectedIndex = index;
    console.log('index :', index);
    if (this.selectedIndex === 3) {
      this.footer = true;
    }
    this.checkAll = false;
    this.getCheckedNodes();
  }

  getStates() {
    this.backupservice.getAllCircle().subscribe(
      (response) => {
        console.log('getStates response :', response);
        this.states = JSON.parse(response['body']);
        this.states.forEach(element => {
          if (this.selectedIndex === 0) {
            this.stateList1.push({
              display: element,
              value: element
            });
          }
          else if (this.selectedIndex === 1) {
            this.stateList2.push({
              display: element,
              value: element
            });
          }

          if (this.selectedIndex === 2) {
            this.stateList3.push({
              display: element,
              value: element
            });
          }
        });
      }
    );
  }


  getNetwork() {
    this.backupservice.getAllNetwork().subscribe(
      (response) => {
        console.log('Networks response :', response);
        this.network = JSON.parse(response['body']);
        this.network.forEach(element => {
          if (this.selectedIndex === 0) {
            this.networkList1.push({
              display: element,
              value: element
            });
          }

          else if (this.selectedIndex === 1) {
            this.networkList2.push({
              display: element,
              value: element
            });
          }

          else if (this.selectedIndex === 2) {
            this.networkList3.push({
              display: element,
              value: element
            });
          }
        });
      }
    );
  }

  getNodeId() {
    let netype: string;
    if (this.selectedIndex === 0)
      netype = this.nodeType1;
    else if (this.selectedIndex === 1)
      netype = this.nodeType2;
    else if (this.selectedIndex === 2)
      netype = this.nodeType3;
    let headers = new HttpHeaders()
      .append('Netype', netype);
    this.backupservice.getAllNodes(headers).subscribe(
      (response) => {
        console.log('Nodes response :', response);
        this.nodeId = JSON.parse(response['body']);
        this.nodeId.forEach(element => {
          if (this.selectedIndex === 0) {
            this.nodeIdList1.push({
              display: element,
              value: element
            });
          }

          else if (this.selectedIndex === 1) {
            this.nodeIdList2.push({
              display: element,
              value: element
            });
          }

          else if (this.selectedIndex === 2) {
            this.nodeIdList3.push({
              display: element,
              value: element
            });
          }

        });
      }
    );
  }

  onAllNodes() {
    if (this.allNodes == false) {
      this.allNodes = true;
    }
    else {
      this.allNodes = false;
    }

  }

  setDateAndTime() {
    this.min = this.scheduleFrom;
    this.minDate = new Date();
    this.maxDate = new Date(Date.parse(this.from) + 2592000000);
  }

  onChange(value) {
    if (value) {
      this.scheduleAll();
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  backToNode() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onGetTable1() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType1)
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('---headers :----', headers);
    this.backupservice.getDataBackuprestore(headers).subscribe(
      (response) => {
        this.spinner.stop();
        if (this.stateSubscription1)
          this.stateSubscription1.unsubscribe();
        if (this.networkSubscription1)
          this.networkSubscription1.unsubscribe();
        if (this.nodeSubscription1)
          this.nodeSubscription1.unsubscribe();
        this.filterChange1();
        setTimeout(() => { this.initialFlag1 = true; }, 2000);
        this.footer = true;
        console.log('---------response :--------', response);
        this.tableTab1 = JSON.parse(response['body']);
        this.length1 = this.tableTab1.length;
        this.tableTab1Temp = this.tableTab1.slice(0, this.pageSize1);
        if (this.paginator1)
          this.paginator1.firstPage();
        if (this.length1 > 0) {
          this.tableShow1 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table1DetailsFlag = false;
        }
        else {
          this.table1DetailsFlag = true;
          this.footer = false;
        }
      }
    );
  }

  onGetTable2() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType2)
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('---headers :----', headers);
    this.backupservice.getDataBackuprestore(headers).subscribe(
      (response) => {
        this.spinner.stop();
        console.log('calling filterChange2 :');
        if (this.stateSubscription2)
          this.stateSubscription2.unsubscribe();
        if (this.networkSubscription2)
          this.networkSubscription2.unsubscribe();
        if (this.nodeSubscription2)
          this.nodeSubscription2.unsubscribe();
        this.filterChange2();
        setTimeout(() => { this.initialFlag2 = true; }, 2000);
        console.log('service called :');
        console.log("------------inside selectedIndex 1 called--------");
        this.tableTab2 = JSON.parse(response['body']);
        this.length2 = this.tableTab2.length;
        this.tableTab2Temp = this.tableTab2.slice(0, this.pageSize2);
        if (this.paginator2)
          this.paginator2.firstPage();
        if (this.length2 > 0) {
          this.tableShow2 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table2DetailsFlag = false;
        }
        else {
          this.table2DetailsFlag = true;
          this.footer = false;
        }
      }
    );
  }

  onGetTable3() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType3)
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('---headers :----', headers);
    this.backupservice.getDataBackuprestore(headers).subscribe(
      (response) => {
        this.spinner.stop();
        if (this.stateSubscription3)
          this.stateSubscription3.unsubscribe();
        if (this.networkSubscription3)
          this.networkSubscription3.unsubscribe();
        if (this.nodeSubscription3)
          this.nodeSubscription3.unsubscribe();
        this.filterChange3();
        setTimeout(() => { this.initialFlag3 = true; }, 2000);
        this.tableTab3 = JSON.parse(response['body']);
        this.length3 = this.tableTab3.length;
        this.tableTab3Temp = this.tableTab3.slice(0, this.pageSize3);
        if (this.paginator3)
          this.paginator3.firstPage();
        if (this.length3 > 0) {
          this.tableShow3 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table3DetailsFlag = false;
        }
        else {
          this.table3DetailsFlag = true;
          this.footer = false;
        }
      }
    );
  }

  onGetNmapBackUp() {
    this.backupservice.getNmapBackUp().subscribe(
      (response) => {
        console.log('response :', response);
        this.status = response['status'];
        this.statusCode = response['status_code'];
        if (this.statusCode == "200") {
          this.notificationService.notificationMessage(this.status, 'success');
          this.checkAll = true;
          this.selectAll();
          this.checkAll = false;
        }
        else if (this.statusCode == "410") {
          this.notificationService.notificationMessage(this.status, 'danger');
        }
      }
    )
  }

  onGetBackup1() {
    if (this.selectType1 === 'NMAP') {
      this.tableShow1 = false;
      this.nodeType1 = '';
      this.nmap = true;
      this.footer = true;
      console.log('this.nmap :', this.nmap);
    }
    else if (this.selectType1 === 'Node Type' && (this.nodeType1 !== '' && this.nodeType1 !== undefined && this.nodeType1 !== null)) {
      //call the api for NOdetype and nodetype value;
      if (this.changeNode1) {
        this.stateList1 = [];
        this.networkList1 = [];
        this.nodeIdList1 = [];
        this.getStates();
        this.getNetwork();
        this.getNodeId();
        this.changeNode1 = false;
        this.initialFlag1 = false;
      }
      this.onGetTable1();
      this.nmap = false;
    }
  }

  onGetBackup2() {
    console.log("---------- onGetBackup2 called--------------");
    if (this.selectType2 === 'NMAP') {
      this.onGetNmapBackUp();
    }
    else if (this.selectType2 === 'Node Type' && (this.nodeType2 !== '' && this.nodeType2 !== undefined && this.nodeType2 !== null)) {
      //call the api for NOdetype and nodetype value;
      if (this.changeNode2) {
        this.stateList2 = [];
        this.networkList2 = [];
        this.nodeIdList2 = [];
        this.getStates();
        this.getNetwork();
        this.getNodeId();
        this.changeNode2 = false;
        this.initialFlag2 = false;
      }
      this.onGetTable2();
    }
  }

  onGetBackup3() {
    console.log("---------- onGetBackup3 called--------------");
    if (this.selectType3 === 'NMAP') {
      this.onGetNmapBackUp();
    }
    else if (this.selectType3 === 'Node Type' && (this.nodeType3 !== '' && this.nodeType3 !== undefined && this.nodeType3 !== null)) {
      //call the api for NOdetype and nodetype value;
      if (this.changeNode3) {
        this.stateList3 = [];
        this.networkList3 = [];
        this.nodeIdList3 = [];
        this.getStates();
        this.getNetwork();
        this.getNodeId();
        this.changeNode3 = false;
        this.initialFlag3 = false;
      }
      this.onGetTable3();
      this.nmap = false;
    }
  }

  getFilteredDataForBR1() {
    this.spinner.start();
    let header = new HttpHeaders()
      .append('Netype', this.nodeType1)
      .append('Filter-State', this.filterState1.toString())
      .append('Filter-Network', this.filterNetwork1.toString())
      .append('Filter-Nename', this.filterNode1.toString())
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('sending headers', header);
    this.backupservice.getFilteredData(header).subscribe(
      (response) => {
        this.spinner.stop();
        this.footer = true;
        console.log('---------response :--------', response);
        this.tableTab1 = JSON.parse(response['body']);
        this.length1 = this.tableTab1.length;
        this.tableTab1Temp = this.tableTab1.slice(0, this.pageSize1);
        if (this.paginator1)
          this.paginator1.firstPage();
        if (this.length1 > 0) {
          this.tableShow1 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table1DetailsFlag = false;
        }
        else {
          this.table1DetailsFlag = true;
          this.footer = false;
        }
      }
    );
  }

  getFilteredDataForBR2() {
    this.spinner.start();
    let header = new HttpHeaders()
      .append('Netype', this.nodeType2)
      .append('Filter-State', this.filterState2.toString())
      .append('Filter-Network', this.filterNetwork2.toString())
      .append('Filter-Nename', this.filterNode2.toString())
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('sending headers', header);
    this.backupservice.getFilteredData(header).subscribe(
      (response) => {
        this.spinner.stop();
        console.log(response);
        this.tableTab2 = JSON.parse(response['body']);
        this.length2 = this.tableTab2.length;
        this.tableTab2Temp = this.tableTab2.slice(0, this.pageSize2);
        if (this.paginator2)
          this.paginator2.firstPage();
        if (this.length2 > 0) {
          this.tableShow2 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table2DetailsFlag = false;
        }
        else {
          this.table2DetailsFlag = true;
          this.footer = false;
        }

      }
    );
  }

  getFilteredDataForBR3() {
    this.spinner.start();
    let header = new HttpHeaders()
      .append('Netype', this.nodeType3)
      .append('Filter-State', this.filterState3.toString())
      .append('Filter-Network', this.filterNetwork3.toString())
      .append('Filter-Nename', this.filterNode3.toString())
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('sending headers', header);
    this.backupservice.getFilteredData(header).subscribe(
      (response) => {
        this.spinner.stop();
        console.log(response);
        this.tableTab3 = JSON.parse(response['body']);
        this.length3 = this.tableTab3.length;
        this.tableTab3Temp = this.tableTab3.slice(0, this.pageSize3);
        if (this.paginator3)
          this.paginator3.firstPage();
        if (this.length3 > 0) {
          this.tableShow3 = true;
          this.getCheckedNodes();
          this.footer = true;
          this.table3DetailsFlag = false;
        }
        else {
          this.table3DetailsFlag = true;
          this.footer = false;
        }
      }
    );
  }

  filterChange1() {
    this.stateSubscription1 = this.statesList1.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 0) {
        return;
      }
      this.filterState1 = this.statesList1.value['selected'];
      if (JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList1.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList1.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR1();
      } else {
        if (this.initialFlag1 && !this.resetFilterValue1['state']) {
          this.onGetBackup1();
        } else {
          if (this.resetFilterValue1['state']) {
            this.resetFilterValue1['state'] = false;
          }
        }
      }
    });
    this.networkSubscription1 = this.networksList1.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 0) {
        return;
      }
      this.filterNetwork1 = this.networksList1.value['selected'];
      if (JSON.stringify(this.statesList1.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList1.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR1();
      } else {
        if (this.initialFlag1 && !this.resetFilterValue1['network']) {
          this.onGetBackup1();
        } else {
          if (this.resetFilterValue1['network']) {
            this.resetFilterValue1['network'] = false;
          }
        }
      }
    });
    this.nodeSubscription1 = this.nodeIdsList1.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 0) {
        return;
      }
      this.filterNode1 = this.nodeIdsList1.value['selected'];
      if (JSON.stringify(this.statesList1.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList1.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR1();
      } else {
        if (this.initialFlag1 && !this.resetFilterValue1['node']) {
          this.onGetBackup1();
        } else {
          if (this.resetFilterValue1['node']) {
            this.resetFilterValue1['node'] = false;
          }
        }
      }
    });
  }

  filterChange2() {
    this.stateSubscription2 = this.statesList2.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 1) {
        return;
      }
      this.filterState2 = this.statesList2.value['selected'];
      if (JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList2.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList2.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR2();
      } else {
        if (this.initialFlag2 && !this.resetFilterValue2['state']) {
          this.onGetBackup2();
        } else {
          if (this.resetFilterValue2['state']) {
            this.resetFilterValue2['state'] = false;
          }
        }
      }
    });
    this.networkSubscription2 = this.networksList2.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 1) {
        return;
      }
      this.filterNetwork2 = this.networksList2.value['selected'];
      if (JSON.stringify(this.statesList2.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList2.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR2();
      } else {
        if (this.initialFlag2 && !this.resetFilterValue2['network']) {
          this.onGetBackup2();
        } else {
          if (this.resetFilterValue2['network']) {
            this.resetFilterValue2['network'] = false;
          }
        }
      }
    });
    this.nodeSubscription2 = this.nodeIdsList2.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 1) {
        return;
      }
      this.filterNode2 = this.nodeIdsList2.value['selected'];
      if (JSON.stringify(this.statesList2.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList2.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR2();
      } else {
        if (this.initialFlag2 && !this.resetFilterValue2['node']) {
          this.onGetBackup2();
        } else {
          if (this.resetFilterValue2['node']) {
            this.resetFilterValue2['node'] = false;
          }
        }
      }
    });
  }

  filterChange3() {
    this.stateSubscription3 = this.statesList3.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 2) {
        return;
      }
      this.filterState3 = this.statesList3.value['selected'];
      if (JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList3.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList3.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR3();
      } else {
        if (this.initialFlag3 && !this.resetFilterValue3['state']) {
          this.onGetBackup3();
        } else {
          if (this.resetFilterValue3['state']) {
            this.resetFilterValue3['state'] = false;
          }
        }
      }
    });
    this.networkSubscription3 = this.networksList3.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 2) {
        return;
      }
      this.filterNetwork3 = this.networksList3.value['selected'];
      if (JSON.stringify(this.statesList3.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([]) || JSON.stringify(this.nodeIdsList3.value['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR3();
      } else {
        if (this.initialFlag3 && !this.resetFilterValue3['network']) {
          this.onGetBackup3();
        } else {
          if (this.resetFilterValue3['network']) {
            this.resetFilterValue3['network'] = false;
          }
        }
      }
    });
    this.nodeSubscription3 = this.nodeIdsList3.valueChanges.subscribe(data => {
      if (this.selectedIndex !== 2) {
        return;
      }
      this.filterNode3 = this.nodeIdsList3.value['selected'];
      if (JSON.stringify(this.statesList3.value['selected']) !== JSON.stringify([]) || JSON.stringify(this.networksList3.value['selected']) !== JSON.stringify([]) || JSON.stringify(data['selected']) !== JSON.stringify([])) {
        this.getFilteredDataForBR3();
      } else {
        if (this.initialFlag3 && !this.resetFilterValue3['node']) {
          this.onGetBackup3();
        } else {
          if (this.resetFilterValue3['node']) {
            this.resetFilterValue3['node'] = false;
          }
        }
      }
    });
  }

  getCheckedNodes() {
    this.nodeList1 = [];
    this.nodeList2 = [];
    this.nodeList3 = [];
    if (this.selectedIndex === 0) {
      this.tableTab1.forEach(element => {
        if (element.checked == true) {
          this.nodeList1.push({
            nename: element.nename,
            netype: this.nodeType1
          });
        }
      });

      let count = 0;
      this.tableTab1Temp.forEach(data => {
        if (data.checked == true) {
          count++;
        }
      });
      if (count === this.tableTab1Temp.length) {
        this.checkAll = true;
      }
      else {
        this.checkAll = false;
      }


    }
    else if (this.selectedIndex === 1) {
      this.tableTab2.forEach(element => {
        if (element.checked == true) {
          this.nodeList2.push({
            nename: element.nename,
            netype: this.nodeType2
          });
        }
      });
      let count = 0;
      this.tableTab2Temp.forEach(data => {
        if (data.checked == true) {
          count++;
        }
      });
      if (count === this.tableTab2Temp.length) {
        this.checkAll = true;
      }
      else {
        this.checkAll = false;
      }
    }
    else if (this.selectedIndex === 2) {
      this.tableTab3.forEach(element => {
        if (element.checked == true) {
          this.nodeList3.push({
            nename: element.nename,
            netype: this.nodeType3
          });
        }
      });
      let count = 0;
      this.tableTab3Temp.forEach(data => {
        if (data.checked == true) {
          count++;
        }
      });
      if (count === this.tableTab3Temp.length) {
        this.checkAll = true;
      }
      else {
        this.checkAll = false;
      }
    }
  }

  takeBackupNow() {
    if (this.selectType1 === 'NMAP') {
      this.onGetNmapBackUp();
    }
    else {
      this.getCheckedNodes();
      if (this.nodeList1.length > 10) {
        this.notificationService.notificationMessage("Node count limit reached. Please select upto 10 nodes.", 'danger');
      }
      else {
        //call API to take backup now
        this.multiNodeBackUpJson = {
          "data": this.nodeList1
        };

        this.backupservice.getMultiNodeBackup(this.multiNodeBackUpJson).subscribe(
          (response) => {
            console.log('response :', response);
            this.status = response['status'];
            this.statusCode = response['status_code'];
            if (this.statusCode == "200") {
              this.notificationService.notificationMessage(this.status, 'success');
              this.checkAll = true;
              this.selectAll();
              this.checkAll = false;
              this.getCheckedNodes();
            }
            else if (this.statusCode == "410") {
              this.notificationService.notificationMessage(this.status, 'danger');
            }
          }
        )
      }
    }
  }

  backUpAll() {
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType1);
    this.backupservice.getAllNodeBackup(headers).subscribe(
      (response) => {
        console.log('response :', response);
        this.status = response['status'];
        this.statusCode = response['status_code'];
        if (this.statusCode == "200") {
          this.notificationService.notificationMessage(this.status, 'success');
          this.checkAll = true;
          this.selectAll();
          this.checkAll = false;
        }
        else if (this.statusCode == "410") {
          this.notificationService.notificationMessage(this.status, 'danger');
        }
      }
    )
  }
  openScheduleModal() {
    this.cienaServiceModal = true;
    this.scheduleRestoreForm.reset();
  }
  onScheduleBackup() {
    this.cienaServiceModal = false;
    if (this.selectType1 == 'NMAP') {
      let json = {
        "schedule": {
          "frequency": this.scheduleType,
          "utcTime": Date.parse(this.scheduleFrom).toString()

        }
      };
      this.backupservice.getNmapScheduled(json).subscribe(
        (response) => {
          console.log('response :', response);
          this.status = response['status'];
          this.statusCode = response['status_code'];
          if (this.statusCode == "200") {
            this.notificationService.notificationMessage(this.status, 'success');
            this.checkAll = true;
            this.selectAll();
            this.checkAll = false;

          }
          else if (this.statusCode == "410") {
            this.notificationService.notificationMessage(this.status, 'danger');
          }
        }
      );
    }
    else if (this.allNodes == true) {
      this.scheduleAll();
    }
    else {
      let scheduleJson = {
        "scheduleFrequency": this.scheduleType,
        "scheduleTime": Date.parse(this.scheduleFrom).toString()
      };
      this.getCheckedNodes();
      if (this.nodeList1.length > 10) {
        this.notificationService.notificationMessage("Node count limit reached. Please select upto 10 nodes.", 'danger');
      }
      else {
        //call API to take backup now
        this.scheduleBackUpJson = {
          "data": this.nodeList1,
          "schedule": scheduleJson
        };
        this.backupservice.getmultischeduleDataBackup(this.scheduleBackUpJson).subscribe(
          (response) => {
            console.log('response :', response);
            this.status = response['status'];
            this.statusCode = response['status_code'];
            if (this.statusCode == "200") {
              this.notificationService.notificationMessage(this.status, 'success');
              this.checkAll = true;
              this.selectAll();
              this.checkAll = false;
              this.getCheckedNodes();
            }
            else if (this.statusCode == "410") {
              this.notificationService.notificationMessage(this.status, 'danger');
            }
          }
        );
      }
      console.log('-----------------------this.nodeList1 :', this.nodeList1);
    }
  }

  scheduleAll() {
    let json = {
      "schedule": {
        "scheduleFrequency": this.scheduleType,
        "scheduleTime": Date.parse(this.scheduleFrom).toString()
      }
    };
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType1);
    this.backupservice.getAllscheduleDataBackup(json, headers).subscribe(
      (response) => {
        console.log('response :', response);
        this.status = response['status'];
        this.statusCode = response['status_code'];
        if (this.statusCode == "200") {
          this.notificationService.notificationMessage(this.status, 'success');
          this.checkAll = true;
          this.selectAll();
          this.checkAll = false;
          this.getCheckedNodes();
        }
        else if (this.statusCode == "410") {
          this.notificationService.notificationMessage(this.status, 'danger');
        }
      }
    )
  }

  checkBackup() {
    this.spinner.start();
    this.getCheckedNodes();
    if (this.nodeList2.length > 10) {
      this.notificationService.notificationMessage("Node count limit reached. Please select upto 10 nodes.", 'danger');
    }
    else {
      //call API to take backup now
      this.multiCheckBackUpJson = {
        "data": this.nodeList2
      };

      this.backupservice.getCheckup(this.multiCheckBackUpJson).subscribe(
        (response) => {
          this.spinner.stop();
          console.log('response :', response);
          this.statusCode = response['status_code'];
          this.status = response['status'];
          if (this.statusCode == "200") {
            this.downloadFile(response);
            this.checkAll = true;
            this.selectAll();
            this.checkAll = false;
            this.getCheckedNodes();
          }
          else if (this.statusCode == "410") {
            this.notificationService.notificationMessage(this.status, 'danger');
          }
        }
      )
    }
    console.log('-----------------------this.nodeList2 :', this.nodeList2);
  }

  checkBackupAll() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType2);
    this.backupservice.getALLCheckup(headers).subscribe(
      (response) => {
        this.spinner.stop();
        console.log('response :', response);
        this.status = response['status'];
        this.statusCode = response['status_code'];
        if (this.statusCode == "200") {
          this.downloadFile(response);
          // this.notificationService.notificationMessage(this.status, 'success');
          this.checkAll = true;
          this.selectAll();
          this.checkAll = false;
        }
        else if (this.statusCode == "410") {
          this.notificationService.notificationMessage(this.status, 'danger');
        }
      }
    )
  }

  selectAll() {
    if (this.selectedIndex === 0) {
      this.tableTab1Temp.forEach(element => {
        console.log('this.table1 :', element.checked);
        console.log('this.checkAll :', this.checkAll);
        if (this.checkAll == false) {
          element.checked = true;
        }
        else {
          element.checked = false;
        }
        console.log('------------ :', element.checked);
      });
    }

    if (this.selectedIndex === 1) {
      this.tableTab2Temp.forEach(element => {
        console.log('this.tableTab2 :', element.checked);
        console.log('this.checkAll :', this.checkAll);
        if (this.checkAll == false) {
          element.checked = true;
        }
        else {
          element.checked = false;
        }
        console.log('------------ :', element.checked);
      });
    }
    if (this.selectedIndex === 2) {
      this.tableTab3Temp.forEach(element => {
        console.log('this.tableTab1 :', element.checked);
        console.log('this.checkAll :', this.checkAll);
        if (this.checkAll == false) {
          element.checked = true;
        }
        else {
          element.checked = false;
        }
        console.log('------------ :', element.checked);
      });
    }
  }

  downloadFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response['fileData']);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    linkElement.download = response['filename'];
    console.log(response);
    document.body.appendChild(linkElement);
    linkElement.click();
  }

  /*Restore functions himaja ............*/

  fetchFile() {
    this.spinner.start();
    console.log('-------------------this.fetchFile :----------', this.tableTab3);
    this.fileRestoreModal = true;
    this.getCheckedNodes();
    if (this.nodeList3.length > 10) {
      this.notificationService.notificationMessage("Node count limit reached. Please select upto 10 nodes.", 'danger');
    }
    else {
      //call API to take backup now
      this.fetchFileJson = {
        "data": this.nodeList3
      };
      console.log('this.fetchFileJson :', this.fetchFileJson);

      this.backupservice.getBackupPath(this.fetchFileJson).subscribe(
        (response) => {
          this.spinner.stop();
          console.log('response  in fetch file :', response);
          this.FetchFileData = response;
          this.fetchFileDataArray = response['data'];
          this.fetchFileDataArray = this.FetchFileData.data.map(element => {
            let result = {};
            result['nename'] = element['nename'];
            result['netype'] = element['netype'];
            result['list'] = element['list'];
            result['selected-creationTime'] = result['list'][0]['creationTime'];
            result['selected-imageLocation'] = result['list'][0]['imageLocation'];
            result['edited'] = false;
            return result;
          });
          this.statusCode = response['status_code'];
          console.log('-------- After response this.fetchFileDataArray :----', this.fetchFileDataArray);
        }
      )
    }
    console.log('-----------------------this.nodeList2 :', this.nodeList2);

  }

  restoreFile() {
    let transformedOutput = this.fetchFileDataArray.map(element => {
      let result = {};
      result['nename'] = element['nename'];
      result['netype'] = element['netype'];
      result['filePath'] = element['selected-imageLocation'];
      return result;
    });
    console.log(transformedOutput);
    let finalOutput = {
      "data": transformedOutput
    };
    let headers = new HttpHeaders()
      .append('Netype', this.nodeType3);
    this.backupservice.getOnDemandRestoration(headers, finalOutput).subscribe(
      (response) => {
        console.log('response :', response);
        this.status = response['status'];
        this.statusCode = response['status_code'];
        if (this.statusCode == "200") {
          this.notificationService.notificationMessage(this.status, 'success');
          this.checkAll = true;
          this.selectAll();
          this.checkAll = false;
          this.getCheckedNodes();
        }
        else if (this.statusCode == "410") {
          this.notificationService.notificationMessage(this.status, 'danger');
        }
      }
    )
  }

  mapLocationToDate(index, ListIndex) {
    console.log('ListIndex :', ListIndex);
    console.log('index :', index);
    this.fetchFileDataArray[index]['selected-imageLocation'] = this.FetchFileData['data'][index]['list'][ListIndex]['imageLocation'];
    this.fetchFileDataArray[index]['edited'] = true;
    console.log('this.locationPath :', this.fetchFileDataArray[index]['selected-imageLocation']);
  }

  restoreReset() {
    this.fetchFileDataArray = this.FetchFileData.data.map(element => {
      let result = {};
      result['nename'] = element['nename'];
      result['netype'] = element['netype'];
      result['list'] = element['list'];
      result['selected-creationTime'] = result['list'][0]['creationTime'];
      result['selected-imageLocation'] = result['list'][0]['imageLocation'];
      result['edited'] = false;
      return result;
    });

  }

  resetFilter1() {
    this.resetFilterValue1 = {
      'node': true,
      'network': true,
      'state': true
    };
    this.statesList1.controls['selected'].setValue([]);
    this.networksList1.controls['selected'].setValue([]);
    this.nodeIdsList1.controls['selected'].setValue([]);
  }

  resetFilter2() {
    this.resetFilterValue2 = {
      'node': true,
      'network': true,
      'state': true
    };
    this.statesList2.controls['selected'].setValue([]);
    this.networksList2.controls['selected'].setValue([]);
    this.nodeIdsList2.controls['selected'].setValue([]);
  }

  resetFilter3() {
    this.resetFilterValue3 = {
      'node': true,
      'network': true,
      'state': true
    };
    this.statesList3.controls['selected'].setValue([]);
    this.networksList3.controls['selected'].setValue([]);
    this.nodeIdsList3.controls['selected'].setValue([]);

  }

  /*  Logs Nageswar .............................*/

  getDataBackupRestoreLog() {
    let oldtimestamp = Date.parse(this.from).toString();
    let latesttimestamp = Date.parse(this.to).toString();
    let headers = new HttpHeaders()
      .append('Oldtimestamp', oldtimestamp)
      .append('Latesttimestamp', latesttimestamp);
    this.backupservice.getBackupRestoreLog(headers).subscribe(
      data => {
        this.backupLogData1 = JSON.parse(data.body);
        if (this.backupLogData1.length > 0) {
          this.length4 = this.backupLogData1.length;
          this.backupLogData = this.backupLogData1.slice(0, this.pageSize4);
          this.LogDetailsFlag = false;
          this.showTable = true;
          this.tab3Footer = false;
        }
        else {
          this.LogDetailsFlag = true;
        }
      }
    );
  }

  fromDateChanged() {
    if (Date.parse(this.from) + 2592000000 > new Date().getTime()) {
      this.maxTo = new Date();
    } else {
      this.maxTo = new Date(Date.parse(this.from) + 2592000000);
    }
    this.minTo = new Date(Date.parse(this.from));
    this.maxFrom = new Date();
  }


  toDateChanged() {
    this.minFrom = new Date(Date.parse(this.to) - 2592000000);
    this.maxFrom = new Date(Date.parse(this.to));
    if (Date.parse(this.from) + 2592000000 > new Date().getTime()) {
      this.maxTo = new Date();
    } else {
      this.maxTo = new Date(Date.parse(this.from) + 2592000000);
    }
  }

  ngOnDestroy() {
    this.spinner.stop();
  }


}
