import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { OpticalTransportComponent } from '../optical-transport.component';
import { opticalModuleAPIService } from '../opticalTransportModule_API.service';
//import { access } from 'fs';

@Component({
  selector: 'app-ciena-mcp',
  templateUrl: './ciena-mcp.component.html',
  styleUrls: ['./ciena-mcp.component.css']
})
export class CienaMCPComponent implements OnInit {

  list: any[] = [
    {
      title: "Bandwidth On Demand",
      value: "Ciena MCP Bandwidth on Demand Module",
      access: true,
    },
    {
      title: "Golden Configuration Template (GCT) Audit",
      value: "Ciena MCP GCT Module",
      access: true,
    },
    {
      title: "Health Check",
      value: "Ciena MCP Health Check Module",
      access: true,
    },
    {
      title: "Alarm Analysis",
      value: "Ciena MCP Alarm Analysis Module",
      access: true,
    },
    {
      title: "Backup and Restore",
      value: "Ciena MCP Backup and Restore Module",
      access: true,
    },
    {
      title: "PM Management",
      value: "Ciena MCP PM Management Module",
      access: true,
    },
    {
      title: "Inventory Management",
      value: "Ciena MCP Inventory Management Module",
      access: true,
    },
    {
      title: "Get Data",
      value: "Ciena MCP Get Data Module",
      access: true,
    }
  ]

  constructor(private router: Router,
    private route: ActivatedRoute,
    private accessService: AccessService,
    private optService: opticalModuleAPIService) { }

  ngOnInit() {
    this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'Optical Transport');
    // this.list[6]['access'] = true;
  }

  onClick(action) {
    switch (action) {
      case "Ciena MCP Bandwidth on Demand Module":
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/BOD");
        break;
      case "Ciena MCP GCT Module":
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/GCT");
        break;
      case "Ciena MCP Health Check Module":
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/HealthCheck");
        break;
      case 'Ciena MCP Alarm Analysis Module':
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/AlarmAnalysis");
        break;
      case 'Ciena MCP Backup and Restore Module':
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/BackupRestore");
        break;
      case 'Ciena MCP PM Management Module':
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/PmManagement");
        break;
      case 'Ciena MCP Inventory Management Module':
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/inventoryManagement");
        break;
      case 'Ciena MCP Get Data Module':
        this.router.navigateByUrl("layout/opticalTransport/cienaMCP/GetData");
        break;
      case 'opticalTransport':
        this.router.navigateByUrl("layout/opticalTransport");
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
}
