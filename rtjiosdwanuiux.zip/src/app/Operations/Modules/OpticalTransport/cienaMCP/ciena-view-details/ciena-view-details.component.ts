import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CienaService } from '../ciena.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';

@Component({
  selector: 'app-ciena-view-details',
  templateUrl: './ciena-view-details.component.html',
  styleUrls: ['./ciena-view-details.component.css']
})
export class CienaViewDetailsComponent implements OnInit, OnDestroy {

  @ViewChild('viewForm') viewForm: NgForm;
  viewDetailsResult = '';
  getApi = '';
  constructor(private optService: opticalModuleAPIService
    , private cienaService: CienaService
    , private router: Router,
    private route: ActivatedRoute,
    private accessService: AccessService,
    private ngxSpinner: SpinnerService) { }

  ngOnInit() {
  }

  getViewDetails() {

    this.viewDetailsResult = '';
    this.ngxSpinner.start();
    this.cienaService.getViewDetails(this.viewForm.value['getApi'])
      .subscribe(res => {
        this.ngxSpinner.stop();
        this.viewDetailsResult = JSON.stringify(res, null, 4);
        console.log(this.viewDetailsResult);
      });
  }

  async downloadJSONFile() {
    const filename = 'Ciena_viewDetails.json';
    const jsonStr = this.viewDetailsResult;
    let element = document.createElement('a');
    this.ngxSpinner.start();
    let encodeMessage = await encodeURIComponent(jsonStr);
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeMessage);
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    this.ngxSpinner.stop();
    document.body.removeChild(element);

  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  backToNSP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  ngOnDestroy(): void {
    this.ngxSpinner.stop();
  }

}
