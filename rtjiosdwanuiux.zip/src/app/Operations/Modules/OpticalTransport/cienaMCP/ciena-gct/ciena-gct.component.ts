import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { CienaService } from '../ciena.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
declare var $: any;

@Component({
    selector: 'app-ciena-gct',
    templateUrl: './ciena-gct.component.html',
    styleUrls: ['./ciena-gct.component.css']
})

export class CienaGCTComponent implements OnInit, OnDestroy {
    toolTipPostion: TooltipPosition = "above";
    checkEnable: boolean = false;
    @ViewChild('cienaGCTForm') cienaGCTForm: NgForm;
    @ViewChild('paginator') paginator: MatPaginator;
    gctDetailsFlag = false;
    length: number;
    selectedNeid;
    selectedIndex;
    displayDelete: string;
    afterSuccessGCTModal: boolean = false;
    afterdeleteGCTModal: boolean = false;
    deleteGCTModal: boolean = false;
    displaySuccess: string;
    deleteStatus: boolean = false;
    pageSizeOptions = [5, 10, 15, 20, 30.50, 100];
    gctDetails = [];
    gctDetailsTemp = [];
    pageSize: number;
    offset: number;
    matTabIndex;
    read: boolean;
    write: boolean;
    delete: boolean;

    constructor(private router: Router,
        private route: ActivatedRoute,
        private cienaService: CienaService,
        private ngxService: SpinnerService,
        private accessService: AccessService,
        private optService: opticalModuleAPIService
    ) {
    }

    ngOnInit() {
        this.pageSize = 5;
        this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP GCT Module', 'R');
        this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP GCT Module', 'W');
        this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP GCT Module', 'D');
        if (this.write) {
            this.matTabIndex = 0;
        }
        else {
            this.matTabIndex = 1;
            this.getGCTDetailsRequest();
        }
    }



    onPageChanged(e) {
        this.offset = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.gctDetailsTemp = this.gctDetails.slice(firstCut, secondCut);
    }

    backToMCP() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onSubmit() {
        this.ngxService.start();
        console.log(this.cienaGCTForm.value['NeId'], "neid Value");
        this.cienaService.cienaGCTRequest(this.cienaGCTForm.value['NeId']).subscribe(
            (response) => {
                this.ngxService.stop();
                this.displaySuccess = response['status'];
                console.log(response, "check response");
                if (response['status_code'] === 200) {
                    this.checkEnable = true;
                    //$('#afterSuccessGCTModal').modal('show');
                    this.afterSuccessGCTModal = true;
                    this.cienaGCTForm.resetForm();
                }
                else {
                    this.checkEnable = false;
                    //$('#afterSuccessGCTModal').modal('show');
                    this.afterSuccessGCTModal = true;
                }

            }
        );
    }

    getGCTDetailsRequest() {
        console.log("inside LIST req");

        this.cienaService.getGCTListDetails().
            subscribe(response => {
                console.log("response GCT Details", response);
                this.gctDetails = response;

                // this.gctDetails = [{"item": ""},{"item": ""}]
                this.gctDetailsTemp = this.gctDetails;
                this.length = this.gctDetails.length;
                this.gctDetailsTemp = this.gctDetails.slice(0, this.pageSize);
                if (this.gctDetails.length > 0) {
                    this.gctDetailsFlag = false;
                }
                else this.gctDetailsFlag = true;
            });
    }

    getEventNumber(event) {
        console.log("event", event);
        if (event == 1) {
            this.getGCTDetailsRequest();
        }
    }

    onDownload(neid) {
        this.cienaService.downloadGCTTemplate(neid).subscribe(res => {
            console.log(res)
            this.downloadFile(res);
        });
    }

    downloadFile(data) {
        var linkElement = document.createElement('a');
        if (data['status_code'] == 202) {
            var byteArray = new Uint8Array(data['fileData']);
            linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
            // linkElement.target = '_blank';
            linkElement.download = data['fileName'];
            document.body.appendChild(linkElement);
            linkElement.click();
            this.checkEnable = false;
        }

        else {
            this.displayDelete = data['status'];
            //$('#afterdeleteGCTModal').modal('show');
            this.afterdeleteGCTModal = true;
            setTimeout(() => this.getGCTDetailsRequest(), 1000);
        }
    }

    beforeDelete(neid, index) {
        this.selectedNeid = neid;
        this.selectedIndex = index;
        $('#deleteGCTModal').modal('show');
    }

    onDeleteGCT(neid) {

        // index = this.offset + index;
        // this.cienaService.deleteGCTDetails(neid).subscribe(res => {
        //     console.log("delete", res);
        //     if (res['status_code'] == 200) {
        //         this.displayDelete = res['status'];
        //         $('afterdeleteGCTModal').modal('show');
        //         this.gctDetails = this.gctDetails.splice(index, 1);
        //         this.paginator.firstPage();
        //         if (this.gctDetails.length > 0) {
        //             this.gctDetailsFlag = false;
        //             this.length = this.gctDetails.length;
        //             if (this.gctDetails.length > 5)
        //                 this.gctDetailsTemp = this.gctDetails.slice(0, 5);
        //             else
        //                 this.gctDetailsTemp = this.gctDetails;
        //         }
        //         else this.gctDetailsFlag = true;
        //     }

        //     else if (res['status_code'] == 400) {
        //         this.displayDelete = res['status'];
        //         $('afterdeleteGCTModal').('show');
        //     }

        // });

        this.cienaService.deleteGCTDetails(neid).subscribe(res => {
            console.log("delete", res);
            this.displayDelete = res['status'];
            if (res['status_code'] == 202) {
                this.deleteStatus = true;
            }
            else {
                this.deleteStatus = false;
            }
            console.log(this.deleteStatus, "deleteStatus");

            //$('#afterdeleteGCTModal').modal('show');
            this.afterdeleteGCTModal = true;
            setTimeout(() => this.getGCTDetailsRequest(), 1000);
        });

    }

    breadcrumbNavigation(path: string) {
        this.optService.breadcrumbNavigation(path);
    }

    ngOnDestroy() {
        this.ngxService.stop();
    }
}
