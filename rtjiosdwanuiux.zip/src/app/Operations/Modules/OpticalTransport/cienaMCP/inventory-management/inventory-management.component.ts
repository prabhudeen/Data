import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material';
import { inventoryManagementService } from './inventory-management.service';
import { HttpHeaders } from '@angular/common/http';
import { NotificationService } from '../../../../../SharedFolder/services/notification.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { NgxMaterialTimepickerComponent } from 'ngx-material-timepicker';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';


@Component({
  selector: 'app-inventory-management',
  templateUrl: './inventory-management.component.html',
  styleUrls: ['./inventory-management.component.css']
})
export class InventoryManagementComponent implements OnInit {
  // @Input() gctSchedularType: string = '';
  // @Input() ModuleLevel: string = 'nokia';
  // @Input() SubModuleLevel: string = '';
  @ViewChild('paginatorBackup4') paginator4: MatPaginator;
  @ViewChild('fullTime') fullTime: NgxMaterialTimepickerComponent;
  @ViewChild('analyticsForm') analyticsForm: NgForm;
  @ViewChild('fetchInvDetailsForm') fetchInvDetailsForm: NgForm;
  @ViewChild('fetchModalForm') fetchModalForm: NgForm;
  @ViewChild('nodeSelectModalForm') nodeSelectModalForm: NgForm;
  @ViewChild('linkSelectModalForm') linkSelectModalForm: NgForm;
  reportTable = [];
  reportName: string;
  nodeDetailsArray = [];
  linkDetailsArray = [];
  networkTypes = [];
  nodes = [];
  checkAll: boolean;
  fetchcheckAll: boolean;
  invDetailsList = [];
  selectedIndex: number;
  nodeNumber: number;
  reportCategory: String;
  reportScope: String;
  generatedOn: String;
  GeneratedBy: String;
  generatedBY1: any;
  data1: any = [];
  dataraw: any = [];
  data2: any;
  item1: any;
  GeneratedType: string;
  checkVAll: boolean = false;
  isAllCircleSelected: boolean = false;
  circleList: any;
  circleValue = [];
  showCircleValue: string = 'All';
  ShowModel1: boolean = false;
  status: any;
  isSuccess: boolean = false;
  ViewReportIntial: boolean = false;
  offset4: number;
  pageSize4: number;
  // pageSizeOptions = [5, 10];
  length4: number;
  showpaginator: boolean = false;
  // constructor(private router: Router,
  //   private route: ActivatedRoute,
  //   private inventoryService: InventoryService,
  //   private optService: opticalModuleAPIService) { }
  matTabIndex: number;
  network: any;
  nodeSelectModal: boolean = false;
  neType: any = '';
  generateBoolean: boolean = false;
  startIndex: number = 0;
  batchSize: number = 100;
  invLinksList = [];
  linkNumber: number;
  eventKey: string;
  Status: any;
  inventoryType = [];
  neTypeFetch: string = '';
  networkFetch: string;
  fetchInvNodeNumber: number;
  nodefetchInvNodeArray = [];
  fetchInvDetailsList = [];
  fetchInvNodeModal: boolean = false;
  invTypeFetch: any;
  read: boolean;
  write: boolean;
  delete: boolean;
  linkSelectModal: boolean;
  gctSchedularType: any;
  disabled: boolean;



  // Prashant's 

  scheduleTypes = ['Inventory', 'Analytics'];


  pmMIN: Boolean = false;
  pmHR: Boolean = false;
  scheduleList: any[] = [];
  scheduleListTemp: any[] = [];
  scheduleDay: Number[] = [1, 2, 3, 4, 5, 6, 7];
  scheduleDayTemp: Number[] = [1, 2, 3, 4, 5, 6, 7];
  scheduleGctModal: boolean = false;
  scheduleGctModalSuccess: boolean = false;
  displaySuccess: string = '';
  tickEnable: boolean = false;
  allDaysToggleBtn: boolean = true;
  selectedTime: string = '';
  roleName: string = '';
  pageSize: number;
  offset: number;
  length: number;
  displayDelete: string = '';
  deleteGCTModal: boolean = false;
  selectedGUILabel: string = '';
  deleteStatus: boolean = false;
  toggleAllDays: number = 0;
  opticalModule: any;
  pageSizeOptions = [5, 10, 25, 100];
  @ViewChild('gctSchedulerForm') gctSchedulerForm: NgForm;
  Type: any;
  switchBackNodes: string[];
  pageIndex: any;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private optService: opticalModuleAPIService,
    private inventoryService: inventoryManagementService,
    private notificationService: NotificationService,
    private accessService: AccessService,
    private ngxService: SpinnerService,
    private session: SessionService,
  ) { }

  ngOnInit() {
    this.pageSize = 5;

    // this.roleName = this.session.get('roleName');
    this.roleName = this.session.get('roleName');
    if (this.roleName && this.roleName.includes('admin'))
      this.roleName = 'TelcoRole';
    console.log(this.roleName);

    console.log('this.invTypeFetch :>> ', this.invTypeFetch);
    this.checkAll = false;
    this.fetchcheckAll = false;
    this.selectedIndex = 0;
    this.offset4 = 0;
    this.pageSize4 = 10;
    // this.pageSize4 = 10;
    // this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'R');
    // this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'W');
    // this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'D');
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Inventory Management Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Inventory Management Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Inventory Management Module', 'D');
    console.log('this.write :>> ', this.write);
    console.log('delete', this.delete);
    this.reportName = "table";
    this.generatedBY1 = ["Auto-generated", "User generated"];

    console.log("this is circlelist", + this.circleList);
    this.status = "i am rready now you can carry on";
    this.onGenerated1();
    this.onGenerate2();


    this.networkTypes = ['NLD Core'];
    this.nodes = ['All', '5430', '6500'];
    this.switchBackNodes = ['5430'];
    this.inventoryType = ['All', 'Shelf', 'Card', 'Pluggable', 'Modules'];
    this.reportTable = [{
      "type": "Hardware Utilization Report",
      "name": "Slot utilization in shelf"

    },
    {
      "type": "Hardware Utilization Report",
      "name": "Port utilization in multi port card"

    },
    {
      "type": "Hardware Utilization Report",
      "name": "Switch matrix capacity utilization"

    },
    {
      "type": "Hardware Utilization Report",
      "name": "Backplane capacity utilization"

    },
    {
      "type": "Hardware Utilization Report",
      "name": "Unutilized hardware detail"

    },
    {
      "type": "Link Utilization Report",
      "name": "Wavelength utilization on photonic link"

    },
    {
      "type": "Link Utilization Report",
      "name": "Sub-wavelength utilization"
    }];

  }
  tabChanged(index) {
    this.selectedIndex = index;
    console.log('index :', index);
    if (index === 1) {
      this.checkAll = true;
      this.selectAll();
      this.checkAll = false;
    }
    console.log('this.checkAll :>> ', this.checkAll);
    this.getCheckedNodes();
    if (index === 2 && this.write) {
      // console.log("this.ViewReportIntial", + this.ViewReportIntial);
      // this.ViewReportIntial = true;
      this.isAllCircleSelected = true;
      this.getReportList();

    }
    if (index === 0 && !this.write) {
      // console.log("this.ViewReportIntial", + this.ViewReportIntial);
      // this.ViewReportIntial = true;
      this.isAllCircleSelected = true;
      this.getReportList();
    }
    if (index === 3 && this.write) {
      this.callGCTScheduler();
    }
    if (index === 1 && !this.write) {
      this.callGCTScheduler();
    }

  }


  onGenerateReport(item) {
    this.generateBoolean = true;
    console.log('item :>> ', item);
    switch (item) {
      case "Slot utilization in shelf":
        this.reportName = "slot";
        break;
      case "Port utilization in multi port card":
        this.reportName = "port";
        break;
      case "Switch matrix capacity utilization":
        this.reportName = "switchMatrix";
        break;
      case "Backplane capacity utilization":
        this.reportName = "backPlane";
        break;
      case "Unutilized hardware detail":
        this.reportName = "unutilized";
        break;
      case "Wavelength utilization on photonic link":
        this.reportName = "wavelength";
        break;
      case "Sub-wavelength utilization":
        this.reportName = "subWavelength";
        break;
    }
  }

  fetchinvNodeFunction() {
    this.fetchInvNodeNumber = undefined;
    this.invTypeFetch = undefined;
    this.ngxService.start();
    let headers = new HttpHeaders()
      .append('Netype', this.neTypeFetch)
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('nodeFetch headers are :>> ', headers);
    this.inventoryService.getNodesList(headers).subscribe(
      response => {
        this.ngxService.stop();
        console.log('response :>> ', response);
        this.nodefetchInvNodeArray = JSON.parse(response['body']);
      }
    );
  }

  getFetchCheckedNodes() {
    this.fetchInvDetailsList = [];
    this.nodefetchInvNodeArray.forEach(element => {
      if (element.checked == true) {
        this.fetchInvDetailsList.push({
          nename: element.nename,
          netype: element.netype
        });
      }
    });

    let count = 0;
    this.nodefetchInvNodeArray.forEach(data => {
      if (data.checked == true) {
        count++;
      }
    });
    if (count === this.nodefetchInvNodeArray.length) {
      this.fetchcheckAll = true;
    }
    else {
      this.fetchcheckAll = false;
    }
    this.fetchInvNodeNumber = this.fetchInvDetailsList.length;
    console.log('this.invDetailsList :>> ', this.fetchInvDetailsList);
  }

  fetchInvSelectAll() {
    this.nodefetchInvNodeArray.forEach(element => {
      console.log('this.table1 :', element.checked);
      console.log('this.checkAll :', this.fetchcheckAll);
      if (this.fetchcheckAll == false) {
        element.checked = true;
      }
      else {
        element.checked = false;
      }
      console.log('------------ :', element.checked);
    });

  }

  nodeModalFunction() {
    this.nodeNumber = undefined;
    this.linkNumber = undefined;
    this.deselectCheck();
    this.ngxService.start();
    let headers = new HttpHeaders()
      .append('Netype', this.neType)
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    console.log('nodeFetch headers are :>> ', headers);
    this.inventoryService.getNodesList(headers).subscribe(
      response => {
        this.ngxService.stop();
        console.log('response :>> ', response);
        this.nodeDetailsArray = JSON.parse(response['body']);
      }
    );
  }

  getCheckedNodes() {
    this.invDetailsList = [];
    this.nodeDetailsArray.forEach(element => {
      if (element.checked == true) {
        this.invDetailsList.push({
          nename: element.nename,
          netype: element.netype
        });
      }
    });

    let count = 0;
    this.nodeDetailsArray.forEach(data => {
      if (data.checked == true) {
        count++;
      }
    });
    if (count === this.nodeDetailsArray.length) {
      this.checkAll = true;
    }
    else {
      this.checkAll = false;
    }
    this.nodeNumber = this.invDetailsList.length;
    console.log('this.invDetailsList :>> ', this.invDetailsList);
  }

  selectAll() {
    this.nodeDetailsArray.forEach(element => {
      console.log('this.table1 :', element.checked);
      console.log('this.checkAll :', this.checkAll);
      if (this.checkAll == false) {
        element.checked = true;
      }
      else {
        element.checked = false;
      }
      console.log('------------ :', element.checked);
    });

  }

  linkModalFunction() {
    this.deselectCheck();
    this.inventoryService.getLinksList().subscribe(
      response => {
        console.log('response :>> ', response);
        this.linkDetailsArray = response['data'];
      }
    );
  }

  getLinkNodes() {
    this.invLinksList = [];
    this.linkDetailsArray.forEach(element => {
      if (element.checked == true) {
        this.invLinksList.push({
          z1nename: element.z1nename,
          a1nename: element.a1nename,
          omsname: element.omsname
        });
      }
    });

    let count = 0;
    this.linkDetailsArray.forEach(data => {
      if (data.checked == true) {
        count++;
      }
    });
    if (count === this.linkDetailsArray.length) {
      this.checkAll = true;
    }
    else {
      this.checkAll = false;
    }
    this.linkNumber = this.invLinksList.length;
    console.log('this.invLinksList :>> ', this.invLinksList);
  }

  selectAllLinks() {
    this.linkDetailsArray.forEach(element => {
      console.log('this.table1 :', element.checked);
      console.log('this.checkAll :', this.checkAll);
      if (this.checkAll == false) {
        element.checked = true;
      }
      else {
        element.checked = false;
      }
      console.log('------------ :', element.checked);
    });

  }

  submitReport() {
    let requestJson = {};
    switch (this.reportName) {
      case "slot":
        this.eventKey = "slotUtilAnalytics";
        requestJson = {
          "data": this.invDetailsList
        }
        break;
      case "port":
        this.eventKey = "portUtilAnalytics";
        requestJson = {
          "data": this.invDetailsList
        }
        break;
      case "switchMatrix":
        this.eventKey = "switchMatrixAnalytics";
        requestJson = {
          "data": this.invDetailsList
        }
        break;
      case "backPlane":
        this.eventKey = "backPlaneAnalytics";
        requestJson = {
          "data": this.invDetailsList
        }
        break;
      case "unutilized":
        this.eventKey = "unutilInvAnalytics";
        requestJson = {
          "data": this.invDetailsList
        }
        break;
      case "wavelength":
        this.eventKey = "wavelengthAnalytics";
        requestJson = {
          "data": this.invLinksList
        }
        break;
      case "subWavelength":
        this.eventKey = "subwavelengthAnalytics";
        requestJson = {
          "data": this.invLinksList
        }
        break;
    }
    this.ngxService.start();
    this.inventoryService.submitReport(this.eventKey, requestJson).subscribe(
      response => {
        this.ngxService.stop();
        this.analyticsForm.resetForm();
        console.log('response :>> ', response);
        this.Status = response.status;
        if (response['status_code'] == 410) {
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.notificationService.notificationMessage(this.Status, 'success');
        }
      }
    );
  }

  fetchInvDetailsReport() {
    this.ngxService.start();
    let requestJson = {
      "data": this.fetchInvDetailsList
    }
    let headers = new HttpHeaders().append('Inventory-Type', this.invTypeFetch);
    console.log('requestJson :>> ', requestJson);
    this.inventoryService.fetchInventoryDetails(requestJson, headers).subscribe(
      response => {
        this.ngxService.stop();
        this.fetchInvDetailsForm.resetForm();
        console.log('response :>> ', response);
        this.Status = response.status;
        if (response['status_code'] == 410) {
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.notificationService.notificationMessage(this.Status, 'success');
        }
      }
    );
  }

  backToMCP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  // Nageswar 
  onDownload(item) {
    this.data2 = item;
    let headers = new HttpHeaders().append('category', this.data2.category).append('scope', this.data2.scope).append('timestamp', this.data2.timestamp).append('User-Name', this.data2.username);
    this.inventoryService.downLoadReport(headers).subscribe((response) => {
      console.log('response :', response);
      //  console.log("hii this  nageswar");
      if (response["status_code"] == 200) {
        this.downloadFile(response);
      }
      else {
        this.status = response["status"];
        this.ShowModel1 = true;
        this.isSuccess = true;
      }

    })
  }
  downloadFile(response) {
    // console.log("In the download function");
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response['fileData']);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    // linkElement.target = '_blank';
    linkElement.download = response['fileName'];
    console.log(response);
    document.body.appendChild(linkElement);
    linkElement.click();
  }
  onGenerated(isAllCheckboxClicked) {
    console.log('this.circleList :', this.circleList);
    console.log('this.isAllCircleSelected :', this.isAllCircleSelected);
    if (isAllCheckboxClicked) {
      if (this.isAllCircleSelected) {
        this.circleValue = [];
        console.log('object :', "isAllCircleSelected");
        this.circleList.forEach((ele, index) => {
          this.circleList[index]['isChecked'] = true;
          this.circleValue.push(this.circleList[index]['value']);
        })
      }
      else {
        this.circleValue = [];
        this.circleList.forEach((ele, index) => {
          this.circleList[index]['isChecked'] = false;
        })
      }
    }
    else {
      if (this.isAllCircleClicked()) {
        this.isAllCircleSelected = true;

        console.log("all selected");
      }
      else {
        this.isAllCircleSelected = false;
        console.log("Not all selected");
      }
    }
    this.showCircleValue = this.circleValue.join();
    this.getReportList();

  }
  isAllCircleClicked() {
    let isAllCircleSelecetd = true;
    this.circleValue = [];
    console.log('this.circleList checked:', this.circleList);
    for (let i = 0; i < this.circleList.length; i++) {
      if (!this.circleList[i]['isChecked']) {
        isAllCircleSelecetd = false;
      }
      else {
        this.circleValue.push(this.circleList[i]['value']);
      }
    }

    return isAllCircleSelecetd;
  }
  onGenerated1() {
    this.circleList = this.inventoryService.getJSONFormat(this.generatedBY1);
  }
  onGenerate2() {
    if (this.write) {

    }
    else {
      this.isAllCircleSelected = true;
      this.getReportList();
    }
  }
  getReportList() {
    if (this.isAllCircleSelected) {
      this.ViewReportIntial = false;

      this.isAllCircleSelected = true;
      let headers = new HttpHeaders().append('Type', "All");
      //console.log("this.circleValue", + this.circleValue[0]);
      this.inventoryService.GetReportList(headers).subscribe((response) => {
        console.log('response :', response);
        if (response['status_Code'] == 200) {
          this.dataraw = response['data'];
          this.length4 = this.dataraw.length;
          this.showpaginator = true;
          // this.offset4 = 0;
          // this.pageIndex = 0;
          if (this.paginator4)
            this.paginator4.firstPage();
          this.data1 = this.dataraw.slice(0, this.pageSize4);
        }
        else {
          // this.showpaginator = false;
          this.status = response['status'];
          this.ShowModel1 = true;
          this.isSuccess = true;
        }
      })
    }
    else {
      let headers = new HttpHeaders().append('Type', this.circleValue.length > 0 ? this.circleValue[0] : "");
      this.inventoryService.GetReportList(headers).subscribe((response) => {
        console.log('response :', response);
        if (response['status_Code'] == 200) {
          // this.offset4 = 0;
          // this.pageIndex = 0;
          this.dataraw = response['data'];
          this.length4 = this.dataraw.length;
          this.showpaginator = true;
          if (this.paginator4)
            this.paginator4.firstPage();
          this.data1 = this.dataraw.slice(0, this.pageSize4);

        }
        else {
          // this.showpaginator = false;
          this.ShowModel1 = true;
          this.status = response['status'];
          this.isSuccess = true;
        }
      })
    }
  }
  deselectCheck() {
    this.checkAll = true;
    this.selectAll();
    this.checkAll = false;
  }
  onPageChanged4(e) {

    this.offset4 = e.pageIndex * e.pageSize;
    this.pageSize4 = e.pageSize;
    //this.pageIndex = e.pageIndex;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    if (secondCut > this.length4) {
      this.data1 = this.dataraw.slice(firstCut, this.length4);
    }
    else {
      this.data1 = this.dataraw.slice(firstCut, secondCut);
    }


  }



  // Prashant's functions

  callGCTScheduler() {
    console.log("callGCTScheduler(modelName)");
    // console.log('callGCTScheduler>>> ', this.gctSchedularType);
    this.inventoryService.callGCTScheduler()
      .subscribe(resp => {
        console.log(resp);
        // console.log(this.scheduleData);
        this.scheduleList = resp.map(element => {
          const curElement = element['data'];
          const time = this.timeformat(curElement['hour'], curElement['minute'].toString());
          const newWeekOfDay = new Array(7).fill(-1);
          this.scheduleDay.forEach((day, index) => {
            if (curElement['daysOfWeek'].findIndex(curDay => curDay === day) !== -1)
              newWeekOfDay[index] = index + 1;
          })
          console.log(newWeekOfDay);
          const obj = {
            scheduleTime: time,
            scheduleDays: newWeekOfDay,
            schedulerName: element['schedulerName'],
            schedulerType: element['data']['type']
          };
          console.log(obj);

          //       if (this.gctSchedularType == EventConstants.GCT_PM_SCHEDULER_NAME) {
          //         obj['granularity'] = curElement['granularity'];
          //       }
          return obj;

        });
        console.log(this.scheduleList);
        this.scheduleListTemp = [];
        if (this.scheduleList.length > 0) {
          // this.gctDetailsFlag = false;
          this.length = this.scheduleList.length;
          if (this.scheduleList.length > this.pageSize)
            this.scheduleListTemp = this.scheduleList.slice(0, this.pageSize);
          else
            this.scheduleListTemp = this.scheduleList;
        }

        console.log('schedule List>>>> ', this.scheduleListTemp);
      })
  }


  onPageChanged(e) {
    console.log(e);
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.scheduleListTemp = this.scheduleList.slice(firstCut, secondCut);
  }

  timeformat(hour = 0, min = '0') {
    const x = hour >= 12 ? 'pm' : 'am';
    hour = hour % 12;
    hour = hour ? hour : 12;
    min = Number(min) < 10 ? '0' + min : min;
    const mytime = hour + ':' + min + ' ' + x;
    return mytime;
  }

  dayOfCurrentNum(num) {
    switch (num) {
      case 1: return 'Sun'
      case 2: return 'Mon'
      case 3: return 'Tue'
      case 4: return 'Wed'
      case 5: return 'Thu'
      case 6: return 'Fri'
      case 7: return 'Sat'

    }
  }

  showSeletedTime() {
    console.log(this.selectedTime);
  }

  CancelGCTSchedule(scheduleName, scheduleType, index) {
    console.log("CancelGCTSchedule(scheduleName, index)");

    // let modelName = this.ModuleLevel;
    console.log('CancelGCTSchedule >>>> ', scheduleName);
    console.log('CancelGCTSchedule >>>> ', scheduleType);


    this.ngxService.start();
    let headers = new HttpHeaders()
      .append('Scheduler-Name', scheduleName)
      .append('Type', scheduleType)
    this.inventoryService.CancelGCTSchedule(headers).subscribe(
      res => {
        this.ngxService.stop();
        console.log(res);
        if (res['status_code'] === 200) {
          this.tickEnable = true;
          //       if (modelName === "nokia") {
          //         this.displaySuccess = res['state'];
          //       }
          //       else {
          this.displaySuccess = res['status'];
          // }
          console.log('this.displaySuccess :', this.displaySuccess);
          this.scheduleGctModalSuccess = true;
          this.callGCTScheduler();
        }
        else {
          this.tickEnable = false;
          //       if (modelName === "nokia") {
          //         this.displaySuccess = res['state'] ? res['state'] : 'Unknow Error';
          //       }

          //       else {
          this.displaySuccess = res['status'] ? res['status'] : 'Unknown Error';
          //       }
          this.scheduleGctModalSuccess = true;
        }
      })


  }

  scheduleGCT() {
    console.log("scheduleGCT");
    // this.opticalModule = this.ModuleLevel;
    // console.log("schedule gct >>> ", this.pmHR, this.pmMIN)
    const filterDay = this.scheduleDayTemp.filter(day => day !== -1);
    let hour = this.selectedTime.split(':')[0];
    let min = this.selectedTime.split(':')[1];

    hour = hour[0] == '0' ? hour[1] : hour;
    min = min[0] == '0' ? min[1] : min;
    console.log(this.selectedTime, 'hour>>>', hour, 'and minute >>>> ', min);
    const requestJson = {
      'hour': hour,
      'minute': min,
      'daysOfWeek': filterDay
    }
    // if (this.gctSchedularType === EventConstants.GCT_PM_SCHEDULER_NAME)
    //   requestJson['granularity'] = (this.pmMIN == true && this.pmHR == true) ? 'both' : this.pmMIN ? '15min' : '24hr';

    console.log('requestJson >>>>', requestJson);
    console.log(this.Type);
    this.ngxService.start();
    let headers = new HttpHeaders()
      .append('Type', this.Type)
    this.inventoryService.scheduleGCT(headers, requestJson).subscribe(
      res => {
        this.ngxService.stop();
        console.log(res);
        if (res['status_code'] === 200) {
          //       if (this.opticalModule === 'nokia')
          //         this.displaySuccess = res['state'];
          //       else
          this.displaySuccess = res['status'];
          this.tickEnable = true;
          this.scheduleGctModalSuccess = true;
          this.callGCTScheduler();
          //       this.pmHR = false;
          //       this.pmMIN = false;
        }
        else {
          //       if (this.opticalModule === "nokia") {
          //         this.displaySuccess = res['state'];
          //       }
          //       else {
          this.displaySuccess = res['status'];
          //       }
          this.tickEnable = false;
          this.scheduleGctModalSuccess = true;
        }
      })
  }

  toggleMatChip(day, i) {
    if (day == -1) this.toggleAllDays++;
    else this.toggleAllDays--;

    this.scheduleDayTemp[i] = day == -1 ? i + 1 : -1;
  }

  resetAllDays() {
    if (this.allDaysToggleBtn == false) {
      this.toggleAllDays = 0;
      this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => -1);
    }
    else {
      this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => i + 1);
    }

    console.log('callled reset function called ', this.scheduleDayTemp)
  }

  resetScheduleModalData() {
    this.pmMIN = false;
    this.pmHR = false;
    this.selectedTime = '';
    this.allDaysToggleBtn = true;
    this.toggleAllDays = 0;
    this.scheduleDayTemp = this.scheduleDayTemp.map((data, i) => i + 1);


  }


}
