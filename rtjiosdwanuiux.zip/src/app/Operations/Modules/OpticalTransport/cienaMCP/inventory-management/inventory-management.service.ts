import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
@Injectable({
    providedIn: 'root'
})
export class inventoryManagementService {
    constructor(private commonService: SdWanServiceService) { }

    getNodesList(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, header, null, EventConstants.CIENA_INVENTORY_NODELIST_TYPE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }

    getLinksList(): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, null, null, EventConstants.CIENA_INVENTORY_LINKSLIST_TYPE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }

    submitReport(eventKey, reqJson): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_INVENTORY_MANAGEMENT, reqJson, null, null, eventKey).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }

    fetchInventoryDetails(reqJson, headers): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_INVENTORY_MANAGEMENT, reqJson, headers, null, EventConstants.CIENA_FETCH_INVENTORY_TYPE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }

    CancelGCTSchedule(header): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('DELETE', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, header, null, EventConstants.CIENA_INVENTORY_CANCEL_SCHEDULED_REPORT).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }
    scheduleGCT(header, reqJson): Observable<any> {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_INVENTORY_MANAGEMENT, reqJson, header, null, EventConstants.CIENA_INVENTORY_SCHEDULE_REPORT).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );
    }
    callGCTScheduler(): Observable<any> {
        return new Observable<any>(observer => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, null, null, EventConstants.CIENA_INVENTORY_GET_SCHEDULED_REPORTS)
                .subscribe(response => {
                    console.log(response);
                    observer.next(JSON.parse(response['body']));
                })
        })

        // return new Observable<any>(observe => {
        //     this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, null, null, EventConstants.CIENA_INVENTORY_GET_SCHEDULED_REPORTS).subscribe(
        //         (response) => {
        //             observer.next(JSON.parse(response['body']));
        //             console.log(response);
        //             observe.next(response);
        //         }
        //     );
        // }
        // );
    }
    downLoadReport(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, header, null, EventConstants.CIENA_DOWNLOAD_REPORT).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    GetReportList(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_INVENTORY_MANAGEMENT, null, header, null, EventConstants.CIENA_GET_REPORT_LIST).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    getJSONFormat(circleData) {
        return circleData.map((ele) => {
            return {
                value: ele,
                isChecked: true
            }
        })
    }
}