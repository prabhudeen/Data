import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CienaService } from '../ciena.service';
import { TooltipPosition, MatPaginator } from '@angular/material';
import swal from 'sweetalert2';
import { HttpHeaders } from '@angular/common/http';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { ExcelService } from '../../../../../SharedFolder/services/excel.service';
import { DatePipe } from '@angular/common';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { Workbook, WorkbookSheetColumn, WorkbookSheetRow, WorkbookSheetRowCell, WorkbookSheet } from '@progress/kendo-angular-excel-export';
import { saveAs } from '@progress/kendo-file-saver';
declare var $: any;


@Component({
  selector: 'app-ciena-bod',
  templateUrl: './ciena-bod.component.html',
  styleUrls: ['./ciena-bod.component.css']
})
export class CienaBodComponent implements OnInit, OnDestroy {
  toolTipPostion: TooltipPosition = "above";
  cienaSCNMRequestJson: {};
  // demandRate = ['DSR_10GE', 'DSR_100GE', 'ODU2', 'ODU2e', 'ODU4', 'DSR_OC192_STM64', 'DSR_OC48_STM16'];
  demandRate = ['10 GbE', '100 GbE', 'ODU2', 'ODU4', 'STM-64', 'STM-16', 'STM-4', 'STM-1', 'ODU0', 'ODU2E', 'OC-3', 'OC-12', 'OC-48', 'OC-192'];
  recilencyType = ['MESH_RESTORABLE', 'PERMANENT'];
  aendZendShelf = ['A', 'C'];
  aendZendSlot = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15'];
  retainList = [];
  @ViewChild('cienaSNCForm') cienaSNCForm: NgForm;
  @ViewChild('cienaSNCForm1') cienaSNCForm1: NgForm;
  @ViewChild('paginator') paginator: MatPaginator;
  fileUrl;
  demandType = ['SNC-MR', 'SNCP-MR'];
  demandTypeValue: any;
  demandBoolean: boolean = false;
  aendArray = [];
  serviceOrderId: string;
  index: number;
  offset: number;
  fileName = '';
  file: File;
  from: any = '';
  to: any = '';
  aendNE = '';
  zendNE = '';
  showTable: boolean = false;
  public min = new Date();
  public minDate = new Date();
  CIENA_BOD = 'CIENA BOD';
  bodDetailsFlag = false;
  length: number;
  deleteStatus: boolean = false;
  deleteJSON: any = {};
  displayDelete: string;
  pageSizeOptions = [5, 10, 20, 30, 50];
  bodDetails = [];
  bodDetailsTemp = [];
  excelBodDetails = [];
  pageSize: number;
  matTabIndex: number = 0;
  read: boolean;
  write: boolean;
  delete: boolean;
  deleteGCTModal: boolean = false;
  afterdeleteGCTModal: boolean = false;
  checked: boolean = false;
  checkedBulk: boolean = false;
  validated: boolean = false;
  validatedFileName: any = '';
  validatedFile: any;
  beforeValidate: boolean = true;
  demandDisplayName: any;
  validatedResponse: any;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private service: CienaService,
    private ngxService: SpinnerService,
    private accessService: AccessService,
    private optService: opticalModuleAPIService,
    private excelService: ExcelService,
    private datePipe: DatePipe) { }


  onPageChanged(e) {
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.bodDetailsTemp = this.bodDetails.slice(firstCut, secondCut);
  }

  setDateAndTime() {
    setTimeout(() => {
      this.min = this.from;
    }, 10);
    this.minDate = new Date(new Date().getTime());
    this.showTable = false;
    console.log("showTable is:", this.showTable);
  }

  onDateChange() {
    this.min = this.from;
    this.minDate = new Date(new Date().getTime());
  }

  ngOnInit() {
    console.log("from date is:", this.min);

    this.retainList = [false, true];
    this.pageSize = 5;
    this.offset = 0;
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Bandwidth on Demand Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Bandwidth on Demand Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP Bandwidth on Demand Module', 'D');

    if (this.write) {
      this.matTabIndex = 0;
    } else {
      this.matTabIndex = 1;
    }
  }

  onAendLoad() {
    this.service.getAendZend().subscribe(res => {
      if (res['status_code'] == 410) {
        this.displayDelete = res['status'];
        this.deleteStatus = false;
        this.afterdeleteGCTModal = true;
      } else {
        this.aendArray = res['data'];
        console.log('got Aend Zend response...');
      }
    });
  }

  onSubmitCiena() {
    if (this.cienaSNCForm1.value['demandType'] == 'SNC-MR') {
      this.cienaSCNMRequestJson = {
        "circuit_type": this.cienaSNCForm1.value['demandType'],
        "label": this.cienaSNCForm1.value["demandLabel"],
        "work_DTL": this.cienaSNCForm1.value["workDTL"],
        "properties": {
          // "name": this.cienaSNCForm1.value["demandName"],
          "layerRate": this.cienaSNCForm1.value["demandRate"],
          "endPointA": [
            {
              "shelf": this.cienaSNCForm1.value["aendShelf"],
              "networkElement": {
                "name": this.cienaSNCForm1.value.aendNE
              },
              "port": this.cienaSNCForm1.value["AendPort"].toString(),
              "slot": this.cienaSNCForm1.value["aendSlot"]
            }
          ],
          "endPointZ": [
            {
              "shelf": this.cienaSNCForm1.value["zendShelf"],
              "networkElement": {
                "name": this.cienaSNCForm1.value.zendNE
              },
              "port": this.cienaSNCForm1.value["zendPort"].toString(),
              "slot": this.cienaSNCForm1.value["zendSlot"]
            }
          ],

          "sncAttributes": {
            "controlPlanePackage": {
              "resiliencyType": this.cienaSNCForm1.value["reciliencyType"],
              "rhp": this.cienaSNCForm1.value["retainHomePath"]
            }
          }

        }
      }


      if (this.checked === true) {
        this.cienaSCNMRequestJson = this.cienaSCNMRequestJson;
      }

      else {
        delete this.cienaSCNMRequestJson['work_DTL'];
        this.cienaSCNMRequestJson = this.cienaSCNMRequestJson;
        console.log("deleted JSON impli SCN", this.cienaSCNMRequestJson);

      }

    } else {
      this.cienaSCNMRequestJson = {
        "circuit_type": this.cienaSNCForm1.value['demandType'],
        "label": this.cienaSNCForm1.value["demandLabel"],
        "work_DTL": this.cienaSNCForm1.value["workDTL"],
        "protect_DTL": this.cienaSNCForm1.value["protectDTL"],
        "properties": {
          //"name": this.cienaSNCForm1.value["demandName"],
          "layerRate": this.cienaSNCForm1.value["demandRate"],
          "endPointA": [
            {
              "protServiceEndpoint": {
                "shelf": this.cienaSNCForm1.value["aendShelf"],
                "networkElement": {
                  "name": this.cienaSNCForm1.value.aendNE
                },
                "port": this.cienaSNCForm1.value["AendPort"].toString(),
                "slot": this.cienaSNCForm1.value["aendSlot"]
              }
            }
          ],
          "endPointZ": [
            {
              "protServiceEndpoint": {
                "shelf": this.cienaSNCForm1.value["zendShelf"],
                "networkElement": {
                  "name": this.cienaSNCForm1.value.zendNE
                },
                "port": this.cienaSNCForm1.value["zendPort"].toString(),
                "slot": this.cienaSNCForm1.value["zendSlot"]
              }
            }
          ],

          "workSncAttributes": {
            "controlPlanePackage": {
              "resiliencyType": this.cienaSNCForm1.value["reciliencyType"],
              "rhp": this.cienaSNCForm1.value["retainHomePath"]
            }
          },

          "protectSncAttributes": {
            "controlPlanePackage": {
              "resiliencyType": this.cienaSNCForm1.value["reciliencyType"],
              "rhp": this.cienaSNCForm1.value["retainHomePath"]

            }
          }
        }
      }


      if (this.checked === true) {
        this.cienaSCNMRequestJson = this.cienaSCNMRequestJson;
      }

      else {
        delete this.cienaSCNMRequestJson['work_DTL'];
        delete this.cienaSCNMRequestJson['protect_DTL'];
        this.cienaSCNMRequestJson = this.cienaSCNMRequestJson;
        console.log("deleted JSON impli SCMR", this.cienaSCNMRequestJson);
      }
    }

    console.log("final sending JSON", this.cienaSCNMRequestJson);
    //this.ngxService.start();
    console.log('this.checked :', this.checked);
    this.service.singleProvisioning(this.cienaSCNMRequestJson, this.checked).
      subscribe(response => {
        //  this.ngxService.stop();
        console.log(JSON.stringify(response));
        this.cienaSNCForm1.reset();
        this.checked = false;
        if (response.status_code == 409) {
          this.showSwalWarning(this.CIENA_BOD, response.status);
        }
        else if (response.status_code === 200) {
          console.log('onSubmit success...');
          this.showSwal(this.CIENA_BOD, response.status);
        }
      });
  }

  getServiceDetailsRequest() {
    let oldtimestamp = Date.parse(this.from).toString();
    let latesttimestamp = Date.parse(this.to).toString();
    let headers = new HttpHeaders()
      .append('oldtimestamp', oldtimestamp)
      .append('latesttimestamp', latesttimestamp);
    this.ngxService.start();
    this.service.getServiceDetailsRequest(headers).
      subscribe(res => {
        this.ngxService.stop();
        this.showTable = true;
        this.bodDetails = JSON.parse(res);
        this.excelBodDetails = JSON.parse(res);
        this.length = this.bodDetails.length;
        this.excelBodDetails.forEach(element => {
          element['timeStamp'] = this.datePipe.transform(element['timeStamp'], 'medium');
          console.log("filtered stamp", element['timeStamp']);
        });


        this.bodDetailsTemp = this.bodDetails.slice(0, this.pageSize);
        if (this.paginator)
          this.paginator.firstPage();
        if (this.bodDetails.length > 0) {
          this.bodDetailsFlag = false;
        }
        else this.bodDetailsFlag = true;
        // this.from = '';
        // this.to = '';
      });
  }


  uploadFile() {
    this.ngxService.start();
    this.service.uploadBulkFile(this.validatedResponse, this.checkedBulk).
      subscribe(res => {
        this.ngxService.stop();
        if (res['status_code'] == 200) {
          this.showSwal('CIENA BULK BOD', this.validatedFileName + " " + res.status);
          this.validatedFileName = '';
          this.fileName = '';
          this.validated = false;
          this.beforeValidate = true;
        }
      });
  }


  selectedFile(event) {
    this.file = event.target.files[0];
    this.fileName = this.file.name;
    this.validated = false;
    this.beforeValidate = true;
    this.validatedFileName = '';
    console.log(this.file);
    console.log('uploaded..');
  }

  downloadTemplate() {
    this.service.downloadTemplate(this.checkedBulk).
      subscribe(res => {
        console.log(res)
        this.downloadFile(res);
      });
  }

  downloadFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response['fileData']);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    // linkElement.target = '_blank';
    linkElement.download = response['fileName'];
    console.log(response);
    document.body.appendChild(linkElement);
    linkElement.click();
  }


  onValidate() {
    this.ngxService.start();
    this.service.validatePorts(this.checkedBulk, this.file).
      subscribe(res => {
        this.ngxService.stop();
        this.validatedResponse = res;
        this.validatedFileName = res['fileName'];
        this.validatedFile = res['fileData'];
        this.beforeValidate = false;
        if (res['status_code'] == 2000) {
          this.showSwal('PORTS VALIDATED SUCCESSFULLY', this.validatedFileName + " " + res.status);
          this.validated = true;
          console.log('this.validated :', this.validated);
        }

        if (res['status_code'] == 410) {
          this.showSwalWarning('TEMPLATE VALIDATION FAILED', res.status);
          this.validated = false;
        }

        if (res['status_code'] == 4001) {
          this.showSwalWarning('PORT VALIDATION FAILED', this.validatedFileName + " " + res.status);
          this.validated = false;
        }
      });
  }

  downloadValidatedTemplate() {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(this.validatedFile);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    linkElement.download = this.validatedFileName;
    document.body.appendChild(linkElement);
    linkElement.click();
  }

  backToMCP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  showSwal(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-success",
      type: "success"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop);

  }

  showSwalWarning(moduleName: string, message: string) {
    swal({
      title: moduleName,
      text: message,
      buttonsStyling: false,
      confirmButtonClass: "btn btn-danger",
      type: "warning"
    }).then((result) => {
      // this.backToMCP();
    }).
      catch(swal.noop);

  }

  beforeDelete(bodItem, index) {
    console.log("index", index);
    this.deleteJSON = {
      "ZendNE": bodItem['ZendNE'],
      "layerRate": bodItem['layerRate'],
      "AendNE": bodItem['AendNE'],
      "source": bodItem['source'],
      "destination": bodItem['destination']
    }
    this.demandDisplayName = bodItem["demandName"];
    this.index = this.offset + index;
    console.log("offset:", this.offset);

    console.log("offset index", this.index);
    // $('#deleteGCTModal').modal('show');
    this.deleteGCTModal = true;
  }

  onDeleteBOD() {
    console.log("inside on delete");
    console.log('this.deleteJSON :', this.deleteJSON);
    this.ngxService.start();
    this.service.deleteBODDetails(this.deleteJSON).subscribe(
      (response) => {
        this.ngxService.stop();
        console.log("res inside", response);
        this.displayDelete = response['status'];
        if (response['status_code'] == 200) {
          this.deleteStatus = true;
          // $('#afterdeleteGCTModal').modal('show');
          this.afterdeleteGCTModal = true;
          this.bodDetails.splice(this.index, 1);
          this.excelBodDetails.splice(this.index, 1);
          this.length = this.bodDetails.length;
          if (this.bodDetails.length > 0) {
            this.bodDetailsFlag = false;
          }
          else this.bodDetailsFlag = true;
          console.log("bodDetails", this.bodDetails);
          this.bodDetailsTemp = this.bodDetails.slice(0, 5);
          if (this.paginator)
            this.paginator.firstPage();
        }
        else {
          this.deleteStatus = false;
          //$('#afterdeleteGCTModal').modal('show');
          this.afterdeleteGCTModal = true;
          setTimeout(() => this.getServiceDetailsRequest(), 1000);
        }
      }
    );
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }

  exportAsXLSX() {
    //this.excelService.exportAsExcelFile(this.excelBodDetails, 'BOD Details');
    this.exportNewWorkbook();
  }

  //functon which export excel
  list: any[] = [];
  public exportNewWorkbook() {
    this.list.push({
      cells: <WorkbookSheetRowCell[]>[
        // First cell
        { value: 'AendNE' },
        // Second cell
        { value: 'ZendNE' },
        { value: 'source' },
        { value: 'destination' },
        // { value: 'AendShelf' },
        // { value: 'ZendShelf' },
        // { value: 'Aend_Slot' },
        // { value: 'Zend_Slot' },
        // { value: 'Aend_Port' },
        // { value: 'Zend_Port' },
        { value: 'layerRate' },
        { value: 'username' },
        { value: 'demandName' },
        { value: 'isServiceCreated' },
        { value: 'timeStamp' },
        { value: 'Failure Reason' }


      ]
    });
    // this.bodDetails = JSON.parse(JSON.stringify(this.bodDetails));
    console.log(this.bodDetails);
    this.bodDetails.forEach(item => {

      this.list.push({
        cells: <WorkbookSheetRowCell[]>[
          // First cell
          { value: item["AendNE"] },
          // Second cell
          { value: item["ZendNE"] },
          { value: item["source"] },
          { value: item["destination"] },
          // { value: item["AendShelf"] },
          // { value: item["ZendShelf"] },
          // { value: item["Aend_Slot"] },
          // { value: item["Zend_Slot"] },
          // { value: item["Aend_Port"] },
          // { value: item["Zend_Port"] },
          { value: item["layerRate"] },
          { value: item["username"] },
          { value: item["demandName"] },
          { value: item["isServiceCreated"] == true ? "True" : "False" },
          { value: this.datePipe.transform(item['timeStamp'], 'medium') },
          { value: item["Failure Reason"] ? item["Failure Reason"] : "" }
        ]
      })
    });
    console.log(this.list);
    const workbook = new Workbook({
      sheets: <WorkbookSheet[]>[
        {
          // Column settings (width)
          columns: <WorkbookSheetColumn[]>[
            { autoWidth: true },
            { autoWidth: true }
          ],
          // Title of the sheet
          name: 'Customers',
          // Rows of the sheet
          rows: <WorkbookSheetRow[]>[
            // First row (header)

            // Second row (data)
            ...this.list
          ]
        }
      ]
    });
    workbook.toDataURL().then(dataUrl => {
      saveAs(dataUrl, 'BOD-LOG-Details.xlsx');
    });
  }

  onChange() {
    console.log('this.checked :', this.checked);
  }

  onDemandChange(demand) {
    if (demand == 'SNC-MR') {
      this.demandBoolean = false;
    }
    else {
      this.demandBoolean = true;
    }
    console.log('this.demandBoolean :', this.demandBoolean);
  }

  ngOnDestroy() {
    this.ngxService.stop();
  }


}
