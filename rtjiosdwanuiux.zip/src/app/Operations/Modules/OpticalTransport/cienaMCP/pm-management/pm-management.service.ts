import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../../../SharedFolder/constants/eventConstants';
@Injectable({
    providedIn: 'root'
})
export class PmManagementService {
    constructor(private commonService: SdWanServiceService) { }

    getNodeDataForResourceType(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, header, null, EventConstants.CIENA_GET_NODEDATA_RESOURCE_TYPE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    // getPortLevelPmMultinode(header, body): Observable<any> {

    //     return new Observable<any>(observe => {
    //         this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, body, header, null, EventConstants.CIENA_GET_PORT_LEVEL_PM_MULTINODE).subscribe(
    //             (response) => {
    //                 console.log(response);
    //                 observe.next(response);
    //             }
    //         );
    //     }
    //     );

    //  }

    getDemandsForNode(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, header, null, EventConstants.CIENA_GET_DEMANDS).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    demandPm(body): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_PM_MANAGEMENT, body, null, null, EventConstants.CIENA_GET_DEMAND_PM).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }

    getPmCounter(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, header, null, EventConstants.CIENA_GET_PM_Counters).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    getDemandTrend(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, header, null, EventConstants.CIENA_GET_DEMAND_TREND).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }


    // RunTableData(json) {
    //     // let header = 
    //     return new Observable<any>(observe => {
    //         this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, json, null, null, EventConstants.CIENA_GET_PMDEMANDPM).subscribe(
    //             (response) => {
    //                 console.log(response);
    //                 observe.next(response);
    //             }
    //         );
    //     }
    //     );
    // }

    portLevelPmMultinode(header, Json): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.CIENA_PM_MANAGEMENT, Json, header, null, EventConstants.CIENA_PORT_LEVEL_PM_MULTINODE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }

    viewPmNodeDetails(header): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, header, null, EventConstants.CIENA_PORT_LEVEL_VIEW_PM_MULTINODE).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }

    getAllCountersForCategory(headers): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, headers, null, EventConstants.CIENA_PORT_COUNTERS_ALL_CATEGORY).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }

    viewPmTrendForCounter(headers): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, headers, null, EventConstants.CIENA_PORT_VIEW_PM_TREND_FOR_COUNTER).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }

    downloadPortLevelPmReport(headers): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, headers, null, EventConstants.CIENA_DOWNLOAD_PORT_LEVEL_PM_REPORT).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }
    downloadDemand(headers): Observable<any> {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CIENA_PM_MANAGEMENT, null, headers, null, EventConstants.CIENA_DOWNLOAD_DEMAND).subscribe(
                (response) => {
                    console.log(response);
                    observe.next(response);
                }
            );
        }
        );

    }



}