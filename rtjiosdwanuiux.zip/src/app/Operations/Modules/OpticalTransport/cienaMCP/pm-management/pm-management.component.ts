import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { opticalModuleAPIService } from '../../opticalTransportModule_API.service';
import { FormGroup, FormControl, NgForm, FormsModule } from '@angular/forms';
import { PmManagementService } from './pm-management.service';
import { HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { MatPaginator } from '@angular/material';
import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { NotificationService } from '../../../../../SharedFolder/services/notification.service';


declare var Highcharts: any;

@Component({
  selector: 'app-pm-management',
  templateUrl: './pm-management.component.html',
  styleUrls: ['./pm-management.component.css']
})
export class PMManagementComponent implements OnInit, OnDestroy {

  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('pmPortLevelForm') pmPortLevelForm: NgForm;
  @ViewChild('demandForm') demandForm: NgForm;
  @ViewChild('counterForm') counterForm: NgForm;
  @ViewChild('demandGraphForm') demandGraphForm: NgForm;
  //--------------HARD CODED VALUES--------------------------//
  nodes = [];
  nodeList = [];
  nodesList = new FormGroup({
    selected: new FormControl([])
  });

  netypes: string[];
  pmtypes: string[];
  durations: string[];
  colspancount: number;
  maxArrow: number;


  public maxFrom = new Date(new Date().getTime());
  public minFrom = new Date(new Date().getTime() - 155520000000000);
  public maxTo = new Date(new Date().getTime());
  public minTo = new Date(new Date().getTime() - 155520000000000);

  from: any = '';
  to: any = '';
  neType: any;
  pmType: any;
  durationType: any;
  // prashant
  public maxFrom2 = new Date(new Date().getTime());
  public minFrom2 = new Date(new Date().getTime() - 155520000000000);
  public maxTo2 = new Date(new Date().getTime());
  public minTo2 = new Date(new Date().getTime() - 155520000000000);

  ///Himaja
  matTabIndex: any;
  opened = -1;
  offset: number;
  pageSize: number;
  pageSizeOptions = [10, 20, 30, 50];
  startIndex: number = 0;
  batchSize: number = 100;
  tableShow: boolean = false;
  portLevelPMArray = [];
  tempPortLevelPMArray = [];
  portLevelPMArrayFlag: boolean = false;
  footer: boolean = false;
  length: number = 0;
  viewPortLevelJSON = {};
  actualPortLevelJSON = {};
  pmManagementModal: boolean = false;
  pmCounterArray = [];
  counterArray = [];
  pmCounterList = new FormGroup({
    selected: new FormControl([])
  });
  selectedNodeName: string;
  selectedPort: string;
  graphJSON1: { unit: string; data: ({ "Collection-Time": string; value: string; } | { "Collection-Time": string; value?: undefined; })[]; name: string; };
  arrowIndex1: number;
  graphYAxis1: any;
  graphXAxis1: any;
  slider1: boolean = false;
  from2: any = '';
  to2: any = '';
  neType2: any;
  pmType2: any;
  durationType2: any;
  demandData = [];
  nodes2: string[];
  node2: any;
  demandType: any;
  selectedIndex: any;
  demandAttributes: any;
  pmCounts = [];
  ends: string[];
  endType: any;
  pmCount: any;
  cienaServiceModal: boolean;
  arrowIndex: number;
  graphYAxis: number[];
  graphXAxis: number[];
  // graphJson: { unit: string; data: ({ "Collection-Time": string; value: string; } | { "Collection-Time": string; value?: undefined; })[]; name: string; };
  slider: boolean;
  pmCounterValue: string;
  read: boolean;
  write: boolean;
  delete: boolean;
  boolCounterDemandEnable: boolean = false;
  getBatchBool: boolean = true;


  //nageswar
  dtable: any;
  dtable1: any;
  data1: any;
  headerdata: any;
  maxArrow1: number;
  tableShow2: boolean = false;
  dName: any;
  Aend: any;
  rate: any;
  Zend: any;
  Rtype: any;
  graphJson: { unit: string; data: { "Collection-Time": string; value: string; valueInMillis: number; }[]; name: string; };
  pmtypes2: string[];
  Status: any;
  nodesListValue: string;


  constructor(
    private optService: opticalModuleAPIService,
    private pmservice: PmManagementService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: SpinnerService,
    private accessService: AccessService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.pageSize = 10;
    this.selectedIndex = 0;
    this.netypes = ['5430', '6500'];
    this.pmtypes = ['Ethernet', 'Analog', 'OTN'];
    this.pmtypes2 = ['Ethernet', 'OTN'];
    this.durations = ['15_MINUTE', '24_HOUR'];
    this.ends = ['Aend', 'Zend'];
    this.dtable1 = [];
    this.dtable = ["BBE",
      "CSES",
      "ES",
      "SES",
      "UAS"
    ];
    this.colspancount = 5;
    this.read = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'R');
    this.write = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'W');
    this.delete = this.accessService.getAccessForSubModule('Optical Transport', 'Ciena MCP PM Management Module', 'D');
    console.log('this.write :>> ', this.write);
    console.log('this.neType :>> ', this.neType);
    console.log('this.node2 :>> ', this.node2);

    this.nodesList.valueChanges.subscribe(data => {
      this.nodesListValue = JSON.stringify(data['selected']);
      console.log('value is :>> ', JSON.stringify(data['selected']));
      console.log('this.pmType :>> ', this.pmType);
      this.pmType = '';
    });

  }

  ///himaja
  getPortLevelPmData() {
    this.spinner.start(60000 * 5);
    let headers = new HttpHeaders()
      .append('From', this.startIndex.toString())
      .append('Batch-Size', this.batchSize.toString());
    let requestJson: {};
    requestJson = {
      "neType": this.neType,
      "pmType": this.pmType,
      "duration": this.durationType,
      "startTime": Date.parse(this.from).toString(),
      "endTime": Date.parse(this.to).toString(),
      "nodeData": this.nodesList.value['selected'],
      "forwardRequest": this.getBatchBool.toString()
    };
    console.log("Request Json -->", requestJson);
    this.pmservice.portLevelPmMultinode(headers, requestJson).subscribe(
      response => {
        this.spinner.stop();
        console.log('response in pmPortMultiNode :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.footer = true;
          this.actualPortLevelJSON = response;
          this.portLevelPMArray = response['data'];
          this.length = response['headers']['Total'];
          this.tempPortLevelPMArray = this.portLevelPMArray.slice(0, this.pageSize);
          // if (this.paginator)
          //   this.paginator.firstPage();
          if (this.length > 0) {
            this.tableShow = true;
            this.footer = true;
            this.portLevelPMArrayFlag = false;
          }
          else {
            this.portLevelPMArrayFlag = true;
            this.footer = false;
          }
        }
      });

  }


  getNodesTab2() {
    this.spinner.start();
    this.demandData = [];
    this.node2 = '';
    console.log("node2 value is:" + this.node2);
    console.log("Nodes tab 2 called");

    let headers = new HttpHeaders()
      .append('NeType', this.neType2.toString())

    console.log('---headers :----', headers);
    this.pmservice.getNodeDataForResourceType(headers).subscribe(
      (response) => {
        this.spinner.stop();
        console.log('Nodes 2 Response :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.nodes2 = JSON.parse(response['body']);
          console.log('this.nodes2 :>> ', this.nodes2);
        }
      });

  }

  onPageChanged(e) {
    this.opened = -1;
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    if (firstCut >= (this.startIndex + this.batchSize)) {
      this.getBatchBool = true;
      this.startIndex = this.startIndex + this.batchSize;
      this.getPortLevelPmData();
    }
    else if (firstCut < (this.startIndex)) {
      this.getBatchBool = false;
      this.startIndex = this.startIndex - this.batchSize;
      this.getPortLevelPmData();
    } else {
      this.tempPortLevelPMArray = this.portLevelPMArray.slice(firstCut - this.startIndex, secondCut - this.startIndex);
    }
  }

  getNodeForPortLevelPM() {
    this.spinner.start();
    this.nodes = [];
    this.nodeList = [];
    let headers = new HttpHeaders().append('NeType', this.neType);
    this.pmservice.getNodeDataForResourceType(headers).subscribe(
      response => {
        this.spinner.stop();
        console.log('response :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.nodes = JSON.parse(response['body']);
          this.nodes.forEach(element => {
            this.nodeList.push({
              display: element,
              value: element
            });
          }
          );
        }
      });
  }


  downloadPortLevelPmData() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('PmType', this.pmType)
      .append('NeType', this.neType);
    this.pmservice.downloadPortLevelPmReport(headers).
      subscribe(res => {
        this.spinner.stop();
        console.log(res)
        if (res['status_code'] == 410) {
          this.Status = res.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.downloadPortLevelFile(res);
        }
      });
  }

  getDemands() {
    this.demandData = [];
    console.log('this.demandData :>> ', this.demandData);
    let headers = new HttpHeaders()
      .append('Node-Name', this.node2)

    console.log('---headers :----', headers);
    this.pmservice.getDemandsForNode(headers).subscribe(
      (response) => {
        console.log('Demands 2 Response :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
          this.demandData = [];
        }
        else {
          this.demandData = response['data'];
          console.log('this.demandData :>> ', this.demandData);
        }
      });

  }

  getDemandPm() {

    let requestJson: {};
    requestJson = {

      "neType": this.neType2,
      "pmType": this.pmType2,
      "duration": this.durationType2,
      "startTime": Date.parse(this.from2).toString(),
      "endTime": Date.parse(this.to2).toString(),
      "nodeName": this.node2,
      "demandName": this.demandType,


    };
    console.log("Request Json Demand -->", requestJson);

    let responseJson: {};
    this.spinner.start();
    this.pmservice.demandPm(requestJson).subscribe(
      (response) => {
        this.spinner.stop();
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.tableShow2 = true;
          console.log('this.tableShow2 :>> ', this.tableShow2);
          console.log('Demand PM Response :>> ', response);
          responseJson = response;
          this.demandAttributes = responseJson['attributes'];
          console.log('this.demandAttributes :---------', this.demandAttributes);
          this.dName = this.demandAttributes['demandName'];
          this.Aend = this.demandAttributes['Aend'];
          this.rate = this.demandAttributes['rate'];
          this.Zend = this.demandAttributes['Zend'];
          this.Rtype = this.demandAttributes['type'];
          //for nageswar

          this.headerdata = responseJson['headersObj']['header-data'];
          // console.log("headerdata", + this.headerdata(0));
          this.dtable = responseJson['headersObj']['header-List'];
          this.colspancount = this.dtable.length;
          this.data1 = responseJson['data'];
        }

      });


  }

  getPmCounts() {
    this.boolCounterDemandEnable = true;
    this.pmCount = '';
    this.pmCounts = [];
    this.slider = false;
    let headers = new HttpHeaders()
      .append('NeType', this.neType2)
      .append('End-Type', this.endType)


    console.log('---headers :----', headers);
    this.pmservice.getPmCounter(headers).subscribe(
      (response) => {
        console.log('Demand PM Response :>> ', response);
        this.pmCounts = JSON.parse(response['body']);
      });


  }


  getGraph2() {
    console.log('this.endType :', this.endType);
    console.log('this.pmCount :', this.pmCount);

    Highcharts.chart('container-table', {
      xAxis: {
        categories: [this.graphXAxis[4 * this.arrowIndex + 0], this.graphXAxis[4 * this.arrowIndex + 1], this.graphXAxis[4 * this.arrowIndex + 2], this.graphXAxis[4 * this.arrowIndex + 3]],


      },
      y: this.graphJson['unit'],
      credits: {
        enabled: false
      },
      title: {
        text: 'PM Trend'
      },
      exporting: { enabled: false },
      yAxis:
      {
        title: {
          text: this.graphJson['unit']
        },
      },
      series: [{
        data: [this.graphYAxis[4 * this.arrowIndex + 0], this.graphYAxis[4 * this.arrowIndex + 1], this.graphYAxis[4 * this.arrowIndex + 2], this.graphYAxis[4 * this.arrowIndex + 3]],
        name: this.graphJson['name'],
        color: '#7cb5ec',
        style: 'dotted',
        dashStyle: 'dot'

      }]
    });
  }

  onNextArrow() {
    this.arrowIndex += 1;
    console.log('this.arrowIndex :>> ', this.arrowIndex);
    this.getGraph2();
  }

  onBackArrow() {
    this.arrowIndex -= 1;
    console.log('this.arrowIndex :>> ', this.arrowIndex);
    this.getGraph2();
  }


  callGraphApi() {
    let headers = new HttpHeaders()
      .append('NeType', this.neType2)
      .append('End-Type', this.endType)
      .append('Counter-Name', this.pmCount)

    console.log('---headers :----', headers);

    this.pmservice.getDemandTrend(headers).subscribe(
      (response) => {

        console.log('Demand trend PM Response :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
          this.resetGraphData();
        }
        else {
          this.graphJson = response;

          this.arrowIndex = -1;
          this.maxArrow = Math.ceil((this.graphJson['data'].length / 4) - 1);
          console.log('this.maxArrow :>> ', this.maxArrow);

          this.slider = true;
          console.log((this.graphJson['data']).length);
          let tempArray1 = [];
          for (let i = 0; i < (this.graphJson['data']).length; i++) {
            console.log('arrowIndex :', this.arrowIndex);
            tempArray1.push(this.graphJson['data'][i]['Collection-Time']);
          }
          this.graphXAxis = tempArray1;
          let tempArray2 = [];
          for (let i = 0; i < (this.graphJson['data']).length; i++) {
            console.log('arrowIndex :', this.arrowIndex);
            tempArray2.push(parseFloat((this.graphJson['data'][i]['value'])));
          }
          this.graphYAxis = tempArray2;
          console.log('this.graphXAxis :>> ', this.graphXAxis);
          console.log('this.graphYAxis :>> ', this.graphYAxis);
          setTimeout(() => { this.onNextArrow(); }, 500);
        }
      }
    );
  }

  downloadDemand() {
    this.spinner.start();
    let headers = new HttpHeaders()
      .append('PmType', this.pmType2)
      .append('NeType', this.neType2);
    this.pmservice.downloadDemand(headers).
      subscribe(res => {
        this.spinner.stop();
        console.log(res);
        if (res['status_code'] == 410) {
          this.Status = res.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        this.downloadPortLevelFile(res);
      });

  }

  openDemandModal() {
    this.cienaServiceModal = true;
    this.arrowIndex = 0;
  }
  resetGraphData() {
    this.pmCounts = [];
    this.boolCounterDemandEnable = false;
    this.graphXAxis = undefined;
    this.graphYAxis = undefined;
    this.arrowIndex = 0;
    this.maxArrow = 0;
    this.slider = false;
    this.demandGraphForm.resetForm();

  }

  tabChanged(index) {
    this.selectedIndex = index;
    console.log('index :', index);
  }

  fromDateChanged2() {
    if (Date.parse(this.from2) + 2592000000 > new Date().getTime()) {
      this.maxTo2 = new Date();
    } else {
      this.maxTo2 = new Date(Date.parse(this.from2) + 2592000000);
    }
    this.minTo2 = new Date(Date.parse(this.from2));
    this.maxFrom2 = new Date();
  }
  afterDelete() {

  }

  toDateChanged2() {
    this.minFrom2 = new Date(Date.parse(this.to2) - 2592000000);
    this.maxFrom2 = new Date(Date.parse(this.to2));
    if (Date.parse(this.from2) + 2592000000 > new Date().getTime()) {
      this.maxTo2 = new Date();
    } else {
      this.maxTo2 = new Date(Date.parse(this.from2) + 2592000000);
    }
  }

  downloadPortLevelFile(response) {
    var linkElement = document.createElement('a');
    var byteArray = new Uint8Array(response['fileData']);
    linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    // linkElement.target = '_blank';
    linkElement.download = response['filename'];
    console.log(response);
    document.body.appendChild(linkElement);
    linkElement.click();
  }


  viewPMNodeAPI(element) {
    let headers = new HttpHeaders()
      .append('Port', element['Port'])
      .append('Node-Name', element['NE-Name'])
      .append('PmType', this.pmType);
    this.pmservice.viewPmNodeDetails(headers).subscribe(
      response => {
        console.log('response :>> ', response);
        this.viewPortLevelJSON = response['data'];
      }
    );

  }

  onViewPMModal(item) {
    this.counterForm.resetForm();
    this.slider1 = false;
    this.selectedNodeName = item['NE-Name'];
    this.selectedPort = item['Port'];
    this.arrowIndex1 = 0;
    this.getAllPMCounter();
  }


  getGraph1() {
    console.log('this.pmCounter :', this.pmCounterValue);

    Highcharts.chart('container-table1', {
      xAxis: {
        categories: [this.graphXAxis1[4 * this.arrowIndex1 + 0], this.graphXAxis1[4 * this.arrowIndex1 + 1], this.graphXAxis1[4 * this.arrowIndex1 + 2], this.graphXAxis1[4 * this.arrowIndex1 + 3]],
      },
      y: this.graphJSON1['unit'],
      credits: {
        enabled: false
      },
      title: {
        text: 'PM Trend'
      },
      exporting: { enabled: false },
      yAxis:
      {
        title: {
          text: this.graphJSON1['unit']
        },
      },
      series: [{
        data: [this.graphYAxis1[4 * this.arrowIndex1 + 0], this.graphYAxis1[4 * this.arrowIndex1 + 1], this.graphYAxis1[4 * this.arrowIndex1 + 2], this.graphYAxis1[4 * this.arrowIndex1 + 3]],
        name: this.graphJSON1['name'],
        color: '#7cb5ec',
        style: 'dotted',
        dashStyle: 'dot'

      }]
    });
  }

  onNextArrow1() {
    this.arrowIndex1 += 1;
    console.log('this.arrowIndex :>> ', this.arrowIndex1);
    this.getGraph1();
  }

  onBackArrow1() {
    this.arrowIndex1 -= 1;
    console.log('this.arrowIndex :>> ', this.arrowIndex1);
    this.getGraph1();
  }

  callAPIGraph1() {
    console.log('this.pmCounterList :>> ', this.pmCounterValue);
    console.log('this.slider1 :>> ', this.slider1);
    if ((this.pmCounterValue !== '') && (this.pmCounterValue !== undefined) && (this.pmCounterValue !== null)) {
      let graphHeaders = new HttpHeaders()
        .append('Node-Name', this.selectedNodeName)
        .append('Port', this.selectedPort)
        .append('Counter-Name', this.pmCounterValue);

      this.pmservice.viewPmTrendForCounter(graphHeaders).subscribe(
        response => {
          console.log('response :>> ', response);
          if (response['status_code'] == 410) {
            this.slider1 = false;
            this.Status = response.status;
            this.notificationService.notificationMessage(this.Status, 'danger');
          }
          else {
            this.graphJSON1 = response;
            this.slider1 = true;
            this.maxArrow1 = Math.ceil((this.graphJSON1['data'].length / 4) - 1);
            console.log('this.maxArrow :>> ', this.maxArrow1);
            console.log((this.graphJSON1['data']).length);
            let tempArray0 = [];
            for (let i = 0; i < (this.graphJSON1['data']).length; i++) {
              console.log('arrowIndex :', this.arrowIndex1);
              tempArray0.push(this.graphJSON1['data'][i]['Collection-Time']);
            }
            this.graphXAxis1 = tempArray0;
            let tempArray = [];
            for (let i = 0; i < (this.graphJSON1['data']).length; i++) {
              console.log('arrowIndex :', this.arrowIndex1);
              tempArray.push(parseFloat((this.graphJSON1['data'][i]['value'])));
            }
            this.graphYAxis1 = tempArray;
            console.log('this.graphXAxis :>> ', this.graphXAxis1);
            console.log('this.graphYAxis :>> ', this.graphYAxis1);
            this.arrowIndex1 = -1;
            setTimeout(() => { this.onNextArrow1(); }, 500);
          }
        }
      );
    }


  }

  getAllPMCounter() {
    let headers = new HttpHeaders()
      .append('PmType', this.pmType)
      .append('NeType', this.neType);

    this.pmservice.getAllCountersForCategory(headers).subscribe(
      response => {
        console.log('response :>> ', response);
        if (response['status_code'] == 410) {
          this.Status = response.status;
          this.notificationService.notificationMessage(this.Status, 'danger');
        }
        else {
          this.pmCounterArray = JSON.parse(response['body']);
          console.log('this.pmCounterArray :>> ', this.pmCounterArray);
        }
      })
  }

  fromDateChanged() {
    if (Date.parse(this.from) + 2592000000 > new Date().getTime()) {
      this.maxTo = new Date();
    } else {
      this.maxTo = new Date(Date.parse(this.from) + 2592000000);
    }
    this.minTo = new Date(Date.parse(this.from));
    this.maxFrom = new Date();
  }

  toDateChanged() {
    this.minFrom = new Date(Date.parse(this.to) - 2592000000);
    this.maxFrom = new Date(Date.parse(this.to));
    if (Date.parse(this.from) + 2592000000 > new Date().getTime()) {
      this.maxTo = new Date();
    } else {
      this.maxTo = new Date(Date.parse(this.from) + 2592000000);
    }
  }

  backToMCP() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.optService.breadcrumbNavigation(path);
  }
  //nageswar

  toRunmethod() {
    let json = {};
  }

  ngOnDestroy() {
    this.spinner.stop();
  }


}
