import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable, ObjectUnsubscribedError } from 'rxjs';
import 'rxjs/Rx'
import { SdWanServiceService } from '../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../SharedFolder/constants/eventConstants';
import { Router } from '@angular/router';

@Injectable({
    providedIn: "root"
})
export class ServiceModuleAPIService {
    portList;

    constructor(private commonService: SdWanServiceService,
        private router: Router) { }

    devicedetailsrequest(deviceDetails) {

        let queryParam = "pincode=" + deviceDetails['pincode'] + "&device_type=" + deviceDetails['device_type'];
        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', '/PEAG/nbHandler', null, null, queryParam, EventConstants.DEVICE_DETAILS_REQUEST).subscribe(
                (response) => {
                    if (response['status_code'] < 3000) {
                        observe.next(response['data']['devices']);
                    }
                }
            );
        }
        );

    }

    getServiceStatus(customerId, serviceSpecificId) {
        let headers = new HttpHeaders(
            {
                "Customer_Id": customerId,
                "Service_Specific_Id": serviceSpecificId
            }
        );

        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', '/PEAG/nbGUIHandler', null, headers, null, EventConstants.GET_SERVICE_STATUS).subscribe(
                (response) => {
                    if (response['status_code'] === 200)
                        observe.next(response['service-status']);
                    else
                        observe.next([]);
                }
            );
        });
    }

    deviceportdetailsrequest(portDetails) {

        let queryParam = "neid=" + portDetails["neid"];
        let portArray;
        let freePort = [];
        let freePortModified = [{
            "port": 'Select',
            'provisioned_bandwidth': '-',
            'available_bandwidth': '-',
            "service": '-',
            "customer_id": "-"
        }];
        let usedPortModified = [{
            "port": 'Select',
            'provisioned_bandwidth': '-',
            'available_bandwidth': '-',
            "service": '-',
            "customer_id": "-"
        }]

        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', '/PEAG/nbHandler', null, null, queryParam, EventConstants.DEVICE_PORT_DETAILS_REQUEST).subscribe(
                (response) => {
                    portArray = response["data"]["devices"][0]["usedport"];
                    freePort = response['data']['devices'][0]["freeport"];

                    for (let i = 0; i < freePort.length; i++) {
                        let json = {
                            "port": freePort[i],
                            'provisioned_bandwidth': '-',
                            'available_bandwidth': '-',
                            "service": '-',
                            "customer_id": "-"
                        }
                        freePortModified.push(json);
                    }

                    for (let i = 0; i < portArray.length; i++) {
                        usedPortModified.push(portArray[i]);
                    }

                    observe.next({
                        usedPort: usedPortModified,
                        freePort: freePortModified
                    })
                }
            )
        })
    }

    Provisionservicerequest(json, serviceOrderId) {

        let headers = new HttpHeaders(
            {
                "Service-Order-Id": serviceOrderId

            }
        );

        console.log("inside provision service");
        return new Observable<any>(observe => {
            this.commonService.sendRequest('post', '/PEAG/nbHandler', json, headers, null, EventConstants.PROVISION_SERVICE_REQUEST).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });

    }



    deletesingleservice(completeDeleteRequestJson) {
        let headers = new HttpHeaders(
            completeDeleteRequestJson
        );

        return new Observable<any>(observe => {
            this.commonService.sendRequest("DELETE", "/PEAG/nbHandler", null, headers, null, EventConstants.COMPLETE_DELETE).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    getServiceOrderInfo(serviceOrderId) {
        let headers = new HttpHeaders({
            'Service-Order-Id': serviceOrderId
        });

        return new Observable<any>(observe => {
            this.commonService.sendRequest("GET", "/PEAG/nbGUIHandler", null, headers, null, EventConstants.GET_SERVICE_ORDER_INFO).subscribe(
                (response) => {
                    console.log('respone in getServiceOrderInfo', response);
                    if (response['status_code'] === 200) {
                        observe.next(response);
                    }
                }
            );
        }
        );
    }

    deletesingleservicepartial(partialDeleteRequestJson) {

        let headers = new HttpHeaders(
            partialDeleteRequestJson
        );

        return new Observable<any>(observe => {
            this.commonService.sendRequest("DELETE", "/PEAG/nbHandler", null, headers, null, EventConstants.PARTIAL_DELETE).subscribe(
                (response) => {
                    console.log('response::::deletepartialservice:', response);
                    observe.next(response);
                }
            );
        }
        );
    }

    modifyservicerequest(modifyServiceJson) {

        return new Observable<any>(observe => {
            this.commonService.sendRequest("patch", "/PEAG/nbHandler", modifyServiceJson, null, null, EventConstants.MODIFY_SERVICE).subscribe(
                (response) => {
                    observe.next(response['reason']);
                }
            );
        }
        );
    }

    getadlList(customerId, serviceSpecificId) {

        let jsonBody = {
            "customer_id": customerId,
            "service_specific_id": serviceSpecificId
        }

        let queryParam = "customer_id=" + customerId + '&service_specific_id=' + serviceSpecificId;

        return new Observable<any>(observe => {
            this.commonService.sendRequest("get", "/PEAG/nbHandler", null, null, queryParam, EventConstants.ALD).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        observe.next(response['ne_ids']);
                    } else {
                        observe.next([]);
                    }
                }
            );
        }
        );
    }

    addCustomerDetails(customerJson) {
        return new Observable<any>(observe => {
            console.log('inside addCustomerObservable');
            this.commonService.sendRequest('post', '/PEAG/nbHandler', customerJson, null, null, EventConstants.ADD_CUSTOMER).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    getAllCustomerDetails() {

        return new Observable<any>(observe => {
            this.commonService.sendRequest("GET", "/PEAG/nbGUIHandler", null, null, null, EventConstants.GET_ALL_CUSTOMER_DETAILS).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    breadcrumbNavigation(path: string) {
        switch (path) {
            case 'dashboard': return this.router.navigate(['/layout/Dashboard']);
            case 'underlayService': return this.router.navigate(['/layout/underlayService']);
        }
    }

}
