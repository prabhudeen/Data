import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import swal from 'sweetalert2';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';

@Component({
  selector: 'app-provision-service',
  templateUrl: './provision-service.component.html',
  styleUrls: ['./provision-service.component.css']
})
export class ProvisionServiceComponent implements OnInit {
  profileBoolean = false;
  boolean: any[];
  neIdList: any[];
  customerId: any;
  topologyTypeList: any[] = [
    { name: 'Hub and Spoke', value: 1 },
    { name: 'Full Mesh', value: 2 },
    { name: 'P2P', value: 3 },
    { name: 'P2M', value: 4 },
    { name: 'M2M', value: 5 },
    { name: 'Partial Mesh', value: 6 }
  ]
  deviceTypeList: any[] = [
    { name: "ECR", value: 'ecr' },
    { name: "CSS", value: 'css' },
    { name: "DEMARC", value: 'demarc' },
    { name: "AG1", value: 'ag1' },
    { name: "AG2", value: 'ag2' }
  ]
  portList: any = {
    usedPort: [{
      "port": 'Select',
      'provisioned_bandwidth': '-',
      'available_bandwidth': '-',
      "service": '-',
      "customer_id": "-"
    }],
    freePort: [{
      "port": 'Select',
      'provisioned_bandwidth': '-',
      'available_bandwidth': '-',
      "service": '-',
      "customer_id": "-"
    }]
  };
  dualPortList: any = {
    usedPort: [{
      "port": 'Select',
      'provisioned_bandwidth': '-',
      'available_bandwidth': '-',
      "service": '-',
      "customer_id": "-"
    }],
    freePort: [{
      "port": 'Select',
      'provisioned_bandwidth': '-',
      'available_bandwidth': '-',
      "service": '-',
      "customer_id": "-"
    }]
  };
  slideToggle = false;
  displayNeid = null;
  displayDualNeid = null;
  portValueJson = {
    "port": "Select",
    "provisioned_bandwidth": "",
    "available_bandwidth": "",
    "service": "",
    "customer_id": ""
  };
  dualPortValueJson = {
    "port": "Select",
    "provisioned_bandwidth": "",
    "available_bandwidth": "",
    "service": "",
    "customer_id": ""
  };
  profileValueList;
  step = 1;
  deviceType;
  addHubList: any[];
  adlTypeList: any[];
  adlTypeValue: any;
  adlBoolean: boolean = true;
  adlList: any[] = [];
  tagList: any[] = [
    { name: "Select", value: null },
    {
      name: 'Tagged',
      value: 'tagged'
    },
    {
      name: 'Untagged',
      value: 'untagged'
    }
  ]
  ipTypeList: any[] = [
    {
      name: 'IPV4',
      value: 'ipv4'
    },
    {
      name: 'IPV6',
      value: 'ipv6'
    },
    {
      name: 'Both',
      value: 'both'
    }
  ]
  managedList: any[] = [
    {
      name: 'Managed',
      value: 1
    },
    {
      name: 'Unmanaged',
      value: 0
    }
  ]
  routingProtocolList = [
    {
      name: 'BGP',
      value: 1
    },
    {
      name: 'Static',
      value: 2
    },
    {
      name: 'No Protocol',
      value: -1
    }
  ]

  serviceIdList = [
    { name: 'SIP', value: "1" },
    { name: 'L3VPN', value: "2" },
    { name: 'ILL-DR', value: "4" },
    { name: 'ILL-FR', value: "5" },
    { name: 'L2VPN', value: "6" },
  ]

  peTyleList = [
    {
      name: 'Both',
      value: 2
    },
    {
      name: 'Single',
      value: 1
    }
  ]

  @ViewChild('form1') form1: NgForm;
  @ViewChild('form2') NE_ID_Form: NgForm;
  @ViewChild('form3') provisionalSingleServiceForm: NgForm;
  @ViewChild('container') containerPointer: ElementRef;
  @ViewChild('footer') secondPageFooterRef: ElementRef;
  originalNeidList = [];
  dualNeidList = [];
  usedPortValue: any = 0;
  freePortValue: any = 0;
  dualFreePortValue: any = 0;
  dualUsedPortValue: any = 0;

  constructor(private router: Router,
    private ServiceModuleAPIService: ServiceModuleAPIService,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService) { }

  ngOnInit() {
    this.boolean = [{ 'name': "True", 'value': true }, { 'name': "False", 'value': false }];
    this.addHubList = [{ name: "Select", value: null }, { name: "HUB", value: "HUB" }, { name: "NULL", value: "NULL" }];
    this.adlTypeList =
      [
        { name: "Select", value: null },
        { name: "Permit", value: "Permit" },
        { name: "Deny", value: "Deny" },
        { name: "False", value: "False" }
      ];

    this.profileValueList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  }

  onStep1Submit() {
    this.step = 2;
    this.ServiceModuleAPIService.devicedetailsrequest(this.form1.value).subscribe(
      (response) => {
        this.originalNeidList = response;
        this.dualNeidList = this.originalNeidList;
        this.neIdList = this.originalNeidList;
        this.step = 2;
      }
    );
  }

  onStep2Submit() {
    this.step = 3;
    if (this.portValueJson.port === 'Select') {
      this.portValueJson.port = '';
    }

    if (this.slideToggle) {
      if (this.dualPortValueJson.port === 'Select') {
        this.dualPortValueJson.port = '';
      }
    }

  }

  checkValidation(value) {
    if (value !== '' && value !== undefined && value !== null) {
      return true;
    }
    return false;
  }

  onStep3Submit() {
    //for true then profile value is 11 
    if (this.profileBoolean) {
      this.provisionalSingleServiceForm.value["profile"] = 11;
    }

    //checking values for provided or not


    let ipType = this.provisionalSingleServiceForm.value["ip-type"];

    let value;
    let endPointJson = {};
    let parametersJson = {};

    if (this.slideToggle) {
      endPointJson['ne_id'] = `${this.displayNeid['neid']},${this.displayDualNeid['neid']}`
      endPointJson['port'] = `${this.portValueJson.port},${this.dualPortValueJson.port}`
    } else {
      endPointJson['ne_id'] = this.displayNeid['neid'];
      endPointJson['port'] = this.portValueJson.port;
    }

    parametersJson['ip-type'] = ipType;

    if (ipType === 'ipv4' || ipType === 'both') {
      parametersJson['lan-pool-ipv4-mask'] = this.provisionalSingleServiceForm.value["lan-pool-ipv4-mask"];
      value = this.provisionalSingleServiceForm.value["ipv4-wan-address"];

      if (this.checkValidation(value)) {
        parametersJson['ipv4-wan-address'] = value;
      }
    }

    if (ipType === 'ipv6' || ipType === 'both') {
      parametersJson['lan-pool-ipv6-mask'] = this.provisionalSingleServiceForm.value["lan-pool-ipv6-mask"];
      value = this.provisionalSingleServiceForm.value["ipv6-wan-address"];

      if (this.checkValidation(value)) {
        parametersJson['ipv6-wan-address'] = value;
      }
    }

    value = this.provisionalSingleServiceForm.value["cust-vlan"];
    if (this.checkValidation(value)) {
      parametersJson['cust-vlan'] = value;
    }

    value = this.provisionalSingleServiceForm.value["tag"];
    if (this.checkValidation(value)) {
      parametersJson['tag'] = value;
    }

    value = this.provisionalSingleServiceForm.value["remote-as"];
    if (this.checkValidation(value)) {
      parametersJson['remote-as'] = value;
    }

    value = this.provisionalSingleServiceForm.value["add_Hub"];
    if (this.checkValidation(value)) {
      endPointJson['add_Hub'] = value;
    }

    value = this.provisionalSingleServiceForm.value["adl"];
    if (value !== '' && value !== null && value !== undefined && value.length !== 0) {
      value = value.join(',');
      endPointJson['adl'] = value;
    }

    value = this.provisionalSingleServiceForm.value["bandwidth"];
    if (this.checkValidation(value)) {
      endPointJson['bandwidth'] = value;
    }

    value = this.provisionalSingleServiceForm.value["profile"];
    if (this.checkValidation(value)) {
      endPointJson['profile'] = value;
    }

    if (this.provisionalSingleServiceForm.value["profile"] === 11) {
      endPointJson['flexi_profile'] = [
        {
          "platinum": this.provisionalSingleServiceForm.value["platinum"],
          "gold": this.provisionalSingleServiceForm.value["gold"],
          "silver": this.provisionalSingleServiceForm.value["silver"]
        }
      ]
    }

    let finalJson = {
      "customer_id": this.customerId,
      "services":
        [
          {
            "service_id": this.provisionalSingleServiceForm.value["service_id"],
            "service_specific_id": this.provisionalSingleServiceForm.value["service_specific_id"],
            "action": 1,
            "endpoint_devices":
              [{
                "adl_type": this.provisionalSingleServiceForm.value["adl_type"],
                ...endPointJson,
                "parameters":
                {
                  "is_managed": this.provisionalSingleServiceForm.value["is_managed"],
                  "routing_protocol": this.provisionalSingleServiceForm.value["routing_protocol"],
                  "pe_type": this.provisionalSingleServiceForm.value["pe_type"],
                  "topology_type": this.provisionalSingleServiceForm.value["topology_type"],
                  ...parametersJson
                }
              }
              ]
          }
        ]
    }

    console.log('finalJSON:::::::::', JSON.stringify(finalJson));

    this.spinnerService.start(60000 * 5);
    this.ServiceModuleAPIService.Provisionservicerequest(finalJson, this.provisionalSingleServiceForm.value["Service-Order-Id"]).subscribe(
      (response) => {
        console.log(response);
        this.spinnerService.stop();
        if (response["status_code"] < 3000) {
          this.onSuccess("Success Case", response);
        }
        else {
          this.onFailure("Failure Case", response);
        }
      }
    );
  }

  gotoTop() {
    const element = document.querySelector('#scrollId');
    element.scrollIntoView();
  }

  onStep1Prev() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onStep2Prev() {
    this.step = 1;
  }

  onStep3Prev() {
    this.step = 2;
  }

  onNEIDSelect(element) {
    this.displayNeid = {};
    this.displayNeid['neid'] = element.neid;
    this.dualNeidList = this.originalNeidList.filter(element => {
      return element.neid !== this.displayNeid['neid'];
    });
    this.ServiceModuleAPIService.deviceportdetailsrequest(element).subscribe(
      (response) => {
        this.portList = response;
      }
    );
  }

  portValueChange(portType) {
    if (portType === 'usedPort') {
      this.portValueJson = this.portList.usedPort[this.usedPortValue];
    } else {
      this.portValueJson = this.portList.freePort[this.freePortValue];
    }
  }

  ondualNEIDSelect(element) {
    this.displayDualNeid = {};
    this.displayDualNeid['neid'] = element.neid;
    this.neIdList = this.originalNeidList.filter(element => {
      return element.neid !== this.displayDualNeid['neid'];
    });
    this.ServiceModuleAPIService.deviceportdetailsrequest(element).subscribe(
      (response) => {
        this.dualPortList = response;
      }
    );
  }

  dualPortValueChange(portType) {
    if (portType === 'usedPort') {
      this.dualPortValueJson = this.dualPortList.usedPort[this.dualUsedPortValue];
    } else {
      this.dualPortValueJson = this.dualPortList.freePort[this.dualFreePortValue];
    }
  }

  onAdlTypeClick() {
    if (this.adlTypeValue !== "False") {
      this.adlBoolean = false;
    } else {
      this.adlBoolean = true;
    }
    this.getaldList();
  }

  getaldList() {
    let customerId = this.customerId;
    let serviceSpecificId = this.provisionalSingleServiceForm.value["service_specific_id"];
    if (!this.adlBoolean && serviceSpecificId !== undefined && serviceSpecificId !== '') {
      this.ServiceModuleAPIService.getadlList(customerId, serviceSpecificId).subscribe(
        (response) => {
          this.adlList = response;
        }
      );
    }
  }

  onSuccess(type, response) {
    if (type == 'Success Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          text: 'Service Order ID: ' + response["data"]["service_order_id"],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.router.navigate(['layout/underlayService']);
        }
        else {
          console.log("not deleted");
        }
      })
    }
  }

  onFailure(type, response) {
    if (type == 'Failure Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).catch(swal.noop)
    }
  }

  breadcrumbNavigation(path: string) {
    this.ServiceModuleAPIService.breadcrumbNavigation(path);
  }

}
