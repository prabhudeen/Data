import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';


// interface JSONFormat {
//   "Service-Order-Id",
//   "service_id",
//   'service_specific_id',
//   "ne_id",
//    "port",
//    "add_Hub",
//    "adl_type",
//    "adl",
//    "bandwidth",
//    "profile",
//    "platinum",
//    "gold",
//    "silver",
//    "is_managed",
//    "terminated_at",
//    "dual",
//    "witheds",
//    "routing_protocol",
//    "remote-as",
//    "pe_type",
//    "tag",
//    "lan-pool-ipv4-mask",
//    "lan-pool-ipv6-mask",
//    "demarc-egress-bridge-port-no-1",
//    "demarc-egress-bridge-port-no-3",
//    "demarc-egress-bridge-port-no-4",
//    "demarc-ingress-port-no-1",
//    "demarc-ingress-port-no-3",
//    "demarc-ingress-port-no-4",
//    "demarc-erps-id-1",
//    "demarc-erps-id-2",
//    "demarc-interface-id-1",
//    "demarc-interface-id-2",
//    "demarc-raps-vlan-1",
//    "demarc-raps-vlan-2",
//    "demarc-erps-mode-1",
//    "demarc-erps-mode-2",
//    "ipv4-wan-address",
//    "ipv6-wan-address",
//    "cust-vlan",
//    "topology_type",
//    "ip-type",
//    "cpe-interface-id1",
//    "cpe-interface-id2",
//    "ipv4-subnet",
//    "ipv6-subnet"
// }
@Component({
  selector: 'app-modify-service',
  templateUrl: './modify-service.component.html',
  styleUrls: ['./modify-service.component.css']
})
export class ModifyServiceComponent implements OnInit {

  @ViewChild('form') ModifyServiceForm: NgForm;
  customerId;
  boolean;
  profileBoolean = false;
  profileValueList;
  ModifyJson: any;

  constructor(private ServiceModuleAPIService: ServiceModuleAPIService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.boolean = [{ 'name': "True", 'value': true }, { 'name': "False", 'value': false }];
    this.profileValueList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  }

  onStep3Prev() {

  }

  onNext() {


    let ModifyJson = {
      "endpoint_devices": [{
        "service_order_id": this.ModifyServiceForm.value['service_order_id1'],
        "service_specific_id": this.ModifyServiceForm.value['service_specific_id1'],
        "ne_id": this.ModifyServiceForm.value['ne_id1'],
        "port": this.ModifyServiceForm.value['port1'],
        "add_Hub": this.ModifyServiceForm.value['service_specific_id1'],//not there
        "adl_type": this.ModifyServiceForm.value['service_specific_id1'],// not there
        "adl": this.ModifyServiceForm.value['service_specific_id1'],// not there
        "bandwidth": 500,
        "profile": 11,
        "flexi_profile": [{
          "platinum": 1,
          "gold": 2,
          "silver": 34
        }],
        "parameters": {
          "is_managed": 0,
          "terminated_at": 1,
          "dual": 1,
          "witheds": 1,
          "routing_protocol": 1,
          "remote-as": 64512,
          "pe_type": "2",
          "tag": this.ModifyServiceForm.value['tag1'],
          "lan-pool-ipv4-mask": this.ModifyServiceForm.value['lan-pool-ipv4-mask1'],
          "lan-pool-ipv6-mask": this.ModifyServiceForm.value['lan-pool-ipv6-mask1'],
          "demarc-egress-bridge-port-no-1": this.ModifyServiceForm.value['demarc-egress-bridge-port-no-11'],
          "demarc-egress-bridge-port-no-3": this.ModifyServiceForm.value['demarc-egress-bridge-port-no-31'],
          "demarc-egress-bridge-port-no-4": this.ModifyServiceForm.value['demarc-egress-bridge-port-no-41'],
          "demarc-ingress-port-no-1": this.ModifyServiceForm.value['demarc-ingress-port-no-11'],
          "demarc-ingress-port-no-3": this.ModifyServiceForm.value['demarc-ingress-port-no-31'],
          "demarc-ingress-port-no-4": this.ModifyServiceForm.value['demarc-ingress-port-no-41'],
          "demarc-erps-id-1": this.ModifyServiceForm.value['demarc-erps-id-11'],
          "demarc-erps-id-2": this.ModifyServiceForm.value['demarc-erps-id-21'],
          "demarc-interface-id-1": this.ModifyServiceForm.value['demarc-interface-id-11'],
          "demarc-interface-id-2": this.ModifyServiceForm.value['demarc-interface-id-21'],
          "demarc-raps-vlan-1": this.ModifyServiceForm.value['demarc-raps-vlan-11'],
          "demarc-raps-vlan-2": this.ModifyServiceForm.value['demarc-raps-vlan-21'],
          "demarc-erps-mode-1": this.ModifyServiceForm.value['demarc-erps-mode-11'],
          "demarc-erps-mode-2": this.ModifyServiceForm.value['demarc-erps-mode-21'],
          "ipv4-wan-address": this.ModifyServiceForm.value['ipv4-wan-address1'],
          "ipv6-wan-address": this.ModifyServiceForm.value['ipv6-wan-address1'],
          "cust-vlan": this.ModifyServiceForm.value['cust_vlan1'],
          "topology_type": this.ModifyServiceForm.value['topoloyg_type1'],
          "ip-type": this.ModifyServiceForm.value['ip-type1'],
          "cpe-interface-id1": this.ModifyServiceForm.value['cpe-interface-id11'],
          "cpe-interface-id2": this.ModifyServiceForm.value['cpe-interface-id21'],
          "ipv4-subnet": this.ModifyServiceForm.value['ipv4-subnet1'],
          "ipv6-subnet": this.ModifyServiceForm.value['ipv6-subnet1']
        }
      }]
    }

    // let ModifyJson = {
    //   "endpoint_devices": [{
    //     "service_order_id": "hfdfd008",
    //     "service_specific_id": "hdfcvpn_2",
    //     "ne_id": "INMUMUMBRLB1NB0020ENTEDS017",
    //     "port": "ETH-1",
    //     "parameters": {
    //       "is_managed": 0,
    //       "terminated_at": 1,
    //       "dual": 1,
    //       "witheds": 1,
    //       "routing_protocol": 1,
    //       "remote-as": 64512,
    //       "pe_type": "2",
    //       "tag": "tagged",
    //       "lan-pool-ipv4-mask": "10.64.88.0/29",
    //       "lan-pool-ipv6-mask": "2405:0200:1410:1401:0000:0000:0004:0100/125 ",
    //       "demarc-egress-bridge-port-no-1": 8,
    //       "demarc-egress-bridge-port-no-3": 6,
    //       "demarc-egress-bridge-port-no-4": 7,
    //       "demarc-ingress-port-no-1": 3,
    //       "demarc-ingress-port-no-3": 4,
    //       "demarc-ingress-port-no-4": 2,
    //       "demarc-erps-id-1": 1,
    //       "demarc-erps-id-2": 2,
    //       "demarc-interface-id-1": "gig0/0/9",
    //       "demarc-interface-id-2": "gig0/0/10",
    //       "demarc-raps-vlan-1": 606,
    //       "demarc-raps-vlan-2": 616,
    //       "demarc-erps-mode-1": "Sub",
    //       "demarc-erps-mode-2": "Sub",
    //       "ipv4-wan-address": "10.64.88.17 255.255.255.252,10.64.88.21 255.255.255.252",
    //       "ipv6-wan-address": "2405:0200:1410:1401:0000:0000:0004:0110/127,2405:0200:1410:1401:0000:0000:0004:0112/127",
    //       "cust-vlan": "2000,2001",
    //       "topology_type": 1,
    //       "ip-type": "both",
    //       "cpe-interface-id1": "gig0/0/22",
    //       "cpe-interface-id2": "gig0/0/8",
    //       "ipv4-subnet": "/30",
    //       "ipv6-subnet": "/126"
    //     }
    //   }]
    // }


    this.ServiceModuleAPIService.modifyservicerequest(ModifyJson).subscribe(
      (response) => {
        console.log(response);
      }
    );

  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.ServiceModuleAPIService.breadcrumbNavigation(path);
  }
}
