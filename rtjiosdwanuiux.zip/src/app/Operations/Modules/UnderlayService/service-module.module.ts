import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ServiceRoutes } from './service.routing';
import { ProvisionServiceComponent } from './ProvisionService/provision-service.component';
import { ModifyServiceComponent } from './ModifyService/modify-service.component';
import { PartialdeleteComponent } from './PartialDelete/partialdelete.component';
import { CompletedeleteComponent } from './CompleteDelete/completedelete.component';
import { AddCustomerComponent } from './AddCustomer/add-customer.component';
import { UnderlayServiceComponent } from './underlay-service.component';
import { ServiceStatusComponent } from './ServiceStatus/serviceStatus.component';
import { SharedModule } from '../../../SharedFolder/modules/shared.module';
@NgModule({
  declarations: [
    PartialdeleteComponent,
    CompletedeleteComponent,
    ProvisionServiceComponent,
    ModifyServiceComponent,
    AddCustomerComponent,
    UnderlayServiceComponent,
    ServiceStatusComponent
  ],
  imports: [
    RouterModule.forChild(ServiceRoutes),
    SharedModule
  ]
})
export class ServiceModuleModule { }
