import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../SharedFolder/services/access.service';
import { ServiceModuleAPIService } from './ServiceModule_API.service';
@Component({
  selector: 'app-underlay-service',
  templateUrl: './underlay-service.component.html',
  styleUrls: ['./underlay-service.component.css']
})

export class UnderlayServiceComponent implements OnInit {

  list: any[] = [
    {
      iconLink: "assets/img/addCustomerIcon.svg",
      title: "ADD CUSTOMER",
      value: "Add Customer",
      access: true
    },
    {
      iconLink: "assets/img/provisionServiceIcon.svg",
      title: "PROVISION SERVICE",
      value: "Provision Service",
      access: true
    },
    {
      iconLink: "assets/img/modifyServiceIcon.svg",
      title: "MODIFY SERVICE",
      value: "Modify Service",
      access: true
    },
    {
      iconLink: "assets/img/deleteServiceIcon.svg",
      title: "DELETE SERVICE",
      value: "Delete Service",
      access: true
    },
    {
      iconLink: "assets/img/partialDeleteServiceIcon.svg",
      title: "PARTIAL DELETE",
      value: "Partial Delete",
      access: true
    },
    {
      iconLink: "assets/img/serviceStatus.svg",
      title: "SERVICE STATUS",
      value: "Service Status",
      access: true
    }
  ]
  constructor(private router: Router,
    private accessService: AccessService,
    private underlayService: ServiceModuleAPIService) { }

  ngOnInit() {
    this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'Underlay Management');
  }

  onClick(action) {
    switch (action) {
      case "Provision Service":
        this.router.navigateByUrl("layout/underlayService/provisionService");
        break;
      case "Modify Service":
        this.router.navigateByUrl("layout/underlayService/modifyService");
        break;
      case "Delete Service":
        this.router.navigateByUrl("layout/underlayService/deleteService");
        break;
      case "Partial Delete":
        this.router.navigateByUrl("layout/underlayService/partialDeleteService");
        break;
      case "Add Customer":
        this.router.navigateByUrl("layout/underlayService/addCustomer");
        break;
      case "Service Status":
        this.router.navigateByUrl("layout/underlayService/serviceStatus");
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.underlayService.breadcrumbNavigation(path);
  }

}
