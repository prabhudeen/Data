import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-partialdelete',
  templateUrl: './partialdelete.component.html',
  styleUrls: ['./partialdelete.component.css']
})
export class PartialdeleteComponent implements OnInit {

  public service_order_id;
  public service_specific_id;
  public partialDeleteRequest;
  public neIdDataModal: string;
  public portDataModal: string;
  public endpoint_devices;
  public customerId;
  public serviceSpecificIdList: any[] = [];
  serviceSpecificJson;
  serviceOrderId;
  serviceSpecificId;
  isServiceSpecificId: boolean = true;
  isNeid: boolean = true;
  NeidList = [];
  neid;
  portData;

  @ViewChild('deleteForm') deleteForm: NgForm;
  @ViewChild('serviceSpecificIdController') serviceSpecificIdController: NgModel;
  @ViewChild('neIdController') neIdController: NgModel;

  public singleEndPointDeviceRecord = {
    "Ne_Id": "",
    "Port": ""
  };
  getCustomersJson: any = {};
  customerIdArray: string[] = [];
  disableServiceOrderId: boolean = true;
  serviceOrderIdArray: any[] = [];
  constructor(private ServiceModuleAPIService: ServiceModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService) { }

  ngOnInit() {
    this.partialDeleteRequest = {};
    this.ServiceModuleAPIService.getAllCustomerDetails()
      .subscribe(
        response => {
          if (response['status_code'] === 200) {
            console.log('getAllCustomerDetails Json successful:', response);
            this.getCustomersJson = response['data'];
            this.customerIdArray = Object.keys(response['data']);
          } else {
            console.log('getAllCustomerDetails Json failed:', response);
          }
        }
      )
  }

  onNeidListChange() {
    this.portData = this.serviceSpecificJson[this.serviceSpecificId][this.neid];
  }

  onCustomerIdChange(name) {
    if (this.getCustomersJson[name]) {
      this.disableServiceOrderId = false;
      this.serviceOrderIdArray = this.getCustomersJson[name]['serviceOrderIdList'];
    } else {
      this.disableServiceOrderId = true;
    }
  }

  onServiceSpecificIdChange() {
    let json = this.serviceSpecificJson[this.serviceSpecificId];
    this.NeidList = Object.keys(json);
    this.isNeid = false;
    this.portData = undefined;
  }

  onServiceOrderIdChange() {
    if (this.serviceOrderId && this.serviceOrderIdArray.findIndex(element => element === this.serviceOrderId) !== -1) {
      this.ServiceModuleAPIService.getServiceOrderInfo(this.serviceOrderId).subscribe(
        (response) => {
          this.serviceSpecificIdList = Object.keys(response['data']);
          this.serviceSpecificJson = response['data'];
          this.isServiceSpecificId = false;
          this.isNeid = true;
          this.portData = undefined;
          this.neid = undefined;
          this.serviceSpecificId = undefined;
          this.neIdController.reset();
          this.serviceSpecificIdController.reset();
        }
      )
    }

  }

  showSwal(type) {
    if (type == 'warning-message-and-confirmation') {
      swal(
        {
          title: "Are you sure want to Delete",
          text: "Are you sure want to Delete",
          type: 'warning',
          showCancelButton: true,
          cancelButtonClass: "btn btn-danger",
          confirmButtonClass: "btn btn-primary",
          confirmButtonText: 'YES',
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.onDelete();
        }
        else {
          console.log("not deleted");
        }
      })
    }
  }

  onDelete() {
    console.log("Going for Partial delete");
    this.endpoint_devices = [];
    this.makeJson();
    this.spinnerService.start(60000 * 5);
    this.ServiceModuleAPIService.deletesingleservicepartial(this.partialDeleteRequest).subscribe(
      (response) => {
        this.spinnerService.stop();
        if (response["status_code"] < 3000) {
          this.onSuccess("Success Case", response);
        }
        else {
          this.onFailure("Failure Case", response);
        }
      }
    );
    this.deleteForm.reset();
  }

  makeJson() {
    this.singleEndPointDeviceRecord.Ne_Id = this.neid;
    this.singleEndPointDeviceRecord.Port = this.portData;
    this.partialDeleteRequest = {
      "Service_Order_Id": this.serviceOrderId,
      "Service_Specific_Id": this.serviceSpecificId,
      ...this.singleEndPointDeviceRecord
    };
    console.log(this.partialDeleteRequest);
  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.ServiceModuleAPIService.breadcrumbNavigation(path);
  }

  onSuccess(type, response) {
    if (type == 'Success Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          text: 'Service Order Id : ' + response['data']['service_order_id'],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.router.navigate(['layout/underlayService']);
        }
      })
    }
  }

  onFailure(type, response) {
    if (type == 'Failure Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).catch(swal.noop)
    }
  }


}
