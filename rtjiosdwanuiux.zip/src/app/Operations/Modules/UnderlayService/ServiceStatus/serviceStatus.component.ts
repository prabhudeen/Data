import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';
import { NgForm } from '@angular/forms';

@Component({
    selector: 'service-status',
    templateUrl: './serviceStatus.component.html',
    styleUrls: ['./serviceStatus.component.css']
})
export class ServiceStatusComponent implements OnInit {

    @ViewChild('form') form: NgForm;
    showTable: boolean = false;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number = 0;
    offSet: number = 0;
    pageSize = 5;
    serviceStatusList = [];
    serviceStatusTempList = [];
    getCustomersJson: any = {};
    customerIdArray: any[] = [];
    serviceSpecificIdArray: any[] = [];
    disableServiceSpecificId: boolean = true;
    customerId: any;
    serviceSpecificId: any;

    constructor(private router: Router,
        private route: ActivatedRoute,
        private serviceModuleAPIService: ServiceModuleAPIService) { }

    ngOnInit(): void {
        this.serviceModuleAPIService.getAllCustomerDetails()
            .subscribe(
                response => {
                    if (response['status_code'] === 200) {
                        console.log('getAllCustomerDetails Json successful:', response);
                        this.getCustomersJson = response['data'];
                        this.customerIdArray = Object.keys(response['data']);
                    } else {
                        console.log('getAllCustomerDetails Json failed:', response);
                    }
                }
            )
    }

    onGet() {
        let customerId = this.form.value['customerId'];
        let serviceSpecificId = this.form.value['serviceSpecificId'];
        this.serviceModuleAPIService.getServiceStatus(customerId, serviceSpecificId).subscribe(
            (response) => {
                console.log(response);
                this.showTable = true;
                this.serviceStatusList = response;
                this.length = this.serviceStatusList.length;
                this.serviceStatusTempList = this.serviceStatusList.slice(0, this.pageSize);
            }
        );
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onCustomerIdChange(name) {
        if (this.getCustomersJson[name]) {
            this.disableServiceSpecificId = false;
            this.serviceSpecificIdArray = this.getCustomersJson[name]['serviceSpecificIdList'];
        } else {
            this.disableServiceSpecificId = true;
        }
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.serviceStatusTempList = this.serviceStatusList.slice(firstCut, secondCut);
    }

    breadcrumbNavigation(path: string) {
        this.serviceModuleAPIService.breadcrumbNavigation(path);
    }

}
