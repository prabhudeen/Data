import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import swal from 'sweetalert2';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  customerId;
  @ViewChild('form') addCustomerForm: NgForm;

  constructor(private router: Router,
    private addCustomerService: ServiceModuleAPIService,
    private route: ActivatedRoute) { }

  ngOnInit() {
  }


  onSuccess(type, response) {
    if (type == 'Success Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          text: response["data"]["customer_id"],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.router.navigate(['../service/provisionService'], { relativeTo: this.route });
        }
        else {
          console.log("not deleted");
        }
      })
    }
  }

  onFailure(type, response) {
    if (type == 'Failure Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          // text:  response["data"]["customer_id"],   
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).catch(swal.noop)
    }
  }

  onNext() {

    let addcustomerJSON = {
      "customer_id": this.addCustomerForm.value.customer_id,
      "customer_name": this.addCustomerForm.value.customer_name,
      "short_name": this.addCustomerForm.value.customer_name.substring(0, 4)
    }

    this.addCustomerService.addCustomerDetails(addcustomerJSON).subscribe(
      (response) => {
        console.log(response);
        if (response["status_code"] < 3000) {
          this.customerId = response["data"]["customer_id"];
          this.onSuccess("Success Case", response);
        }
        else {
          this.onFailure("Failure Case", response);
        }
      }
    );
  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.addCustomerService.breadcrumbNavigation(path);
  }

}
