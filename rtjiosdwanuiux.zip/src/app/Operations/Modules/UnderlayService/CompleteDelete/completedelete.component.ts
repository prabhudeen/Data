import { Component, OnInit, ViewChild } from '@angular/core';
import swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { ServiceModuleAPIService } from '../ServiceModule_API.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';

@Component({
  selector: 'app-completedelete',
  templateUrl: './completedelete.component.html',
  styleUrls: ['./completedelete.component.css']
})
export class CompletedeleteComponent implements OnInit {

  @ViewChild('form') deleteForm: NgForm;
  public completeDeleteRequest;
  public customerId;
  getCustomersJson: any = {};
  customerIdArray: string[] = [];
  disableServiceSpecificId: boolean = true;
  serviceSpecificIdArray: any[] = [];
  serviceSpecificId: any;

  constructor(private ServiceModuleAPIService: ServiceModuleAPIService,
    private router: Router,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService) { }

  ngOnInit() {
    this.ServiceModuleAPIService.getAllCustomerDetails()
      .subscribe(
        response => {
          if (response['status_code'] === 200) {
            console.log('getAllCustomerDetails Json successful:', response);
            this.getCustomersJson = response['data'];
            this.customerIdArray = Object.keys(response['data']);
          } else {
            console.log('getAllCustomerDetails Json failed:', response);
          }
        }
      )
  }

  onCustomerIdChange(name) {
    if (this.getCustomersJson[name]) {
      this.disableServiceSpecificId = false;
      this.serviceSpecificIdArray = this.getCustomersJson[name]['serviceSpecificIdList'];
    } else {
      this.disableServiceSpecificId = true;
    }
  }

  showSwal(type) {
    if (type == 'warning-message-and-confirmation') {
      swal(
        {
          title: "Are you sure want to Delete",
          text: "Are you sure want to Delete",
          type: 'warning',
          showCancelButton: true,
          cancelButtonClass: "btn btn-danger",
          confirmButtonClass: "btn btn-primary",
          confirmButtonText: 'YES',
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.makeJson();
          this.completeDelete();
        }
        else {
          console.log("not deleted");
        }
      })
    }
  }

  makeJson() {
    this.completeDeleteRequest = {
      Customer_Id: this.deleteForm.value['customerId'],
      Service_Specific_Id: this.deleteForm.value['serviceSpecificId']
    }
  }

  completeDelete() {
    console.log("Going for Complete Delete");
    console.log(this.completeDeleteRequest);
    this.spinnerService.start(60000 * 5);
    this.ServiceModuleAPIService.deletesingleservice(this.completeDeleteRequest).subscribe(
      (response) => {
        this.spinnerService.stop();
        if (response["status_code"] < 3000) {
          this.onSuccess("Success Case", response);
        }
        else {
          this.onFailure("Failure Case", response);
        }
      }
    );
    this.deleteForm.reset();
  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  breadcrumbNavigation(path: string) {
    this.ServiceModuleAPIService.breadcrumbNavigation(path);
  }

  onSuccess(type, response) {
    if (type == 'Success Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          text: 'Customer Id : ' + response["data"]["customer_id"] + '\n' + 'Service Specific Id : ' + response['data']['service_specific_id'],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).then((result) => {
        if (result.value) {
          this.router.navigate(['layout/underlayService']);
        }
      })
    }
  }

  onFailure(type, response) {
    if (type == 'Failure Case') {
      console.log(response);
      swal(
        {
          title: response["reason"],
          confirmButtonClass: "btn btn-info",
          buttonsStyling: false
        }
      ).catch(swal.noop)
    }
  }

}
