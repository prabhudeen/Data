import { Routes } from '@angular/router';
import { CompletedeleteComponent } from './CompleteDelete/completedelete.component';
import { PartialdeleteComponent } from './PartialDelete/partialdelete.component';
import { ProvisionServiceComponent } from './ProvisionService/provision-service.component';
import { ModifyServiceComponent } from './ModifyService/modify-service.component';
import { AddCustomerComponent } from './AddCustomer/add-customer.component';
import { UnderlayServiceComponent } from './underlay-service.component';
import { ServiceStatusComponent } from './ServiceStatus/serviceStatus.component';
import { ModuleActivateGuard } from '../../../SharedFolder/services/moduleActivate.guard';

export const ServiceRoutes: Routes = [
    {
        path: '',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'Underlay Management' },
        component: UnderlayServiceComponent
    },
    {
        path: 'deleteService',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Delete Service' },
        component: CompletedeleteComponent
    },
    {
        path: 'partialDeleteService',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Partial Delete' },
        component: PartialdeleteComponent
    },
    {
        path: 'provisionService',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Provision Service' },
        component: ProvisionServiceComponent
    },
    {
        path: 'modifyService',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Modify Service' },
        component: ModifyServiceComponent
    },
    {
        path: 'addCustomer',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Add Customer' },
        component: AddCustomerComponent
    },
    {
        path: 'serviceStatus',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'Underlay Management', subModuleName: 'Service Status' },
        component: ServiceStatusComponent
    }
]
