import { Component, OnInit, ViewChild } from '@angular/core';
import { FilterArray } from '../Utility/filter.pipe';
import { UserManagementService } from '../user-management.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { NotificationService } from '../../../../SharedFolder/services/notification.service';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { PageEvent, MatPaginator } from '@angular/material';
import { OrderByDate } from '../Utility/orderbydate.pipe';
import { MessageMapping } from 'iam';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';
import { NameFilterPipe } from '../Utility/name-filter.pipe';
import { UIConfigurationService } from '../../../../SharedFolder/services/UIConfig.service';

declare var $: any;
@Component({
    selector: 'user-list-component',
    templateUrl: './user-list.component.html',
    styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
    userList: any[] = [];
    show: boolean = false;
    userSelect: boolean = false;
    adminSelect: boolean = false;
    FilterList: any[] = [];
    searchValue = '';
    role: string;
    userName: string;
    isEdit: boolean = false;
    editData: any;
    step: number = 1;
    length: number;
    pageSize = 10;
    pageIndex: number = 0;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    previousPageIndex: number;
    opticalTransport: boolean = false;
    cpeManagement: boolean = false;
    underlayService: boolean = false;
    userManagement: boolean = false;
    todayDate = new Date();
    opticalTransportList: any[] = [];
    cpeManagementList: any[] = [];
    underlayServiceList: any[] = [];
    userManagementList = { title: 'User Management', read: true, write: true, delete: true, all: true };
    tempData: any;
    jsonBody: any;
    @ViewChild('form') form: NgForm;
    @ViewChild('form2') form2: NgForm;
    @ViewChild('paginator') paginator: MatPaginator;
    index: number;
    roleId: any;
    indexDelete: number;
    isSuccess: boolean = false;
    filtered: boolean = false;
    FilterData: any[] = [];
    FilterDataBySearch: any[] = [];
    submitEnable: boolean = false;
    lockItem: any;
    lockUserIndex: boolean;
    afterdeleteModal: boolean;
    unlockItem: boolean;
    unlockUserIndex: boolean = false;
    uiConfiguration;

    constructor(private userMangementService: UserManagementService,
        private router: Router,
        private notificationService: NotificationService,
        private accessService: AccessService,
        private ngxService: SpinnerService,
        private uiConfigurationService: UIConfigurationService) { }

    ngOnInit(): void {

        this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
        this.pageSize = 5;

        this.opticalTransportList = [
            { title: 'Ciena MCP Bandwidth on Demand Module', read: false, write: false, delete: false },
            { title: 'Ciena MCP GCT Module', read: false, write: false, delete: false },
            { title: "Ciena MCP Health Check Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Get Data Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Alarm Analysis Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Backup and Restore Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP PM Management Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Inventory Management Module", read: false, write: false, delete: false, all: false },

            { title: 'Nokia NSP Bandwidth on Demand Module', read: false, write: false, delete: false },
            { title: 'Nokia NSP GCT Module', read: false, write: false, delete: false },
            { title: "Nokia NSP Health Check Module", read: false, write: false, delete: false },
            { title: "Nokia NSP Get Data Module", read: false, write: false, delete: false },
            { title: "Nokia Infra trails Module", read: false, write: false, delete: false }
        ];

        this.cpeManagementList = [
            { title: 'Circle', read: false, write: false, delete: false },
            { title: 'Domain Server', read: false, write: false, delete: false },
            { title: 'ZTP', read: false, write: false, delete: false },
            { title: 'Custom Parameters', read: false, write: false, delete: false },
            { title: 'Template Management', read: false, write: false, delete: false },
            { title: 'Customer Details', read: false, write: false, delete: false },
            { title: 'BootStrap Server Details', read: false, write: false, delete: false },
        ];

        this.underlayServiceList = [
            { title: 'Add Customer', read: false, write: false, delete: false },
            { title: 'Provision Service', read: false, write: false, delete: false },
            { title: 'Modify Service', read: false, write: false, delete: false },
            { title: 'Delete Service', read: false, write: false, delete: false },
            { title: 'Partial Delete', read: false, write: false, delete: false },
            { title: 'Service Status', read: false, write: false, delete: false }
        ]

        this.getUserList();
    }

    getUserList() {
        this.userMangementService.getUserList().subscribe((data) => {
            this.userList = data['statusCode']['AppData']['userInfo'];
            this.FilterList = this.userList;
            if (this.FilterList.length > 1)
                this.FilterList = new OrderByDate().transform(this.userList, 'timestamp');
            this.length = this.FilterList.length;
            this.FilterList = this.userList.slice(0, this.pageSize);
            if (this.searchValue != '') {
                this.onFilter(undefined);
            }
            console.log(JSON.stringify(data['statusCode']['AppData']['userInfo']));
        });
    }

    onSelect(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.show = !this.show;

    }
    onSelect1() {
        this.show = false;
    }
    onFilter(event) {
        let filterby = '';
        if (event && event.stopPropagation) {
            event.stopPropagation();
        }
        setTimeout(() => {
            if (this.userSelect && this.adminSelect) {
                filterby = 'all';
                this.filtered = false;
            }
            else if (this.userSelect) {
                filterby = 'user';
                this.filtered = true;
            }
            else if (this.adminSelect) {
                filterby = 'admin';
                this.filtered = true;
            }
            else {
                filterby = 'all';
                this.filtered = false;
            }
            if (this.searchValue != '' && this.filtered) {

                this.FilterDataBySearch = new NameFilterPipe().transform(this.userList, this.searchValue, 'userName', 'email');
                this.FilterData = new FilterArray().transform(this.FilterDataBySearch, filterby);

            }
            else if (this.searchValue != '') {
                this.FilterDataBySearch = new NameFilterPipe().transform(this.userList, this.searchValue, 'userName', 'email');
                this.FilterData = this.FilterDataBySearch;

            }
            else {
                this.FilterData = new FilterArray().transform(this.userList, filterby);
            }
            this.updateFilterListToShowOntable();
            console.log("onfilter");
        }, 500);

    }
    onPageChanged(e) {
        console.log(this.paginator.pageIndex);
        console.log(e.pageSize);
        this.pageSize = e.pageSize;
        let from = e.pageSize * e.pageIndex;
        let to = from + e.pageSize;
        if (this.searchValue != '' || this.filtered) {
            console.log("search value and filterd");
            this.FilterList = this.FilterData.slice(from, to);
        }
        else {

            this.FilterList = this.userList.slice(from, to);
        }
    }
    updateFilterListToShowOntable() {
        this.length = this.FilterData.length;
        this.updatePageIndex();
        this.FilterList = this.FilterData.slice(0, this.pageSize);
    }
    updatePageIndex() {
        setTimeout(() => {
            if (this.length > 0)
                this.paginator.pageIndex = 0;
        }, 200)
    }
    onDeleteModal(item) {
        this.indexDelete = this.userList.findIndex((record) => { return record.roleId === item.roleId });
        this.role = item.role;
        this.userName = item.userName;
        this.roleId = item.roleId;
    }
    onDelete() {
        this.ngxService.start();

        this.userMangementService.deleteUser(this.userName).subscribe((result) => {
            setTimeout(() => {
                // console.log('result :', result);
                if (result['statusCode']['httpstatuscode'] == 200) {
                    this.userMangementService.deleteRole(this.roleId).subscribe((data) => {
                        this.ngxService.stop();
                        if (data['statusCode']['httpstatuscode'] == 200) {
                            this.isSuccess = true;
                            this.userList.splice(this.indexDelete, 1);
                            this.FilterList = this.userList;
                            this.length = this.userList.length;
                            // this.paginator.pageIndex = 0;
                            this.FilterList = this.FilterList.slice(this.paginator.pageIndex * this.pageSize, this.paginator.pageIndex * this.pageSize + this.pageSize);
                            if (this.length > 0 && this.FilterList.length == 0) {
                                this.paginator.pageIndex = this.paginator.pageIndex - 1;
                                this.FilterList = this.userList.slice((this.paginator.pageIndex) * this.pageSize, (this.paginator.pageIndex) * this.pageSize + this.pageSize);
                            }
                            $('#afterdeleteModal').modal('show');
                        }
                        else {
                            this.isSuccess = false;
                            $('#afterdeleteModal').modal('show');
                        }
                    })
                } else {
                    this.isSuccess = false;
                    $('#afterdeleteModal').modal('show');
                }


            }, 2000)

        });

    }

    afterDelete() {
    }

    onEdit(item) {
        this.isEdit = true;
        this.editData = item;
        let dob = this.editData.dob;
        let [day, month, year] = dob.split('-');
        let date = new Date(year, month - 1, day);
        this.editData.dob = date;
        this.opticalTransport = false;
        this.cpeManagement = false;
        this.underlayService = false;

        this.userMangementService.getRole(item.roleId).subscribe((data) => {
            let moduleShortCode = this.accessService.getShortCode('Optical Transport');
            console.log(JSON.stringify(data));

            if (data[moduleShortCode]) {
                this.opticalTransport = true;
                this.opticalTransportList.forEach(element => {
                    let subModuleShortCode = this.accessService.getShortCode(element.title);
                    if (data[moduleShortCode][subModuleShortCode]) {
                        element.read = data[moduleShortCode][subModuleShortCode]['access']['R'] ? true : false;
                        element.write = data[moduleShortCode][subModuleShortCode]['access']['W'] ? true : false;
                        element.delete = data[moduleShortCode][subModuleShortCode]['access']['D'] ? true : false;
                        if (data[moduleShortCode][subModuleShortCode]['access']['W'] && data[moduleShortCode][subModuleShortCode]['access']['D'])
                            element['all'] = true;
                    } else {
                        element.read = false;
                        element.write = false;
                        element.delete = false;
                        element.all = false;
                    }
                })
            }

            moduleShortCode = this.accessService.getShortCode('CPE Management');
            if (data[moduleShortCode]) {
                this.cpeManagement = true;
                this.cpeManagementList.forEach(element => {
                    let subModuleShortCode = this.accessService.getShortCode(element.title);
                    if (data[moduleShortCode][subModuleShortCode]) {
                        element.read = data[moduleShortCode][subModuleShortCode]['access']['R'] ? true : false;
                        element.write = data[moduleShortCode][subModuleShortCode]['access']['W'] ? true : false;
                        element.delete = data[moduleShortCode][subModuleShortCode]['access']['D'] ? true : false;
                        if (data[moduleShortCode][subModuleShortCode]['access']['W'] && data[moduleShortCode][subModuleShortCode]['access']['D'])
                            element['all'] = true;
                    } else {
                        element.read = false;
                        element.write = false;
                        element.delete = false;
                        element.all = false;
                    }
                })
            }

            moduleShortCode = this.accessService.getShortCode('Underlay Management');
            if (data[moduleShortCode]) {
                this.underlayService = true;
                this.underlayServiceList.forEach(element => {
                    let subModuleShortCode = this.accessService.getShortCode(element.title);
                    if (data[moduleShortCode][subModuleShortCode]) {
                        element.read = data[moduleShortCode][subModuleShortCode]['access']['R'] ? true : false;
                        element.write = data[moduleShortCode][subModuleShortCode]['access']['W'] ? true : false;
                        element.delete = data[moduleShortCode][subModuleShortCode]['access']['D'] ? true : false;
                        if (data[moduleShortCode][subModuleShortCode]['access']['W'] && data[moduleShortCode][subModuleShortCode]['access']['D'])
                            element['all'] = true;
                    } else {
                        element.read = false;
                        element.write = false;
                        element.delete = false;
                        element.all = false;
                    }
                })
            }

            moduleShortCode = this.accessService.getShortCode('User Management');
            if (data[moduleShortCode]) {
                this.userManagement = true;
                this.userManagementList = {
                    title: 'User Management',
                    read: true,
                    write: true,
                    delete: true,
                    all: true
                }
            }
        })

    }
    roleChanged() {
        this.opticalTransport = false;
        this.cpeManagement = false;
        this.underlayService = false;
        this.userManagement = false;
    }
    onNext() {
        this.step = 2;

        if (this.opticalTransport) {
            this.index = 0;
        } else if (this.cpeManagement) {
            this.index = 1;
        } else if (this.underlayService) {
            this.index = 2;
        }

        // if (this.editData.role === 'admin') {
        //     if (this.opticalTransport) {
        //         this.opticalTransportList = [
        //             { title: 'Ciena MCP Bandwidth on Demand Module', read: true, write: true, delete: true },
        //             { title: 'Ciena MCP GCT Module', read: true, write: true, delete: true },
        //             { title: "Ciena MCP Health Check Module", read: true, write: true, delete: true, all: true },
        //             { title: "Ciena MCP Get Data Module", read: true, write: true, delete: true, all: true },

        //             { title: 'Nokia NSP Bandwidth on Demand Module', read: true, write: true, delete: true },
        //             { title: 'Nokia NSP GCT Module', read: true, write: true, delete: true },

        //             { title: "Nokia NSP Health Check Module", read: true, write: true, delete: true },
        //             { title: "Nokia NSP Get Data Module", read: true, write: true, delete: true },
        //             { title: "Nokia Infra trails Module", read: false, write: false, delete: false }

        //         ];
        //     }

        //     if (this.cpeManagement) {
        //         this.cpeManagementList = [
        //             { title: 'Circle', read: true, write: true, delete: true },
        //             { title: 'Domain Server', read: true, write: true, delete: true },
        //             { title: 'ZTP', read: true, write: true, delete: true },
        //             { title: 'Custom Parameters', read: true, write: true, delete: true },
        //             { title: 'Template Management', read: true, write: true, delete: true },
        //             { title: 'Customer Details', read: true, write: true, delete: true },
        //             { title: 'BootStrap Server Details', read: true, write: true, delete: true },
        //         ];
        //     }

        //     if (this.underlayService) {
        //         this.underlayServiceList = [
        //             { title: 'Add Customer', read: true, write: true, delete: true },
        //             { title: 'Provision Service', read: true, write: true, delete: true },
        //             { title: 'Modify Service', read: true, write: true, delete: true },
        //             { title: 'Delete Service', read: true, write: true, delete: true },
        //             { title: 'Partial Delete', read: true, write: true, delete: true },
        //             { title: 'Service Status', read: true, write: true, delete: true }
        //         ]
        //     }
        // }

    }

    validationAccess(item, type) {

        if (type === 'write') {
            item.write ? item.read = item.write : item.read = item.delete
        } else if (type === 'delete') {
            item.delete ? item.read = item.delete : item.read = item.write
        } else {
            item.read = item.all;
            item.write = item.all;
            item.delete = item.all;
        }
        if (item.read === true && item.write === true && item.delete === true) {
            item.all = true;
        } else {
            item.all = false;
        }

        return item;
    }
    onCancel() {
        if (this.step === 1) {
            // this.router.navigate(['../'], { relativeTo: this.route });
            this.isEdit = false;
            this.getUserList();
            this.searchValue = '';
        } else {
            this.step = 1;
        }
    }
    resetList() {
        this.opticalTransportList = [
            { title: 'Ciena MCP Bandwidth on Demand Module', read: false, write: false, delete: false },
            { title: 'Ciena MCP GCT Module', read: false, write: false, delete: false },
            { title: "Ciena MCP Health Check Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Get Data Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Alarm Analysis Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Backup and Restore Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP PM Management Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Inventory Management Module", read: false, write: false, delete: false, all: false },


            { title: 'Nokia NSP Bandwidth on Demand Module', read: false, write: false, delete: false },
            { title: 'Nokia NSP GCT Module', read: false, write: false, delete: false },

            { title: "Nokia NSP Health Check Module", read: false, write: false, delete: false },
            { title: "Nokia NSP Get Data Module", read: false, write: false, delete: false },
            { title: "Nokia Infra trails Module", read: false, write: false, delete: false }

        ];
        this.cpeManagementList = [
            { title: 'Circle', read: false, write: false, delete: false },
            { title: 'Domain Server', read: false, write: false, delete: false },
            { title: 'ZTP', read: false, write: false, delete: false },
            { title: 'Custom Parameters', read: false, write: false, delete: false },
            { title: 'Template Management', read: false, write: false, delete: false },
            { title: 'Customer Details', read: false, write: false, delete: false },
            { title: 'BootStrap Server Details', read: false, write: false, delete: false },
        ];
        this.underlayServiceList = [
            { title: 'Add Customer', read: false, write: false, delete: false },
            { title: 'Provision Service', read: false, write: false, delete: false },
            { title: 'Modify Service', read: false, write: false, delete: false },
            { title: 'Delete Service', read: false, write: false, delete: false },
            { title: 'Partial Delete', read: false, write: false, delete: false },
            { title: 'Service Status', read: false, write: false, delete: false }
        ]
    }
    onSave() {

        let dobForm: Date = this.form.value.dob;
        let date = dobForm.getDate();
        let month = dobForm.getMonth() + 1;
        let year = dobForm.getFullYear();

        let dob = `${date}-${month}-${year}`;

        let userBody = {
            "userInfo": {
                "fullName": this.form.value.fullName,
                "email": this.form.value.email,
                "userName": this.form.value.userName,
                "dob": dob,
                "userPassword": this.form.value.password,
                "contact": this.form.value.mobileNumber,

            }
        }

        delete userBody['userInfo']['userPassword'];

        let jsonBody = {
            "userName": this.form.value.userName,
            "role": this.editData.role

        }
        userBody['userInfo']['roleId'] = `${jsonBody['userName']}${jsonBody['role']}`.toLowerCase();
        userBody['userInfo']['roleName'] = `${jsonBody['userName']}${jsonBody['role']}`;

        if (this.cpeManagement) {
            jsonBody['CPE Management'] = this.cpeManagementList;
        }

        if (this.opticalTransport) {
            jsonBody['Optical Transport'] = this.opticalTransportList;
        }

        if (this.underlayService) {
            jsonBody['Underlay Management'] = this.underlayServiceList;
        }

        if (this.userManagement) {
            jsonBody['User Management'] = this.userManagementList;
        }

        console.log(JSON.stringify(jsonBody));
        this.ngxService.start();
        this.userMangementService.editRole(`${jsonBody['userName']}${jsonBody['role']}`.toLowerCase(), jsonBody)
            .subscribe((res) => {
                console.log(res);
                if (res['statusCode']['httpstatuscode'] != 200) {
                    this.ngxService.stop();
                    let message = MessageMapping.getMessage(+res['statusCode']['opStatusCode']);
                    this.notificationService.notificationMessage(message, 'danger');
                }
                // setTimeout(() => {
                this.userMangementService.editUser(`${userBody['userInfo']['userName']}`, userBody)
                    .subscribe(
                        (response) => {
                            let message = MessageMapping.getMessage(+response['statusCode']['opStatusCode']);
                            this.ngxService.stop();
                            if (response['statusCode']['httpstatuscode'] == 200) {
                                this.notificationService.notificationMessage(message, 'success');
                            }
                            else {
                                this.notificationService.notificationMessage(message, 'danger');
                            }
                            this.router.navigate(['layout/userManagement']);
                            console.log(response);
                        },
                        (error) => {
                            console.log('error case in createUser:', error);
                        }
                    )
                // }, 2000)
            })

    }

    breadcrumbNavigation(path: string) {
        this.userMangementService.breadcrumbNavigation(path);
    }
    exportUserListasExcel() {
        this.userMangementService.getUserListAsExcel();
    }

    changeTick() {

        let cpeFlag = false;
        let optFlag = false;
        let underlayServiceFlag = false;

        if (this.cpeManagement) {
            this.cpeManagementList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    cpeFlag = true;
                }
            });
        } else {
            cpeFlag = true;
        }

        if (this.opticalTransport) {
            this.opticalTransportList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    optFlag = true;
                }
            });
        } else {
            optFlag = true;
        }

        if (this.underlayService) {
            this.underlayServiceList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    underlayServiceFlag = true;
                }
            });
        } else {
            underlayServiceFlag = true;
        }

        this.submitEnable = cpeFlag && optFlag && underlayServiceFlag;

    }
    beforeLockUser(item) {
        this.indexDelete = this.userList.findIndex((record) => { return record.roleId === item.roleId });
        this.role = item.role;
        this.userName = item.userName;
        this.roleId = item.roleId;
        this.lockUserIndex = true;

    }
    beforeUnLockUser(item) {
        this.indexDelete = this.userList.findIndex((record) => { return record.roleId === item.roleId });
        this.role = item.role;
        this.userName = item.userName;
        this.roleId = item.roleId;
        this.lockUserIndex = false;

    }

    lockUser() {
        this.ngxService.start();
        this.userMangementService.lockUser(this.userName).subscribe(res => {
            console.log('res :', res);

            this.ngxService.stop();
            if (res['statusCode']['httpstatuscode'] == 200) {
                this.isSuccess = true;

                this.lockItem = true;
                $('#afterLockModal').modal('show');
                setTimeout(() => {
                    // this.searchValue = '';
                    this.getUserList();
                }, 1000);
            }
            else {
                this.isSuccess = false;
                this.lockItem = false;
                $('#afterLockModal').modal('show');

            }
        })
    }

    unlockUser() {
        this.ngxService.start();

        this.userMangementService.unlockUser(this.userName).subscribe(res => {
            console.log('res :', res);
            this.ngxService.stop();
            if (res['statusCode']['httpstatuscode'] == 200) {

                this.isSuccess = true;
                this.unlockItem = true;
                $('#afterUnLockModal').modal('show');
                setTimeout(() => {
                    // this.searchValue = '';
                    this.getUserList();
                }, 1000);

            }
            else {
                this.isSuccess = false;
                this.unlockItem = false;
                $('#afterUnLockModal').modal('show');

            }
        })
    }

}
