import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../SharedFolder/services/sd-wan-service.service';
import { IamService } from 'iam';
import { AccessService } from '../../../SharedFolder/services/access.service';
import { Router } from '@angular/router';


@Injectable({
    providedIn: "root"
})
export class UserManagementService {

    ModuleArray: string[] = ['Optical Transport', 'CPE Management', 'Underlay Management', 'User Management'];
    tempData = {
        "freeAllow": {
            "access": {
                "R": true,
                "W": true,
                "D": true
            }
        },
        "sc2": {
            "sc2.1": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.5": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.8": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.2": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.6": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.3": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.4": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc2.7": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            }
        },
        "sc1": {
            "sc1.1": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc1.2": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc1.3": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc1.4": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            },
            "sc1.5": {
                "access": {
                    "R": true,
                    "W": true,
                    "D": true
                }
            }
            // ,
            // "sc1.6": {
            //     "access": {
            //         "R": true,
            //         "W": true,
            //         "D": true
            //     }
            // },
            // "sc1.7": {
            //     "access": {
            //         "R": true,
            //         "W": true,
            //         "D": true
            //     }
            // },
        }
    };

    constructor(private commonService: SdWanServiceService,
        private accessService: AccessService,
        private _iamService: IamService,
        private router: Router) { }

    createRole(jsonBody) {
        let json = this.createRoleObject(jsonBody, "create");

        return new Observable<any>(observe => {
            this._iamService.createRole(json)
                .subscribe(response => {
                    console.log('response in success:', response);
                    if (response['statusCode']['httpstatuscode'] == "200") {
                        observe.next({
                            value: true,
                            data: response
                        })
                    } else {
                        observe.next({
                            value: false,
                            data: response
                        });
                    }
                }, error => {
                    observe.error({
                        value: false,
                        data: error
                    });
                    console.log('error response :', error);
                })
        });
    }

    private createRoleObject(json, method) {
        let jsonBody = {
            "roleInfo": {
                "role": {
                    "roleName": `${json.userName}${json.role}`,
                    "roleDescription": `${json.userName}${json.role}`,
                    "roleParameters": {}
                }
            }
        }
        if (method === 'edit') {
            jsonBody['roleInfo']['role']['roleId'] = `${json.userName}${json.role}`.toLowerCase();
        }
        this.ModuleArray.forEach(moduleTitle => {
            if (moduleTitle === 'User Management') {

                let result = {};

                if (json[moduleTitle]) {
                    let moduleName = json[moduleTitle];
                    if (moduleName.read) {
                        result['Read'] = true;
                    }
                    if (moduleName.write) {
                        result['Write'] = true;
                    }
                    if (moduleName.delete) {
                        result['Delete'] = true;
                    }
                    let shortCodeForModule = this.accessService.getShortCode(moduleTitle);
                    result['shortCode'] = shortCodeForModule;
                    jsonBody['roleInfo']['role']['roleParameters'][moduleTitle] = result;
                }

            } else if (json[moduleTitle]) {
                let result = {};
                json[moduleTitle].forEach(subModule => {

                    result[subModule.title] = {}

                    if (subModule.read) {
                        result[subModule.title].Read = true;
                    }
                    if (subModule.write) {
                        result[subModule.title].Write = true;
                    }
                    if (subModule.delete) {
                        result[subModule.title].Delete = true;
                    }

                    let subModuleForShortCode = this.accessService.getShortCode(subModule.title);
                    result[subModule.title].shortCode = subModuleForShortCode;
                });

                let shortCodeForModule = this.accessService.getShortCode(moduleTitle);
                result['shortCode'] = shortCodeForModule;
                jsonBody['roleInfo']['role']['roleParameters'][moduleTitle] = result;
            }
        })
        console.log('jsonBody in userManagement:', JSON.stringify(jsonBody));
        return jsonBody;
    }

    createUser(jsonBody) {
        return new Observable<any>(observe => {
            this._iamService.createSingleUser('admin', jsonBody)
                .subscribe(response => {
                    console.log('response in success:', response);
                    if (response['statusCode']['httpstatuscode'] == "200") {
                        observe.next({
                            value: true,
                            data: response
                        })
                    } else {
                        observe.next({
                            value: false,
                            data: response
                        });
                    }
                }, error => {
                    observe.error({
                        value: false,
                        data: error
                    });
                    console.log('error response :', error);
                })
        });
    }

    getUserList() {
        return new Observable((observe) => {
            this._iamService.getAllUser(0, 1000).subscribe((response) => {
                console.log(response);
                observe.next(response);

            })
        });

    }

    getRole(roleId) {
        return new Observable((observe) => {
            console.log(roleId);

            this._iamService.viewRole(roleId).subscribe((data) => {
                console.log(JSON.stringify(data));
                if (data['statusCode']['httpstatuscode'] == 200) {
                    let temp = data['statusCode']['AppData']['_source']['roleInfo']['role']['roleParameters'];
                    let result = {};
                    Object.keys(temp).forEach(moduleElement => {

                        let shortCodeForModule = temp[moduleElement].shortCode;
                        result[shortCodeForModule] = {};
                        let flag = true;
                        let count = 0;
                        let notExist = 0;
                        Object.keys(temp[moduleElement]).forEach(subElement => {
                            if (subElement !== 'shortCode') {
                                count++;
                                let shortCodeForSubModule = temp[moduleElement][subElement].shortCode;
                                result[shortCodeForModule][shortCodeForSubModule] = {};
                                result[shortCodeForModule][shortCodeForSubModule]['access'] = {};

                                if (Object.keys(temp[moduleElement][subElement]).length !== 1) {
                                    let read = temp[moduleElement][subElement]['Read'];
                                    let write = temp[moduleElement][subElement]['Write'];
                                    let del = temp[moduleElement][subElement]['Delete'];
                                    if (read) {
                                        result[shortCodeForModule][shortCodeForSubModule]['access']['R'] = true;
                                    }
                                    if (write) {
                                        result[shortCodeForModule][shortCodeForSubModule]['access']['W'] = true;
                                    }
                                    if (del) {
                                        result[shortCodeForModule][shortCodeForSubModule]['access']['D'] = true;
                                    }
                                } else {
                                    notExist++;
                                }
                            }
                        })
                        if (count === notExist) {
                            delete result[shortCodeForModule];
                        }
                    });
                    observe.next(result);
                }
                console.log(JSON.stringify(data));
            }, error => {
                console.log(error);
            })
        })
    }

    deleteUser(userName) {
        return new Observable((observe) => {
            console.log("delete user method");
            console.log('userName:', userName);
            this._iamService.deleteUser(userName).subscribe((data) => {
                console.log(data);
                observe.next(data);
            }, error => {
                observe.next(error);
                console.log(error);
            })
        })
    }

    deleteRole(roleId) {
        return new Observable((observe) => {
            console.log("delete Role method");
            console.log('roleId:', roleId);
            this._iamService.deleteRole(roleId).subscribe((data) => {
                observe.next(data);
                console.log(data);
            }, error => {
                observe.next(error);
                console.log(error);
            })
        })
    }
    editUser(userName, jsonBody) {
        console.log(userName, jsonBody);
        return new Observable((observe) => {
            this._iamService.modifyUser(userName, jsonBody).subscribe((data) => {
                console.log(JSON.stringify(data));
                observe.next(data);

            })
        })
    }
    editRole(roleId, roleData) {

        let json = this.createRoleObject(roleData, "edit");
        console.log(roleId, json);

        return new Observable((observe) => {

            this._iamService.modifyRole(roleId, json).subscribe((data) => {
                console.log(JSON.stringify(data));
                observe.next(data);

            })
        })
    }

    breadcrumbNavigation(path: string) {
        switch (path) {
            case 'dashboard': return this.router.navigate(['/layout/Dashboard']);
            case 'userManagement': return this.router.navigate(['/layout/userManagement']);
        }
    }
    getUserListAsExcel() {
        this._iamService.downloadBulkUsers().subscribe((response) => {
            // console.log('response :', response);
        })
    }
    downLoadTemplate(): any {
        return new Observable((observe) => {
            this._iamService.downloadUserTemplate().subscribe(
                (data) => {
                    console.log('data :', data);
                    observe.next("data");
                }
            )
        })
    }
    createBulkUser(file: File) {
        return new Observable((observe) => {

            this._iamService.createBulkRolesandUsers('admin', file).subscribe((data) => {
                console.log('data :', data);
            })
        })
    }

    lockUser(userName) {
        return new Observable((observe) => {
            this._iamService.lockUser(userName).subscribe((data) => {
                console.log('data :', data);
                observe.next(data);
            })
        })
    }

    unlockUser(userName) {
        return new Observable((observe) => {
            this._iamService.unlockUser(userName).subscribe((data) => {
                console.log('data :', data);
                observe.next(data);
            })
        })
    }

}