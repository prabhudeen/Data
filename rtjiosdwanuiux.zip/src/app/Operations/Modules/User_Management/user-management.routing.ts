import { Routes } from '@angular/router';
import { UserListComponent } from './UserList/user-list.component';
import { CreateUserComponent } from './createUser/create-user.component';
import { UserManagementComponent } from './user-management.component';
import { ModuleActivateGuard } from '../../../SharedFolder/services/moduleActivate.guard';

export const userManagementRoutes: Routes = [
    {
        path: '',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'User Management' },
        component: UserManagementComponent
    },
    {
        path: 'userList',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'User Management' },
        component: UserListComponent
    },
    {
        path: 'createUser',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'User Management' },
        component: CreateUserComponent
    }
]
