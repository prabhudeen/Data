import { Component, OnInit, ViewChild } from '@angular/core';
import { UserManagementService } from '../user-management.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { NotificationService } from '../../../../SharedFolder/services/notification.service';
import { MessageMapping } from 'iam';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';
import { UIConfigurationService } from '../../../../SharedFolder/services/UIConfig.service';

@Component({
    selector: 'create-user-component',
    templateUrl: './create-user.component.html',
    styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

    @ViewChild('form') form: NgForm;
    role: string;
    opticalTransport: boolean = false;
    cpeManagement: boolean = false;
    underlayService: boolean = false;
    userManagement: boolean = false;
    step: number = 1;
    index: number;
    opticalTransportList: any[] = [];
    cpeManagementList: any[] = [];
    underlayServiceList: any[] = [];
    userManagementList: any;
    todayDate = new Date();
    submitEnable: boolean = false;
    uiConfiguration;
    seen = false;
    seen1 = false;

    constructor(private route: ActivatedRoute,
        private router: Router,
        private service: UserManagementService,
        private notificationService: NotificationService,
        private ngxService: SpinnerService,
        private uiConfigurationService: UIConfigurationService) {

    }

    ngOnInit(): void {
        this.uiConfiguration = this.uiConfigurationService.getConfiguration()['UserValidation'];
        this.resetList();
    }

    resetList() {
        this.opticalTransportList = [
            { title: 'Ciena MCP Bandwidth on Demand Module', read: false, write: false, delete: false, all: false },
            { title: 'Ciena MCP GCT Module', read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Health Check Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Get Data Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Alarm Analysis Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Backup and Restore Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP PM Management Module", read: false, write: false, delete: false, all: false },
            { title: "Ciena MCP Inventory Management Module", read: false, write: false, delete: false, all: false },


            { title: 'Nokia NSP Bandwidth on Demand Module', read: false, write: false, delete: false, all: false },
            { title: 'Nokia NSP GCT Module', read: false, write: false, delete: false, all: false },
            // { title: 'Nokia NSP GET GCT Template Module', read: false, write: false, delete: false }
            { title: "Nokia NSP Health Check Module", read: false, write: false, delete: false, all: false },
            { title: "Nokia NSP Get Data Module", read: false, write: false, delete: false, all: false },
            { title: "Nokia Infra trails Module", read: false, write: false, delete: false, all: false }

        ];
        this.cpeManagementList = [
            { title: 'Circle', read: false, write: false, delete: false, all: false },
            { title: 'Domain Server', read: false, write: false, delete: false, all: false },
            { title: 'ZTP', read: false, write: false, delete: false, all: false },
            { title: 'Custom Parameters', read: false, write: false, delete: false, all: false },
            { title: 'Template Management', read: false, write: false, delete: false, all: false },
            { title: 'Customer Details', read: false, write: false, delete: false, all: false },
            { title: 'BootStrap Server Details', read: false, write: false, delete: false, all: false },
        ];
        this.underlayServiceList = [
            { title: 'Add Customer', read: false, write: false, delete: false, all: false },
            { title: 'Provision Service', read: false, write: false, delete: false, all: false },
            { title: 'Modify Service', read: false, write: false, delete: false, all: false },
            { title: 'Delete Service', read: false, write: false, delete: false, all: false },
            { title: 'Partial Delete', read: false, write: false, delete: false, all: false },
            { title: 'Service Status', read: false, write: false, delete: false, all: false }
        ]
        this.userManagementList =
            { title: 'User Management', read: false, write: false, delete: false, all: false }

    }

    onCancel() {
        if (this.step === 1) {
            this.router.navigate(['../'], { relativeTo: this.route });
        } else {
            this.step = 1;
        }
    }

    onNext() {
        this.step = 2;

        if (this.opticalTransport) {
            this.index = 0;
        } else if (this.cpeManagement) {
            this.index = 1;
        } else if (this.underlayService) {
            this.index = 2;
        }

        if (this.role === 'admin') {
            if (this.opticalTransport) {
                this.opticalTransportList = [
                    { title: 'Ciena MCP Bandwidth on Demand Module', read: true, write: true, delete: true, all: true },
                    { title: 'Ciena MCP GCT Module', read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP Health Check Module", read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP Get Data Module", read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP Alarm Analysis Module", read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP Backup and Restore Module", read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP PM Management Module", read: true, write: true, delete: true, all: true },
                    { title: "Ciena MCP Inventory Management Module", read: true, write: true, delete: true, all: true },


                    { title: 'Nokia NSP Bandwidth on Demand Module', read: true, write: true, delete: true, all: true },
                    { title: 'Nokia NSP GCT Module', read: true, write: true, delete: true, all: true },
                    { title: "Nokia NSP Health Check Module", read: true, write: true, delete: true, all: true },
                    { title: "Nokia NSP Get Data Module", read: true, write: true, delete: true, all: true },
                    { title: "Nokia Infra trails Module", read: true, write: true, delete: true, all: true }

                ];
            }

            if (this.cpeManagement) {
                this.cpeManagementList = [
                    { title: 'Circle', read: true, write: true, delete: true, all: true },
                    { title: 'Domain Server', read: true, write: true, delete: true, all: true },
                    { title: 'ZTP', read: true, write: true, delete: true, all: true },
                    { title: 'Custom Parameters', read: true, write: true, delete: true, all: true },
                    { title: 'Template Management', read: true, write: true, delete: true, all: true },
                    { title: 'Customer Details', read: true, write: true, delete: true, all: true },
                    { title: 'BootStrap Server Details', read: true, write: true, delete: true, all: true },
                ];
            }

            if (this.underlayService) {
                this.underlayServiceList = [
                    { title: 'Add Customer', read: true, write: true, delete: true, all: true },
                    { title: 'Provision Service', read: true, write: true, delete: true, all: true },
                    { title: 'Modify Service', read: true, write: true, delete: true, all: true },
                    { title: 'Delete Service', read: true, write: true, delete: true, all: true },
                    { title: 'Partial Delete', read: true, write: true, delete: true, all: true },
                    { title: 'Service Status', read: true, write: true, delete: true, all: true }
                ]
            }

            if (this.userManagement) {
                this.userManagementList =
                    { title: 'User Management', read: true, write: true, delete: true, all: true }

            }
        } else {
            this.resetList();
        }
    }

    roleChanged() {
        this.opticalTransport = false;
        this.cpeManagement = false;
        this.underlayService = false;
        this.userManagement = false;
    }

    validationAccess(item, type) {
        if (type === 'write') {
            item.write ? item.read = item.write : item.read = item.delete
        } else if (type === 'delete') {
            item.delete ? item.read = item.delete : item.read = item.write
        } else {
            item.read = item.all;
            item.write = item.all;
            item.delete = item.all;
        }

        if (item.read === true && item.write === true && item.delete === true) {
            item.all = true;
        } else {
            item.all = false;
        }
        return item;
    }

    changeTick() {

        let cpeFlag = false;
        let optFlag = false;
        let underlayServiceFlag = false;

        if (this.cpeManagement) {
            this.cpeManagementList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    cpeFlag = true;
                }
            });
        } else {
            cpeFlag = true;
        }

        if (this.opticalTransport) {
            this.opticalTransportList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    optFlag = true;
                }
            });
        } else {
            optFlag = true;
        }

        if (this.underlayService) {
            this.underlayServiceList.forEach(element => {
                if (element.read || element.write || element.delete) {
                    underlayServiceFlag = true;
                }
            });
        } else {
            underlayServiceFlag = true;
        }

        this.submitEnable = cpeFlag && optFlag && underlayServiceFlag;

    }

    onCreate() {
        let dobForm: Date = this.form.value.dob;
        let date = dobForm.getDate();
        let month = dobForm.getMonth() + 1;
        let year = dobForm.getFullYear();

        let dob = `${date}-${month}-${year}`;

        let userBody = {
            "userInfo": {
                "fullName": this.form.value.fullName,
                "email": this.form.value.email,
                "userName": this.form.value.userName,
                "dob": dob,
                "userPassword": this.form.value.password,
                "contact": this.form.value.mobileNumber,
                "role": this.role
            }
        }

        console.log('userBody:', userBody);


        let jsonBody = {
            "userName": this.form.value.userName,
            "role": this.role
        }

        if (this.cpeManagement) {
            jsonBody['CPE Management'] = this.cpeManagementList;
        }

        if (this.opticalTransport) {
            jsonBody['Optical Transport'] = this.opticalTransportList;
        }

        if (this.underlayService) {
            jsonBody['Underlay Management'] = this.underlayServiceList;
        }

        if (this.userManagement) {
            jsonBody['User Management'] = this.userManagementList;
        }

        this.ngxService.start();
        this.service.createRole(jsonBody)
            .subscribe((res) => {
                if (res.value) {
                    userBody['userInfo']['roleId'] = `${jsonBody['userName']}${jsonBody['role']}`.toLowerCase();
                    console.log('userBody:', JSON.stringify(userBody));
                    this.service.createUser(userBody)
                        .subscribe(
                            (response) => {
                                this.ngxService.stop();
                                let message = MessageMapping.getMessage(+response['data']['statusCode']['opStatusCode']);
                                if (response.value) {
                                    this.notificationService.notificationMessage(message, 'success');
                                } else {
                                    this.notificationService.notificationMessage(message, 'danger');
                                    this.service.deleteRole(userBody['userInfo']['roleId']).subscribe(element => {
                                        if (element['statusCode']['httpstatuscode'] == 200) {
                                            let message = MessageMapping.getMessage(+element['statusCode']['opStatusCode']);
                                            console.log('success in deleteRole message:', message);
                                        }
                                        else {
                                            let message = MessageMapping.getMessage(+element['statusCode']['opStatusCode']);
                                            console.log('error in deleteRole message:', message);
                                        }
                                    })
                                }
                                this.router.navigate(['layout/userManagement']);
                            },
                            (error) => {
                                console.log('error case in createUser:', error);
                            }
                        )
                } else {
                    let message = MessageMapping.getMessage(+res['data']['statusCode']['opStatusCode']);
                    this.ngxService.stop();
                    this.notificationService.notificationMessage(message, 'danger');
                    console.log('response:', res);
                }
            }, (error) => {
                this.ngxService.stop();
                console.log('error case in createRole:', error);
            })
    }


    breadcrumbNavigation(path: string) {
        this.service.breadcrumbNavigation(path);
    }
    downLoadTemplate() {
        this.service.downLoadTemplate().subscribe((data) => {
            console.log(data);
        }
        )

    }
    onUploadFile(event, form) {
        let file: File = event.target.files[0];
        let fileName = file.name;
        console.log(fileName);

        this.service.createBulkUser(file).subscribe(
            (data) => {
                console.log(data);
            }
        );
        // this.inputFile.nativeElement.value = '';
    }
}
