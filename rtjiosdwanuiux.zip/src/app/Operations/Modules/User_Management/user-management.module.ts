import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { userManagementRoutes } from './user-management.routing';
import { CreateUserComponent } from './createUser/create-user.component';
import { UserListComponent } from './UserList/user-list.component';
import { UserManagementComponent } from './user-management.component';
import { FilterArray } from './Utility/filter.pipe';
import { OrderByDate } from './Utility/orderbydate.pipe';
import { SharedModule } from '../../../SharedFolder/modules/shared.module';


@NgModule({
    declarations: [
        CreateUserComponent,
        UserListComponent,
        UserManagementComponent,
        FilterArray,
        OrderByDate,
    ],
    imports: [
        RouterModule.forChild(userManagementRoutes),
        SharedModule
    ]
})
export class UserManagementModule {

}
