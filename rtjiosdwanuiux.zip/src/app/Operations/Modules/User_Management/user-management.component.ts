import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserManagementService } from './user-management.service';

@Component({
    selector: 'user-management-component',
    templateUrl: './user-management.component.html',
    styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
    list: any[] = [
        {
            title: "User List",
            value: "userList"
        },
        {
            title: "Create User",
            value: "createUser"
        }
    ]
    constructor(private router: Router,
        private userManagementService: UserManagementService) { }

    ngOnInit(): void {
    }

    onClick(action) {
        switch (action) {
            case "userList":
                this.router.navigateByUrl("layout/userManagement/userList");
                break;
            case "createUser":
                this.router.navigateByUrl("layout/userManagement/createUser");
                break;
        }
    }

    breadcrumbNavigation(path: string) {
        this.userManagementService.breadcrumbNavigation(path);
    }

}
