
import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'filter'
})
export class FilterArray implements PipeTransform {

    transform(array, args) {
        let temp = [];
        console.log(args);
        if (args === 'all') {
            return array;
        }

        for (let i = 0; i < array.length; i++) {
            if (array[i].role === args) {
                console.log(args);
                temp.push(array[i]);
            }
        }
        return temp;
    }
}