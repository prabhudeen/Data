import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nameFilter'
})
export class NameFilterPipe implements PipeTransform {

  transform(arr: any, filterValue?: any, param?: any, email?: any): any {
    if (arr.length === 0 || filterValue === '' || filterValue === null || filterValue === undefined)
      return arr;
    const results = [];
    for (let item of arr) {
      if (param) {
        if (item[param].toLocaleLowerCase().startsWith(filterValue.toLocaleLowerCase()) || (email && item[email].toLocaleLowerCase().startsWith(filterValue.toLocaleLowerCase())))
          results.push(item);
      } else {
        if (item.toLocaleLowerCase().startsWith(filterValue.toLocaleLowerCase()))
          results.push(item);
      }
    }
    return results;
  }

}
