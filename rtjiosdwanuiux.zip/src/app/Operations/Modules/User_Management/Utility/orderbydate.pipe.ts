import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
    name: 'orderBydate'
})
export class OrderByDate implements PipeTransform {
    transform(array: Array<number>, args: string): Array<number> {
        
        array.sort((a: number, b: number) => {
            if (new Date(a[args]).getTime() < new Date(b[args]).getTime()) {
                return 1;
            }
            else if (new Date(a[args]).getTime() > new Date(b[args]).getTime()) {
                return -1;
            }
            else {
                return 0;
            }
        });
        return array;
    }

}