import { Validator, NG_VALIDATORS, AbstractControl } from '@angular/forms';
import { Directive, Input } from '@angular/core';

@Directive({
    selector: '[passwordValidator]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting: PasswordValidationDirective,
        multi: true
    }]
})
export class PasswordValidationDirective implements Validator {
    @Input() passwordValidator: string;
    validate(control: AbstractControl): { [key: string]: any } | null {
        const controlToCompare = control.parent.get(this.passwordValidator);
        if (controlToCompare && controlToCompare.value !== control.value) {
            return { 'notEqual': true };
        }
        return null;
    }

}