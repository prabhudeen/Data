import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { cpeManagementRoutes } from './cpeManagement.routing';
import { CPEManagementComponent } from './cpe-management.component';
import { DomainServerComponent } from './domainServer/domainServer.component';
import { CircleComponent } from './circle/circle.component';
import { ZTPComponent } from './ztp/ztp.component';
import { CircleCreateComponent } from './circle/createCircle/createCircle.component';
import { CircleGetAllComponent } from './circle/getAllCircle/getAllCircle.component';
import { DomainCreateComponent } from './domainServer/domainCreate/domainCreate.component';
import { DomainGetAllComponent } from './domainServer/getAllDomain/getAllDomain.component';
import { DomainGetByCircleComponent } from './domainServer/getDomainByCircle/getDomainByCircle.component';
import { DomainGetByDuidComponent } from './domainServer/getDomainByDuid/getDomainByDuid.component';
import { ZTPCreateComponent } from './ztp/ztpCreate/ztpCreate.component';
import { CPEManagmentModuleService } from './cpeManagementModule_API.service';
import { CircleService } from './circle/circle.service';
import { CPCustomParametersComponent } from './customParameters/customParameters.component';
import { CPCreateCustomParametersComponent } from './customParameters/createCustomParameters/createCustomParameters.component';
import { CPGetAllTargetedParametersComponent } from './customParameters/getAllTargetedParameters/getAllTargetedParameters.component';
import { CPGetParametersByCustomComponent } from './customParameters/getParametersByCustom/getParametersByCustom.component';
import { TMTemplateManagementComponent } from './templateManagement/templateManagement.component';
import { TMCreateTemplateComponent } from './templateManagement/createTemplate/createTemplate.component';
import { TMGetAllTemplate } from './templateManagement/getAllTemplate/getAllTemplate.component';
import { BootstrapServerDetailsComponent } from './bootstrap-server-details/bootstrap-server-details.component';
import { BootstrapService } from './bootstrap-server-details/bootstrapService';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { ZTPViewZtpStatus } from './ztp/viewZtpStatus/viewZtpStatus.component';
import { AddressValidator } from './addressValidator.directive';
import { SharedModule } from '../../../SharedFolder/modules/shared.module';
import { OrderStatusComponent } from './ztp/orderStatus/orderStatus.component';


@NgModule({
    declarations: [
        CPEManagementComponent,
        CircleComponent,
        DomainServerComponent,
        ZTPComponent,
        CircleCreateComponent,
        CircleGetAllComponent,
        DomainCreateComponent,
        DomainGetAllComponent,
        DomainGetByCircleComponent,
        DomainGetByDuidComponent,
        ZTPCreateComponent,
        CPCustomParametersComponent,
        CPCreateCustomParametersComponent,
        CPGetAllTargetedParametersComponent,
        CPGetParametersByCustomComponent,
        TMTemplateManagementComponent,
        TMCreateTemplateComponent,
        TMGetAllTemplate,
        BootstrapServerDetailsComponent,
        CustomerDetailsComponent,
        ZTPViewZtpStatus,
        AddressValidator,
        OrderStatusComponent
    ],
    imports: [
        RouterModule.forChild(cpeManagementRoutes),
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        SharedModule
    ],
    providers: [
        CPEManagmentModuleService,
        CircleService,
        BootstrapService
    ]
})
export class CPEManagementModule { }
