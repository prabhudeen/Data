import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from './cpeManagementModule_API.service';

@Component({
    selector: 'app-cpe-management',
    templateUrl: './cpe-management.component.html',
    styleUrls: ['./cpe-management.component.css']
})
export class CPEManagementComponent implements OnInit {

    list: any[] = [
        {
            title: "CIRCLE",
            access: true,
            value: "Circle"
        },
        {
            title: "RV DOMAIN SERVER",
            access: true,
            value: "Domain Server"
        },
        {
            title: "ZTP",
            access: true,
            value: "ZTP"
        },
        {
            title: "CUSTOM PARAMETERS",
            access: true,
            value: "Custom Parameters"
        },
        {
            title: "TEMPLATE MANAGEMENT",
            access: true,
            value: "Template Management"
        },
        {
            title: "BOOTSTRAP SERVER DETAILS",
            access: true,
            value: "BootStrap Server Details"
        },
        {
            title: "CUSTOMER DETAILS",
            access: true,
            value: "Customer Details"
        }
    ]

    constructor(private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit() {
        this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'CPE Management');
    }

    onClick(action) {
        switch (action) {
            case "Circle":
                this.router.navigateByUrl("layout/CPE_Management/circle");
                break;
            case "Domain Server":
                this.router.navigateByUrl("layout/CPE_Management/domainServer");
                break;
            case "ZTP":
                this.router.navigateByUrl("layout/CPE_Management/ztp");
                break;
            case "Custom Parameters":
                this.router.navigateByUrl("layout/CPE_Management/customParameters");
                break;
            case "Template Management":
                this.router.navigateByUrl("layout/CPE_Management/templateManagement");
                break;
            case "BootStrap Server Details":
                this.router.navigateByUrl("layout/CPE_Management/bootstrapServerDetails");
                break;
            case "Customer Details":
                this.router.navigateByUrl("layout/CPE_Management/customerDetails");
                break;
        }
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
