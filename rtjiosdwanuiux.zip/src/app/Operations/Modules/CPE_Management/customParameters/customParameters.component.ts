import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';


@Component({
    selector: 'app-customParameters',
    templateUrl: './customParameters.component.html',
    styleUrls: ['./customParameters.component.css']
})
export class CPCustomParametersComponent implements OnInit {
    customParametersList = [
        {
            title: 'CREATE',
            access: true,
            value: 'createCustomParameters'
        },
        {
            title: 'VIEW ALL',
            access: true,
            value: 'getAllTargetedParameters'
        },
        {
            title: 'VIEW BY NAME',
            access: true,
            value: 'getParametersByCustom'
        }
    ];

    constructor(private router: Router,
        private accessService: AccessService,
        private cpeService: CPEManagmentModuleService) {
        let read;
        this.customParametersList[0].access = this.accessService.getAccessForSubModule('CPE Management', 'Custom Parameters', 'W');
        read = this.accessService.getAccessForSubModule('CPE Management', 'Custom Parameters', 'R');
        this.customParametersList[1].access = read;
        this.customParametersList[2].access = read;
    }

    onClick(value) {
        switch (value) {
            case "createCustomParameters":
                this.router.navigateByUrl("layout/CPE_Management/customParameters/createCustomParameters");
                break;
            case "getAllTargetedParameters":
                this.router.navigateByUrl("layout/CPE_Management/customParameters/getAllTargetedParameters");
                break;
            case "getParametersByCustom":
                this.router.navigateByUrl("layout/CPE_Management/customParameters/getParametersByCustom");
                break;
        }
    }

    ngOnInit(): void { }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
