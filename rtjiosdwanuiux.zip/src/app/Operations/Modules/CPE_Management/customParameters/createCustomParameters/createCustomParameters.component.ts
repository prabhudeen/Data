import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CustomParametersService } from '../customParameters.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';

@Component({
    selector: 'app-createCustomParameters',
    templateUrl: './createCustomParameters.component.html',
    styleUrls: ['./createCustomParameters.component.css']
})
export class CPCreateCustomParametersComponent implements OnInit, OnDestroy {

    @ViewChild('form') form: NgForm;
    // zoneNames = ['East', 'West', 'North', 'South'];
    typeNames = ['String', 'Number', 'IP Address', 'IP Address and Mask'];
    customParameterName: string;
    isSuccess: boolean;
    modalShow: boolean = false;

    constructor(private customParametersService: CustomParametersService,
        private router: Router,
        private route: ActivatedRoute,
        private spinnerService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit(): void { }

    onCreate() {
        this.customParameterName = this.form.value.customParameterName;
        let type = this.form.value.type;
        // let zoneName = this.form.value.zoneName;
        // $("#createModal").modal('show')
        this.spinnerService.start();
        this.form.reset();
        this.customParametersService.createCustomParameters(this.customParameterName, type)
            .subscribe(
                (value) => {
                    this.spinnerService.stop();
                    this.isSuccess = value;
                    this.modalShow = true;
                }
            );
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }

}
