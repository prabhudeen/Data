import { Injectable } from "@angular/core";
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: "root"
})
export class CustomParametersService {

    constructor(private commonService: SdWanServiceService) { }

    createCustomParameters(targetName: string, type: string) {
        let headers = new HttpHeaders()
            .append('targetname', targetName)
            .append('type', type);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('post', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.CREATE_CUSTOM_PARAMETERS).subscribe(
                (response) => {
                    if (response['status_code'] >= 200 && response['status_code'] < 300) {
                        console.log('received response for createCustomParameters in success:', response);
                        observe.next(true);
                    } else {
                        console.log('received response for createCustomParameters in fail:', response);
                        observe.next(false);
                    }
                }
            );
        }
        );
    }


    getAllCustomParameters() {
        // let headers = new HttpHeaders().append('zoneName', zoneName);

        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', EventConstants.CustomParametersContextHandler, null, null, null, EventConstants.GET_ALL_TARGET_CONFIG_PARAMETERS).subscribe(
                (response) => {
                    if (response['status_code'] >= 200 && response['status_code'] < 300) {
                        console.log('received response in getAllCustomParameters success:', response);
                        console.log("check", JSON.stringify(response));

                        let data = response['data'];
                        let resultArray = [];
                        data.forEach(element => {
                            let name = element['name'];
                            let type = element['type'];
                            let domainId = [];
                            let status: string;
                            element.domainsList.forEach(p => {
                                domainId.push(p['domainId']);
                                status = p['status'];
                            });
                            let json = {
                                "customParameterName": name,
                                "type": type,
                                "domainId": domainId,
                                "status": status
                            }
                            resultArray.push(json);
                        });
                        console.log("resultArray is:", resultArray);

                        observe.next(resultArray);
                    } else {
                        console.log('received response in getAllCustomParameters fail:', response);
                        observe.next([]);
                    }
                }
            );
        }
        );
    }

    getParametersByCustom(customParameterName) {
        let headers = new HttpHeaders()
            // .append('zoneName', zoneName)
            .append('targetname', customParameterName);

        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.GET_PARAMETER_BY_CUSTOM).subscribe(
                (response) => {
                    if (response['status_code'] >= 200 && response['status_code'] < 300) {
                        console.log('received response in getAllCustomParameters success:', response);
                        let data = response['data'];
                        let resultArray = [];
                        data.forEach(element => {
                            let name = element['name'];
                            let type = element['type'];
                            let domainId = [];
                            let status: string;
                            element.domainsList.forEach(p => {
                                domainId.push(p['domainId']);
                                status = p['status'];
                            });
                            let json = {
                                "customParameterName": name,
                                "type": type,
                                "domainId": domainId,
                                "status": status
                            }
                            resultArray.push(json);
                        });
                        observe.next(resultArray);
                    } else {
                        console.log('received response in getAllCustomParameters fail:', response);
                        observe.next([]);
                    }
                }
            );
        }
        );
    }

    deleteCustomParameterName(customParameterName) {
        let headers = new HttpHeaders()
            // .append('zoneName', zoneName)
            .append('targetname', customParameterName);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('delete', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.DELETE_PARAMETER_BY_CUSTOM).subscribe(
                (response) => {
                    if (response['status_code'] >= 200 && response['status_code'] < 300) {
                        console.log('received response for deleteCustomParameterName success:', response);
                        if (response['data']['deleted']) {
                            observe.next(true);
                        } else {
                            observe.next(false);
                        }
                    } else {
                        console.log('received response for deleteCustomParameterName fail:', response);
                        observe.next(false);
                    }
                }
            );
        }
        );
    }
}