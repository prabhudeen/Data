import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CustomParametersService } from '../customParameters.service';
import { MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';

@Component({
    selector: 'app-getAllTargetedParameters',
    templateUrl: './getAllTargetedParameters.component.html',
    styleUrls: ['./getAllTargetedParameters.component.css']
})
export class CPGetAllTargetedParametersComponent implements OnInit, OnDestroy {

    @ViewChild('form') form: NgForm;
    @ViewChild('paginator') paginator: MatPaginator
    // zoneNames = ['East', 'West', 'North', 'South'];
    isSuccess: boolean = false;
    arrayList = [];
    arrayTempList = [];
    showTable: boolean = true;
    pageSize = 5;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number = 0;
    offSet: number = 0;
    index: number;
    customParameterName: string;
    isDeletable: boolean = false;
    deleteModalShow: boolean = false;
    afterDeleteModalShow: boolean = false;

    constructor(private customParametersService: CustomParametersService,
        private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private spinnerService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit(): void {
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'Custom Parameters', 'D');
        this.onGet();
    }

    onGet() {
        // let zoneName = this.form.value.zoneName;
        this.spinnerService.start();
        this.customParametersService.getAllCustomParameters()
            .subscribe(
                (response) => {
                    console.log("response", response);
                    this.spinnerService.stop();
                    this.showTable = true;
                    this.arrayList = response;
                    this.length = this.arrayList.length;
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                });
        this.spinnerService.stop();
    }

    onDeleteIconClick(index) {
        this.index = this.offSet + index;
        this.customParameterName = this.arrayList[this.index].customParameterName;
        this.deleteModalShow = true;
    }

    onDelete() {
        // let zoneName = this.form.value.zoneName;
        let customParameterName = this.arrayList[this.index].customParameterName;
        this.spinnerService.start();
        this.customParametersService.deleteCustomParameterName(customParameterName)
            .subscribe((value) => {
                this.spinnerService.stop();
                if (value) {
                    this.isSuccess = true;
                    console.log('Successfully deleted');
                    this.afterDeleteModalShow = true;
                    this.arrayList.splice(this.index, 1);
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                    this.paginator.firstPage();
                } else {
                    this.isSuccess = false;
                    this.afterDeleteModalShow = true;
                    console.log('deleted not successful');
                }
            });
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.arrayTempList = this.arrayList.slice(firstCut, secondCut);
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
