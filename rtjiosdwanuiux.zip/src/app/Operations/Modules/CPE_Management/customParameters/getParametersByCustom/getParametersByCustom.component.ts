import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { CustomParametersService } from '../customParameters.service';
import { NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';

@Component({
    selector: 'app-getParametersByCustom',
    templateUrl: './getParametersByCustom.component.html',
    styleUrls: ['./getParametersByCustom.component.css']
})
export class CPGetParametersByCustomComponent implements OnInit, OnDestroy {
    @ViewChild('form') form: NgForm;
    @ViewChild('paginator') paginator: MatPaginator
    // zoneNames = ['East', 'West', 'North', 'South'];
    arrayList = [];
    arrayTempList = [];
    showTable: boolean = false;
    isSuccess: boolean = false;
    pageSize = 5;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number = 0;
    offSet: number = 0;
    index: number;
    zoneName;
    customParameterName;
    isDeletable: boolean = false;
    deleteModalShow: boolean = false;
    afterDeleteModalShow: boolean = false;

    constructor(private customParametersService: CustomParametersService,
        private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private spinnerService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit(): void {
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'Custom Parameters', 'D');
    }

    onGet() {
        // this.zoneName = this.form.value.zoneName;
        this.customParameterName = this.form.value.customParameterName;
        this.spinnerService.start();
        this.form.reset();
        this.customParametersService.getParametersByCustom(this.customParameterName)
            .subscribe(
                (response) => {
                    this.spinnerService.stop();
                    this.showTable = true;
                    this.arrayList = response;
                    this.length = this.arrayList.length;
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                });
    }

    onDeleteIconClick(index) {
        this.index = this.offSet + index;
        this.deleteModalShow = true;
    }

    onDelete() {
        this.spinnerService.start();
        this.customParametersService.deleteCustomParameterName(this.customParameterName)
            .subscribe((value) => {
                this.spinnerService.stop();
                if (value) {
                    this.isSuccess = true;
                    console.log('Successfully deleted');
                    this.afterDeleteModalShow = true;
                    this.arrayList.splice(this.index, 1);
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                    this.paginator.firstPage();
                } else {
                    this.isSuccess = false;
                    this.afterDeleteModalShow = true;
                    console.log('deleted not successful');
                }
            });
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.arrayTempList = this.arrayList.slice(firstCut, secondCut);
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
