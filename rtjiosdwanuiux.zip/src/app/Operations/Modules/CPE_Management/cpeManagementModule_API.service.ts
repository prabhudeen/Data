import { Injectable } from "@angular/core";
import { SdWanServiceService } from '../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { EventConstants } from '../../../SharedFolder/constants/eventConstants';
import { Router } from '@angular/router';


@Injectable({
    providedIn: "root"
})
export class CPEManagmentModuleService {

    getAllDomainCheckJson: {};

    constructor(private commonService: SdWanServiceService, private router: Router) { }

    domainServerCreate(headerJson) {
        let headers = new HttpHeaders()
            .append("ip", headerJson["Ip"])
            .append("port", headerJson["Port"])
            .append("name", headerJson["Name"]);
        console.log("headers are", headers);

        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/RAD/GUIHandler', headerJson["circleName"], headers, null, EventConstants.CPE_DOMAINSERVER_CREATE).subscribe(
                (response) => {
                    console.log("response is:", response);
                    if (response["message"] == "Domain Server created successfully")
                        observe.next(true);
                    else
                        observe.next(false);
                }
            );
        });
    }

    getAllDomainServer() {
        // let headers = new HttpHeaders().append("zoneName", ZoneName);
        //  console.log("headers", headers);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', '/PEAG/RAD/GUIHandler', null, null, null, EventConstants.CPE_DOMAINSERVER_GETALLSERVER).subscribe(
                (response) => {
                    console.log("response is", response);
                    observe.next(response);
                }
            );
        });
    }


    updateDomainServer(circleArray, domainId) {
        console.log("inside cpe service:", circleArray);

        let headers = new HttpHeaders().append('id', domainId);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', '/PEAG/RAD/GUIHandler', circleArray, headers, null, EventConstants.UPDATE_ZTP).subscribe(
                (response) => {
                    observe.next(response);
                }
            )
        })
    }

    deleteDomainServer(Id) {
        let headers = new HttpHeaders().append("domainId", Id)
        console.log(JSON.stringify(headers), "headers");
        return new Observable<any>(observe => {
            this.commonService.sendRequest('delete', '/PEAG/RAD/GUIHandler', null, headers, null, EventConstants.CPE_DOMAINSERVER_DELETESERVER).subscribe(
                (response) => {
                    observe.next(response);
                }
            )
        });
    }

    breadcrumbNavigation(path: string) {
        switch (path) {
            case 'dashboard': return this.router.navigate(['/layout/Dashboard']);
            case 'CPE_Management': return this.router.navigate(['/layout/CPE_Management']);
            case 'circle': return this.router.navigate(['/layout/CPE_Management/circle']);
            case 'domainServer': return this.router.navigate(['/layout/CPE_Management/domainServer']);
            case 'ztp': return this.router.navigate(['/layout/CPE_Management/ztp']);
            case 'customParameters': return this.router.navigate(['/layout/CPE_Management/customParameters']);
            case 'templateManagement': return this.router.navigate(['/layout/CPE_Management/templateManagement']);
        }
    }
}