import { Injectable } from "@angular/core";
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: "root"
})
export class TemplateManagementService {

    constructor(private commonService: SdWanServiceService) { }

    createTemplate(serviceType: string, templateName: string) {
        let headers = new HttpHeaders()
            .append('serviceType', serviceType)
            .append('templateName', templateName);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('post', EventConstants.TemplateContextHanlder, null, headers, null, EventConstants.CREATE_TEMPLATE).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response for createTemplate in success:', response);
                        observe.next(true);
                    } else {
                        console.log('received response for createTemplate in fail:', response);
                        observe.next(false);
                    }
                }
            );
        }
        );
    }


    getAllTemplate() {

        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', EventConstants.TemplateContextHanlder, null, null, null, EventConstants.GET_ALL_TEMPLATE).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response in getAllTemplate success:', response);
                        let data = response['data'];
                        observe.next(data);
                    } else {
                        console.log('received response in getAllTemplate fail:', response);
                        observe.next([]);
                    }
                }
            );
        }
        );
    }

    deleteTemplate(serviceType) {
        let headers = new HttpHeaders()
            .append('serviceType', serviceType);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('delete', EventConstants.TemplateContextHanlder, null, headers, null, EventConstants.DELETE_TEMPLATE).subscribe(
                (response) => {
                    if (response['status_code'] < 3000) {
                        console.log('received response for deleteTemplate success:', response);
                        if (response['data']['deleted']) {
                            observe.next(true);
                        } else {
                            observe.next(false);
                        }
                    } else {
                        console.log('received response for deleteTemplate fail:', response);
                        observe.next(false);
                    }
                }
            );
        }
        );
    }
}