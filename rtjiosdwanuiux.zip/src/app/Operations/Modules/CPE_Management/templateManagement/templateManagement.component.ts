import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';

@Component({
    selector: 'app-templateManagement',
    templateUrl: './templateManagement.component.html',
    styleUrls: ['./templateManagement.component.css']
})
export class TMTemplateManagementComponent implements OnInit {

    templateManagementList = [
        {
            title: 'CREATE',
            access: true,
            value: 'createTemplate'
        },
        {
            title: 'VIEW ALL',
            access: true,
            value: 'getAllTemplate'
        }
    ];

    constructor(private router: Router,
        private accessService: AccessService,
        private cpeService: CPEManagmentModuleService) {
    }

    ngOnInit(): void {
        this.templateManagementList[0].access = this.accessService.getAccessForSubModule('CPE Management', 'Template Management', 'W');
        this.templateManagementList[1].access = this.accessService.getAccessForSubModule('CPE Management', 'Template Management', 'R');
    }

    onClick(value) {
        switch (value) {
            case "createTemplate":
                this.router.navigateByUrl("layout/CPE_Management/templateManagement/createTemplate");
                break;
            case "getAllTemplate":
                this.router.navigateByUrl("layout/CPE_Management/templateManagement/getAllTemplate");
                break;
        }
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }

}
