import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TemplateManagementService } from '../templateManagement.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';

export interface ztpSevrice {
  value: string;
  viewValue: string;
  index: number;
}

export interface ztpSevriceGroup {
  disabled?: boolean;
  name: string;
  ztpServiceList: ztpSevrice[];
}
@Component({
  selector: 'app-createTemplate',
  templateUrl: './createTemplate.component.html',
  styleUrls: ['./createTemplate.component.css']
})
export class TMCreateTemplateComponent implements OnInit, OnDestroy {

  @ViewChild('form') form: NgForm;
  // serviceList = ['Bundle 1', 'Bundle 2', 'Bundle 3'];
  isMultiple: boolean = true;
  isSuccess: Boolean = false;
  templateName: string;
  serviceType: string[] = [];
  displayTemplateName: string;
  srvType: string = '';
  displayServiceType: string;
  singleServiceType: string = '';
  serviceList: ztpSevriceGroup[] = [
    {
      name: 'BNG (Single Select)',
      disabled: false,
      ztpServiceList: [
        { value: 'Bundle 1', viewValue: 'Bundle 1 (Dual Play)', index: 0 },
        { value: 'Bundle 2', viewValue: 'Bundle 2 (Triple Play)', index: 1 },
        { value: 'Bundle 3', viewValue: 'Bundle 3 (Penta Play)', index: 2 }
      ]
    },
    {
      name: 'Non-BNG (Multi Select)',
      disabled: false,
      ztpServiceList: [
        { value: 'TYPE 1', viewValue: 'L3VPN', index: 0 },
        { value: 'TYPE 2', viewValue: 'ILL', index: 1 },
        { value: 'TYPE 3', viewValue: 'IP-Centrex', index: 2 },
        { value: 'TYPE 4', viewValue: 'Business Broadband', index: 3 }
      ]
    }];
  modalShow: boolean = false;

  constructor(private templateManagementService: TemplateManagementService,
    private router: Router,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService,
    private cpeService: CPEManagmentModuleService) { }




  ngOnInit(): void { }

  changeServiceType(services = []) {
    // console.log(services);
    this.srvType = "";
    if (this.serviceType && this.serviceType.length > 1) {
      this.serviceType.forEach(element => {
        this.srvType += element.replace(/\s/g, "") + "_";
      });
      this.srvType = this.srvType.slice(0, -1);
    }
    else {
      if (this.serviceType && this.serviceType.length == 1)
        this.srvType = this.serviceType[0];
    }
    console.log(this.srvType);
    if (this.serviceType && this.serviceType.length > 0) {
      if (this.serviceType[0].includes('Bundle')) {
        this.serviceList[1].disabled = true;
        this.serviceList[0].disabled = false;
        if (this.singleServiceType !== '') {
          //   setTimeout(()=>{
          this.serviceType = this.serviceType.filter((element, index) => {
            if (element !== this.singleServiceType)
              return element;
          });
          this.singleServiceType = this.serviceType[0];
        } else {
          this.singleServiceType = this.serviceType[0];
        }
        this.srvType = this.singleServiceType;

      }
      else if (this.serviceType[0].includes('TYPE')) {
        this.singleServiceType = '';
        this.serviceList[0].disabled = true;
        this.serviceList[1].disabled = false;
      }
    } else {
      this.serviceList[0].disabled = false;
      this.serviceList[1].disabled = false;

    }
    console.log(this.serviceType, this.srvType);
  }


  // check() {
  //   console.log("checking", this.serviceType);
  // }

  onCreate() {
    let serviceTypeListMapping = {
      'TYPE 1': 'L3VPN',
      'TYPE 2': 'ILL',
      'TYPE 3': 'IP-Centrex',
      'TYPE 4': 'Business Broadband',
      'TYPE1_TYPE2': 'L3VPN_ILL',
      'TYPE1_TYPE3': 'L3VPN_IP-Centrex',
      'TYPE1_TYPE4': 'L3VPN_Business Broadband',
      'TYPE2_TYPE3': 'ILL_IP-Centrex',
      'TYPE2_TYPE4': 'ILL_Business Broadband',
      'TYPE3_TYPE4': 'IP-Centrex_Business Broadband',
      'TYPE1_TYPE2_TYPE3': 'L3VPN_ILL_IP-Centrex',
      'TYPE1_TYPE2_TYPE4': 'L3VPN_ILL_Business Broadband',
      'TYPE1_TYPE3_TYPE4': 'L3VPN_IP-Centrex_Business Broadband',
      'TYPE2_TYPE3_TYPE4': 'ILL_IP-Centrex_Business Broadband',
      'TYPE1_TYPE2_TYPE3_TYPE4': 'L3VPN_ILL_IP-Centrex_Business Broadband',
    }
    this.displayServiceType = serviceTypeListMapping[this.srvType] ? serviceTypeListMapping[this.srvType] : this.srvType;
    this.displayTemplateName = this.templateName;
    this.spinnerService.start();
    this.templateManagementService.createTemplate(this.srvType, this.displayTemplateName)
      .subscribe(
        (value) => {
          this.spinnerService.stop();
          this.isSuccess = value;
          this.form.reset();
          this.modalShow = true
        }
      );
  }

  resetForm() {
    this.form.reset();
  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  ngOnDestroy() {
    this.spinnerService.stop();
  }

  breadcrumbNavigation(path: string) {
    this.cpeService.breadcrumbNavigation(path);
  }

}


