import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { TemplateManagementService } from '../templateManagement.service';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';

@Component({
    selector: 'app-getAllTemplate',
    templateUrl: './getAllTemplate.component.html',
    styleUrls: ['./getAllTemplate.component.css']
})
export class TMGetAllTemplate implements OnInit, OnDestroy {

    @ViewChild('paginator') paginator: MatPaginator;
    arrayList = [];
    arrayTempList = [];
    pageSize = 5;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number = 0;
    offSet: number = 0;
    index: number;
    serviceType: string;
    isSuccess: boolean = false;
    templateName: string;
    isDeletable: boolean = false;
    deleteModalShow: boolean = false;
    afterDeleteModalShow: boolean = false;
    serviceTypeView: string;

    constructor(private templateManagementService: TemplateManagementService,
        private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private spinneService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit(): void {
        this.onGet();
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'Template Management', 'D');
    }

    onGet() {

        let serviceTypeListMapping = {
            'TYPE 1': 'L3VPN',
            'TYPE 2': 'ILL',
            'TYPE 3': 'IP-Centrex',
            'TYPE 4': 'Business Broadband',
            'TYPE1_TYPE2': 'L3VPN_ILL',
            'TYPE1_TYPE3': 'L3VPN_IP-Centrex',
            'TYPE1_TYPE4': 'L3VPN_Business Broadband',
            'TYPE2_TYPE3': 'ILL_IP-Centrex',
            'TYPE2_TYPE4': 'ILL_Business Broadband',
            'TYPE3_TYPE4': 'IP-Centrex_Business Broadband',
            'TYPE1_TYPE2_TYPE3': 'L3VPN_ILL_IP-Centrex',
            'TYPE1_TYPE2_TYPE4': 'L3VPN_ILL_Business Broadband',
            'TYPE1_TYPE3_TYPE4': 'L3VPN_IP-Centrex_Business Broadband',
            'TYPE2_TYPE3_TYPE4': 'ILL_IP-Centrex_Business Broadband',
            'TYPE1_TYPE2_TYPE3_TYPE4': 'L3VPN_ILL_IP-Centrex_Business Broadband',
        }

        this.spinneService.start();
        this.templateManagementService.getAllTemplate()
            .subscribe(
                (response) => {
                    this.spinneService.stop();
                    this.arrayList = response;
                    console.log('this.arrayList :', this.arrayList);
                    this.arrayList = this.arrayList.map(element => {
                        if (serviceTypeListMapping[element.serviceType]) {
                            element.serviceTypeView = serviceTypeListMapping[element.serviceType];
                        } else {
                            element.serviceTypeView = element.serviceType
                        }
                        return element;
                    })
                    this.length = this.arrayList.length;
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                });

    }

    onDeleteIconClick(index, serviceTypeView, serviceType, templateName) {
        this.index = this.offSet + index;
        this.serviceTypeView = serviceTypeView;
        this.serviceType = serviceType;
        this.templateName = templateName;
        this.deleteModalShow = true;
    }

    onDelete() {
        this.spinneService.start();
        this.templateManagementService.deleteTemplate(this.serviceType)
            .subscribe((value) => {
                this.spinneService.stop();
                if (value) {
                    this.isSuccess = true;
                    console.log('Successfully deleted');
                    this.afterDeleteModalShow = true;
                    this.arrayList.splice(this.index, 1);
                    this.arrayTempList = this.arrayList.slice(0, this.pageSize);
                    this.paginator.firstPage();
                } else {
                    this.isSuccess = false;
                    this.afterDeleteModalShow = true;
                    console.log('deleted not successful');
                }
            });
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.arrayTempList = this.arrayList.slice(firstCut, secondCut);
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinneService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }

}
