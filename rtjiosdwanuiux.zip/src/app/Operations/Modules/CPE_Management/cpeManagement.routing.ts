import { Routes } from '@angular/router';
import { CPEManagementComponent } from './cpe-management.component';
import { CircleComponent } from './circle/circle.component';
import { DomainServerComponent } from './domainServer/domainServer.component';
import { ZTPComponent } from './ztp/ztp.component';
import { DomainCreateComponent } from './domainServer/domainCreate/domainCreate.component';
import { DomainGetAllComponent } from './domainServer/getAllDomain/getAllDomain.component';
import { DomainGetByDuidComponent } from './domainServer/getDomainByDuid/getDomainByDuid.component';
import { DomainGetByCircleComponent } from './domainServer/getDomainByCircle/getDomainByCircle.component';
import { ZTPCreateComponent } from './ztp/ztpCreate/ztpCreate.component';
import { CircleCreateComponent } from './circle/createCircle/createCircle.component';
import { CircleGetAllComponent } from './circle/getAllCircle/getAllCircle.component';
import { CPCustomParametersComponent } from './customParameters/customParameters.component';
import { CPCreateCustomParametersComponent } from './customParameters/createCustomParameters/createCustomParameters.component';
import { CPGetParametersByCustomComponent } from './customParameters/getParametersByCustom/getParametersByCustom.component';
import { CPGetAllTargetedParametersComponent } from './customParameters/getAllTargetedParameters/getAllTargetedParameters.component';
import { TMTemplateManagementComponent } from './templateManagement/templateManagement.component';
import { TMCreateTemplateComponent } from './templateManagement/createTemplate/createTemplate.component';
import { TMGetAllTemplate } from './templateManagement/getAllTemplate/getAllTemplate.component';
import { BootstrapServerDetailsComponent } from './bootstrap-server-details/bootstrap-server-details.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { ZTPViewZtpStatus } from './ztp/viewZtpStatus/viewZtpStatus.component';
import { ModuleActivateGuard } from '../../../SharedFolder/services/moduleActivate.guard';
import { OrderStatusComponent } from './ztp/orderStatus/orderStatus.component';

export const cpeManagementRoutes: Routes = [
    {
        path: '',
        canActivate: [ModuleActivateGuard],
        data: { level: 'Module', moduleName: 'CPE Management' },
        component: CPEManagementComponent
    },
    {
        path: 'circle',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Circle' },
        component: CircleComponent
    },
    {
        path: 'circle/create',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Circle', accessType: 'W' },
        component: CircleCreateComponent
    },
    {
        path: 'circle/getAll',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Circle' },
        component: CircleGetAllComponent
    },
    {
        path: 'domainServer',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Domain Server' },
        component: DomainServerComponent
    },
    {
        path: 'domainServer/create',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Domain Server', accessType: 'W' },
        component: DomainCreateComponent
    },
    {
        path: 'domainServer/getAll',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Domain Server' },
        component: DomainGetAllComponent
    },
    {
        path: 'domainServer/getByDuid',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Domain Server' },
        component: DomainGetByDuidComponent
    },
    {
        path: 'domainServer/getByCircle',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Domain Server' },
        component: DomainGetByCircleComponent
    },
    {
        path: 'ztp',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'ZTP' },
        component: ZTPComponent
    },
    {
        path: 'ztp/create',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'ZTP', accessType: 'W' },
        component: ZTPCreateComponent
    },
    {
        path: 'ztp/getZtpStatus',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'ZTP' },
        component: ZTPViewZtpStatus
    },
    {
        path: 'ztp/orderStatus',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'ZTP' },
        component: OrderStatusComponent
    },
    {
        path: 'customParameters',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Custom Parameters' },
        component: CPCustomParametersComponent
    },
    {
        path: 'customParameters/createCustomParameters',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Custom Parameters', accessType: 'W' },
        component: CPCreateCustomParametersComponent
    },
    {
        path: 'customParameters/getAllTargetedParameters',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Custom Parameters' },
        component: CPGetAllTargetedParametersComponent
    },
    {
        path: 'customParameters/getParametersByCustom',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Custom Parameters' },
        component: CPGetParametersByCustomComponent
    },
    {
        path: 'templateManagement',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Template Management' },
        component: TMTemplateManagementComponent
    },
    {
        path: 'templateManagement/createTemplate',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Template Management', accessType: 'W' },
        component: TMCreateTemplateComponent
    },
    {
        path: 'templateManagement/getAllTemplate',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Template Management' },
        component: TMGetAllTemplate
    },
    {
        path: 'bootstrapServerDetails',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'BootStrap Server Details' },
        component: BootstrapServerDetailsComponent
    },
    {
        path: 'customerDetails',
        canActivate: [ModuleActivateGuard],
        data: { level: 'SubModule', moduleName: 'CPE Management', subModuleName: 'Customer Details' },
        component: CustomerDetailsComponent
    }
]
