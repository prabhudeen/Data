import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { BootstrapService } from './bootstrapService';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { TooltipPosition } from '@angular/material';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';
import { AccessService } from '../../../../SharedFolder/services/access.service';
declare var $: any;

@Component({
  selector: 'app-bootstrap-server-details',
  templateUrl: './bootstrap-server-details.component.html',
  styleUrls: ['./bootstrap-server-details.component.css']
})
export class BootstrapServerDetailsComponent implements OnInit, OnDestroy {
  @ViewChild('form') form: NgForm;
  tooltipPosition: TooltipPosition = 'above';
  zoneList: string[];
  isSuccess: any;
  data: any = {};
  edit: boolean = false;
  writeAccess: boolean = false;
  zoneName;
  constructor(private bootstrapService: BootstrapService,
    private spinnerService: SpinnerService,
    private router: Router,
    private cpeService: CPEManagmentModuleService,
    private accessService: AccessService) { }

  ngOnInit() {
    this.zoneList = ["North", "South", "East", "West"];
    this.writeAccess = this.accessService.getAccessForSubModule('CPE Management', 'Circle', 'W');
    this.onGet();
  }

  onEdit() {
    this.edit = true;
  }

  onGet() {
    this.edit = false;
    this.spinnerService.start();
    this.bootstrapService.getBootstrapDetails().subscribe((response) => {
      console.log('response :', response);
      this.data = response['data']['bootstrapServer'];
      this.spinnerService.stop();
    }, (error) => {
      this.spinnerService.stop();
    });
  }

  onCreate() {
    let headers = new HttpHeaders()
      .append('name', this.data['bsServerName'])
      .append('ip', this.data['bsServerIPAddress'])
      .append('user', this.data['bsServerUserName'])
      .append('password', this.data['bsServerPassword'])
      .append('enabled', this.data['bootstrapServerEnabled']);
    this.spinnerService.start();
    this.bootstrapService.createBootstrapServerDetails(headers).subscribe((value) => {
      this.form.reset();
      this.isSuccess = value;
      this.spinnerService.stop();
      $("#createModal").modal('show');
      this.onGet();
    }, (error) => {
      this.spinnerService.stop();
      this.onGet();
    });
  }

  onCancel() {
    if (!this.edit)
      this.router.navigate(['/layout/CPE_Management']);
    else {
      this.onGet();
    }
  }

  ngOnDestroy() {
    this.spinnerService.stop();
  }

  breadcrumbNavigation(path: string) {
    this.cpeService.breadcrumbNavigation(path);
  }

}
