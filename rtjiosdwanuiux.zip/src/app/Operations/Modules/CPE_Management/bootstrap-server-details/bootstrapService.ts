
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';

@Injectable()
export class BootstrapService {
    constructor(private sdwanService: SdWanServiceService) {

    }

    getBootstrapDetails() {
        return new Observable((observe) => {
            this.sdwanService.sendRequest('GET', '/PEAG/RAD/GUIHandler', null, null, null, 'getBSDetails').subscribe((response) => {
                if (response['status_code'] == 200) {
                    observe.next(response);
                }
                else {
                    observe.error(response);
                }
            })
        });
    }

    createBootstrapServerDetails(headers) {
        console.log(headers);
        return new Observable((observe) => {
            this.sdwanService.sendRequest('POST', '/PEAG/RAD/GUIHandler', null, headers, null, 'updateBSDetails').subscribe((response) => {
                console.log(response);
                if (response['status_code'] == 200) {
                    console.log("Bootstrap Server Details Updated")
                    observe.next(true);
                }
                else {
                    observe.next(false);
                }

            })
        });
    }
}