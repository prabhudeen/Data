import { Validator, NG_VALIDATORS, AbstractControl } from '@angular/forms';
import { Directive, Input } from '@angular/core';

@Directive({
    selector: '[addressValidator]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting: AddressValidator,
        multi: true
    }]
})
export class AddressValidator implements Validator {

    @Input() addressValidator: boolean;
    @Input() addressValidatorType: string;

    addressMaskMapping = {
        'ipv4': {
            0: "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$",
            1: "^((?:[0-9])|(?:[1-2][0-9])|(?:3[0-2]))$"
        },
        'ipv6': {
            0: "(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)",
            1: "^([0-9]{1,2}|1[01][0-9]|12[0-8])$"
        }
    }

    validate(control: AbstractControl): { [key: string]: any } | null {

        if (this.addressValidator) {

            if (!control.value) {
                return { 'notAddress': true };
            }

            let values = control.value.split('/');

            if (values.length !== 2) {
                return { 'notAddress': true };
            }

            let flag = true;

            values.forEach((element, index) => {
                let pattern = new RegExp(this.addressMaskMapping[this.addressValidatorType][index]);
                pattern.test(element) ? '' : flag = false;
            })

            if (flag) {
                return null;
            } else {
                return { 'notAddress': true };
            }

        }

        return null;
    }

}