import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';
import { CustomerDetails } from './customerDetails.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { SpinnerService } from '../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';
import { NameFilterPipe } from '../../User_Management/Utility/name-filter.pipe';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit, OnDestroy {
  matTooltipPosition: TooltipPosition = "above";
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('customerDetailsForm') customerDetailsForm: NgForm;
  customerId;
  searchValue = '';
  customerDetailsActual = [];
  customerDetails = [];
  customerDetailsTemp = [];
  customerDetailsFlag: boolean = false;
  showTable: boolean = false;
  length: number;
  pageSize: number;
  offset: number;
  pageSizeOptions = [5, 10, 20, 30, 50];
  matTabIndex: number = 0;
  index = 0;
  customerList = [];
  customerName = '';
  serviceTypeListMapping = {
    'TYPE 1': 'L3VPN',
    'TYPE 2': 'ILL',
    'TYPE 3': 'IP-Centrex',
    'TYPE 4': 'Business Broadband',
    'TYPE1_TYPE2': 'L3VPN_ILL',
    'TYPE1_TYPE3': 'L3VPN_IP-Centrex',
    'TYPE1_TYPE4': 'L3VPN_Business Broadband',
    'TYPE2_TYPE3': 'ILL_IP-Centrex',
    'TYPE2_TYPE4': 'ILL_Business Broadband',
    'TYPE3_TYPE4': 'IP-Centrex_Business Broadband',
    'TYPE1_TYPE2_TYPE3': 'L3VPN_ILL_IP-Centrex',
    'TYPE1_TYPE2_TYPE4': 'L3VPN_ILL_Business Broadband',
    'TYPE1_TYPE3_TYPE4': 'L3VPN_IP-Centrex_Business Broadband',
    'TYPE2_TYPE3_TYPE4': 'ILL_IP-Centrex_Business Broadband',
    'TYPE1_TYPE2_TYPE3_TYPE4': 'L3VPN_ILL_IP-Centrex_Business Broadband',
  }
  MappingStatustooltipDescription: string = `1 - In Progress - ZTP initiated for the device. Config file generation is in progress.
  2 - Config Ready - ZTP config file generation successful and is available for download.
  3 - Managed - Config file uploaded on the device successfully and device has been enrolled on RADView.
  4 - Failed - ZTP config file generation failed.`;
  tooltipDescriptionforStatus = [
    'ZTP initiated for the device. Config file generation is in progress.',
    'ZTP config file generation successful and is available for download.',
    'Config file uploaded on the device successfully and device has been enrolled on RADView.',
    'ZTP config file generation failed.'
  ]
  constructor(private service: CustomerDetails,
    private router: Router,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService,
    private cpeService: CPEManagmentModuleService) { }

  ngOnInit() {
    this.pageSize = 5;
    this.offset = 0;
    this.getCustomerDetails();
  }

  getEventNumber(event) {
    console.log('event:', event);
    switch (event) {
      case 0:
      case '0':
        this.showTable = false;
        this.customerName = '';
        this.customerDetailsForm.reset();
        this.getCustomerDetails();
        break;
      case 1:
      case '1':
        this.getAllSitesDetails();
        break;
    }
  }

  getCustomerDetails() {
    this.service.getAllCustomerDetails().subscribe(
      (response) => {
        this.customerList = response;
      }
    )
  }

  onFilter() {
    this.customerDetails = this.customerDetailsActual;
    this.customerDetails = new NameFilterPipe().transform(this.customerDetails, this.searchValue, 'customerId');
    this.length = this.customerDetails.length;
    this.customerDetailsTemp = this.customerDetails.slice(0, this.pageSize);
    if (this.paginator)
      this.paginator.firstPage();
  }

  getAllSitesDetails() {
    this.customerDetails = [];
    this.customerDetailsTemp = [];
    this.customerDetailsActual = [];
    this.spinnerService.start();
    this.service.getAllCustomerSiteDetails().subscribe(
      (response) => {
        this.spinnerService.stop();
        if (response['status_code'] == 200) {
          this.customerDetails = response['data'];
          this.customerDetailsActual = this.customerDetails;
          this.customerDetails = new NameFilterPipe().transform(this.customerDetails, this.searchValue, 'customerId');
          this.length = this.customerDetails.length;
          this.customerDetailsTemp = this.customerDetails.slice(0, this.pageSize);
        }
        if (this.paginator)
          this.paginator.firstPage();
      }
    );
  }

  onMainTable() {
    this.spinnerService.start();
    this.service.mainDownload().subscribe(response => {
      this.spinnerService.stop();
      if (response['status_code'] === 200) {
        console.log('onMainTable:', response);
        var linkElement = document.createElement('a');
        var byteArray = new Uint8Array(response.fileData);
        linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
        linkElement.download = response['fileName'];
        document.body.appendChild(linkElement);
        linkElement.click();
        document.body.removeChild(linkElement);
      }
    })
  }

  rowDownload(customerId) {
    this.spinnerService.start();
    this.service.rowDownload(customerId).subscribe(response => {
      this.spinnerService.stop();
      if (response['status_code'] === 200) {
        console.log('rowDownload:', response);
        var linkElement = document.createElement('a');
        var byteArray = new Uint8Array(response.fileData);
        linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
        linkElement.download = response['fileName'];
        document.body.appendChild(linkElement);
        linkElement.click();
        document.body.removeChild(linkElement);
      }
    })
  }

  onPageChanged(e) {
    this.offset = e.pageIndex * e.pageSize;
    this.pageSize = e.pageSize;
    let firstCut = e.pageIndex * e.pageSize;
    let secondCut = firstCut + e.pageSize;
    this.customerDetailsTemp = this.customerDetails.slice(firstCut, secondCut);
  }

  backToCPE() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  onGetCustomerDetails() {
    this.customerDetails = [];
    this.customerDetailsTemp = [];
    this.customerId = this.customerDetailsForm.value['customerId'];
    this.spinnerService.start();
    let headers = new HttpHeaders().append("customerId", this.customerId);
    this.service.getCustomerDetails(headers).subscribe(
      (response) => {
        console.log(response);
        this.spinnerService.stop();
        if (response['status_code'] == 200) {
          this.showTable = true;
          this.customerDetails = response['data'];
          this.customerDetails = this.customerDetails.map(element => {
            element['serviceNameView'] = this.serviceTypeListMapping[element['serviceName']] ? this.serviceTypeListMapping[element['serviceName']] : element['serviceName'];
            return element;
          })
          this.length = this.customerDetails.length;
          console.log("customerDetails", this.customerDetails);
          console.log("paze size:", this.pageSize);
          this.customerDetailsTemp = this.customerDetails.slice(0, this.pageSize);
        }
        if (this.paginator)
          this.paginator.firstPage();
      }
    );
  }

  ngOnDestroy() {
    this.spinnerService.stop();
  }

  breadcrumbNavigation(path: string) {
    this.cpeService.breadcrumbNavigation(path);
  }

}
