import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: "root"
})

export class CustomerDetails {
    constructor(private commonService: SdWanServiceService) { }

    getCustomerDetails(headers) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomerDetailsContextHandler, null, headers, null, EventConstants.GET_CUSTOMER_DETAILS).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    getAllCustomerSiteDetails() {
        // let array = [
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     },
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     },
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     },
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     },
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     },
        //     {
        //         "customerName": 'HDFC',
        //         "noofSites": 200
        //     }
        // ]
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomerDetailsContextHandler, null, null, null, EventConstants.GET_ALL_CUSTOMERSITE_LIST).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
            // observe.next(array);
        });
    }

    rowDownload(customerId) {
        let headers = new HttpHeaders().append('customerId', customerId);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomerDetailsContextHandler, null, headers, null, EventConstants.ROW_TABLE_LIST).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    mainDownload() {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomerDetailsContextHandler, null, null, null, EventConstants.MAIN_TABLE_LIST).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    getAllCustomerDetails() {
        return new Observable<any>(observe => {
            // let array = [
            //     {
            //         name: 'Dosapati Nikhil'
            //     },
            //     {
            //         name: 'Himaja'
            //     },
            //     {
            //         name: 'Annasamudram'
            //     },
            //     {
            //         name: 'Ghajnafar Shahid'
            //     },
            //     {
            //         name: 'Prashanth Meena'
            //     }
            // ];

            // observe.next(array);
            this.commonService.sendRequest('GET', EventConstants.CustomParametersContextHandler, null, null, null, EventConstants.GET_CUSTOMER_DETAILS_LIST).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response for getAllCustomerDetails success:', response);
                        observe.next(response['data'].map(element => {
                            return {
                                name: element
                            }
                        }));
                    } else {
                        console.log('received response for getAllCustomerDetails fail:', response);
                    }
                }
            );
        });
    }
}