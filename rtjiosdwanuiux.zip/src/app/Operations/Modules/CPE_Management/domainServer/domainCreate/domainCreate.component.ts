import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm, FormControl } from '@angular/forms';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
import { TooltipPosition } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { DomainServerService } from '../domainServer.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
declare var $: any;

@Component({
    selector: 'app-domain-create',
    templateUrl: './domainCreate.component.html',
    styleUrls: ['./domainCreate.component.css']
})
export class DomainCreateComponent implements OnInit, OnDestroy {

    tooltipPosition: TooltipPosition = "above";
    @ViewChild('domainCreateForm') domainCreateForm: NgForm;
    circleArrayValue = [];
    domainCreateJson: {};
    circles = [];
    createModal: boolean = false;
    circleFormControl = new FormControl();
    constructor(private CpeService: CPEManagmentModuleService,
        private router: Router,
        private route: ActivatedRoute,
        private service: DomainServerService,
        private spinnerService: SpinnerService) { }

    ngOnInit() {
        this.service.getCirclesList().subscribe(
            (response) => {
                this.circles = response['data'];
            }
        );
    }

    onSubmitDomainCreate() {
        this.spinnerService.start();
        // this.circleName = this.domainCreateForm.value.circleName;
        this.domainCreateJson = {
            "circleName": this.circleArrayValue,
            "Ip": this.domainCreateForm.value["ip"],
            "Port": this.domainCreateForm.value["port"].toString(),
            "Name": this.domainCreateForm.value["domainSeverName"]
        }
        console.log("multiCheck", this.circleArrayValue);
        this.CpeService.domainServerCreate(this.domainCreateJson).subscribe(
            (response) => {
                this.spinnerService.stop();
                console.log(response);
                if (response) {
                   // $("#createModal").modal('show');
                   this.createModal = true;
                    this.domainCreateForm.reset();
                } else {
                    this.domainCreateForm.reset();
                }
            }
        )
        console.log(this.domainCreateJson, "checkJSON");

    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.CpeService.breadcrumbNavigation(path);
    }

}
