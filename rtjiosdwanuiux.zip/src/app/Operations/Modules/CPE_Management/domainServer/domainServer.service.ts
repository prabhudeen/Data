import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DomainServerService {
  // serversByDUID = {
  //   "id": 1,
  //   "name": "DomainA",
  //   "description": "RADview Server domain (TLV)",
  //   "circleId": 36,
  //   "maxSupportedNEs": 25000,
  //   "Data": [{
  //     "hostName": "DNA-D-HPG2-W10",
  //     "ipAddress": "10.10.10.10",
  //     "port": 3002
  //   },
  //   {
  //     "hostName": "DNA-D-HPG2-W10",
  //     "ipAddress": "10.10.10.10",
  //     "port": 3002
  //   }],
  //   "operStatus": {
  //     "value": 1,
  //     "name": "UP",
  //     "description": "Domain is UP"
  //   },
  //   "lastPollingTime": 1542027663601
  // };

  constructor(private commonService: SdWanServiceService) { }

  getServerByDUID(id) {
    let headers = new HttpHeaders().append('duid', id);
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.getDomainServerCircleWise, null, headers, null, EventConstants.GET_DOMAIN_BY_DUID).subscribe(
        (response) => {
          console.log("response is:", response);
          observe.next(response);
        }
      );
    });
  }

  getCirclesList() {
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.getDomainServerCircleWise, null, null, null, EventConstants.GET_DOMAINSERVER_CIRCLEWISE).subscribe(
        (response) => {
          console.log("response is:", response);
          observe.next(response);
        }
      );
    });

  }


  getDomainServerByCircleName(circleName) {
    let headers = new HttpHeaders().append('circleName', circleName);
    return new Observable<any>(observe => {
      this.commonService.sendRequest('GET', EventConstants.getDomainServerCircleWise, null, headers, null, EventConstants.GET_DOMAIN_BY_CIRCLENAME).subscribe(
        (response) => {
          console.log("response is:", response);
          observe.next(response);
        }
      );
    });
  }


  deleteDomainServerByCircle(Id, deleteCircleName) {
    let headers = new HttpHeaders().append("domainId", Id)
      .append("circleName", deleteCircleName);
    console.log(JSON.stringify(headers), "headers");


    return new Observable<any>(observe => {
      this.commonService.sendRequest('delete', '/PEAG/RAD/GUIHandler', null, headers, null, EventConstants.CPE_DOMAINSERVER_DELETESERVER).subscribe(
        (response) => {
          if (response["data"]["deleted"]) {
            observe.next(true);
          }
          else
            observe.next(false);
        }
      )
    });
  }

  deleteDomainServerByDuid(Id, deleteDuidName) {
    let headers = new HttpHeaders().append("domainId", Id)
      .append("duid", deleteDuidName);
    console.log(JSON.stringify(headers), "headers");
    return new Observable<any>(observe => {
      this.commonService.sendRequest('delete', '/PEAG/RAD/GUIHandler', null, headers, null, EventConstants.CPE_DOMAINSERVER_DELETESERVER).subscribe(
        (response) => {
          if (response["data"]["deleted"]) {
            observe.next(true);
          }
          else
            observe.next(false);
        }
      )
    });
  }


}

