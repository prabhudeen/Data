import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DomainServerService } from '../domainServer.service';
import { NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
declare var $: any;
@Component({
    selector: 'app-get-domain-byCircle',
    templateUrl: './getDomainByCircle.component.html',
    styleUrls: ['./getDomainByCircle.component.css']
})
export class DomainGetByCircleComponent implements OnInit, OnDestroy {
    circles: string[];
    circleName: string;
    getDomainCircleDetails = [];
    getDomainCircleDetailsTemp = [];
    getDomainCircleDetailsFlag: boolean = false;
    length: number;
    pageSize: number;
    offset: number;
    index: number;
    isSuccess: boolean = false;
    deleteItem;
    domainId;
    deleteZoneName;
    zoneName: string;
    showTable: boolean = false;
    pageSizeOptions = [5, 10, 20, 30, 50];
    zoneList = ["North", "South", "East", "West"];
    @ViewChild('getDomainByCircleForm') getDomainByCircleForm: NgForm;
    @ViewChild('paginator') paginator: MatPaginator;

    constructor(private router: Router,
        private route: ActivatedRoute,
        private service: DomainServerService,
        private spinnerService: SpinnerService,
        private CpeService: CPEManagmentModuleService) { }

    ngOnInit() {
        this.pageSize = 5;
        this.offset = 0;
        this.service.getCirclesList().subscribe(
            (response) => {
                this.circles = response['data'];
            }
        );
    }

    onPageChanged(e) {
        this.offset = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.getDomainCircleDetailsTemp = this.getDomainCircleDetails.slice(firstCut, secondCut);
    }

    backToDomain() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onSubmitgetDomainCircleDetails() {
        let circleName = this.circleName;
        this.spinnerService.start();
        this.service.getDomainServerByCircleName(circleName).subscribe(
            (res) => {
                console.log("response is:", res);
                this.spinnerService.stop();
                this.showTable = true;
                if (res['status_code'] === 200) {
                    console.log("data response is:", res['data']);
                    this.getDomainCircleDetails = res['data'];
                    this.length = this.getDomainCircleDetails.length;
                    this.getDomainCircleDetailsTemp = this.getDomainCircleDetails.slice(0, this.pageSize);
                    console.log("pazeSize is:", this.pageSize);
                    console.log("getDomainCircleDetails", this.getDomainCircleDetailsTemp);
                }
                if (this.paginator)
                    this.paginator.firstPage();
                if (this.getDomainCircleDetails.length > 0) {
                    this.getDomainCircleDetailsFlag = false;
                }
                else this.getDomainCircleDetailsFlag = true;
            });
    }

    // onDeleteButton(ind) {
    //     this.index = this.offset + ind;
    //     this.deleteItem = this.getDomainCircleDetails[this.index];
    //     this.domainId = this.deleteItem["id"];
    // }

    // onDelete() {
    //     this.domainId = this.deleteItem["id"];
    //     this.deleteZoneName = this.circleName;
    //     this.service.deleteDomainServerByCircle(this.domainId, this.deleteZoneName).subscribe(
    //         (response) => {
    //             if (response) {
    //                 console.log('response received:', response);
    //                 this.isSuccess = true;
    //                 $('#afterdeleteModal').modal('show');
    //                 this.getDomainCircleDetails.splice(this.index, 1);
    //                 this.length = this.getDomainCircleDetails.length;
    //                 this.getDomainCircleDetailsTemp = this.getDomainCircleDetails.slice(0, this.pageSize);
    //                 this.paginator.firstPage();
    //             }
    //             else{
    //                 this.isSuccess = false;
    //                 $('#afterdeleteModal').modal('show');
    //             }
    //         }
    //     )
    // }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.CpeService.breadcrumbNavigation(path);
    }

}
