import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';

@Component({
    selector: 'app-domain-server',
    templateUrl: './domainServer.component.html',
    styleUrls: ['./domainServer.component.css']
})
export class DomainServerComponent implements OnInit {

    list = [{
        title: "CREATE",
        access: true,
        value: "create"
    },
    {
        title: "VIEW ALL",
        access: true,
        value: "getAll"
    },
    {
        title: "VIEW DUID WISE",
        access: true,
        value: "getByDuid"
    },
    {
        title: "VIEW CIRCLE WISE",
        access: true,
        value: "getByCircle"
    }
    ]

    constructor(private router: Router,
        private accessService: AccessService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit() {
        this.list[0].access = this.accessService.getAccessForSubModule('CPE Management', 'Domain Server', 'W');
        let read = this.accessService.getAccessForSubModule('CPE Management', 'Domain Server', 'R');
        this.list[1].access = read;
        this.list[2].access = read;
        this.list[3].access = read;
    }

    onClick(action) {
        switch (action) {
            case "create":
                this.router.navigateByUrl("layout/CPE_Management/domainServer/create");
                break;
            case "getAll":
                this.router.navigateByUrl("layout/CPE_Management/domainServer/getAll");
                break;
            case "getByDuid":
                this.router.navigateByUrl("layout/CPE_Management/domainServer/getByDuid");
                break;
            case "getByCircle":
                this.router.navigateByUrl("layout/CPE_Management/domainServer/getByCircle");
                break;
        }
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
