import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatPaginator } from '@angular/material';
import { DomainServerService } from '../domainServer.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
declare var $: any;
@Component({
    selector: 'app-get-domain-byDuid',
    templateUrl: './getDomainByDuid.component.html',
    styleUrls: ['./getDomainByDuid.component.css']
})
export class DomainGetByDuidComponent implements OnInit, OnDestroy {
    duid: string;
    getDomainDuidDetails = {};
    getDomainDuidDetailsFlag: boolean = false;
    length: number;
    isSuccess: boolean = false;
    showTable: boolean = false;
    deleteItem;
    domainId;
    deleteDuid;
    @ViewChild('getDomainByDuidForm') getDomainByDuidForm: NgForm;
    @ViewChild('paginator') paginator: MatPaginator;

    constructor(private router: Router,
        private route: ActivatedRoute,
        private service: DomainServerService,
        private spinnerService: SpinnerService,
        private CpeService: CPEManagmentModuleService) { }

    ngOnInit() {
    }

    backToDomain() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onSubmitgetDomainDuidDetails() {
        // this.router.navigate(['../', 'serversByCircle'], { relativeTo: this.route });
        this.duid = this.getDomainByDuidForm.value['duid'];
        this.spinnerService.start();
        this.service.getServerByDUID(this.duid).subscribe(
            (res) => {
                this.spinnerService.stop();
                if (res['status_code'] == 200) {
                    this.showTable = true;
                    console.log("response is:", res);
                    console.log("data response:", res['data']);
                    this.getDomainDuidDetails = res['data'];
                    console.log('dosapati:', this.getDomainDuidDetails);
                    console.log('showTable:', this.showTable);
                    this.getDomainDuidDetailsFlag = false;
                }
                else if (res['status_code'] == 400) {
                    this.getDomainDuidDetailsFlag = true;
                    this.showTable = false;
                }
            });
    }


    // onDeleteButton() {
    //     this.domainId = this.getDomainDuidDetails["id"];
    // }

    // onDelete() {
    //     this.deleteDuid = this.duid;
    //     this.service.deleteDomainServerByDuid(this.domainId, this.deleteDuid).subscribe(
    //         (response) => {
    //             if (response) {
    //                 console.log('response received:', response);
    //                 this.isSuccess = true;
    //                 $('#afterdeleteModal').modal('show');
    //                 this.getDomainDuidDetailsFlag = true;
    //                 this.showTable = false;
    //             }
    //             else {
    //                 this.isSuccess = false;
    //                 $('#afterdeleteModal').modal('show');
    //             }
    //         }
    //     )
    // }


    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.CpeService.breadcrumbNavigation(path);
    }
}
