import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm, FormControl } from '@angular/forms';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { DomainServerService } from '../domainServer.service';
declare var $: any;

@Component({
    selector: 'app-getAll-domain',
    templateUrl: './getAllDomain.component.html',
    styleUrls: ['./getAllDomain.component.css']
})
export class DomainGetAllComponent implements OnInit, OnDestroy {
    tooltipPosition: TooltipPosition = "above";
    @ViewChild('paginator') paginator: MatPaginator;
    @ViewChild('getAllDomainForm') getAllDomainForm: NgForm;
    circleFormControl = new FormControl();
    zoneList = [];
    circles = [];
    circleNames = [];
    resultArray = [];
    id;
    hostName: string;
    ipAddress: string;
    port: string;
    editedCircleName = [];
    index: number = 0;
    deleteItem = [];
    editItem = [];
    isEdit: boolean = false;
    domainServerTableList = [];
    domainServerTableTempList = [];
    zoneName: any;
    showTable: boolean = true;
    isSuccess: boolean = false;
    afterdeleteModal: boolean = false;
    afterEditModal: boolean = false;
    domainId;
    deleteZoneName;
    offSet: number = 0;
    pageSize = 5;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number;
    isDeletable: boolean = false;
    deleteModal: boolean = false;

    constructor(private CpeService: CPEManagmentModuleService,
        private service: DomainServerService,
        private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private spinnerService: SpinnerService) { }

    ngOnInit() {
        this.onSubmitgetAllDomainServer();
        this.zoneList = ["North", "South", "East", "West"];
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'Domain Server', 'D');
    }

    backToDomain() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onSubmitgetAllDomainServer() {
        // this.showTable = false;
        console.log(this.zoneName, "this is zoneName");
        this.spinnerService.start();
        this.CpeService.getAllDomainServer().subscribe(
            (response) => {
                this.spinnerService.stop();
                console.log("inside:", response);
                // this.showTable = true;
                if (response['status_code'] === 200) {
                    this.domainServerTableList = response['data'];
                    this.length = this.domainServerTableList.length;
                    this.domainServerTableTempList = this.domainServerTableList.slice(0, this.pageSize);
                } else {
                    this.domainServerTableList = [];
                    this.length = this.domainServerTableList.length;
                    this.domainServerTableTempList = this.domainServerTableList.slice(0, this.pageSize);

                }
            }
        );
    }

    onEditButton(reqInd) {
        this.editItem = this.domainServerTableList[reqInd];
        this.service.getCirclesList().subscribe(
            (response) => {
                this.circles = response['data'];
            }
        );
        this.id = this.editItem['id'];
        this.editedCircleName = this.editItem['circleName'];
        this.hostName = this.editItem['primaryNetData']['hostName'];
        this.ipAddress = this.editItem["primaryNetData"]["ipAddress"];
        this.port = this.editItem["primaryNetData"]["port"];
    }

    onDeleteButton(ind) {
        this.index = this.offSet + ind;
        this.deleteItem = this.domainServerTableList[this.index];
        this.domainId = this.deleteItem["id"];
    }

    onDelete() {
        this.domainId = this.deleteItem["id"];
        this.spinnerService.start();
        this.CpeService.deleteDomainServer(this.domainId).subscribe(
            (response) => {

                if (response['data'] && response["data"]["deleted"]) {
                    this.spinnerService.stop();
                    console.log('response received:', response);
                    this.isSuccess = true;
                    // $('#afterdeleteModal').modal('show');
                    this.afterdeleteModal = true;
                    this.domainServerTableList.splice(this.index, 1);
                    this.length = this.domainServerTableList.length;
                    this.domainServerTableTempList = this.domainServerTableList.slice(0, this.pageSize);
                    this.paginator.firstPage();
                }
                else {
                    this.spinnerService.stop();
                    this.isSuccess = false;
                    // $('#afterdeleteModal').modal('show');
                    this.afterdeleteModal = true;
                }
            }
        )
    }

    onEdit() {
        // console.log("check:", this.resultArray);

        // this.editedCircleName.forEach(function (Element) {
        //     console.log("element is:", Element);

        //     if (this.resultArray.indexOf(Element) === -1) {
        //         this.resultArray.push(Element);
        //     }
        // });
        // console.log("editedName is:", this.editedCircleName);
        // console.log("resultArray is:", this.resultArray);
        this.CpeService.updateDomainServer(this.editedCircleName, this.id).subscribe(
            (response) => {
                if (response['status_code'] === 200) {
                    this.isEdit = true;
                    this.onSubmitgetAllDomainServer();
                    //$('#afterEditModal').modal('show');
                    this.afterEditModal = true;
                }
                else {
                    this.isEdit = false;
                    //$('#afterEditModal').modal('show');
                    this.afterEditModal = true;
                }
            }
        )
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.domainServerTableTempList = this.domainServerTableList.slice(firstCut, secondCut);
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.CpeService.breadcrumbNavigation(path);
    }
}
