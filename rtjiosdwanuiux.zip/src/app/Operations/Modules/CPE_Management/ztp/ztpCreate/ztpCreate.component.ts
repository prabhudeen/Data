import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ZTPService } from '../ztp.service';
import { TooltipPosition } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
import { HttpHeaders } from '@angular/common/http';
import { UIConfigurationService } from '../../../../../SharedFolder/services/UIConfig.service';

export interface ztpSevrice {
    value: string;
    viewValue: string;
    index: number;
}

export interface ztpSevriceGroup {
    disabled?: boolean;
    name: string;
    ztpServiceList: ztpSevrice[];
}
@Component({
    selector: 'app-ztp-create',
    templateUrl: './ztpCreate.component.html',
    styleUrls: ['./ztpCreate.component.css']
})
export class ZTPCreateComponent implements OnInit, OnDestroy {

    @ViewChild('form') form: NgForm;
    @ViewChild('form1') form1: NgForm;
    customerId: string;
    zoneName: string;
    duid: string;
    targetConfigParamTemp = [];
    isSuccess: boolean = true;
    serviceType: string[] = [];
    singleServiceType: string = '';
    isMultiple: boolean = true;
    udParam = {};
    cirlceName: string = '';
    srvType: string = '';
    modalShow: boolean = false;
    customerList = [];
    udParamList = [];
    ztRuleDeviceTyeList = ['pCPE-500B', 'pCPE-110', 'pCPE-260ES'];
    circleNameList = [];
    tooltipPosition: TooltipPosition = "above";
    selectedZTP: string = '';
    parametersPlaceholderMapping;

    // {
    //     'WAN_VLAN_ID_L3VPN': {
    //         pattern: '^(([1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))(,\s*[1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))*)$',
    //         required: true,
    //         errorMessage: 'Please enter VLAN in range: 0 - 4094'
    //     },
    //     'WAN_IPv4_Address_L3VPN': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv4 address'
    //     },
    //     'WAN_IPv4_MASK_L3VPN': {
    //         pattern: '^((?:[0-9])|(?:[1-2][0-9])|(?:3[0-2]))$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 32'
    //     },
    //     'WAN_IPv6_Address_L3VPN': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv6 address'
    //     },
    //     'WAN_IPv6_MASK_L3VPN': {
    //         pattern: '^([0-9]{1,2}|1[01][0-9]|12[0-8])$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 128'
    //     },
    //     'LAN_IPv4_Address_Mask_L3VPN': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv4 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv4'
    //     },
    //     'LAN_IPv6_Address_Mask_L3VPN': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv6 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv6'
    //     },
    //     'Remote_Side_IPv4_LAN_Pool_Address': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv4 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv4'
    //     },
    //     'Remote_Side_IPv6_LAN_Pool_Address': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv6 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv6'
    //     },
    //     'WAN_IPv4_L3VPN_Gateway_Address': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv4 address (without mask)'
    //     },
    //     'WAN_IPv6_L3VPN_Gateway_Address': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv6 address (without mask)'
    //     },
    //     'WAN_VLAN_ID_ILL': {
    //         pattern: '^(([1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))(,\s*[1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))*)$',
    //         required: true,
    //         errorMessage: 'Please enter VLAN in range: 0 - 4094'
    //     },
    //     'WAN_IPv4_Address_ILL': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv4 address'
    //     },
    //     'WAN_IPv4_MASK_ILL': {
    //         pattern: '^((?:[0-9])|(?:[1-2][0-9])|(?:3[0-2]))$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 32'
    //     },
    //     'WAN_IPv6_Address_ILL': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv6 address'
    //     },
    //     'WAN_IPv6_MASK_ILL': {
    //         pattern: '^([0-9]{1,2}|1[01][0-9]|12[0-8])$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 128'
    //     },
    //     'LAN_IPv4_Address_Mask_ILL': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv4 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv4'
    //     },
    //     'LAN_IPv6_Address_Mask_ILL': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv6 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv6'
    //     },
    //     'WAN_IPv4_ILL_Gateway_Address': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv4 address (without mask)'
    //     },
    //     'WAN_IPv6_ILL_Gateway_Address': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv6 address (without mask)'
    //     },
    //     'WAN_VLAN_ID_Centrex': {
    //         pattern: '^(([1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))(,\s*[1-9][0-9]{0,2}|[1-3][0-9][0-9][0-9]|40([0-8][0-9]|9[0-4]))*)$',
    //         required: true,
    //         errorMessage: 'Please enter VLAN in range: 0 - 4094'
    //     },
    //     'LAN_IPv6_Address_Pool_Centrex': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv6 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv6'
    //     },
    //     'WAN_IPv4_Address_Centrex': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv4 address'
    //     },
    //     'WAN_IPv4_MASK_Centrex': {
    //         pattern: '^((?:[0-9])|(?:[1-2][0-9])|(?:3[0-2]))$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 32'
    //     },
    //     'WAN_IPv6_Address_Centrex': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid IPv6 address'
    //     },
    //     'WAN_IPv6_MASK_Centrex': {
    //         pattern: '^([0-9]{1,2}|1[01][0-9]|12[0-8])$',
    //         required: true,
    //         errorMessage: 'Please enter mask in range: 0 - 128'
    //     },
    //     'LAN_IPv6_Address_Mask_Centrex': {
    //         pattern: '',
    //         required: true,
    //         errorMessage: 'Please enter correct value in format IPv6 Address/mask',
    //         addressvalidator: true,
    //         addressValidatorType: 'ipv6'
    //     },
    //     'WAN_IPv4_Centrex_Gateway_Address': {
    //         pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv4 address (without mask)'
    //     },
    //     'WAN_IPv6_Centrex_Gateway_Address': {
    //         pattern: '(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)',
    //         required: true,
    //         errorMessage: 'Please enter valid Gateway IPv6 address (without mask)'
    //     },
    //     'FLN': {
    //         placeholder: 'Enter Parameter Value',
    //         pattern: '',
    //         required: false
    //     }
    // }

    // ^((?:[0-9])|(?:[1-2][0-9])|(?:3[0-2]))$ pattern for 0-32 (doesnt includes 0 & 32)
    // /^([0-9]{1,2}|1[01][0-9]|12[0-8])$ pattern for 0-128 

    serviceList: ztpSevriceGroup[] = [
        {
            name: 'BNG (Single Select)',
            disabled: false,
            ztpServiceList: [
                { value: 'Bundle 1', viewValue: 'Bundle 1 (Dual Play)', index: 0 },
                { value: 'Bundle 2', viewValue: 'Bundle 2 (Triple Play)', index: 1 },
                { value: 'Bundle 3', viewValue: 'Bundle 3 (Penta Play)', index: 2 }
            ]
        },
        {
            name: 'Non-BNG (Multi Select)',
            disabled: false,
            ztpServiceList: [
                { value: 'TYPE 1', viewValue: 'L3VPN', index: 0 },
                { value: 'TYPE 2', viewValue: 'ILL', index: 1 },
                { value: 'TYPE 3', viewValue: 'IP-Centrex', index: 2 },
                { value: 'TYPE 4', viewValue: 'Business Broadband', index: 3 }
            ]
        }];

    // parameters = [
    //     {
    //         title: 'L3VPN 1',
    //         list: [
    //             {
    //                 name: 'hostName',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'Host Name',
    //                 pattern: '^([1-9][0-9]{0,2}|1000)$',
    //             },
    //             {
    //                 name: 'fln',
    //                 value: '',
    //                 required: false,
    //                 placeholder: 'FLN'
    //             },
    //             {
    //                 name: 'WAN_IPV4_ADDRESS',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'WAN IPV4 ADDRESS'
    //             },
    //             {
    //                 name: 'WAN_IPV6_ADDRESS',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'WAN_IPV6_ADDRESS'
    //             },
    //             {
    //                 name: 'WAN_IPV4_ADDRESS_MASK',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'WAN_IPV4_ADDRESS_MASK'
    //             }
    //         ]
    //     },
    //     {
    //         title: 'L3VPN 2',
    //         list: [
    //             {
    //                 name: 'WAN_IPV6_ADDRESS',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'WAN_IPV6_ADDRESS'
    //             },
    //             {
    //                 name: 'WAN_IPV4_ADDRESS_MASK',
    //                 value: '',
    //                 required: true,
    //                 placeholder: 'WAN_IPV4_ADDRESS_MASK'
    //             }
    //         ]
    //     },
    // ]
    customerName: any;

    constructor(private ztpService: ZTPService,
        private ngxService: SpinnerService,
        private router: Router,
        private route: ActivatedRoute,
        private cpeService: CPEManagmentModuleService,
        private ref: ChangeDetectorRef,
        private UIConfiguration: UIConfigurationService) { }

    ngOnInit() {
        this.ztpService.getAllCircle().subscribe(
            (response) => {
                this.circleNameList = response;
            }
        )
        this.ztpService.getAllCustomerDetails().subscribe(
            (response) => {
                this.customerList = response;
            }
        );

        this.parametersPlaceholderMapping = this.UIConfiguration.getConfiguration()['UIParamsMapping'];
    }

    changeServiceType(services = []) {
        this.targetConfigParamTemp = [];
        this.srvType = "";
        if (this.serviceType && this.serviceType.length > 1) {
            this.serviceType.forEach(element => {
                this.srvType += element.replace(/\s/g, "") + "_";
            });
            this.srvType = this.srvType.slice(0, -1);
        }
        else {
            if (this.serviceType && this.serviceType.length == 1)
                this.srvType = this.serviceType[0];
        }
        console.log(this.srvType);
        if (this.serviceType && this.serviceType.length > 0) {
            if (this.serviceType[0].includes('Bundle')) {
                this.serviceList[1].disabled = true;
                this.serviceList[0].disabled = false;
                if (this.singleServiceType !== '') {
                    //   setTimeout(()=>{
                    this.serviceType = this.serviceType.filter((element, index) => {
                        if (element !== this.singleServiceType)
                            return element;
                    });
                    this.singleServiceType = this.serviceType[0];
                } else {
                    this.singleServiceType = this.serviceType[0];
                }
                this.srvType = this.singleServiceType;

            }
            else if (this.serviceType[0].includes('TYPE')) {
                this.singleServiceType = '';
                this.serviceList[0].disabled = true;
                this.serviceList[1].disabled = false;
            }
        } else {
            this.serviceList[0].disabled = false;
            this.serviceList[1].disabled = false;
        }

        if (this.srvType && this.cirlceName) {
            this.getUDParamList();
        }
        console.log(this.serviceType, this.srvType);
    }

    getCircleName(cirlceName) {
        this.cirlceName = cirlceName;
        if (this.cirlceName && this.srvType) {
            this.getUDParamList();
        }
    }

    getUDParamList() {
        let headers = new HttpHeaders()
            .append('circleName', this.cirlceName)
            .append('serviceType', this.srvType);

        this.ztpService.getUDParamList(headers).
            subscribe(res => {
                if (res['status_code'] == 200) {
                    res = res['data'];
                    this.targetConfigParamTemp = [];
                    this.udParam = {};
                    this.targetConfigParamTemp = Object.entries(res).map((element: any) => {
                        let json = {};
                        json['title'] = element[0];
                        let array = [...element[1]];
                        json['list'] = array.map(el => {
                            return {
                                name: el,
                                value: '',
                                required: this.parametersPlaceholderMapping[el] ? this.parametersPlaceholderMapping[el].required : true,
                                placeholder: el,
                                pattern: this.parametersPlaceholderMapping[el] ? this.parametersPlaceholderMapping[el].pattern : '',
                                errorMessage: this.parametersPlaceholderMapping[el] ? this.parametersPlaceholderMapping[el].errorMessage : '',
                                addressvalidator: this.parametersPlaceholderMapping[el] ? this.parametersPlaceholderMapping[el].addressWithMaskValidator : false,
                                addressValidatorType: this.parametersPlaceholderMapping[el] ? this.parametersPlaceholderMapping[el].addressWithMaskValidatorType : false,
                            }
                        })
                        return json;
                    });
                }
            });
    }

    onCreate() {

        this.customerId = this.form.value.customerId;
        this.duid = this.form.value.duid;
        // this.targetConfigParamTemp = this.targetConfigParamTemp.filter(ele => {
        //     if (ele.name && ele.value) {
        //         delete ele.placeholder;
        //         return ele;
        //     }
        // })

        this.targetConfigParamTemp = this.targetConfigParamTemp.reduce((actual, element) => {
            let list = element.list.map(ele => {
                delete ele.required;
                delete ele.placeholder;
                delete ele.pattern;
                delete ele.errorMessage;
                delete ele.addressvalidator;
                delete ele.addressValidatorType;
                return ele;
            })
            actual.push(...list);
            return actual;
        }, []);

        let jsonBody = {
            "customerId": this.customerId,
            "circleName": this.form.value.circleName,
            "duid": this.duid,
            "serviceType": this.srvType,
            "deviceCustomName": this.form.value.deviceCustomName,
            "ztRuleDeviceType": this.form.value.ztRuleDeviceType,
        }

        this.targetConfigParamTemp.push(
            {
                "name": "HOSTNAME",
                "value": this.form.value.hostName
            }
        )

        if (this.form.value.serialNumber != null && this.form.value.serialNumber != undefined && this.form.value.serialNumber != '') {
            jsonBody['serialno'] = this.form.value.serialNumber;
        }

        //if fixedLineNumber provided then udParams key field added to jsonBody
        if (this.form.value.fixedLineNumber != null && this.form.value.fixedLineNumber != undefined && this.form.value.fixedLineNumber != '') {
            jsonBody['udParams'] = [{
                "name": "FLN",
                "value": this.form.value.fixedLineNumber
            }]
        } else {
            jsonBody['udParams'] = this.targetConfigParamTemp;
        }

        console.log('jsonBody:', jsonBody);
        // this.targetConfigParamTemp = [];

        this.ngxService.start();
        this.ztpService.createZTP(jsonBody).subscribe(
            (value) => {
                this.ngxService.stop();
                this.isSuccess = value;
                this.modalShow = true;
                this.srvType = '';
                this.cirlceName = '';
                this.form.reset();
                this.targetConfigParamTemp = [];
            }
        )
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.ngxService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }

    gotoTop() {
        const element = document.querySelector('#scrollId');
        element.scrollIntoView();
    }
}
