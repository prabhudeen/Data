import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';
import { SessionService } from '../../../../SharedFolder/services/sessionService.service';

@Component({
  selector: 'app-ztp',
  templateUrl: './ztp.component.html',
  styleUrls: ['./ztp.component.css']
})
export class ZTPComponent implements OnInit {

  list = [{
    title: "CREATE ZTP",
    access: true,
    value: "create"
  },
  {
    title: "VIEW ZTP STATUS",
    access: true,
    value: "getZtpStatus"
  },
  {
    title: "ORDER STATUS",
    access: true,
    value: "orderStatus"
  }
  ]

  constructor(private router: Router,
    private accessService: AccessService,
    private cpeService: CPEManagmentModuleService,
    private sessionService: SessionService) {

    let roleName = this.sessionService.get('roleName');

    if (roleName && (roleName.includes('admin') || roleName === 'TelcoRole')) {
      this.list[2].access = true;
    } else {
      this.list[2].access = false;
    }

  }

  ngOnInit() {
    this.list[0].access = this.accessService.getAccessForSubModule('CPE Management', 'ZTP', 'W');
    this.list[1].access = this.accessService.getAccessForSubModule('CPE Management', 'ZTP', 'R');
  }

  onClick(action) {
    switch (action) {
      case "create":
        this.router.navigateByUrl("layout/CPE_Management/ztp/create");
        break;
      case "getZtpStatus":
        this.router.navigateByUrl("layout/CPE_Management/ztp/getZtpStatus");
        break;
      case "orderStatus":
        this.router.navigateByUrl("layout/CPE_Management/ztp/orderStatus");
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.cpeService.breadcrumbNavigation(path);
  }
}
