import { Injectable } from "@angular/core";
import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { Observable } from 'rxjs';
import { EventConstants } from '../../../../SharedFolder/constants/eventConstants';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: "root"
})
export class ZTPService {

    constructor(private commonService: SdWanServiceService) { }

    createZTP(jsonBody) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('post', EventConstants.ZTPContextHandler, jsonBody, null, null, EventConstants.CREATE_ZTP).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response for createZTP in success:', response);
                        observe.next(true);
                    } else {
                        console.log('received response for createZTP in fail:', response);
                        observe.next(false);
                    }
                }
            );
        }
        );
    }

    getZTPStatus(json) {
        let headers = new HttpHeaders(json);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', EventConstants.GetZTPStatusContextHandler, null, headers, null, EventConstants.GET_ZTP_STATUS).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response in getZTPStatus success:', response);
                        observe.next({
                            status_code: 200,
                            data: response['data']
                        });
                    } else {
                        console.log('received response in getZTPStatus fail:', response);
                        observe.next({
                            status_code: 400,
                            data: []
                        });
                    }
                }
            );
        }
        );
    }

    getDUIDMapping(duid) {
        let queryString = `duid=${duid}`;
        // let headers = new HttpHeaders().append('duid', duid);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('get', EventConstants.ZTPContextHandler, null, null, queryString, EventConstants.GET_DUID_MAPPING).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response in getDuidMapping success:', response);
                        let jsonBody = {
                            circleName: response['circleName'],
                            domainServerId: response['domainServerId'],
                            duid: response['duid'],
                            mappingStatus: response['mappingStatus']
                        }
                        let array = [jsonBody]
                        observe.next({
                            status_code: 200,
                            data: array
                        });
                    } else {
                        console.log('received response in getDuidMapping fail:', response);
                        observe.next({
                            status_code: 400,
                            data: []
                        });
                    }
                }
            );
        }
        );
    }

    deleteDUIDMapping(duid) {
        let headers = new HttpHeaders().append('duid', duid);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('POST', EventConstants.ZTPContextHandler, null, headers, null, EventConstants.DELETE_DUID_MAPPING).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    getAllCircle() {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.getDomainServerCircleWise, null, null, null, EventConstants.GET_DOMAINSERVER_CIRCLEWISE).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response for getAllCircle success:', response);
                        observe.next(response['data']);
                    } else {
                        console.log('received response for getAllCircle fail:', response);
                    }
                }
            );
        });
    }

    getAllCustomerDetails() {
        return new Observable<any>(observe => {
            // let array = [
            //     {
            //         name: 'Dosapati Nikhil'
            //     },
            //     {
            //         name: 'Himaja'
            //     },
            //     {
            //         name: 'Annasamudram'
            //     },
            //     {
            //         name: 'Ghajnafar Shahid'
            //     },
            //     {
            //         name: 'Prashanth Meena'
            //     }
            // ];

            // observe.next(array);
            this.commonService.sendRequest('GET', EventConstants.CustomParametersContextHandler, null, null, null, EventConstants.GET_CUSTOMER_DETAILS_LIST).subscribe(
                (response) => {
                    if (response['status_code'] === 200) {
                        console.log('received response for getAllCustomerDetails success:', response);
                        observe.next(response['data'].map(element => {
                            return {
                                name: element
                            }
                        }));
                    } else {
                        console.log('received response for getAllCustomerDetails fail:', response);
                    }
                }
            );
        });
    }

    getAllZTPParameter(headers) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.getDomainServerCircleWise, null, headers, null, EventConstants.GET_ALL_TARGET_CONFIG_PARAMETERS).subscribe(
                (response) => {
                    console.log(response);
                    if (response['status_code'] === 200) {
                        response = response['data'].map(element => {
                            return {
                                name: element['name'],
                                value: '',
                                isSet: true
                            }
                        });
                        observe.next(response);
                    } else {
                        console.log('received response for getAllCircle fail:', response);
                        observe.next([]);
                    }
                }
            );
        });
    }

    getUDParamList(headers) {
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.GET_ALL_TARGET_CONFIG_PARAMETERS).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    downloadFile(duid) {
        let headers = new HttpHeaders().append('duid', duid);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.ZTP_DOWNLOAD_FILE).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        }
        );
    }

    downloadFileTable(jsonBody) {
        let headers = new HttpHeaders(jsonBody);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.CustomParametersContextHandler, null, headers, null, EventConstants.ZTP_DOWNLOAD_FILE_TABLE).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }

    getDeviceDetails(headers) {
        headers = new HttpHeaders(headers);
        return new Observable<any>(observe => {
            this.commonService.sendRequest('GET', EventConstants.GetZTPStatusContextHandler, null, headers, null, EventConstants.GET_ZTP_ORDER_STATUS).subscribe(
                (response) => {
                    observe.next(response);
                }
            );
        });
    }
}