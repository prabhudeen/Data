import { Component, OnInit, ViewChild } from '@angular/core';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
import { ZTPService } from '../ztp.service';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';

@Component({
    selector: 'app-order-status',
    templateUrl: './orderStatus.component.html',
    styleUrls: ['./orderStatus.component.css']
})
export class OrderStatusComponent implements OnInit {

    circleList = [];
    isDetails = false;
    deviceDetails = {}
    mappingJSON = {
        1: 'In Progress',
        2: 'Config Ready',
        3: 'Managed',
        4: 'Failed'
    }
    ossRequest = {
        data: {},
        valid: false
    }
    step1Request = {
        data: {},
        valid: false
    }
    step1Response = {
        data: {},
        valid: false
    }
    step2Request = {
        data: {},
        valid: false
    }
    step2Response = {
        data: {},
        valid: false
    }
    stackTrace = {
        data: {},
        valid: false
    }
    internalProcessingError = {
        data: {},
        valid: false
    }
    deProvisioningResponse = {
        data: {},
        valid: false
    }
    showTab = false;

    @ViewChild('form') form: NgForm;

    constructor(private cpeService: CPEManagmentModuleService,
        private ztpService: ZTPService,
        private router: Router,
        private route: ActivatedRoute,
        private sessionService: SessionService) { }

    ngOnInit(): void {

        let roleName = this.sessionService.get('roleName');

        //URL through if the user tries to navigate orderStatus, so check whether the user has admin role or is admin.
        if (roleName && (roleName.includes('admin') || roleName === 'TelcoRole')) {
            this.getCircleList();
        } else {
            this.onCancel();
        }
    }


    getCircleList() {
        this.ztpService.getAllCircle().subscribe(
            (response) => {
                this.circleList = response;
            }
        )
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    onGet() {
        let circle = this.form.value.circleName;
        let duid = this.form.value.duid;
        this.ztpService.getDeviceDetails({
            CircleName: circle,
            Duid: duid
        }).subscribe((response) => {
            console.log('response in getDeviceDetails:', response);
            if (response['status_code'] == 200) {
                this.isDetails = true;
                this.deviceDetails = response['data'];
                this.deviceDetails['ztpStatus'] = this.mappingJSON[this.deviceDetails['ztpStatus']];
                if (response['data']['isSuccess']) {
                    this.showTab = false;
                    this.deviceDetails['orderStatus'] = 'Success';
                } else {
                    this.showTab = true;
                    this.deviceDetails['orderStatus'] = 'Failed';
                    this.assigning(this.deviceDetails);
                }
            }
        })
    }

    assigning(data) {


        if (data['ossRequest']) {
            this.ossRequest['data'] = JSON.stringify(data['ossRequest'], null, 4);
            this.ossRequest['valid'] = false
            console.log('this.ossRequest:', this.ossRequest);
        } else {
            this.ossRequest['valid'] = true;
        }

        if (data['step1Request']) {
            this.step1Request['data'] = JSON.stringify(data['step1Request'], null, 4);
            this.step1Request['valid'] = false
        } else {
            this.step1Request['valid'] = true;
        }

        if (data['step1Response']) {
            this.step1Response['data'] = JSON.stringify(data['step1Response'], null, 4);
            this.step1Response['valid'] = false
            console.log('this.step1Response:', this.step1Response);
        } else {
            this.step1Response['valid'] = true;
        }

        if (data['step2Request']) {
            this.step2Request['data'] = JSON.stringify(data['step2Request'], null, 4);
            this.step2Request['valid'] = false
        } else {
            this.step2Request['valid'] = true;
        }

        if (data['step2Response']) {
            this.step2Response['data'] = JSON.stringify(data['step2Response'], null, 4);
            this.step2Response['valid'] = false
            console.log('this.step1Response:', this.step2Response);
        } else {
            this.step2Response['valid'] = true;
        }


        if (data['stackTrace']) {
            this.stackTrace['data'] = data['stackTrace'];
            this.stackTrace['valid'] = false
        } else {
            this.stackTrace['valid'] = true;
        }

        if (data['internalProcessingError']) {
            this.internalProcessingError['data'] = data['internalProcessingError'];
            this.internalProcessingError['valid'] = false
        } else {
            this.internalProcessingError['valid'] = true;
        }

        if (data['deprovisionResponse']) {
            this.deProvisioningResponse['data'] = JSON.stringify(data['deprovisionResponse'], null, 4);
            this.deProvisioningResponse['valid'] = false
            console.log('this.deProvisioningResponse:', this.deProvisioningResponse);
        } else {
            this.deProvisioningResponse['valid'] = true;
        }
    }

    onBack() {
        this.isDetails = false;
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
