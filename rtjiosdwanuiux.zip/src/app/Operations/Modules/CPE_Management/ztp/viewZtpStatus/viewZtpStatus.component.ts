import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { ZTPService } from '../ztp.service';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
import { SessionService } from '../../../../../SharedFolder/services/sessionService.service';


export interface ztpSevrice {
    value: string;
    viewValue: string;
    index: number;
}

export interface ztpSevriceGroup {
    disabled?: boolean;
    name: string;
    ztpServiceList: ztpSevrice[];
}
@Component({
    selector: 'viewZtpStatus-component',
    templateUrl: './viewZtpStatus.component.html',
    styleUrls: ['./viewZtpStatus.component.css']
})
export class ZTPViewZtpStatus implements OnInit, OnDestroy {

    @ViewChild('paginator') paginator: MatPaginator;
    @ViewChild('form') form: NgForm;
    showTable: boolean = false;
    isSuccess: boolean = false;
    index: number;
    duidMappingItems: any[] = [];
    duidMappingTempItems: any[] = [];
    ztRuleStatusList = ['1', '2', '3', '4'];
    pageSize = 5;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    length: number = 0;
    offSet: number = 0;
    deleteDuid: string;
    isDeletable: boolean = false;
    valid: boolean = false;
    matTooltipPosition: TooltipPosition = "above";
    MappingStatustooltipDescription: string = `1 - In Progress - ZTP initiated for the device. Config file generation is in progress.
    2 - Config Ready - ZTP config file generation successful and is available for download.
    3 - Managed - Config file uploaded on the device successfully and device has been enrolled on RADView.
    4 - Failed - ZTP config file generation failed.`;
    afterDeleteModalShow: boolean = false;
    deleteModalShow: boolean = false;
    from: any = '';
    to: any = '';
    todayDate = new Date();
    // maxFrom = new Date(new Date().getTime() - 15778800000);
    maxFrom = new Date(new Date().getTime() + 1800000);
    minFrom = new Date(new Date().getTime() - 15552000000);
    maxTo = new Date(new Date().getTime() + 1800000);
    minTo = new Date(new Date().getTime() - 15552000000);
    customerList = [];
    circleNameList = [];
    role;
    tooltipDescriptionforStatus = [
        'ZTP initiated for the device. Config file generation is in progress.',
        'ZTP config file generation successful and is available for download.',
        'Config file uploaded on the device successfully and device has been enrolled on RADView.',
        'ZTP config file generation failed.'
    ]
    serviceList: ztpSevriceGroup[] = [
        {
            name: 'BNG (Single Select)',
            disabled: false,
            ztpServiceList: [
                { value: 'Bundle 1', viewValue: 'Bundle 1 (Dual Play)', index: 0 },
                { value: 'Bundle 2', viewValue: 'Bundle 2 (Triple Play)', index: 1 },
                { value: 'Bundle 3', viewValue: 'Bundle 3 (Penta Play)', index: 2 }
            ]
        },
        {
            name: 'Non-BNG (Multi Select)',
            disabled: false,
            ztpServiceList: [
                { value: 'TYPE 1', viewValue: 'L3VPN', index: 0 },
                { value: 'TYPE 2', viewValue: 'ILL', index: 1 },
                { value: 'TYPE 3', viewValue: 'IP-Centrex', index: 2 },
                { value: 'TYPE 4', viewValue: 'Business Broadband', index: 3 }
            ]
        }];
    serviceType: string[] = [];
    srvType: string = '';
    singleServiceType: string = '';
    isMultiple: boolean = true;
    customerName: any;
    serviceTypeListMapping = {
        'TYPE 1': 'L3VPN',
        'TYPE 2': 'ILL',
        'TYPE 3': 'IP-Centrex',
        'TYPE 4': 'Business Broadband',
        'TYPE1_TYPE2': 'L3VPN_ILL',
        'TYPE1_TYPE3': 'L3VPN_IP-Centrex',
        'TYPE1_TYPE4': 'L3VPN_Business Broadband',
        'TYPE2_TYPE3': 'ILL_IP-Centrex',
        'TYPE2_TYPE4': 'ILL_Business Broadband',
        'TYPE3_TYPE4': 'IP-Centrex_Business Broadband',
        'TYPE1_TYPE2_TYPE3': 'L3VPN_ILL_IP-Centrex',
        'TYPE1_TYPE2_TYPE4': 'L3VPN_ILL_Business Broadband',
        'TYPE1_TYPE3_TYPE4': 'L3VPN_IP-Centrex_Business Broadband',
        'TYPE2_TYPE3_TYPE4': 'ILL_IP-Centrex_Business Broadband',
        'TYPE1_TYPE2_TYPE3_TYPE4': 'L3VPN_ILL_IP-Centrex_Business Broadband',
    }

    constructor(private ztpService: ZTPService,
        private router: Router,
        private route: ActivatedRoute,
        private ngxService: SpinnerService,
        private accessService: AccessService,
        private cpeService: CPEManagmentModuleService,
        private sessionService: SessionService) {
        let roleName = this.sessionService.get('roleName');
        if (roleName && (roleName.includes('admin') || roleName === 'TelcoRole')) {
            this.role = 'admin';
        } else {
            this.role = 'user';
        }
    }

    ngOnInit() {
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'ZTP', 'D');
        this.ztpService.getAllCircle().subscribe(
            (response) => {
                this.circleNameList = response;
            }
        )
        this.ztpService.getAllCustomerDetails().subscribe(
            (response) => {
                this.customerList = response;
            }
        )
    }

    fromDateChanged() {
        if (Date.parse(this.from) + 15778800000 > new Date().getTime()) {
            this.maxTo = new Date();
        } else {
            this.maxTo = new Date(Date.parse(this.from) + 15778800000);
        }
        this.minTo = new Date(Date.parse(this.from));
        this.maxFrom = new Date();
    }

    toDateChanged() {
        this.minFrom = new Date(Date.parse(this.to) - 15778800000);
        this.maxFrom = new Date(Date.parse(this.to));
        this.maxTo = new Date()
    }

    onGet() {
        this.duidMappingTempItems = [];
        this.duidMappingItems = [];
        this.showTable = false;

        let json = {};

        if (this.form.value.customerName) {
            json['CustomerId'] = this.form.value.customerName
        }
        if (Date.parse(this.from).toString() !== 'NaN') {
            json['Old-Timestamp'] = Date.parse(this.from).toString()
        }
        if (Date.parse(this.to).toString() !== 'NaN') {
            json['Latest-Timestamp'] = Date.parse(this.to).toString()
        }
        if (this.form.value.duid) {
            json['Duid'] = this.form.value.duid
        }
        if (this.form.value.circleName || this.form.value.circleName !== '') {
            json['CircleName'] = this.form.value.circleName
        }
        if (this.form.value.hostName) {
            json['HostName'] = this.form.value.hostName
        }
        if (this.form.value.ztRuleStatus || this.form.value.ztRuleStatus !== '') {
            json['ZtRuleStatus'] = this.form.value.ztRuleStatus
        }
        if (this.srvType || this.srvType !== '') {
            json['ServiceName'] = this.srvType;
        }

        json['UserRole'] = this.role;

        this.ngxService.start();
        this.ztpService.getZTPStatus(json).subscribe(
            (response) => {
                this.ngxService.stop();
                if (response['status_code'] === 200) {
                    this.duidMappingItems = response['data'];
                    this.duidMappingItems = this.duidMappingItems.map(element => {
                        element['serviceNameView'] = this.serviceTypeListMapping[element['serviceName']] ? this.serviceTypeListMapping[element['serviceName']] : element['serviceName'];
                        return element;
                    })
                    this.length = this.duidMappingItems.length;
                    this.duidMappingTempItems = this.duidMappingItems.slice(0, this.pageSize);
                    this.showTable = true;
                } else {
                    this.length = 0;
                    this.showTable = true;
                }
            }
        )
    }

    onDeleteIconClick(ind) {
        this.index = this.offSet + ind;
        this.deleteDuid = this.duidMappingItems[this.index].duid;
        this.deleteModalShow = true;
    }

    onDownload(duidValue) {
        let duid = duidValue;
        this.ngxService.start();
        this.ztpService.downloadFile(duid).subscribe(response => {
            this.ngxService.stop();
            if (response['status_code'] === 200) {
                var linkElement = document.createElement('a');
                var byteArray = new Uint8Array(response.fileData);
                linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                linkElement.download = response['fileName'];
                document.body.appendChild(linkElement);
                linkElement.click();
                document.body.removeChild(linkElement);
            }
        })
    }

    validation() {
        this.valid = false;

        if (this.form.value.customerName) {
            this.valid = true;
        }

        if (this.form.value.duid) {
            this.valid = true;
        }

        if (this.form.value.circleName || this.form.value.circleName !== '') {
            this.valid = true;
        }

        if (this.form.value.hostName) {
            this.valid = true;
        }

        if (this.form.value.ztRuleStatus || this.form.value.ztRuleStatus !== '') {
            this.valid = true;
        }

        if (this.srvType || this.srvType !== '') {
            this.valid = true;
        }

        if (Date.parse(this.from).toString() !== 'NaN' && Date.parse(this.to).toString() !== 'NaN') {
            this.valid = true;
        }

        if (Date.parse(this.from).toString() !== 'NaN' && Date.parse(this.to).toString() === 'NaN') {
            this.valid = false;
        }

        if (Date.parse(this.from).toString() === 'NaN' && Date.parse(this.to).toString() !== 'NaN') {
            this.valid = false;
        }

        this.showTable = false;
    }

    onmainDownload() {
        let json = {};

        if (this.form.value.customerName) {
            json['CustomerId'] = this.form.value.customerName
        }
        if (Date.parse(this.from).toString() !== 'NaN') {
            json['Old-Timestamp'] = Date.parse(this.from).toString()
        }
        if (Date.parse(this.to).toString() !== 'NaN') {
            json['Latest-Timestamp'] = Date.parse(this.to).toString()
        }
        if (this.form.value.duid) {
            json['Duid'] = this.form.value.duid
        }
        if (this.form.value.circleName || this.form.value.circleName !== '') {
            json['CircleName'] = this.form.value.circleName
        }
        if (this.form.value.hostName) {
            json['HostName'] = this.form.value.hostName
        }
        if (this.form.value.ztRuleStatus || this.form.value.ztRuleStatus !== '') {
            json['ZtRuleStatus'] = this.form.value.ztRuleStatus
        }
        if (this.srvType || this.srvType !== '') {
            json['ServiceName'] = this.srvType;
        }

        this.ngxService.start();
        this.ztpService.downloadFileTable(json).subscribe(response => {
            this.ngxService.stop();
            if (response['status_code'] === 200) {
                var linkElement = document.createElement('a');
                var byteArray = new Uint8Array(response.fileData);
                linkElement.href = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                linkElement.download = response['fileName'];
                document.body.appendChild(linkElement);
                linkElement.click();
                document.body.removeChild(linkElement);
            }
        })
    }

    onDelete() {
        let duid = this.duidMappingItems[this.index].duid;
        this.ngxService.start();
        this.ztpService.deleteDUIDMapping(duid).subscribe(
            (res) => {
                this.ngxService.stop();
                if (res.status_code == 200) {
                    this.isSuccess = true;
                    this.afterDeleteModalShow = true;
                    this.duidMappingItems.splice(this.index, 1);
                    this.length = this.duidMappingItems.length;
                    this.duidMappingTempItems = this.duidMappingItems.slice(0, this.pageSize);
                    this.paginator.firstPage();
                } else {
                    this.isSuccess = false;
                    this.afterDeleteModalShow = true;
                }
            }
        );
    }

    onPageChanged(e) {
        this.offSet = e.pageIndex * e.pageSize;
        this.pageSize = e.pageSize;
        let firstCut = e.pageIndex * e.pageSize;
        let secondCut = firstCut + e.pageSize;
        this.duidMappingTempItems = this.duidMappingItems.slice(firstCut, secondCut);
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.ngxService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }

    changeServiceType(services = []) {
        this.srvType = "";
        if (this.serviceType && this.serviceType.length > 1) {
            this.serviceType.forEach(element => {
                this.srvType += element.replace(/\s/g, "") + "_";
            });
            this.srvType = this.srvType.slice(0, -1);
        }
        else {
            if (this.serviceType && this.serviceType.length == 1)
                this.srvType = this.serviceType[0];
        }
        if (this.serviceType && this.serviceType.length > 0) {
            if (this.serviceType[0].includes('Bundle')) {
                this.serviceList[1].disabled = true;
                this.serviceList[0].disabled = false;
                if (this.singleServiceType !== '') {
                    this.serviceType = this.serviceType.filter((element, index) => {
                        if (element !== this.singleServiceType)
                            return element;
                    });
                    this.singleServiceType = this.serviceType[0];
                } else {
                    this.singleServiceType = this.serviceType[0];
                }
                this.srvType = this.singleServiceType;
            }
            else if (this.serviceType[0].includes('TYPE')) {
                this.singleServiceType = '';
                this.serviceList[0].disabled = true;
                this.serviceList[1].disabled = false;
            }
        } else {
            this.serviceList[0].disabled = false;
            this.serviceList[1].disabled = false;
        }
        console.log(this.serviceType, this.srvType);
    }
}

