import { SdWanServiceService } from '../../../../SharedFolder/services/sd-wan-service.service';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class CircleService {
    constructor(private sdwanService: SdWanServiceService) {

    }
    createCircle(headers: HttpHeaders): Observable<any> {
        return new Observable((observe) => {
            this.sdwanService.sendRequest("POST", "/PEAG/RAD/GUIHandler", null, headers, null, 'createCircle').subscribe(
                (response) => {
                    console.log(response);

                    if (response['status_code'] == 200) {
                        observe.next(true);
                    }
                    else {
                        observe.next(false);
                    }

                },
                (error) => {
                    observe.next(false);
                }
            );
        })

    }
    getAllCircle(): Observable<any> {
        return new Observable((observe) => {
            this.sdwanService.sendRequest("GET", "/PEAG/RAD/GUIHandler", null, null, null, 'getAllCircles').subscribe(
                (response) => {
                    console.log("getAllCircle",response);
                    observe.next(response);  
                },
            )
        })
    }
    deleteCircle(headers: HttpHeaders): Observable<any> {
        return new Observable((observe) => {
            this.sdwanService.sendRequest("DELETE", "/PEAG/RAD/GUIHandler", null, headers, null, 'deleteCircle').subscribe(
                (response) => {
                    observe.next(response);
                },
                (error) => {
                    observe.next(error);
                }
            )
        })
    }
}