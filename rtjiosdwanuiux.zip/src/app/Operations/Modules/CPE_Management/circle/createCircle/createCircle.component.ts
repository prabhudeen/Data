import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { CircleService } from '../circle.service';
import { NgForm } from '@angular/forms';
import { TooltipPosition } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
declare var $: any;

@Component({
    selector: 'app-circle-create',
    templateUrl: './createCircle.component.html',
    styleUrls: ['./createCircle.component.css']
})
export class CircleCreateComponent implements OnInit, OnDestroy {

    
    tooltipPosition: TooltipPosition = "above";
    isSuccess: boolean;
    @ViewChild('form') form: NgForm;
    circleName: string;
    circlesData;
    circleNameError = false;
    constructor(private circleService: CircleService,
        private router: Router,
        private route: ActivatedRoute,
        private spinnerService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit() { }
    createCircle(): void {
        this.circleName = this.form.value['circleName'];
        let headers = new HttpHeaders()
            .append("circleName", this.form.value['circleName']);
        this.spinnerService.start();
        this.circleService.createCircle(headers).subscribe(
            (value) => {
                this.spinnerService.stop();
                this.form.reset();
                console.log("Response Recieved");
                this.isSuccess = value;
                $("#createModal").modal('show');

            },
            (error) => {
                console.log("Error ocuured");
                this.spinnerService.stop();
            }
        );
    }

    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
    keyDownHandler(event) {
        if (event.which === 32) {
            this.circleNameError = true;
            event.preventDefault();
        }
        else {
            this.circleNameError = false;
        }

    }

}
