import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { CircleService } from '../circle.service';
import { HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { TooltipPosition, MatPaginator } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessService } from '../../../../../SharedFolder/services/access.service';
import { SpinnerService } from '../../../../../SharedFolder/services/SpinnerService.service';
import { CPEManagmentModuleService } from '../../cpeManagementModule_API.service';
declare var $: any;

@Component({
    selector: 'app-circle-getAll',
    templateUrl: './getAllCircle.component.html',
    styleUrls: ['./getAllCircle.component.css']
})
export class CircleGetAllComponent implements OnInit, OnDestroy {

    zoneNames = ["North", "South", "East", "West"];
    tooltipPosition: TooltipPosition = 'above';
    @ViewChild('form') form: NgForm;
    table = false;
    circleByName;
    circleList;
    index: any;
    deleteItem = {};
    isSuccess: boolean;
    circleName: any;
    isDeletable: boolean = false;
    // pagination variable
    length: number;
    pageSize: number;
    pageIndex: number = 0;
    pageSizeOptions: number[] = [5, 10, 25, 100];
    @ViewChild('paginator') paginator: MatPaginator;
    afterDeleteModalShow: boolean = false;
    deleteModalShow: boolean = false;

    constructor(private circleService: CircleService,
        private router: Router,
        private route: ActivatedRoute,
        private accessService: AccessService,
        private spinnerService: SpinnerService,
        private cpeService: CPEManagmentModuleService) { }

    ngOnInit() {
        this.pageSize = 5;
        this.isDeletable = this.accessService.getAccessForSubModule('CPE Management', 'Circle', 'D')
        this.getAllCircles();
    }
    onPageChanged(e) {
        console.log(this.paginator.pageIndex);
        console.log(e.pageSize);
        this.pageSize = e.pageSize;
        let from = e.pageSize * e.pageIndex;
        let to = from + e.pageSize;
        // console.log(from, to);
        this.circleList = this.circleByName.slice(from, to);
        console.log("hello ");
    }
    getAllCircles(): void {
        this.spinnerService.start();
        this.circleService.getAllCircle().subscribe(
            (data) => {
                if (data['status_code'] == 200) {
                    this.spinnerService.stop();
                    this.circleByName = data['data'];
                    console.log("Response Recieved");
                    this.table = true;
                    this.length = this.circleByName.length;
                    this.circleList = this.circleByName.slice(0, this.pageSize);
                } else {
                    this.spinnerService.stop();
                }
            }
        );
    }
    deleteCircle(item) {
        this.deleteItem = item;
        this.index = this.circleByName.findIndex((record) => { return record.id == item.id });
        this.deleteModalShow = true;
        console.log(this.index);
        this.circleName = item['name'];
    }
    onDelete() {
        let headers = new HttpHeaders()
            .append("circleName", this.deleteItem['name']);
        this.spinnerService.start();
        this.circleService.deleteCircle(headers).subscribe(
            (response) => {
                this.spinnerService.stop();
                this.afterDeleteModalShow = true;
                if (response['status_code'] == 200) {
                    this.isSuccess = true;
                    $('#afterdeleteModal').modal('show');
                    this.circleByName.splice(this.index, 1);
                    this.circleList = this.circleByName;
                    this.length = this.circleByName.length;
                    // this.paginator.pageIndex=0;
                    // this.circleList = this.circleByName.slice(0, this.pageSize);
                    this.circleList = this.circleList.slice(this.paginator.pageIndex * this.pageSize, this.paginator.pageIndex * this.pageSize + this.pageSize);
                    if (this.length > 0 && this.circleList.length == 0) {
                        this.paginator.pageIndex = this.paginator.pageIndex - 1;
                        this.circleList = this.circleByName.slice((this.paginator.pageIndex) * this.pageSize, (this.paginator.pageIndex) * this.pageSize + this.pageSize);
                    }
                } else {
                    this.isSuccess = false;
                    $('#afterdeleteModal').modal('show');
                }

                console.log("Response Recieved", response);
            },
            (error) => {
                this.spinnerService.stop();
                console.log("Error occured");
            }
        )
    }
    onCancel() {
        this.router.navigate(['../'], { relativeTo: this.route });
    }

    ngOnDestroy() {
        this.spinnerService.stop();
    }

    breadcrumbNavigation(path: string) {
        this.cpeService.breadcrumbNavigation(path);
    }
}
