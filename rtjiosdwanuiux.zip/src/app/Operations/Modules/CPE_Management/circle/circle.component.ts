import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../../../SharedFolder/services/access.service';
import { CPEManagmentModuleService } from '../cpeManagementModule_API.service';

@Component({
  selector: 'app-circle',
  templateUrl: './circle.component.html',
  styleUrls: ['./circle.component.css']
})
export class CircleComponent implements OnInit {

  list = [{
    title: "CREATE",
    access: true,
    value: "create"
  },
  {
    title: "VIEW ALL",
    access: true,
    value: "getAll"
  }
  ]

  constructor(private router: Router,
    private accessSerivce: AccessService,
    private cpeService: CPEManagmentModuleService) { }

  ngOnInit() {
    //For create ,we need write access
    this.list[0].access = this.accessSerivce.getAccessForSubModule('CPE Management', 'Circle', 'W');

    //For view, we need get access
    this.list[1].access = this.accessSerivce.getAccessForSubModule('CPE Management', 'Circle', 'R');
  }

  onClick(action) {
    switch (action) {
      case "create":
        this.router.navigateByUrl("layout/CPE_Management/circle/create");
        break;
      case "getAll":
        this.router.navigateByUrl("layout/CPE_Management/circle/getAll");
        break;
    }
  }

  breadcrumbNavigation(path: string) {
    this.cpeService.breadcrumbNavigation(path);
  }
}
