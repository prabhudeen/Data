import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessService } from '../../SharedFolder/services/access.service';
import { SessionService } from '../../SharedFolder/services/sessionService.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  list: any[] = [
    {
      iconLink: "assets/img/opticalTransportIcon.svg",
      title: "Optical Transport",
      value: "Optical Transport",
      access: true
    },
    {
      iconLink: "assets/img/underlayServiceIcon.svg",
      title: "Underlay Service",
      value: "Underlay Management",
      access: true
    },
    {
      iconLink: "assets/img/cpeManagementIcon.svg",
      title: "vCPE Management",
      value: "CPE Management",
      access: true
    },
    {
      iconLink: "assets/img/user_Management.svg",
      title: "User Management",
      value: "User Management",
      access: true
    }
  ]

  constructor(private router: Router, private accessService: AccessService, private sessionService: SessionService) { }

  ngOnInit() {
    this.list = this.accessService.getListWithModuleRestrictionAccess(this.list, 'ModuleLevel');
    let roleName = this.sessionService.get('roleName');
    if (roleName && roleName === 'TelcoRole') {
      this.list[3].access = true;
    }
  }

  onClick(action) {
    switch (action) {
      case "Optical Transport":
        this.router.navigateByUrl("layout/opticalTransport");
        break;
      case "Underlay Management":
        this.router.navigateByUrl("layout/underlayService");
        break;
      case "CPE Management":
        this.router.navigateByUrl("layout/CPE_Management");
        break;
      case "User Management":
        this.router.navigateByUrl("layout/userManagement");
        break;
    }
  }

}
