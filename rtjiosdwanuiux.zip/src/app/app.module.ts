import { LayoutModule } from '@angular/cdk/layout';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PreloadAllModules, RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { IamModule } from 'iam';
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routing';
import { SessionService } from './SharedFolder/services/sessionService.service';
import { NavigationComponent } from './Operations/Navigation/navigation.component';
import { DashboardComponent } from './Operations/Dashboard/dashboard.component';
import { AuthenticationModule } from './Operations/Authentication/authentication.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NotificationComponent } from './SharedFolder/notification/notification.component';
import { UIConfigurationService } from './SharedFolder/services/UIConfig.service';
import { SharedModule } from './SharedFolder/modules/shared.module';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

@NgModule({
  declarations: [
    NavigationComponent,
    AppComponent,
    DashboardComponent,
    DashboardComponent,
    NotificationComponent
  ],
  imports: [
    BrowserModule,
    SharedModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(AppRoutes, {
      useHash: true,
      enableTracing: false,
      preloadingStrategy: PreloadAllModules
    }),
    HttpModule,
    HttpClientModule,
    NgbModule,
    LayoutModule,
    IamModule,
    AuthenticationModule,
    NgxSpinnerModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: false }),
  ],
  providers: [
    SessionService,
    { provide: APP_INITIALIZER, useFactory: (configService: UIConfigurationService) => () => { return configService.load() }, deps: [UIConfigurationService], multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
